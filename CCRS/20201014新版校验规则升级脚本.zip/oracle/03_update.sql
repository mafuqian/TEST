alter table GFDR_PM_CLDWDK modify DKYT VARCHAR2(3000);
alter table GFDR_PM_DWDKFS modify DKYT VARCHAR2(3000);
alter table GFDR_PM_FTYKHX modify JYFW VARCHAR2(3000);

alter table GFDR_ITF_CLDWDK modify DKYT VARCHAR2(3000);
alter table GFDR_ITF_DWDKFS modify DKYT VARCHAR2(3000);
alter table GFDR_ITF_FTYKHX modify JYFW VARCHAR2(3000);

update GP_QC_RULE set EXISTS_SQL = replace(EXISTS_SQL, '#{__month}', '') where EXISTS_SQL is not null;