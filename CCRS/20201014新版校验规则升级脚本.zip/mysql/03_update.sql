alter table gfdr_pm_cldwdk modify DKYT varchar(3000) null comment '贷款用途';
alter table gfdr_pm_dwdkfs modify DKYT varchar(3000) null comment '贷款用途';
alter table gfdr_pm_ftykhx modify JYFW varchar(3000) null comment '经营范围';

alter table gfdr_itf_cldwdk modify DKYT varchar(3000) null comment '贷款用途';
alter table gfdr_itf_dwdkfs modify DKYT varchar(3000) null comment '贷款用途';
alter table gfdr_itf_ftykhx modify JYFW varchar(3000) null comment '经营范围';


update GP_QC_RULE set EXISTS_SQL = replace(EXISTS_SQL, '#{__month}', '') where EXISTS_SQL is not null;