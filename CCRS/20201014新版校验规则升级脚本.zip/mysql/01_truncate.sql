truncate table GP_BM_DATA_DIC;
truncate table GP_QC_RULE;
truncate table GP_QC_RULE_MAP;
