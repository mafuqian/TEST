truncate table GP_BM_DATA_DIC
go
truncate table GP_QC_RULE
go
truncate table GP_QC_RULE_MAP
go
