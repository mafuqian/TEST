alter table GFDR_PM_CLDWDK modify DKYT VARCHAR(3000)
go
alter table GFDR_PM_DWDKFS modify DKYT VARCHAR(3000)
go
alter table GFDR_PM_FTYKHX modify JYFW VARCHAR(3000)
go

alter table GFDR_ITF_CLDWDK modify DKYT VARCHAR(3000)
go
alter table GFDR_ITF_DWDKFS modify DKYT VARCHAR(3000)
go
alter table GFDR_ITF_FTYKHX modify JYFW VARCHAR(3000)
go