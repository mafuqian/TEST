package com.gingkoo.crms;

public class CrmsProcess {
    public static void main(String[] args) {
        System.out.println("Hello world");
    }
}
