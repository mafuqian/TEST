var isDigit = "\d+";
