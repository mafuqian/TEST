# **TaskM设计手册**

TaskM目前采用xml文件来进行设计。

## **节点及节点属性描述**

### **`规范说明：`**

> * id节点值要保证在整个xml中唯一

### **job**
xml中只允许出现一个job节点，为xml的根节点
> **job节点必须包含以下namespace**

```xml
<?xml version="1.0" encoding="utf-8"?>
<job xmlns="https://www.gingkoo.com/schema/taskm" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
​     xsi:schemaLocation="https://www.gingkoo.com/schema/taskm https://www.gingkoo.com/schema/taskm/design.xsd"> 
​     ......
</job>
```

> **子节点属性**

<style>
table th:nth-of-type(1) {
	width: 10%;
}
table th:nth-of-type(2) {
	width: 10%;
}
table th:nth-of-type(3) {
	width: 10%;
}
table th:nth-of-type(5) {
	width: 7%;
}
table th:nth-of-type(6) {
	width: 10%;
}
</style>
| tag | 名称 | 必输 | 类型 | 长度 | 样例值 | 描述 |
| --- | --- | :-: | :-: | :-: | --- | --- |
| version | 版本号 | 1 | [string] | 16 | 1.0.01 | 当前设计的版本号，用于区分不同设计版本，需自行修改区分，一般发布前要修改下，`系统不会判断唯一性`|
| id | 作业id | 1 | [ID] | 32 | taskMJob | 作业ID，**`其值整个xml文件中唯一`**，**`修改时此节点值不允许修改`** |
| name | 作业名 | 1 | [string] | 64 | TaskM测试Job | 作业名称，作业的中文名称，用于显示 |
| desc | 描述 | 0-1 | [string] | 512 | 作业描述 | 作业的描述信息，可用于简要介绍此作业的用途 |
| <a name="job_param"> paras </a> | 参数列表 | 0-1 | tag | -- | -- | 参考 <a href="#paras"> paras </a> |
| listeners | 监听器列表 | 0-1 | tag | -- | -- | 参考 <a href="#listeners"> listeners </a> |
| flow | 流程节点列表 | 1 | tag | -- | -- | 参考 <a href="#flow"> flow </a> |

> *注意*：job的子节点必须按照以上顺序出现


### **<a name="flow"> flow </a>**
flow节点用于定义作业中步骤执行的流程

> **子节点属性**

| tag | 名称 | 必输 | 类型 | 长度 | 样例值 | 描述 |
| --- | --- | :-: | :-: | :-: | --- | --- |
| parallel | 并行节点 | 0-n | tag | -- | -- | 参考 <a href="#parallel"> parallel </a> |
| spel | spel作业类型节点| 0-n | tag | -- | -- | 参考 <a href="#spel"> spel </a> |
| shell | shell作业类型节点| 0-n | tag | -- | -- | 参考 <a href="#shell"> shell </a> |
| springBean | springBean作业类型节点| 0-n | tag | -- | -- | 参考 <a href="#springBean"> springBean </a> |
| dbproc | dbproc作业类型节点| 0-n | tag | -- | -- | 参考 <a href="#dbproc"> dbproc </a> |
| remote | remote作业类型节点| 0-n | tag | -- | -- | 参考 <a href="#remote"> remote </a> |
| noop | noop作业类型节点| 0-n | tag | -- | -- | 参考 <a href="#noop"> noop </a> |

> *注意*：flow的子节点可以无序出现, 必须包含一个子节点


### **<a name="parallel"> parallel </a>**

并行节点，此节点下的串行节点和串行节点之间并行执行

| tag | 名称 | 必输 | 类型 | 长度 | 样例值 | 描述 |
| --- | --- | :-: | :-: | :-: | --- | --- |
| id | 节点id | 1 | [ID] | 32 | parallelNode | 并行节点的ID, **`其值整个xml文件中唯一`** |
| serial | 串行节点 | 1-n | tag | -- | -- | 参考 <a href="#noop"> serial </a> |


### **<a name="serial"> serial </a>**

串行节点，此节点下的作业步骤串行执行

| tag | 名称 | 必输 | 类型 | 长度 | 样例值 | 描述 |
| --- | --- | :-: | :-: | :-: | --- | --- |
| id | 节点id | 1 | [ID] | 32 | parallelNode | 串行节点的ID, **`其值整个xml文件中唯一`** |
| parallel | 并行节点 | 0-n | tag | -- | -- | 参考 <a href="#parallel"> parallel </a> |
| spel | spel作业类型节点| 0-n | tag | -- | -- | 参考 <a href="#spel"> spel </a> |
| shell | shell作业类型节点| 0-n | tag | -- | -- | 参考 <a href="#shell"> shell </a> |
| springBean | springBean作业类型节点| 0-n | tag | -- | -- | 参考 <a href="#springBean"> springBean </a> |
| dbproc | dbproc作业类型节点| 0-n | tag | -- | -- | 参考 <a href="#dbproc"> dbproc </a> |
| remote | remote作业类型节点| 0-n | tag | -- | -- | 参考 <a href="#remote"> remote </a> |
| noop | noop作业类型节点| 0-n | tag | -- | -- | 参考 <a href="#noop"> noop </a> |


### **<a name="spel"> spel </a>**

此作业类型可以执行一段[spel]，（可根据业务需求进行二次开发扩展）

| tag | 名称 | 必输 | 类型 | 长度 | 样例值 | 描述 |
| --- | --- | :-: | :-: | :-: | --- | --- |
| <a name="field_id"> id </a> | id | 1 | [ID] | 32 | spelTasklet | 步骤ID，**`其值整个xml文件中唯一`** |
| <a name="field_name"> name </a> | 名称 | 1 | [string] | 64 | spel作业样例 | 步骤名，展示在监控页面节点上，系统不会控制此值的唯一性 |
| <a name="field_desc"> desc | 描述 | 0-1 | [string] | 512 | spel作业描述 | 步骤描述，可用于描述步骤的详细功能 |
| <a name="field_failedTo"> failedTo </a> | 失败跳至 | 0-1 | [string] | 32 | otherTasklet | 若值为其他步骤ID[^1]，表示当前步骤失败后跳至该步骤；若值为end，表示若当前步骤失败后结束，且整个作业的状态为 <a href="#EXIST_COMPLETED"> COMPLETED </a>；值为空，表示若当前步骤失败后结束，且整个作业的状态为<a href="#EXIST_FAILED"> FAILED </a> |
| <a name="field_condition"> condition </a> | 执行条件 | 0-1 | [string] | 512 | demoTasklet.result.status == "FAILED" |此步骤执行的条件，值为一个bool运算表达式，具体规则参考<a href="#condition"> 执行条件配置 </a>。若为空，表示没有条件限制。|
| expression | 表达式 | 1 | [string] | -- | sayHelloService.hello("world") | 表达式内容 |
| <a name="field_listeners"> listeners </a> | 监听器列表 | 0-1 | tag | -- | -- | 参考 <a href="#listeners"> listeners </a> |


### **<a name="shell"> shell </a>**

此作业类型可执行本地或远程的shell脚本。

| tag | 名称 | 必输 | 类型 | 长度 | 样例值 | 描述 |
| --- | --- | :-: | :-: | :-: | --- | --- |
| id | id | 1 | [ID] | 32 | spelTasklet | <a href="#field_id"> 同上 </a> |
| name | 名称 | 1 | [string] | 64 | spel作业样例 | <a href="#field_name"> 同上 </a> |
| desc | 描述 | 0-1 | [string] | 512 | spel作业描述 | <a href="#field_desc"> 同上 </a> |
| failedTo | 失败跳至 | 0-1 | [string] | 32 | otherTasklet | <a href="#field_failedTo"> 同上 </a> |
| condition | 执行条件 | 0-1 | [string] | 512 | demoTasklet.result.status == "FAILED" |<a href="#field_condition"> 同上 </a> |
| script | 脚本 | 1 | [string] | -- | sh /Users/user/test.sh Tom Jerry | 命令脚本 |
| node | 节点ID | 0-1 | [string] | -- | taskm_sit_ssh | 远程节点ID，若为空，表示执行本地脚本；若有值，则连接远程节点执行脚本；节点信息可在`系统管理 > 节点维护`中配置，连接方式必须为ssh的节点才可用于此类型的作业步骤 |
| listeners | 监听器列表 | 0-1 | tag | -- | -- | <a href="#field_listeners"> 同上 </a> |


### **<a name="springBean"> springBean </a>**

执行工程中的已存在的spring bean，此bean必须实现com.gingkoo.taskm.runtime.impl.job.inter.JobBean接口。


| tag | 名称 | 必输 | 类型 | 长度 | 样例值 | 描述 |
| --- | --- | :-: | :-: | :-: | --- | --- |
| id | id | 1 | [ID] | 32 | spelTasklet | <a href="#field_id"> 同上 </a> |
| name | 名称 | 1 | [string] | 64 | spel作业样例 | <a href="#field_name"> 同上 </a> |
| desc | 描述 | 0-1 | [string] | 512 | spel作业描述 | <a href="#field_desc"> 同上 </a> |
| failedTo | 失败跳至 | 0-1 | [string] | 32 | otherTasklet | <a href="#field_failedTo"> 同上 </a> |
| condition | 执行条件 | 0-1 | [string] | 512 | demoTasklet.result.status == "FAILED" | <a href="#field_condition"> 同上 </a> |
| beanClass | bean的名字 | 1 | [string] | -- | springBeanService | 实现了com.gingkoo.taskm.runtime<br>.impl.job.inter.JobBean接口的bean的名字 |
| paras | 变量节点 | 0-1 | tag | -- | -- | 配置的key-value将作为变量传入bean中，参考 <a href="#paras"> paras </a> |
| listeners | 监听器列表 | 0-1 | tag | -- | -- | <a href="#field_listeners"> 同上 </a> |


### **<a name="dbproc"> dbproc </a>**

此作业类型可用于执行数据库中的存储过程。存储过程必须有OUT参数，且OUT参数为`OUT err_code int, OUT err_msg varchar(256)`。例如：

```sql
create procedure insert_one_para(IN param_group varchar(32), IN param_key varchar(32), IN param_value varchar(256),
                                 IN remarks     varchar(256), OUT err_code int, OUT err_msg varchar(256))
  BEGIN
       insert into taskm_test(param_group, param_key, param_value, remarks) values (param_group,param_key,param_value,remarks);
       set err_code = 0;
       set err_msg = 'ok';
     END;
```

| tag | 名称 | 必输 | 类型 | 长度 | 样例值 | 描述 |
| --- | --- | :-: | :-: | :-: | --- | --- |
| id | id | 1 | [ID] | 32 | spelTasklet | <a href="#field_id"> 同上 </a> |
| name | 名称 | 1 | [string] | 64 | spel作业样例 | <a href="#field_name"> 同上 </a> |
| desc | 描述 | 0-1 | [string] | 512 | spel作业描述 | <a href="#field_desc"> 同上 </a> |
| failedTo | 失败跳至 | 0-1 | [string] | 32 | otherTasklet | <a href="#field_failedTo"> 同上 </a> |
| condition | 执行条件 | 0-1 | [string] | 512 | demoTasklet.result.status == "FAILED" | <a href="#field_condition"> 同上 </a> |
| datasource | 数据源ID | 1 | [string] | -- | taskm_sit | 数据源配置的ID。数据源可在`系统管理 > 全局参数 > 数据源` 中配置 |
| transactional | 数据源ID | 0-1 | [boolean] | -- | taskm_sit | 是否包含事务，即返回的`err_code < 0`时是否回滚，默认为false |
| args | 参数列表 | 0-1 | tag | -- | -- | 配置存储过程所需要的IN参数，参考 <a href="#args"> args </a> |
| listeners | 监听器列表 | 0-1 | tag | -- | -- | <a href="#field_listeners"> 同上 </a> |


### **<a name="remote"> remote </a>**

调用rest api接口。接口说明如下：

* 接口的Method必须为POST
* 接口必须接受两个QueryParam：id（请求id），callback（回调url，需进行url decode，异步时用）
* 配置的变量将以json的方式放到请求的body中，例如：

	```json
	{
	    "key1": "value1",
	    "key2": "value2",
	}
	```

	> value 的值都为java.lang.String类型

* 接口返回值必须为以下结构：

	```json
	{
	    "id": "xxxxxxxxxx",
	    "errCode": 0,
	    "errMsg": "ok"
	}
	```
	
	> * id为传入请求id
	> * errCode错误码：大于等于0表示成功；-2表示正在执行，返回此错误码表示改调用为异步调用，作业步骤会阻塞，知道调用callback，传入errCode为成功的错误码；其他表示失败。
	> * errMsg错误信息
	
* 异步时调用callback为post请求，body的结构同上

同步接口样例：

```java
@PostMapping("/test/remote/sync")
public RemoteTaskletResult testRemoteSync(@RequestParam String id, @RequestParam String callback, @RequestBody String body) {
    log.info("########## test remote sync id[{}] callback[{}] body[{}] #############", id, callback, body);
    return new RemoteTaskletResult(id, TaskletResult.SUCCESS_CODE, "ok");
}   
```

异步接口样例：

```java
@PostMapping("/test/remote/async")
    public RemoteTaskletResult testRemoteAsync(@RequestParam String id, @RequestParam String callback, @RequestBody String body) {
        String callbackUrl;
        try {
            callbackUrl = URLDecoder.decode(callback, StandardCharsets.UTF_8.name());
        } catch (UnsupportedEncodingException e) {
            log.error(LogHelper.format("url[{}] decode error"), e);
            return new RemoteTaskletResult(id, TaskletResult.FAILED_CODE, "url decode error");
        }
        log.info("########## test remote async id[{}] callback[{}] body[{}] #############", id, callbackUrl, body);
        taskExecutor.execute(() -> {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ignored) {
            }
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
            RemoteTaskletResult result = new RemoteTaskletResult(id, TaskletResult.SUCCESS_CODE, "ok");
            HttpEntity<RemoteTaskletResult> httpEntity = new HttpEntity<>(result, headers);
            restTemplate.postForObject(callbackUrl, httpEntity, String.class);
        });
        return new RemoteTaskletResult(id, TaskletResult.EXECUTING_CODE, "executing");
    }
```

| tag | 名称 | 必输 | 类型 | 长度 | 样例值 | 描述 |
| --- | --- | :-: | :-: | :-: | --- | --- |
| id | id | 1 | [ID] | 32 | spelTasklet | <a href="#field_id"> 同上 </a> |
| name | 名称 | 1 | [string] | 64 | spel作业样例 | <a href="#field_name"> 同上 </a> |
| desc | 描述 | 0-1 | [string] | 512 | spel作业描述 | <a href="#field_desc"> 同上 </a> |
| failedTo | 失败跳至 | 0-1 | [string] | 32 | otherTasklet | <a href="#field_failedTo"> 同上 </a> |
| condition | 执行条件 | 0-1 | [string] | 512 | demoTasklet.result.status == "FAILED" | <a href="#field_condition"> 同上 </a> |
| url | 接口url | 1 | [string] | -- | 同步：<br>`http://127.0.0.1:8092/api/`<br>`taskm/test/remote/sync`<br>异步：<br>`http://127.0.0.1:8092/api`<br>`/taskm/test/remote/async` | rest api接口的url |
| timeout | 超时时间 | 0-1 | [long] | -- |10000 | 异步调用超时时间。单位为毫秒，默认为一小时。超过此时间，及时异步返回了结果，作业执行也会失败。 |
| paras | 变量列表 | 0-1 | tag | -- | -- | 变量列表，将会作为request body传给rest api。参考 <a href="#paras"> paras </a> |
| listeners | 监听器列表 | 0-1 | tag | -- | -- | <a href="#field_listeners"> 同上 </a> |


### **<a name="noop"> noop </a>**

空步骤，不会做任何操作。可用于并行分支的结束节点，例如：当并行中某个分支的某个步骤报错后想直接让这个分支结束掉而不是真个作业结束掉，可使用类型的作业步骤作为分支的最后一个步骤，failedTo指向此节点ID即可。

| tag | 名称 | 必输 | 类型 | 长度 | 样例值 | 描述 |
| --- | --- | :-: | :-: | :-: | --- | --- |
| id | id | 1 | [ID] | 32 | spelTasklet | <a href="#field_id"> 同上 </a> |
| name | 名称 | 1 | [string] | 64 | spel作业样例 | <a href="#field_name"> 同上 </a> |
| desc | 描述 | 0-1 | [string] | 512 | spel作业描述 | <a href="#field_desc"> 同上 </a> |
| failedTo | 失败跳至 | 0-1 | [string] | 32 | otherTasklet | <a href="#field_failedTo"> 同上 </a> |
| condition | 执行条件 | 0-1 | [string] | 512 | demoTasklet.result.status == "FAILED" | <a href="#field_condition"> 同上 </a> |
| listeners | 监听器列表 | 0-1 | tag | -- | -- | <a href="#field_listeners"> 同上 </a> |

### **<a name="listeners"> listeners </a>**

监听器列表

| tag | 名称 | 必输 | 类型 | 长度 | 样例值 | 描述 |
| --- | --- | :-: | :-: | :-: | --- | --- |
| listener | 监听器 | 0-1 | tag | -- | -- | 监听器标签 |
| --name | 监听器名称 | 1 | [string] | -- | OnPreJobNotify | 监听器的名称<br>若当前监听器列表在作业中，则可取值为:<br>`OnPreJobNotify`，<br>`OnAfterJobNotify`，<br>`OnErrorJobNotify`<br>若当前监听器列表在步骤中，则可取值为:<br>`OnPreStepNotify`，<br>`OnAfterStepNotify`，<br>`OnErrorStepNotify` |
| --template | 通知模板 | 1 | [string] | -- | demoNotify | 监听器通知的模板，可在`系统管理 > 系统通知`中进行配置 |

样例：

```xml
<listeners>
    <listener>
        <name>OnErrorJobNotify</name>
        <template>demoNotify</template>
    </listener>
    <listener>
        <name>OnAfterJobNotify</name>
        <template>demoNotify</template>
    </listener>
</listeners>
```

### **<a name="paras"> paras </a>**

key-value变量列表.

| tag | 名称 | 必输 | 类型 | 长度 | 样例值 | 描述 |
| --- | --- | :-: | :-: | :-: | --- | --- |
| para | 变量 | 0-1 | tag | -- | -- | 变量标签 |
| --key | 变量key | 1 | [string] | 32 | greet | 变量key |
| --value | 变量值 | 1 | [string] | 512 | hello | 变量值<br>若当前变量列表在作业中，则value值可以引用`系统管理 > 全局参数 > 全局变量`中的变量，引用方式为 `${key}` ，其中key为`系统管理 > 全局参数 > 全局变量`中的key<br>若当前变量列表在步骤中，则value值可以引用作业变量列表中的变量，引用方式为 `${key}` ，其中key为作业变量列表中的key |

样例：

```xml
<paras>
    <para>
        <key>greet</key>
        <value>${greetWord}</value>
    </para>
    <para>
        <key>name</key>
        <value>world</value>
    </para>
</paras>
```

### **<a name="args"> args </a>**

参数列表。

| tag | 名称 | 必输 | 类型 | 长度 | 样例值 | 描述 |
| --- | --- | :-: | :-: | :-: | --- | --- |
| arg | 参数值 | 0-1 | [string] | 512 | value | 参数值，可引用作业变量列表中的值变量，引用方式为 `${key}` ，其中key为作业变量列表中的key |

样例：

```xml
<args>
    <arg>test2</arg>
    <arg>test_key2</arg>
    <arg>test_value2</arg>
    <arg>this is for test2</arg>
</args>
```

### **<a name="condition"> 执行条件配置 </a>**
步骤的执行条件，值为一个bool运算表达式。结果为true表示步骤会运行，结果为false表示步骤不会运行。表达式样例：

* 判断某一步骤的返回错误码是否等于指定值（整数型）

  `步骤ID.result.errCode == 0`

* 某一步骤的返回信息是否等于指定值（字符型）

  `步骤ID.result.errMsg == "ok"`

* 某一步骤的<a href="#existStatus"> 退出状态 </a> 是否等于指定状态（字符型）

  `步骤ID.result.status == "COMPLETED"`

* <a href="#job_param"> 作业参数 </a>的值是否等于指定值（字符型）

  `作业参数key == "xxx"`

* 步骤参数的值手否等于指定值（字符型）

  `步骤参数key == "xxx"`


### **<a name="existStatus"> 退出状态 </a>**

退出状态用于描述作业或者步骤的最终状态，当作业或者步骤正正在执行的时候此状态不准确，对于正执行的作业此状态可能为`UNKNOWN`，对于正在执行的步骤，此状态一般与 <a href="#batchStatus"> 运行状态 </a>同步，直至运行结束（不管是成功、失败还是暂停）。

| code | 名称 | 描述 |
| --- | --- | --- |
| <a name="EXIST_UNKNOWN"> UNKNOWN </a> | 未知 | 一般当作业正在执行时才会出现此状态 |
| <a name="EXIST_EXECUTING"> EXECUTING </a> | 正执行 | 执行中 |
| <a name="EXIST_COMPLETED"> COMPLETED </a> | 执行成功 | 执行完成，且结果为成功 |
| <a name="EXIST_NOOP"> NOOP </a> | 作业未执行 | 未满足执行条件而跳过的步骤才会出现此状态 |
| <a name="EXIST_FAILED"> FAILED </a> | 失败 | 执行完成，但结果为失败 |
| <a name="EXIST_STOPPED"> STOPPED </a> | 停止 | 停止执行 |

### **<a name="batchStatus"> 运行状态 </a>**

运行状态，用于描述作业的当前状态（运行时状态）

| code | 名称 | 描述 |
| --- | --- | --- |
| <a name="BATCH_COMPLETED"> COMPLETED </a> | 执行成功 | 执行完成，且结果为成功 |
| <a name="BATCH_STARTED"> STARTED </a> | 已启动 | 正执行 |
| <a name="BATCH_STOPPED"> STOPPED </a> | 已停止 | 已停止执行 |
| <a name="BATCH_FAILED"> FAILED </a> | 执行失败 | 执行完成，但结果为失败 |
| <a name="BATCH_ABANDONED"> ABANDONED </a> | 终止 | 终止，不可重启 |
| <a name="BATCH_UNKNOWN"> UNKNOWN </a> | 未知 | 未知状态 |


[^1]: failedTo若指定步骤ID，则此步骤ID不能为跨级节点：不能是和当前节点同级的并行节点中的一个步骤；若当前节点为并行节点中的步骤，则指定的步骤ID不能是其他并行分支中的步骤，也不能是并行节点外的步骤。

[string]: https://www.w3.org/TR/xmlschema-2/#string
[boolean]: http://www.w3.org/TR/xmlschema-2/#boolean
[long]: http://www.w3.org/TR/xmlschema-2/#long
[ID]: http://www.w3.org/TR/xmlschema-2/#ID
[spel]: https://docs.spring.io/spring/docs/4.2.x/spring-framework-reference/html/expressions.html