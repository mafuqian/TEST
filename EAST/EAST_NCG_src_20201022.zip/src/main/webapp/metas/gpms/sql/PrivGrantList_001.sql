select data_id,data_date,corp_id,org_id,group_id,code_schema,code_item,code_value,code_name,p_code_value from GP_BM_CODE_LIST where 1=1 and code_schema = :"codeSchema" and code_item = :"codeItem"
