CREATE OR REPLACE FUNCTION GET_FIELD_ASSEMBLY(FIELD_ARRAY IN CLOB, TAB_OBJ1 IN VARCHAR2, TAB_OBJ2 IN VARCHAR2) RETURN VARCHAR2 AS
    /*
    Author: DENGCX
    Create Date: 20200924
    FIELD_ARRAY:�ֶμ��� ��Ӣ�Ķ��ŷָ�
    TAB_OBJ1��������1 �������������Ӣ�Ķ��ŷָ�
    TAB_OBJ2����ϵ�� = <>
    Description:
    �Ƚ��ֶ�ƴװ
    */
    FIELDSTR       VARCHAR2(100);
    OBJSTR         VARCHAR2(100);
    V_COUNT        NUMBER(10) := 0;
    FIELD_ASSEMBLY CLOB;
    COMPARE_STR_T0 CLOB;
    COMPARE_STR_T1 CLOB;
    COMPARE_STR_T2 CLOB;
    CURSOR FIELD_SCUR IS
        SELECT REGEXP_SUBSTR(FIELD_ARRAY, '[^,]+', 1, ROWNUM) FIELD
        FROM DUAL
        CONNECT BY ROWNUM <= LENGTH(FIELD_ARRAY) -
                             LENGTH(REGEXP_REPLACE(FIELD_ARRAY, ',', '')) + 1;
    FIELD_ROW      FIELD_SCUR%ROWTYPE;
    CURSOR OBJ_SCUR IS
        SELECT REGEXP_SUBSTR(TAB_OBJ1, '[^,]+', 1, ROWNUM) FIELD
        FROM DUAL
        CONNECT BY ROWNUM <= LENGTH(TAB_OBJ1) -
                             LENGTH(REGEXP_REPLACE(TAB_OBJ1, ',', '')) + 1;
    OBJ_ROW        OBJ_SCUR%ROWTYPE;


BEGIN
    DBMS_OUTPUT.ENABLE(BUFFER_SIZE => NULL);
    IF TAB_OBJ1 IS NULL THEN
        FOR FIELD_ROW IN FIELD_SCUR
            LOOP
                FIELDSTR := FIELD_ROW.FIELD;
                COMPARE_STR_T2 := COMPARE_STR_T2 || '||' || FIELDSTR;
            END LOOP;
    ELSE
        FOR OBJ_ROW IN OBJ_SCUR
            LOOP
                OBJSTR := OBJ_ROW.FIELD;
                COMPARE_STR_T1 := '(';
                FOR FIELD_ROW IN FIELD_SCUR
                    LOOP
                        FIELDSTR := FIELD_ROW.FIELD;
                        COMPARE_STR_T2 := COMPARE_STR_T2 || '||' || OBJSTR || '.' || FIELDSTR;
                    END LOOP;
                COMPARE_STR_T1 := COMPARE_STR_T1 || SUBSTR(COMPARE_STR_T2, 3) || ')';
                COMPARE_STR_T0 := COMPARE_STR_T0 || COMPARE_STR_T1 || TAB_OBJ2;

                COMPARE_STR_T2 := NULL;

            END LOOP;
    END IF;
    IF TAB_OBJ1 IS NOT NULL THEN
        IF TAB_OBJ2 IS NULL THEN
            V_COUNT := 0;
        ELSE
            V_COUNT := LENGTH(TAB_OBJ2);
        END IF;
        FIELD_ASSEMBLY := SUBSTR(COMPARE_STR_T0, 0, (LENGTH(COMPARE_STR_T0) - V_COUNT));
    ELSE
        FIELD_ASSEMBLY := '(' || SUBSTR(COMPARE_STR_T2, 3) || ')';
    END IF;

    RETURN FIELD_ASSEMBLY;

END;

