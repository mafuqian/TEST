DELETE FROM MBT_RPT_DATE_CODE_CFG T WHERE T.INF_REC_TYPE = '110';
DELETE FROM MBT_RPT_DATE_CODE_CFG T WHERE T.INF_REC_TYPE = '210';
DELETE FROM MBT_RPT_DATE_CODE_CFG T WHERE T.INF_REC_TYPE = '220';
DELETE FROM MBT_RPT_DATE_CODE_CFG T WHERE T.INF_REC_TYPE = '230';
DELETE FROM MBT_RPT_DATE_CODE_CFG T WHERE T.INF_REC_TYPE = '310';
DELETE FROM MBT_RPT_DATE_CODE_CFG T WHERE T.INF_REC_TYPE = '410';
DELETE FROM MBT_RPT_DATE_CODE_CFG T WHERE T.INF_REC_TYPE = '420';
DELETE FROM MBT_RPT_DATE_CODE_CFG T WHERE T.INF_REC_TYPE = '440';
DELETE FROM MBT_RPT_DATE_CODE_CFG T WHERE T.INF_REC_TYPE = '510';
DELETE FROM MBT_RPT_DATE_CODE_CFG T WHERE T.INF_REC_TYPE = '610';
DELETE FROM MBT_RPT_DATE_CODE_CFG T WHERE T.INF_REC_TYPE = '620';
DELETE FROM MBT_RPT_DATE_CODE_CFG T WHERE T.INF_REC_TYPE = '630';
DELETE FROM MBT_RPT_DATE_CODE_CFG T WHERE T.INF_REC_TYPE = '640';
DELETE FROM MBT_RPT_DATE_CODE_CFG T WHERE T.INF_REC_TYPE = '650';

insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('110', null, '10', '22222220|1', '11111110|0', '个人基本信息', '2020092200000001');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('110', null, '20', '21111110|1', '11111110|0', '个人基本信息', '2020092200000002');

insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'D1', '10', '2210200|110', '1101001|000', '个人借贷账户信息', '2020092200000003');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'D1', '31', '2210200|111', '1101001|000', '个人借贷账户信息', '2020092200000004');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'D1', '30', '2110200|111', '1101001|000', '个人借贷账户信息', '2020092200000005');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'D1', '32', '2110200|111', '1101001|000', '个人借贷账户信息', '2020092200000006');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'D1', '40', '2000002|000', '1101001|000', '个人借贷账户信息', '2020092200000007');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'D1', '20', '2110200|111', '1101001|000', '个人借贷账户信息', '2020092200000008');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R1', '10', '2220200|110', '1101001|000', '个人借贷账户信息', '2020092200000009');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R1', '31', '2220200|111', '1101001|000', '个人借贷账户信息', '2020092200000010');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R1', '30', '2110200|111', '1101001|000', '个人借贷账户信息', '2020092200000011');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R1', '32', '2110200|111', '1101001|000', '个人借贷账户信息', '2020092200000012');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R1', '40', '2000002|000', '1101001|000', '个人借贷账户信息', '2020092200000013');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R1', '20', '2110200|111', '1101001|000', '个人借贷账户信息', '2020092200000014');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R2', '10', '2210210|110', '1101001|000', '个人借贷账户信息', '2020092200000015');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R2', '31', '2210210|111', '1101001|000', '个人借贷账户信息', '2020092200000016');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R2', '30', '2110210|111', '1101001|000', '个人借贷账户信息', '2020092200000017');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R2', '32', '2110210|111', '1101001|000', '个人借贷账户信息', '2020092200000018');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R2', '40', '2000002|000', '1101001|000', '个人借贷账户信息', '2020092200000019');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R2', '20', '2110210|111', '1101001|000', '个人借贷账户信息', '2020092200000020');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R3', '10', '2220200|110', '1101001|000', '个人借贷账户信息', '2020092200000021');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R3', '31', '2220200|111', '1101001|000', '个人借贷账户信息', '2020092200000022');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R3', '30', '2110200|111', '1101001|000', '个人借贷账户信息', '2020092200000023');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R3', '32', '2110200|111', '1101001|000', '个人借贷账户信息', '2020092200000024');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R3', '20', '2110200|111', '1101001|000', '个人借贷账户信息', '2020092200000025');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R4', '10', '2220200|110', '1101001|000', '个人借贷账户信息', '2020092200000026');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R4', '31', '2220200|111', '1101001|000', '个人借贷账户信息', '2020092200000027');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R4', '30', '2110200|111', '1101001|000', '个人借贷账户信息', '2020092200000028');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R4', '32', '2110200|111', '1101001|000', '个人借贷账户信息', '2020092200000029');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R4', '40', '2000002|000', '1101001|000', '个人借贷账户信息', '2020092200000030');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'R4', '20', '2110200|111', '1101001|000', '个人借贷账户信息', '2020092200000031');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'C1', '10', '2202002|101', '1101001|000', '个人借贷账户信息', '2020092200000032');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'C1', '40', '2100002|001', '1101001|000', '个人借贷账户信息', '2020092200000033');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('210', 'C1', '20', '2100002|001', '1101001|000', '个人借贷账户信息', '2020092200000034');

insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('220', null, '10', '22|1', '11|0', '个人授信协议信息', '2020092200000035');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('220', null, '20', '22|1', '11|0', '个人授信协议信息', '2020092200000036');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('220', null, '30', '22|1', '11|0', '个人授信协议信息', '2020092200000037');

insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('230', null, '10', '222|10', '111|00', '个人担保账户信息', '2020092200000038');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('230', null, '30', '212|10', '111|00', '个人担保账户信息', '2020092200000039');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('230', null, '40', '212|10', '111|00', '个人担保账户信息', '2020092200000040');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('230', null, '50', '210|10', '111|00', '个人担保账户信息', '2020092200000041');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('230', null, '20', '212|10', '111|00', '个人担保账户信息', '2020092200000042');

insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('310', null, '10', '22112|1211', '1111|0100', '企业基本信息', '2020092200000043');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('310', null, '20', '21111|1111', '1111|0000', '企业基本信息', '2020092200000044');

insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'D1', '10', '22102|111', '11101|111', '企业信贷交易信息', '2020092200000045');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'D1', '20', '21102|111', '11101|111', '企业信贷交易信息', '2020092200000046');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'D1', '31', '21102|111', '11101|111', '企业信贷交易信息', '2020092200000047');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'D1', '32', '21102|111', '11101|111', '企业信贷交易信息', '2020092200000048');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'D1', '33', '21102|111', '11101|111', '企业信贷交易信息', '2020092200000049');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'D1', '41', '21102|111', '11101|111', '企业信贷交易信息', '2020092200000050');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'D1', '42', '21102|111', '11101|111', '企业信贷交易信息', '2020092200000051');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'D1', '49', '21102|111', '11101|111', '企业信贷交易信息', '2020092200000052');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'D2', '10', '22002|100', '11001|100', '企业信贷交易信息', '2020092200000053');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'D2', '20', '21002|100', '11001|100', '企业信贷交易信息', '2020092200000054');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'D2', '32', '21002|100', '11001|100', '企业信贷交易信息', '2020092200000055');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'D2', '33', '21002|100', '11001|100', '企业信贷交易信息', '2020092200000056');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'D2', '41', '21002|100', '11001|100', '企业信贷交易信息', '2020092200000057');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'D2', '49', '21002|100', '11001|100', '企业信贷交易信息', '2020092200000058'); 
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'R1', '10', '22202|111', '11101|111', '企业信贷交易信息', '2020092200000059');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'R1', '20', '21102|111', '11101|111', '企业信贷交易信息', '2020092200000060');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'R1', '49', '21102|111', '11101|111', '企业信贷交易信息', '2020092200000061'); 
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'R4', '10', '22202|111', '11101|111', '企业信贷交易信息', '2020092200000062');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'R4', '20', '21102|111', '11101|111', '企业信贷交易信息', '2020092200000063');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'R4', '32', '21102|111', '11101|111', '企业信贷交易信息', '2020092200000064');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'R4', '33', '21102|111', '11101|111', '企业信贷交易信息', '2020092200000065');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'R4', '41', '21102|111', '11101|111', '企业信贷交易信息', '2020092200000066');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'R4', '42', '21102|112', '11101|111', '企业信贷交易信息', '2020092200000067');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'R4', '49', '21102|111', '11101|111', '企业信贷交易信息', '2020092200000068'); 
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'C1', '10', '22012|101', '11011|101', '企业信贷交易信息', '2020092200000069');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'C1', '20', '21002|001', '11001|001', '企业信贷交易信息', '2020092200000070');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'C1', '33', '21002|001', '11001|001', '企业信贷交易信息', '2020092200000071');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'C1', '41', '21002|001', '11001|001', '企业信贷交易信息', '2020092200000072');
insert into MBT_RPT_DATE_CODE_CFG (inf_rec_type, acct_type, rpt_date_code, cfg_value, init_value, remarks, data_id) values ('410', 'C1', '49', '21002|001', '11001|001', '企业信贷交易信息', '2020092200000073');

insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('420', null, '10', '22|1', '11|1', '企业授信协议信息', '2020092200000074');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('420', null, '20', '22|1', '11|1', '企业授信协议信息', '2020092200000075');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('420', null, '30', '22|1', '11|1', '企业授信协议信息', '2020092200000076');

insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('440', null, '10', '2212|10', '1111|10', '个人担保账户信息', '2020092200000077');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('440', null, '30', '2112|10', '1111|10', '个人担保账户信息', '2020092200000078');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('440', null, '40', '2112|10', '1111|10', '个人担保账户信息', '2020092200000079');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('440', null, '50', '2110|10', '1111|10', '个人担保账户信息', '2020092200000080');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('440', null, '20', '2112|10', '1111|10', '个人担保账户信息', '2020092200000081');

insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('510', null, '10', '22|111', '11|111', '抵（质）押物信息', '2020092200000082');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('510', null, '30', '22|111', '11|111', '抵（质）押物信息', '2020092200000083');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('510', null, '20', '22|111', '11|111', '抵（质）押物信息', '2020092200000084');

insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('610', null, '10', '211', '111', '企业资产负债表信息', '2020092200000085');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('610', null, '20', '211', '111', '企业资产负债表信息', '2020092200000086');

insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('620', null, '10', '211', '111', '企业利润及利润分配表信息', '2020092200000087');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('620', null, '20', '211', '111', '企业利润及利润分配表信息', '2020092200000088');

insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('630', null, '10', '211', '111', '企业现金流量表信息', '2020092200000089');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('630', null, '20', '211', '111', '企业现金流量表信息', '2020092200000090');

insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('640', null, '10', '22', '11', '事业单位资产负债表信息', '2020092200000091');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('640', null, '20', '22', '11', '事业单位资产负债表信息', '2020092200000092');

insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('650', null, '10', '22', '11', '事业单位收入支出表信息', '2020092200000093');
insert into MBT_RPT_DATE_CODE_CFG (INF_REC_TYPE, ACCT_TYPE, RPT_DATE_CODE, CFG_VALUE, INIT_VALUE, REMARKS, DATA_ID) values ('650', null, '20', '22', '11', '事业单位收入支出表信息', '2020092200000094');

commit;

