CREATE OR REPLACE FUNCTION GET_ISRPT (CFG_ISRPT IN VARCHAR2, DATA_ISRPT IN VARCHAR2)RETURN VARCHAR2 AS
    /*
    Author: DENGCX
    Create Date: 20200924
    Description:
    ��������isrpt�������ݼ�¼��isrpt
    */
V_COUNT    NUMBER(10) := 0;
--V_STR      VARCHAR2(50) := 0;
ISRPT      VARCHAR2(50) := NULL;
BEGIN
    V_COUNT:=LENGTH(CFG_ISRPT);
    FOR I IN 1..V_COUNT LOOP
      IF SUBSTR(CFG_ISRPT,I,1) = '|' THEN
            ISRPT := ISRPT || '|';
      ELSIF SUBSTR(CFG_ISRPT,I,1) = '2' THEN
            ISRPT := ISRPT || '1';
      ELSIF SUBSTR(CFG_ISRPT,I,1) = '0' THEN
            ISRPT := ISRPT || '0';
      ELSE
            ISRPT := ISRPT || SUBSTR(DATA_ISRPT,I,1);
      END IF;
    END LOOP;
    RETURN ISRPT;
    DBMS_OUTPUT.PUT_LINE(ISRPT);

END;

