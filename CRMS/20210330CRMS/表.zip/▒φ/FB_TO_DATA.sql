CREATE TABLE FB_TO_DATA
(
	DATA_ID						VARCHAR2(64) PRIMARY KEY,
    PM_DATA_ID_A              	VARCHAR2(64),
    UNV_IDN            			VARCHAR2(64),
    PM_DATA_STATUS_A            VARCHAR2(64),
    PM_RPT_STATUS_A             VARCHAR2(64),
    SECTION_CHG_CNT             VARCHAR2(64),
    SECTION_DEL_CNT             VARCHAR2(64),
    WHOLE_DEL_CNT           	VARCHAR2(64),
    IDN_CHG_CNT         		VARCHAR2(64),
    PM_DATA_ID_B       		 	VARCHAR2(64),
    PM_DATA_STATUS_B        	VARCHAR2(64),
    PM_RPT_STATUS_B             VARCHAR2(64),
    RPT_DATA_ID_B               VARCHAR2(64),
    B_RPT_DATE                  VARCHAR2(64),
    RPT_DATA_STATUS_B           VARCHAR2(64),
    RPT_RPT_STATUS_B            VARCHAR2(64),
    PART_TYPE                 	VARCHAR2(64)
);