create table MBT_DM_410 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
O_BIZ_CODE VARCHAR(60),
N_BIZ_CODE VARCHAR(60),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_410 is '企业借贷账户信息';
comment on column MBT_DM_410.DATA_ID is '数据ID';
comment on column MBT_DM_410.DATA_DATE is '数据日期';
comment on column MBT_DM_410.CORP_ID is '法人ID';
comment on column MBT_DM_410.ORG_ID is '机构ID';
comment on column MBT_DM_410.GROUP_ID is '数据分组';
comment on column MBT_DM_410.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_410.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_410.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_410.O_BIZ_CODE is '原业务标识码';
comment on column MBT_DM_410.N_BIZ_CODE is '新业务标识码';
comment on column MBT_DM_410.SECTION_CHG_CNT is '段变更';
comment on column MBT_DM_410.SECTION_DEL_CNT is '段删除';
comment on column MBT_DM_410.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_DM_410.IDN_CHG_CNT is '标识项变更';
comment on column MBT_DM_410.CUST_NO is '客户号';
comment on column MBT_DM_410.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_410.PART_TYPE is '段标识';
comment on column MBT_DM_410.PART_NAME is '段名称';
comment on column MBT_DM_410.START_DATE is '起始日期';
comment on column MBT_DM_410.END_DATE is '结束日期';
comment on column MBT_DM_410.BATCH_NO is '批次号';
comment on column MBT_DM_410.ROW_NUM is '行号';
comment on column MBT_DM_410.IS_RPT is '是否报送';
comment on column MBT_DM_410.IS_VALID is '是否有效';
comment on column MBT_DM_410.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_410.OPT_FLAG is '操作标识';
comment on column MBT_DM_410.RPT_DATE is '报送日期';
comment on column MBT_DM_410.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_410.RPT_STATUS is '报送状态';
comment on column MBT_DM_410.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_410.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_410.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_410.REMARKS is '备注';
comment on column MBT_DM_410.CHECK_FLAG is '校验标志';
comment on column MBT_DM_410.CHECK_DESC is '校验说明';
comment on column MBT_DM_410.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_410.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_410.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_410.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_410.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_410.DATA_FLAG is '数据标志';
comment on column MBT_DM_410.DATA_OP is '操作标志';
comment on column MBT_DM_410.DATA_SOURCE is '数据来源';
comment on column MBT_DM_410.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_410.DATA_HASH is '数据HASH';
comment on column MBT_DM_410.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_410.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_410.DATA_CRT_USER is '创建人';
comment on column MBT_DM_410.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_410.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_410.DATA_CHG_USER is '修改人';
comment on column MBT_DM_410.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_410.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_410.DATA_APV_USER is '审核人';
comment on column MBT_DM_410.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_410.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_410.RSV1 is '备用字段';
comment on column MBT_DM_410.RSV2 is '备用字段';
comment on column MBT_DM_410.RSV3 is '备用字段';
comment on column MBT_DM_410.RSV4 is '备用字段';
comment on column MBT_DM_410.RSV5 is '备用字段';
create table MBT_DM_410_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
B_ACCT_TYPE VARCHAR(2),
B_ID_NUM VARCHAR(80),
B_ID_TYPE VARCHAR(2),
B_INFO_UP_DATE VARCHAR(8),
B_INF_REC_TYPE VARCHAR(3),
B_MNGMT_ORG_CODE VARCHAR(14),
B_MONTH VARCHAR(8),
B_NAME VARCHAR(160),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
MON_SETTLE_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_410_B is '企业借贷账户信息-基础段';
comment on column MBT_DM_410_B.DATA_ID is '数据ID';
comment on column MBT_DM_410_B.DATA_DATE is '数据日期';
comment on column MBT_DM_410_B.CORP_ID is '法人ID';
comment on column MBT_DM_410_B.ORG_ID is '机构ID';
comment on column MBT_DM_410_B.GROUP_ID is '数据分组';
comment on column MBT_DM_410_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_410_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_410_B.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_410_B.B_ACCT_TYPE is '账户类型';
comment on column MBT_DM_410_B.B_ID_NUM is '借款人身份标识号码';
comment on column MBT_DM_410_B.B_ID_TYPE is '借款人身份标识类型';
comment on column MBT_DM_410_B.B_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_410_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_DM_410_B.B_MNGMT_ORG_CODE is '业务管理机构代码';
comment on column MBT_DM_410_B.B_MONTH is '月份';
comment on column MBT_DM_410_B.B_NAME is '借款人名称';
comment on column MBT_DM_410_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_410_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_DM_410_B.MON_SETTLE_DATE is '月结日';
comment on column MBT_DM_410_B.CUST_NO is '客户号';
comment on column MBT_DM_410_B.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_410_B.PART_TYPE is '段标识';
comment on column MBT_DM_410_B.PART_NAME is '段名称';
comment on column MBT_DM_410_B.START_DATE is '起始日期';
comment on column MBT_DM_410_B.END_DATE is '结束日期';
comment on column MBT_DM_410_B.BATCH_NO is '批次号';
comment on column MBT_DM_410_B.ROW_NUM is '行号';
comment on column MBT_DM_410_B.IS_RPT is '是否报送';
comment on column MBT_DM_410_B.IS_VALID is '是否有效';
comment on column MBT_DM_410_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_410_B.OPT_FLAG is '操作标识';
comment on column MBT_DM_410_B.RPT_DATE is '报送日期';
comment on column MBT_DM_410_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_410_B.RPT_STATUS is '报送状态';
comment on column MBT_DM_410_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_410_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_410_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_410_B.REMARKS is '备注';
comment on column MBT_DM_410_B.CHECK_FLAG is '校验标志';
comment on column MBT_DM_410_B.CHECK_DESC is '校验说明';
comment on column MBT_DM_410_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_410_B.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_410_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_410_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_410_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_410_B.DATA_FLAG is '数据标志';
comment on column MBT_DM_410_B.DATA_OP is '操作标志';
comment on column MBT_DM_410_B.DATA_SOURCE is '数据来源';
comment on column MBT_DM_410_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_410_B.DATA_HASH is '数据HASH';
comment on column MBT_DM_410_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_410_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_410_B.DATA_CRT_USER is '创建人';
comment on column MBT_DM_410_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_410_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_410_B.DATA_CHG_USER is '修改人';
comment on column MBT_DM_410_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_410_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_410_B.DATA_APV_USER is '审核人';
comment on column MBT_DM_410_B.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_410_B.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_410_B.RSV1 is '备用字段';
comment on column MBT_DM_410_B.RSV2 is '备用字段';
comment on column MBT_DM_410_B.RSV3 is '备用字段';
comment on column MBT_DM_410_B.RSV4 is '备用字段';
comment on column MBT_DM_410_B.RSV5 is '备用字段';
create table MBT_DM_410_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ACCT_CRED_LINE_AMT NUMBER(15),
C_ACCT_CRED_LINE_AMT_LCY NUMBER(15),
C_ACT_INVEST VARCHAR(5),
C_APPLY_BUSI_DIST VARCHAR(6),
C_ASSET_TRAND_FLAG VARCHAR(1),
C_BUSI_DTL_LINES VARCHAR(2),
C_BUSI_LINES VARCHAR(2),
C_CY VARCHAR(3),
C_DUE_DATE VARCHAR(8),
C_FLAG VARCHAR(1),
C_FUND_SOU VARCHAR(2),
C_GUAR_MODE VARCHAR(1),
C_LOAN_AMT NUMBER(15),
C_LOAN_AMT_LCY NUMBER(15),
C_LOAN_TIME_LIM_CAT VARCHAR(2),
C_LOA_FRM VARCHAR(1),
C_OPEN_DATE VARCHAR(8),
C_OTH_REPY_GUAR_WAY VARCHAR(1),
C_REPAY_FREQCY VARCHAR(2),
C_REPAY_MODE VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_410_C is '企业借贷账户信息-基本信息段';
comment on column MBT_DM_410_C.DATA_ID is '数据ID';
comment on column MBT_DM_410_C.DATA_DATE is '数据日期';
comment on column MBT_DM_410_C.CORP_ID is '法人ID';
comment on column MBT_DM_410_C.ORG_ID is '机构ID';
comment on column MBT_DM_410_C.GROUP_ID is '数据分组';
comment on column MBT_DM_410_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_410_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_410_C.C_ACCT_CRED_LINE_AMT is '信用额度';
comment on column MBT_DM_410_C.C_ACCT_CRED_LINE_AMT_LCY is '信用额度人民币金额';
comment on column MBT_DM_410_C.C_ACT_INVEST is '贷款实际投向';
comment on column MBT_DM_410_C.C_APPLY_BUSI_DIST is '业务申请地行政区划代码';
comment on column MBT_DM_410_C.C_ASSET_TRAND_FLAG is '资产转让标志';
comment on column MBT_DM_410_C.C_BUSI_DTL_LINES is '借贷业务种类细分';
comment on column MBT_DM_410_C.C_BUSI_LINES is '借贷业务大类';
comment on column MBT_DM_410_C.C_CY is '币种';
comment on column MBT_DM_410_C.C_DUE_DATE is '到期日期';
comment on column MBT_DM_410_C.C_FLAG is '分次放款标志';
comment on column MBT_DM_410_C.C_FUND_SOU is '业务经营类型';
comment on column MBT_DM_410_C.C_GUAR_MODE is '担保方式';
comment on column MBT_DM_410_C.C_LOAN_AMT is '借款金额';
comment on column MBT_DM_410_C.C_LOAN_AMT_LCY is '借款金额人民币金额';
comment on column MBT_DM_410_C.C_LOAN_TIME_LIM_CAT is '借款期限分类';
comment on column MBT_DM_410_C.C_LOA_FRM is '贷款发放形式';
comment on column MBT_DM_410_C.C_OPEN_DATE is '开户日期';
comment on column MBT_DM_410_C.C_OTH_REPY_GUAR_WAY is '其他还款保证方式';
comment on column MBT_DM_410_C.C_REPAY_FREQCY is '还款频率';
comment on column MBT_DM_410_C.C_REPAY_MODE is '还款方式';
comment on column MBT_DM_410_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_410_C.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_410_C.CUST_NO is '客户号';
comment on column MBT_DM_410_C.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_410_C.PART_TYPE is '段标识';
comment on column MBT_DM_410_C.PART_NAME is '段名称';
comment on column MBT_DM_410_C.START_DATE is '起始日期';
comment on column MBT_DM_410_C.END_DATE is '结束日期';
comment on column MBT_DM_410_C.BATCH_NO is '批次号';
comment on column MBT_DM_410_C.ROW_NUM is '行号';
comment on column MBT_DM_410_C.IS_RPT is '是否报送';
comment on column MBT_DM_410_C.IS_VALID is '是否有效';
comment on column MBT_DM_410_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_410_C.OPT_FLAG is '操作标识';
comment on column MBT_DM_410_C.RPT_DATE is '报送日期';
comment on column MBT_DM_410_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_410_C.RPT_STATUS is '报送状态';
comment on column MBT_DM_410_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_410_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_410_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_410_C.REMARKS is '备注';
comment on column MBT_DM_410_C.CHECK_FLAG is '校验标志';
comment on column MBT_DM_410_C.CHECK_DESC is '校验说明';
comment on column MBT_DM_410_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_410_C.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_410_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_410_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_410_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_410_C.DATA_FLAG is '数据标志';
comment on column MBT_DM_410_C.DATA_OP is '操作标志';
comment on column MBT_DM_410_C.DATA_SOURCE is '数据来源';
comment on column MBT_DM_410_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_410_C.DATA_HASH is '数据HASH';
comment on column MBT_DM_410_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_410_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_410_C.DATA_CRT_USER is '创建人';
comment on column MBT_DM_410_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_410_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_410_C.DATA_CHG_USER is '修改人';
comment on column MBT_DM_410_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_410_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_410_C.DATA_APV_USER is '审核人';
comment on column MBT_DM_410_C.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_410_C.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_410_C.RSV1 is '备用字段';
comment on column MBT_DM_410_C.RSV2 is '备用字段';
comment on column MBT_DM_410_C.RSV3 is '备用字段';
comment on column MBT_DM_410_C.RSV4 is '备用字段';
comment on column MBT_DM_410_C.RSV5 is '备用字段';
create table MBT_DM_410_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ARLP_AMT NUMBER(15),
D_ARLP_AMT_ORG NUMBER(15),
D_ARLP_CERT_NUM VARCHAR(80),
D_ARLP_CERT_TYPE VARCHAR(2),
D_ARLP_ID_TYPE VARCHAR(1),
D_ARLP_NAME VARCHAR(160),
D_ARLP_TYPE VARCHAR(1),
D_MAX_GUAR_MCC VARCHAR(60),
D_WARTY_SIGN VARCHAR(1),
ACTU_COTRL_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_410_D is '企业借贷账户信息-相关还款责任人段';
comment on column MBT_DM_410_D.DATA_ID is '数据ID';
comment on column MBT_DM_410_D.DATA_DATE is '数据日期';
comment on column MBT_DM_410_D.CORP_ID is '法人ID';
comment on column MBT_DM_410_D.ORG_ID is '机构ID';
comment on column MBT_DM_410_D.GROUP_ID is '数据分组';
comment on column MBT_DM_410_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_410_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_410_D.D_ARLP_AMT is '还款责任金额';
comment on column MBT_DM_410_D.D_ARLP_AMT_ORG is '还款责任金额_原始数据金额';
comment on column MBT_DM_410_D.D_ARLP_CERT_NUM is '责任人身份标识号码';
comment on column MBT_DM_410_D.D_ARLP_CERT_TYPE is '责任人身份标识类型';
comment on column MBT_DM_410_D.D_ARLP_ID_TYPE is '身份类别';
comment on column MBT_DM_410_D.D_ARLP_NAME is '责任人名称';
comment on column MBT_DM_410_D.D_ARLP_TYPE is '还款责任人类型';
comment on column MBT_DM_410_D.D_MAX_GUAR_MCC is '保证合同编号';
comment on column MBT_DM_410_D.D_WARTY_SIGN is '联保标志';
comment on column MBT_DM_410_D.ACTU_COTRL_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_410_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_410_D.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_410_D.CUST_NO is '客户号';
comment on column MBT_DM_410_D.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_410_D.PART_TYPE is '段标识';
comment on column MBT_DM_410_D.PART_NAME is '段名称';
comment on column MBT_DM_410_D.START_DATE is '起始日期';
comment on column MBT_DM_410_D.END_DATE is '结束日期';
comment on column MBT_DM_410_D.BATCH_NO is '批次号';
comment on column MBT_DM_410_D.ROW_NUM is '行号';
comment on column MBT_DM_410_D.IS_RPT is '是否报送';
comment on column MBT_DM_410_D.IS_VALID is '是否有效';
comment on column MBT_DM_410_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_410_D.OPT_FLAG is '操作标识';
comment on column MBT_DM_410_D.RPT_DATE is '报送日期';
comment on column MBT_DM_410_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_410_D.RPT_STATUS is '报送状态';
comment on column MBT_DM_410_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_410_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_410_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_410_D.REMARKS is '备注';
comment on column MBT_DM_410_D.CHECK_FLAG is '校验标志';
comment on column MBT_DM_410_D.CHECK_DESC is '校验说明';
comment on column MBT_DM_410_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_410_D.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_410_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_410_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_410_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_410_D.DATA_FLAG is '数据标志';
comment on column MBT_DM_410_D.DATA_OP is '操作标志';
comment on column MBT_DM_410_D.DATA_SOURCE is '数据来源';
comment on column MBT_DM_410_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_410_D.DATA_HASH is '数据HASH';
comment on column MBT_DM_410_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_410_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_410_D.DATA_CRT_USER is '创建人';
comment on column MBT_DM_410_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_410_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_410_D.DATA_CHG_USER is '修改人';
comment on column MBT_DM_410_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_410_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_410_D.DATA_APV_USER is '审核人';
comment on column MBT_DM_410_D.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_410_D.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_410_D.RSV1 is '备用字段';
comment on column MBT_DM_410_D.RSV2 is '备用字段';
comment on column MBT_DM_410_D.RSV3 is '备用字段';
comment on column MBT_DM_410_D.RSV4 is '备用字段';
comment on column MBT_DM_410_D.RSV5 is '备用字段';
create table MBT_DM_410_E (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
E_CCC VARCHAR(60),
ACTU_COTRL_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_410_E is '企业借贷账户信息-抵质押物信息段';
comment on column MBT_DM_410_E.DATA_ID is '数据ID';
comment on column MBT_DM_410_E.DATA_DATE is '数据日期';
comment on column MBT_DM_410_E.CORP_ID is '法人ID';
comment on column MBT_DM_410_E.ORG_ID is '机构ID';
comment on column MBT_DM_410_E.GROUP_ID is '数据分组';
comment on column MBT_DM_410_E.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_410_E.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_410_E.E_CCC is '抵（质）押合同标识码';
comment on column MBT_DM_410_E.ACTU_COTRL_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_410_E.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_410_E.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_410_E.CUST_NO is '客户号';
comment on column MBT_DM_410_E.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_410_E.PART_TYPE is '段标识';
comment on column MBT_DM_410_E.PART_NAME is '段名称';
comment on column MBT_DM_410_E.START_DATE is '起始日期';
comment on column MBT_DM_410_E.END_DATE is '结束日期';
comment on column MBT_DM_410_E.BATCH_NO is '批次号';
comment on column MBT_DM_410_E.ROW_NUM is '行号';
comment on column MBT_DM_410_E.IS_RPT is '是否报送';
comment on column MBT_DM_410_E.IS_VALID is '是否有效';
comment on column MBT_DM_410_E.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_410_E.OPT_FLAG is '操作标识';
comment on column MBT_DM_410_E.RPT_DATE is '报送日期';
comment on column MBT_DM_410_E.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_410_E.RPT_STATUS is '报送状态';
comment on column MBT_DM_410_E.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_410_E.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_410_E.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_410_E.REMARKS is '备注';
comment on column MBT_DM_410_E.CHECK_FLAG is '校验标志';
comment on column MBT_DM_410_E.CHECK_DESC is '校验说明';
comment on column MBT_DM_410_E.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_410_E.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_410_E.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_410_E.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_410_E.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_410_E.DATA_FLAG is '数据标志';
comment on column MBT_DM_410_E.DATA_OP is '操作标志';
comment on column MBT_DM_410_E.DATA_SOURCE is '数据来源';
comment on column MBT_DM_410_E.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_410_E.DATA_HASH is '数据HASH';
comment on column MBT_DM_410_E.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_E.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_E.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_410_E.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_410_E.DATA_CRT_USER is '创建人';
comment on column MBT_DM_410_E.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_410_E.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_410_E.DATA_CHG_USER is '修改人';
comment on column MBT_DM_410_E.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_410_E.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_410_E.DATA_APV_USER is '审核人';
comment on column MBT_DM_410_E.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_410_E.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_410_E.RSV1 is '备用字段';
comment on column MBT_DM_410_E.RSV2 is '备用字段';
comment on column MBT_DM_410_E.RSV3 is '备用字段';
comment on column MBT_DM_410_E.RSV4 is '备用字段';
comment on column MBT_DM_410_E.RSV5 is '备用字段';
create table MBT_DM_410_F (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
F_MCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_410_F is '企业借贷账户信息-授信额度信息段';
comment on column MBT_DM_410_F.DATA_ID is '数据ID';
comment on column MBT_DM_410_F.DATA_DATE is '数据日期';
comment on column MBT_DM_410_F.CORP_ID is '法人ID';
comment on column MBT_DM_410_F.ORG_ID is '机构ID';
comment on column MBT_DM_410_F.GROUP_ID is '数据分组';
comment on column MBT_DM_410_F.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_410_F.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_410_F.F_MCC is '授信协议标识码';
comment on column MBT_DM_410_F.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_410_F.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_410_F.CUST_NO is '客户号';
comment on column MBT_DM_410_F.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_410_F.PART_TYPE is '段标识';
comment on column MBT_DM_410_F.PART_NAME is '段名称';
comment on column MBT_DM_410_F.START_DATE is '起始日期';
comment on column MBT_DM_410_F.END_DATE is '结束日期';
comment on column MBT_DM_410_F.BATCH_NO is '批次号';
comment on column MBT_DM_410_F.ROW_NUM is '行号';
comment on column MBT_DM_410_F.IS_RPT is '是否报送';
comment on column MBT_DM_410_F.IS_VALID is '是否有效';
comment on column MBT_DM_410_F.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_410_F.OPT_FLAG is '操作标识';
comment on column MBT_DM_410_F.RPT_DATE is '报送日期';
comment on column MBT_DM_410_F.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_410_F.RPT_STATUS is '报送状态';
comment on column MBT_DM_410_F.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_410_F.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_410_F.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_410_F.REMARKS is '备注';
comment on column MBT_DM_410_F.CHECK_FLAG is '校验标志';
comment on column MBT_DM_410_F.CHECK_DESC is '校验说明';
comment on column MBT_DM_410_F.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_410_F.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_410_F.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_410_F.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_410_F.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_410_F.DATA_FLAG is '数据标志';
comment on column MBT_DM_410_F.DATA_OP is '操作标志';
comment on column MBT_DM_410_F.DATA_SOURCE is '数据来源';
comment on column MBT_DM_410_F.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_410_F.DATA_HASH is '数据HASH';
comment on column MBT_DM_410_F.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_F.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_F.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_410_F.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_410_F.DATA_CRT_USER is '创建人';
comment on column MBT_DM_410_F.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_410_F.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_410_F.DATA_CHG_USER is '修改人';
comment on column MBT_DM_410_F.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_410_F.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_410_F.DATA_APV_USER is '审核人';
comment on column MBT_DM_410_F.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_410_F.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_410_F.RSV1 is '备用字段';
comment on column MBT_DM_410_F.RSV2 is '备用字段';
comment on column MBT_DM_410_F.RSV3 is '备用字段';
comment on column MBT_DM_410_F.RSV4 is '备用字段';
comment on column MBT_DM_410_F.RSV5 is '备用字段';
create table MBT_DM_410_G (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_INIT_CED_ORG_CODE VARCHAR(18),
G_INIT_CRED_NAME VARCHAR(160),
G_INIT_RPY_STS VARCHAR(1),
G_ORIG_DBT_CATE VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_410_G is '企业借贷账户信息-初始债权说明段';
comment on column MBT_DM_410_G.DATA_ID is '数据ID';
comment on column MBT_DM_410_G.DATA_DATE is '数据日期';
comment on column MBT_DM_410_G.CORP_ID is '法人ID';
comment on column MBT_DM_410_G.ORG_ID is '机构ID';
comment on column MBT_DM_410_G.GROUP_ID is '数据分组';
comment on column MBT_DM_410_G.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_410_G.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_410_G.G_INIT_CED_ORG_CODE is '初始债权人机构代码';
comment on column MBT_DM_410_G.G_INIT_CRED_NAME is '初始债权人名称';
comment on column MBT_DM_410_G.G_INIT_RPY_STS is '债权转移时的还款状态';
comment on column MBT_DM_410_G.G_ORIG_DBT_CATE is '原债务种类';
comment on column MBT_DM_410_G.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_410_G.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_410_G.CUST_NO is '客户号';
comment on column MBT_DM_410_G.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_410_G.PART_TYPE is '段标识';
comment on column MBT_DM_410_G.PART_NAME is '段名称';
comment on column MBT_DM_410_G.START_DATE is '起始日期';
comment on column MBT_DM_410_G.END_DATE is '结束日期';
comment on column MBT_DM_410_G.BATCH_NO is '批次号';
comment on column MBT_DM_410_G.ROW_NUM is '行号';
comment on column MBT_DM_410_G.IS_RPT is '是否报送';
comment on column MBT_DM_410_G.IS_VALID is '是否有效';
comment on column MBT_DM_410_G.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_410_G.OPT_FLAG is '操作标识';
comment on column MBT_DM_410_G.RPT_DATE is '报送日期';
comment on column MBT_DM_410_G.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_410_G.RPT_STATUS is '报送状态';
comment on column MBT_DM_410_G.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_410_G.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_410_G.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_410_G.REMARKS is '备注';
comment on column MBT_DM_410_G.CHECK_FLAG is '校验标志';
comment on column MBT_DM_410_G.CHECK_DESC is '校验说明';
comment on column MBT_DM_410_G.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_410_G.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_410_G.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_410_G.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_410_G.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_410_G.DATA_FLAG is '数据标志';
comment on column MBT_DM_410_G.DATA_OP is '操作标志';
comment on column MBT_DM_410_G.DATA_SOURCE is '数据来源';
comment on column MBT_DM_410_G.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_410_G.DATA_HASH is '数据HASH';
comment on column MBT_DM_410_G.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_G.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_G.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_410_G.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_410_G.DATA_CRT_USER is '创建人';
comment on column MBT_DM_410_G.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_410_G.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_410_G.DATA_CHG_USER is '修改人';
comment on column MBT_DM_410_G.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_410_G.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_410_G.DATA_APV_USER is '审核人';
comment on column MBT_DM_410_G.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_410_G.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_410_G.RSV1 is '备用字段';
comment on column MBT_DM_410_G.RSV2 is '备用字段';
comment on column MBT_DM_410_G.RSV3 is '备用字段';
comment on column MBT_DM_410_G.RSV4 is '备用字段';
comment on column MBT_DM_410_G.RSV5 is '备用字段';
create table MBT_DM_410_H (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
H_ACCT_BAL NUMBER(15),
H_ACCT_BAL_LCY NUMBER(15),
H_ACCT_STATUS VARCHAR(2),
H_BAL_CHG_DATE VARCHAR(8),
H_CLOSE_DATE VARCHAR(8),
H_FIVE_CATE VARCHAR(1),
H_FIVE_CATE_ADJ_DATE VARCHAR(8),
H_LAT_AGRR_RPY_AMT NUMBER(15),
H_LAT_AGRR_RPY_AMT_LCY NUMBER(15),
H_LAT_AGRR_RPY_DATE VARCHAR(8),
H_LAT_RPY_AMT NUMBER(15),
H_LAT_RPY_AMT_LCY NUMBER(15),
H_LAT_RPY_DATE VARCHAR(8),
H_LAT_RPY_PRINC_AMT NUMBER(15),
H_LAT_RPY_PRINC_AMT_LCY NUMBER(15),
H_NXT_AGRR_RPY_DATE VARCHAR(8),
H_OVERD_DY NUMBER(3),
H_OVERD_PRINC NUMBER(15),
H_OVERD_PRINC_LCY NUMBER(15),
H_PYMT_PRD NUMBER(3),
H_RPMT_TYPE VARCHAR(2),
H_TOT_OVERD NUMBER(15),
H_TOT_OVERD_LCY NUMBER(15),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_410_H is '企业借贷账户信息-还款表现信息段';
comment on column MBT_DM_410_H.DATA_ID is '数据ID';
comment on column MBT_DM_410_H.DATA_DATE is '数据日期';
comment on column MBT_DM_410_H.CORP_ID is '法人ID';
comment on column MBT_DM_410_H.ORG_ID is '机构ID';
comment on column MBT_DM_410_H.GROUP_ID is '数据分组';
comment on column MBT_DM_410_H.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_410_H.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_410_H.H_ACCT_BAL is '余额';
comment on column MBT_DM_410_H.H_ACCT_BAL_LCY is '余额人民币金额';
comment on column MBT_DM_410_H.H_ACCT_STATUS is '账户状态';
comment on column MBT_DM_410_H.H_BAL_CHG_DATE is '余额变化日期';
comment on column MBT_DM_410_H.H_CLOSE_DATE is '账户关闭日期';
comment on column MBT_DM_410_H.H_FIVE_CATE is '五级分类';
comment on column MBT_DM_410_H.H_FIVE_CATE_ADJ_DATE is '五级分类认定日期';
comment on column MBT_DM_410_H.H_LAT_AGRR_RPY_AMT is '最近一次约定还款金额';
comment on column MBT_DM_410_H.H_LAT_AGRR_RPY_AMT_LCY is '最近一次约定还款金额人民币金额';
comment on column MBT_DM_410_H.H_LAT_AGRR_RPY_DATE is '最近一次约定还款日';
comment on column MBT_DM_410_H.H_LAT_RPY_AMT is '最近一次实际还款金额';
comment on column MBT_DM_410_H.H_LAT_RPY_AMT_LCY is '最近一次实际还款金额人民币金额';
comment on column MBT_DM_410_H.H_LAT_RPY_DATE is '最近一次实际还款日期';
comment on column MBT_DM_410_H.H_LAT_RPY_PRINC_AMT is '最近一次实际归还本金';
comment on column MBT_DM_410_H.H_LAT_RPY_PRINC_AMT_LCY is '最近一次实际归还本金人民币金额';
comment on column MBT_DM_410_H.H_NXT_AGRR_RPY_DATE is '下一次约定还款日期';
comment on column MBT_DM_410_H.H_OVERD_DY is '当前逾期天数';
comment on column MBT_DM_410_H.H_OVERD_PRINC is '当前逾期本金';
comment on column MBT_DM_410_H.H_OVERD_PRINC_LCY is '当前逾期本金人民币金额';
comment on column MBT_DM_410_H.H_PYMT_PRD is '剩余还款月数';
comment on column MBT_DM_410_H.H_RPMT_TYPE is '还款形式';
comment on column MBT_DM_410_H.H_TOT_OVERD is '当前逾期总额';
comment on column MBT_DM_410_H.H_TOT_OVERD_LCY is '当前逾期总额人民币金额';
comment on column MBT_DM_410_H.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_410_H.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_410_H.CUST_NO is '客户号';
comment on column MBT_DM_410_H.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_410_H.PART_TYPE is '段标识';
comment on column MBT_DM_410_H.PART_NAME is '段名称';
comment on column MBT_DM_410_H.START_DATE is '起始日期';
comment on column MBT_DM_410_H.END_DATE is '结束日期';
comment on column MBT_DM_410_H.BATCH_NO is '批次号';
comment on column MBT_DM_410_H.ROW_NUM is '行号';
comment on column MBT_DM_410_H.IS_RPT is '是否报送';
comment on column MBT_DM_410_H.IS_VALID is '是否有效';
comment on column MBT_DM_410_H.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_410_H.OPT_FLAG is '操作标识';
comment on column MBT_DM_410_H.RPT_DATE is '报送日期';
comment on column MBT_DM_410_H.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_410_H.RPT_STATUS is '报送状态';
comment on column MBT_DM_410_H.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_410_H.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_410_H.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_410_H.REMARKS is '备注';
comment on column MBT_DM_410_H.CHECK_FLAG is '校验标志';
comment on column MBT_DM_410_H.CHECK_DESC is '校验说明';
comment on column MBT_DM_410_H.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_410_H.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_410_H.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_410_H.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_410_H.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_410_H.DATA_FLAG is '数据标志';
comment on column MBT_DM_410_H.DATA_OP is '操作标志';
comment on column MBT_DM_410_H.DATA_SOURCE is '数据来源';
comment on column MBT_DM_410_H.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_410_H.DATA_HASH is '数据HASH';
comment on column MBT_DM_410_H.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_H.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_H.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_410_H.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_410_H.DATA_CRT_USER is '创建人';
comment on column MBT_DM_410_H.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_410_H.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_410_H.DATA_CHG_USER is '修改人';
comment on column MBT_DM_410_H.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_410_H.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_410_H.DATA_APV_USER is '审核人';
comment on column MBT_DM_410_H.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_410_H.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_410_H.RSV1 is '备用字段';
comment on column MBT_DM_410_H.RSV2 is '备用字段';
comment on column MBT_DM_410_H.RSV3 is '备用字段';
comment on column MBT_DM_410_H.RSV4 is '备用字段';
comment on column MBT_DM_410_H.RSV5 is '备用字段';
create table MBT_DM_410_I (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
I_CHAN_TRAN_TYPE VARCHAR(2),
I_DET_INFO VARCHAR(400),
I_DUE_TRAN_MON NUMBER(3),
I_TRAN_AMT NUMBER(15),
I_TRAN_AMT_ORG NUMBER(15),
I_TRAN_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_410_I is '企业借贷账户信息-特定交易说明段';
comment on column MBT_DM_410_I.DATA_ID is '数据ID';
comment on column MBT_DM_410_I.DATA_DATE is '数据日期';
comment on column MBT_DM_410_I.CORP_ID is '法人ID';
comment on column MBT_DM_410_I.ORG_ID is '机构ID';
comment on column MBT_DM_410_I.GROUP_ID is '数据分组';
comment on column MBT_DM_410_I.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_410_I.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_410_I.I_CHAN_TRAN_TYPE is '交易类型';
comment on column MBT_DM_410_I.I_DET_INFO is '交易明细信息';
comment on column MBT_DM_410_I.I_DUE_TRAN_MON is '到期日期变更月数';
comment on column MBT_DM_410_I.I_TRAN_AMT is '交易金额';
comment on column MBT_DM_410_I.I_TRAN_AMT_ORG is '交易金额_原始数据金额';
comment on column MBT_DM_410_I.I_TRAN_DATE is '交易日期';
comment on column MBT_DM_410_I.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_410_I.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_410_I.CUST_NO is '客户号';
comment on column MBT_DM_410_I.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_410_I.PART_TYPE is '段标识';
comment on column MBT_DM_410_I.PART_NAME is '段名称';
comment on column MBT_DM_410_I.START_DATE is '起始日期';
comment on column MBT_DM_410_I.END_DATE is '结束日期';
comment on column MBT_DM_410_I.BATCH_NO is '批次号';
comment on column MBT_DM_410_I.ROW_NUM is '行号';
comment on column MBT_DM_410_I.IS_RPT is '是否报送';
comment on column MBT_DM_410_I.IS_VALID is '是否有效';
comment on column MBT_DM_410_I.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_410_I.OPT_FLAG is '操作标识';
comment on column MBT_DM_410_I.RPT_DATE is '报送日期';
comment on column MBT_DM_410_I.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_410_I.RPT_STATUS is '报送状态';
comment on column MBT_DM_410_I.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_410_I.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_410_I.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_410_I.REMARKS is '备注';
comment on column MBT_DM_410_I.CHECK_FLAG is '校验标志';
comment on column MBT_DM_410_I.CHECK_DESC is '校验说明';
comment on column MBT_DM_410_I.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_410_I.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_410_I.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_410_I.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_410_I.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_410_I.DATA_FLAG is '数据标志';
comment on column MBT_DM_410_I.DATA_OP is '操作标志';
comment on column MBT_DM_410_I.DATA_SOURCE is '数据来源';
comment on column MBT_DM_410_I.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_410_I.DATA_HASH is '数据HASH';
comment on column MBT_DM_410_I.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_I.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_410_I.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_410_I.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_410_I.DATA_CRT_USER is '创建人';
comment on column MBT_DM_410_I.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_410_I.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_410_I.DATA_CHG_USER is '修改人';
comment on column MBT_DM_410_I.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_410_I.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_410_I.DATA_APV_USER is '审核人';
comment on column MBT_DM_410_I.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_410_I.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_410_I.RSV1 is '备用字段';
comment on column MBT_DM_410_I.RSV2 is '备用字段';
comment on column MBT_DM_410_I.RSV3 is '备用字段';
comment on column MBT_DM_410_I.RSV4 is '备用字段';
comment on column MBT_DM_410_I.RSV5 is '备用字段';
create table MBT_PM_410 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
O_BIZ_CODE VARCHAR(60),
N_BIZ_CODE VARCHAR(60),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_410 is '企业借贷账户信息';
comment on column MBT_PM_410.DATA_ID is '数据ID';
comment on column MBT_PM_410.DATA_DATE is '数据日期';
comment on column MBT_PM_410.CORP_ID is '法人ID';
comment on column MBT_PM_410.ORG_ID is '机构ID';
comment on column MBT_PM_410.GROUP_ID is '数据分组';
comment on column MBT_PM_410.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_410.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_410.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_410.O_BIZ_CODE is '原业务标识码';
comment on column MBT_PM_410.N_BIZ_CODE is '新业务标识码';
comment on column MBT_PM_410.SECTION_CHG_CNT is '段变更';
comment on column MBT_PM_410.SECTION_DEL_CNT is '段删除';
comment on column MBT_PM_410.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_PM_410.IDN_CHG_CNT is '标识项变更';
comment on column MBT_PM_410.CUST_NO is '客户号';
comment on column MBT_PM_410.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_410.PART_TYPE is '段标识';
comment on column MBT_PM_410.PART_NAME is '段名称';
comment on column MBT_PM_410.START_DATE is '起始日期';
comment on column MBT_PM_410.END_DATE is '结束日期';
comment on column MBT_PM_410.BATCH_NO is '批次号';
comment on column MBT_PM_410.ROW_NUM is '行号';
comment on column MBT_PM_410.IS_RPT is '是否报送';
comment on column MBT_PM_410.IS_VALID is '是否有效';
comment on column MBT_PM_410.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_410.OPT_FLAG is '操作标识';
comment on column MBT_PM_410.RPT_DATE is '报送日期';
comment on column MBT_PM_410.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_410.RPT_STATUS is '报送状态';
comment on column MBT_PM_410.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_410.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_410.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_410.REMARKS is '备注';
comment on column MBT_PM_410.CHECK_FLAG is '校验标志';
comment on column MBT_PM_410.CHECK_DESC is '校验说明';
comment on column MBT_PM_410.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_410.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_410.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_410.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_410.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_410.DATA_FLAG is '数据标志';
comment on column MBT_PM_410.DATA_OP is '操作标志';
comment on column MBT_PM_410.DATA_SOURCE is '数据来源';
comment on column MBT_PM_410.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_410.DATA_HASH is '数据HASH';
comment on column MBT_PM_410.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_410.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_410.DATA_CRT_USER is '创建人';
comment on column MBT_PM_410.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_410.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_410.DATA_CHG_USER is '修改人';
comment on column MBT_PM_410.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_410.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_410.DATA_APV_USER is '审核人';
comment on column MBT_PM_410.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_410.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_410.RSV1 is '备用字段';
comment on column MBT_PM_410.RSV2 is '备用字段';
comment on column MBT_PM_410.RSV3 is '备用字段';
comment on column MBT_PM_410.RSV4 is '备用字段';
comment on column MBT_PM_410.RSV5 is '备用字段';
create table MBT_PM_410_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
B_ACCT_TYPE VARCHAR(2),
B_ID_NUM VARCHAR(80),
B_ID_TYPE VARCHAR(2),
B_INFO_UP_DATE VARCHAR(8),
B_INF_REC_TYPE VARCHAR(3),
B_MNGMT_ORG_CODE VARCHAR(14),
B_MONTH VARCHAR(8),
B_NAME VARCHAR(160),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
MON_SETTLE_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_410_B is '企业借贷账户信息-基础段';
comment on column MBT_PM_410_B.DATA_ID is '数据ID';
comment on column MBT_PM_410_B.DATA_DATE is '数据日期';
comment on column MBT_PM_410_B.CORP_ID is '法人ID';
comment on column MBT_PM_410_B.ORG_ID is '机构ID';
comment on column MBT_PM_410_B.GROUP_ID is '数据分组';
comment on column MBT_PM_410_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_410_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_410_B.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_410_B.B_ACCT_TYPE is '账户类型';
comment on column MBT_PM_410_B.B_ID_NUM is '借款人身份标识号码';
comment on column MBT_PM_410_B.B_ID_TYPE is '借款人身份标识类型';
comment on column MBT_PM_410_B.B_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_410_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_PM_410_B.B_MNGMT_ORG_CODE is '业务管理机构代码';
comment on column MBT_PM_410_B.B_MONTH is '月份';
comment on column MBT_PM_410_B.B_NAME is '借款人名称';
comment on column MBT_PM_410_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_410_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_PM_410_B.MON_SETTLE_DATE is '月结日';
comment on column MBT_PM_410_B.CUST_NO is '客户号';
comment on column MBT_PM_410_B.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_410_B.PART_TYPE is '段标识';
comment on column MBT_PM_410_B.PART_NAME is '段名称';
comment on column MBT_PM_410_B.START_DATE is '起始日期';
comment on column MBT_PM_410_B.END_DATE is '结束日期';
comment on column MBT_PM_410_B.BATCH_NO is '批次号';
comment on column MBT_PM_410_B.ROW_NUM is '行号';
comment on column MBT_PM_410_B.IS_RPT is '是否报送';
comment on column MBT_PM_410_B.IS_VALID is '是否有效';
comment on column MBT_PM_410_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_410_B.OPT_FLAG is '操作标识';
comment on column MBT_PM_410_B.RPT_DATE is '报送日期';
comment on column MBT_PM_410_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_410_B.RPT_STATUS is '报送状态';
comment on column MBT_PM_410_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_410_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_410_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_410_B.REMARKS is '备注';
comment on column MBT_PM_410_B.CHECK_FLAG is '校验标志';
comment on column MBT_PM_410_B.CHECK_DESC is '校验说明';
comment on column MBT_PM_410_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_410_B.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_410_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_410_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_410_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_410_B.DATA_FLAG is '数据标志';
comment on column MBT_PM_410_B.DATA_OP is '操作标志';
comment on column MBT_PM_410_B.DATA_SOURCE is '数据来源';
comment on column MBT_PM_410_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_410_B.DATA_HASH is '数据HASH';
comment on column MBT_PM_410_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_410_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_410_B.DATA_CRT_USER is '创建人';
comment on column MBT_PM_410_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_410_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_410_B.DATA_CHG_USER is '修改人';
comment on column MBT_PM_410_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_410_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_410_B.DATA_APV_USER is '审核人';
comment on column MBT_PM_410_B.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_410_B.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_410_B.RSV1 is '备用字段';
comment on column MBT_PM_410_B.RSV2 is '备用字段';
comment on column MBT_PM_410_B.RSV3 is '备用字段';
comment on column MBT_PM_410_B.RSV4 is '备用字段';
comment on column MBT_PM_410_B.RSV5 is '备用字段';
create table MBT_PM_410_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ACCT_CRED_LINE_AMT NUMBER(15),
C_ACCT_CRED_LINE_AMT_LCY NUMBER(15),
C_ACT_INVEST VARCHAR(5),
C_APPLY_BUSI_DIST VARCHAR(6),
C_ASSET_TRAND_FLAG VARCHAR(1),
C_BUSI_DTL_LINES VARCHAR(2),
C_BUSI_LINES VARCHAR(2),
C_CY VARCHAR(3),
C_DUE_DATE VARCHAR(8),
C_FLAG VARCHAR(1),
C_FUND_SOU VARCHAR(2),
C_GUAR_MODE VARCHAR(1),
C_LOAN_AMT NUMBER(15),
C_LOAN_AMT_LCY NUMBER(15),
C_LOAN_TIME_LIM_CAT VARCHAR(2),
C_LOA_FRM VARCHAR(1),
C_OPEN_DATE VARCHAR(8),
C_OTH_REPY_GUAR_WAY VARCHAR(1),
C_REPAY_FREQCY VARCHAR(2),
C_REPAY_MODE VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_410_C is '企业借贷账户信息-基本信息段';
comment on column MBT_PM_410_C.DATA_ID is '数据ID';
comment on column MBT_PM_410_C.DATA_DATE is '数据日期';
comment on column MBT_PM_410_C.CORP_ID is '法人ID';
comment on column MBT_PM_410_C.ORG_ID is '机构ID';
comment on column MBT_PM_410_C.GROUP_ID is '数据分组';
comment on column MBT_PM_410_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_410_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_410_C.C_ACCT_CRED_LINE_AMT is '信用额度';
comment on column MBT_PM_410_C.C_ACCT_CRED_LINE_AMT_LCY is '信用额度人民币金额';
comment on column MBT_PM_410_C.C_ACT_INVEST is '贷款实际投向';
comment on column MBT_PM_410_C.C_APPLY_BUSI_DIST is '业务申请地行政区划代码';
comment on column MBT_PM_410_C.C_ASSET_TRAND_FLAG is '资产转让标志';
comment on column MBT_PM_410_C.C_BUSI_DTL_LINES is '借贷业务种类细分';
comment on column MBT_PM_410_C.C_BUSI_LINES is '借贷业务大类';
comment on column MBT_PM_410_C.C_CY is '币种';
comment on column MBT_PM_410_C.C_DUE_DATE is '到期日期';
comment on column MBT_PM_410_C.C_FLAG is '分次放款标志';
comment on column MBT_PM_410_C.C_FUND_SOU is '业务经营类型';
comment on column MBT_PM_410_C.C_GUAR_MODE is '担保方式';
comment on column MBT_PM_410_C.C_LOAN_AMT is '借款金额';
comment on column MBT_PM_410_C.C_LOAN_AMT_LCY is '借款金额人民币金额';
comment on column MBT_PM_410_C.C_LOAN_TIME_LIM_CAT is '借款期限分类';
comment on column MBT_PM_410_C.C_LOA_FRM is '贷款发放形式';
comment on column MBT_PM_410_C.C_OPEN_DATE is '开户日期';
comment on column MBT_PM_410_C.C_OTH_REPY_GUAR_WAY is '其他还款保证方式';
comment on column MBT_PM_410_C.C_REPAY_FREQCY is '还款频率';
comment on column MBT_PM_410_C.C_REPAY_MODE is '还款方式';
comment on column MBT_PM_410_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_410_C.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_410_C.CUST_NO is '客户号';
comment on column MBT_PM_410_C.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_410_C.PART_TYPE is '段标识';
comment on column MBT_PM_410_C.PART_NAME is '段名称';
comment on column MBT_PM_410_C.START_DATE is '起始日期';
comment on column MBT_PM_410_C.END_DATE is '结束日期';
comment on column MBT_PM_410_C.BATCH_NO is '批次号';
comment on column MBT_PM_410_C.ROW_NUM is '行号';
comment on column MBT_PM_410_C.IS_RPT is '是否报送';
comment on column MBT_PM_410_C.IS_VALID is '是否有效';
comment on column MBT_PM_410_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_410_C.OPT_FLAG is '操作标识';
comment on column MBT_PM_410_C.RPT_DATE is '报送日期';
comment on column MBT_PM_410_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_410_C.RPT_STATUS is '报送状态';
comment on column MBT_PM_410_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_410_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_410_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_410_C.REMARKS is '备注';
comment on column MBT_PM_410_C.CHECK_FLAG is '校验标志';
comment on column MBT_PM_410_C.CHECK_DESC is '校验说明';
comment on column MBT_PM_410_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_410_C.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_410_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_410_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_410_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_410_C.DATA_FLAG is '数据标志';
comment on column MBT_PM_410_C.DATA_OP is '操作标志';
comment on column MBT_PM_410_C.DATA_SOURCE is '数据来源';
comment on column MBT_PM_410_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_410_C.DATA_HASH is '数据HASH';
comment on column MBT_PM_410_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_410_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_410_C.DATA_CRT_USER is '创建人';
comment on column MBT_PM_410_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_410_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_410_C.DATA_CHG_USER is '修改人';
comment on column MBT_PM_410_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_410_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_410_C.DATA_APV_USER is '审核人';
comment on column MBT_PM_410_C.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_410_C.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_410_C.RSV1 is '备用字段';
comment on column MBT_PM_410_C.RSV2 is '备用字段';
comment on column MBT_PM_410_C.RSV3 is '备用字段';
comment on column MBT_PM_410_C.RSV4 is '备用字段';
comment on column MBT_PM_410_C.RSV5 is '备用字段';
create table MBT_PM_410_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ARLP_AMT NUMBER(15),
D_ARLP_AMT_ORG NUMBER(15),
D_ARLP_CERT_NUM VARCHAR(80),
D_ARLP_CERT_TYPE VARCHAR(2),
D_ARLP_ID_TYPE VARCHAR(1),
D_ARLP_NAME VARCHAR(160),
D_ARLP_TYPE VARCHAR(1),
D_MAX_GUAR_MCC VARCHAR(60),
D_WARTY_SIGN VARCHAR(1),
ACTU_COTRL_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_410_D is '企业借贷账户信息-相关还款责任人段';
comment on column MBT_PM_410_D.DATA_ID is '数据ID';
comment on column MBT_PM_410_D.DATA_DATE is '数据日期';
comment on column MBT_PM_410_D.CORP_ID is '法人ID';
comment on column MBT_PM_410_D.ORG_ID is '机构ID';
comment on column MBT_PM_410_D.GROUP_ID is '数据分组';
comment on column MBT_PM_410_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_410_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_410_D.D_ARLP_AMT is '还款责任金额';
comment on column MBT_PM_410_D.D_ARLP_AMT_ORG is '还款责任金额_原始数据金额';
comment on column MBT_PM_410_D.D_ARLP_CERT_NUM is '责任人身份标识号码';
comment on column MBT_PM_410_D.D_ARLP_CERT_TYPE is '责任人身份标识类型';
comment on column MBT_PM_410_D.D_ARLP_ID_TYPE is '身份类别';
comment on column MBT_PM_410_D.D_ARLP_NAME is '责任人名称';
comment on column MBT_PM_410_D.D_ARLP_TYPE is '还款责任人类型';
comment on column MBT_PM_410_D.D_MAX_GUAR_MCC is '保证合同编号';
comment on column MBT_PM_410_D.D_WARTY_SIGN is '联保标志';
comment on column MBT_PM_410_D.ACTU_COTRL_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_410_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_410_D.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_410_D.CUST_NO is '客户号';
comment on column MBT_PM_410_D.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_410_D.PART_TYPE is '段标识';
comment on column MBT_PM_410_D.PART_NAME is '段名称';
comment on column MBT_PM_410_D.START_DATE is '起始日期';
comment on column MBT_PM_410_D.END_DATE is '结束日期';
comment on column MBT_PM_410_D.BATCH_NO is '批次号';
comment on column MBT_PM_410_D.ROW_NUM is '行号';
comment on column MBT_PM_410_D.IS_RPT is '是否报送';
comment on column MBT_PM_410_D.IS_VALID is '是否有效';
comment on column MBT_PM_410_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_410_D.OPT_FLAG is '操作标识';
comment on column MBT_PM_410_D.RPT_DATE is '报送日期';
comment on column MBT_PM_410_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_410_D.RPT_STATUS is '报送状态';
comment on column MBT_PM_410_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_410_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_410_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_410_D.REMARKS is '备注';
comment on column MBT_PM_410_D.CHECK_FLAG is '校验标志';
comment on column MBT_PM_410_D.CHECK_DESC is '校验说明';
comment on column MBT_PM_410_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_410_D.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_410_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_410_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_410_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_410_D.DATA_FLAG is '数据标志';
comment on column MBT_PM_410_D.DATA_OP is '操作标志';
comment on column MBT_PM_410_D.DATA_SOURCE is '数据来源';
comment on column MBT_PM_410_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_410_D.DATA_HASH is '数据HASH';
comment on column MBT_PM_410_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_410_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_410_D.DATA_CRT_USER is '创建人';
comment on column MBT_PM_410_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_410_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_410_D.DATA_CHG_USER is '修改人';
comment on column MBT_PM_410_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_410_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_410_D.DATA_APV_USER is '审核人';
comment on column MBT_PM_410_D.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_410_D.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_410_D.RSV1 is '备用字段';
comment on column MBT_PM_410_D.RSV2 is '备用字段';
comment on column MBT_PM_410_D.RSV3 is '备用字段';
comment on column MBT_PM_410_D.RSV4 is '备用字段';
comment on column MBT_PM_410_D.RSV5 is '备用字段';
create table MBT_PM_410_E (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
E_CCC VARCHAR(60),
ACTU_COTRL_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_410_E is '企业借贷账户信息-抵质押物信息段';
comment on column MBT_PM_410_E.DATA_ID is '数据ID';
comment on column MBT_PM_410_E.DATA_DATE is '数据日期';
comment on column MBT_PM_410_E.CORP_ID is '法人ID';
comment on column MBT_PM_410_E.ORG_ID is '机构ID';
comment on column MBT_PM_410_E.GROUP_ID is '数据分组';
comment on column MBT_PM_410_E.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_410_E.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_410_E.E_CCC is '抵（质）押合同标识码';
comment on column MBT_PM_410_E.ACTU_COTRL_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_410_E.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_410_E.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_410_E.CUST_NO is '客户号';
comment on column MBT_PM_410_E.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_410_E.PART_TYPE is '段标识';
comment on column MBT_PM_410_E.PART_NAME is '段名称';
comment on column MBT_PM_410_E.START_DATE is '起始日期';
comment on column MBT_PM_410_E.END_DATE is '结束日期';
comment on column MBT_PM_410_E.BATCH_NO is '批次号';
comment on column MBT_PM_410_E.ROW_NUM is '行号';
comment on column MBT_PM_410_E.IS_RPT is '是否报送';
comment on column MBT_PM_410_E.IS_VALID is '是否有效';
comment on column MBT_PM_410_E.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_410_E.OPT_FLAG is '操作标识';
comment on column MBT_PM_410_E.RPT_DATE is '报送日期';
comment on column MBT_PM_410_E.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_410_E.RPT_STATUS is '报送状态';
comment on column MBT_PM_410_E.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_410_E.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_410_E.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_410_E.REMARKS is '备注';
comment on column MBT_PM_410_E.CHECK_FLAG is '校验标志';
comment on column MBT_PM_410_E.CHECK_DESC is '校验说明';
comment on column MBT_PM_410_E.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_410_E.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_410_E.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_410_E.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_410_E.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_410_E.DATA_FLAG is '数据标志';
comment on column MBT_PM_410_E.DATA_OP is '操作标志';
comment on column MBT_PM_410_E.DATA_SOURCE is '数据来源';
comment on column MBT_PM_410_E.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_410_E.DATA_HASH is '数据HASH';
comment on column MBT_PM_410_E.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_E.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_E.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_410_E.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_410_E.DATA_CRT_USER is '创建人';
comment on column MBT_PM_410_E.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_410_E.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_410_E.DATA_CHG_USER is '修改人';
comment on column MBT_PM_410_E.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_410_E.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_410_E.DATA_APV_USER is '审核人';
comment on column MBT_PM_410_E.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_410_E.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_410_E.RSV1 is '备用字段';
comment on column MBT_PM_410_E.RSV2 is '备用字段';
comment on column MBT_PM_410_E.RSV3 is '备用字段';
comment on column MBT_PM_410_E.RSV4 is '备用字段';
comment on column MBT_PM_410_E.RSV5 is '备用字段';
create table MBT_PM_410_F (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
F_MCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_410_F is '企业借贷账户信息-授信额度信息段';
comment on column MBT_PM_410_F.DATA_ID is '数据ID';
comment on column MBT_PM_410_F.DATA_DATE is '数据日期';
comment on column MBT_PM_410_F.CORP_ID is '法人ID';
comment on column MBT_PM_410_F.ORG_ID is '机构ID';
comment on column MBT_PM_410_F.GROUP_ID is '数据分组';
comment on column MBT_PM_410_F.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_410_F.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_410_F.F_MCC is '授信协议标识码';
comment on column MBT_PM_410_F.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_410_F.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_410_F.CUST_NO is '客户号';
comment on column MBT_PM_410_F.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_410_F.PART_TYPE is '段标识';
comment on column MBT_PM_410_F.PART_NAME is '段名称';
comment on column MBT_PM_410_F.START_DATE is '起始日期';
comment on column MBT_PM_410_F.END_DATE is '结束日期';
comment on column MBT_PM_410_F.BATCH_NO is '批次号';
comment on column MBT_PM_410_F.ROW_NUM is '行号';
comment on column MBT_PM_410_F.IS_RPT is '是否报送';
comment on column MBT_PM_410_F.IS_VALID is '是否有效';
comment on column MBT_PM_410_F.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_410_F.OPT_FLAG is '操作标识';
comment on column MBT_PM_410_F.RPT_DATE is '报送日期';
comment on column MBT_PM_410_F.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_410_F.RPT_STATUS is '报送状态';
comment on column MBT_PM_410_F.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_410_F.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_410_F.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_410_F.REMARKS is '备注';
comment on column MBT_PM_410_F.CHECK_FLAG is '校验标志';
comment on column MBT_PM_410_F.CHECK_DESC is '校验说明';
comment on column MBT_PM_410_F.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_410_F.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_410_F.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_410_F.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_410_F.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_410_F.DATA_FLAG is '数据标志';
comment on column MBT_PM_410_F.DATA_OP is '操作标志';
comment on column MBT_PM_410_F.DATA_SOURCE is '数据来源';
comment on column MBT_PM_410_F.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_410_F.DATA_HASH is '数据HASH';
comment on column MBT_PM_410_F.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_F.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_F.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_410_F.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_410_F.DATA_CRT_USER is '创建人';
comment on column MBT_PM_410_F.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_410_F.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_410_F.DATA_CHG_USER is '修改人';
comment on column MBT_PM_410_F.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_410_F.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_410_F.DATA_APV_USER is '审核人';
comment on column MBT_PM_410_F.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_410_F.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_410_F.RSV1 is '备用字段';
comment on column MBT_PM_410_F.RSV2 is '备用字段';
comment on column MBT_PM_410_F.RSV3 is '备用字段';
comment on column MBT_PM_410_F.RSV4 is '备用字段';
comment on column MBT_PM_410_F.RSV5 is '备用字段';
create table MBT_PM_410_G (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_INIT_CED_ORG_CODE VARCHAR(18),
G_INIT_CRED_NAME VARCHAR(160),
G_INIT_RPY_STS VARCHAR(1),
G_ORIG_DBT_CATE VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_410_G is '企业借贷账户信息-初始债权说明段';
comment on column MBT_PM_410_G.DATA_ID is '数据ID';
comment on column MBT_PM_410_G.DATA_DATE is '数据日期';
comment on column MBT_PM_410_G.CORP_ID is '法人ID';
comment on column MBT_PM_410_G.ORG_ID is '机构ID';
comment on column MBT_PM_410_G.GROUP_ID is '数据分组';
comment on column MBT_PM_410_G.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_410_G.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_410_G.G_INIT_CED_ORG_CODE is '初始债权人机构代码';
comment on column MBT_PM_410_G.G_INIT_CRED_NAME is '初始债权人名称';
comment on column MBT_PM_410_G.G_INIT_RPY_STS is '债权转移时的还款状态';
comment on column MBT_PM_410_G.G_ORIG_DBT_CATE is '原债务种类';
comment on column MBT_PM_410_G.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_410_G.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_410_G.CUST_NO is '客户号';
comment on column MBT_PM_410_G.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_410_G.PART_TYPE is '段标识';
comment on column MBT_PM_410_G.PART_NAME is '段名称';
comment on column MBT_PM_410_G.START_DATE is '起始日期';
comment on column MBT_PM_410_G.END_DATE is '结束日期';
comment on column MBT_PM_410_G.BATCH_NO is '批次号';
comment on column MBT_PM_410_G.ROW_NUM is '行号';
comment on column MBT_PM_410_G.IS_RPT is '是否报送';
comment on column MBT_PM_410_G.IS_VALID is '是否有效';
comment on column MBT_PM_410_G.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_410_G.OPT_FLAG is '操作标识';
comment on column MBT_PM_410_G.RPT_DATE is '报送日期';
comment on column MBT_PM_410_G.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_410_G.RPT_STATUS is '报送状态';
comment on column MBT_PM_410_G.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_410_G.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_410_G.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_410_G.REMARKS is '备注';
comment on column MBT_PM_410_G.CHECK_FLAG is '校验标志';
comment on column MBT_PM_410_G.CHECK_DESC is '校验说明';
comment on column MBT_PM_410_G.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_410_G.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_410_G.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_410_G.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_410_G.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_410_G.DATA_FLAG is '数据标志';
comment on column MBT_PM_410_G.DATA_OP is '操作标志';
comment on column MBT_PM_410_G.DATA_SOURCE is '数据来源';
comment on column MBT_PM_410_G.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_410_G.DATA_HASH is '数据HASH';
comment on column MBT_PM_410_G.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_G.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_G.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_410_G.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_410_G.DATA_CRT_USER is '创建人';
comment on column MBT_PM_410_G.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_410_G.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_410_G.DATA_CHG_USER is '修改人';
comment on column MBT_PM_410_G.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_410_G.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_410_G.DATA_APV_USER is '审核人';
comment on column MBT_PM_410_G.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_410_G.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_410_G.RSV1 is '备用字段';
comment on column MBT_PM_410_G.RSV2 is '备用字段';
comment on column MBT_PM_410_G.RSV3 is '备用字段';
comment on column MBT_PM_410_G.RSV4 is '备用字段';
comment on column MBT_PM_410_G.RSV5 is '备用字段';
create table MBT_PM_410_H (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
H_ACCT_BAL NUMBER(15),
H_ACCT_BAL_LCY NUMBER(15),
H_ACCT_STATUS VARCHAR(2),
H_BAL_CHG_DATE VARCHAR(8),
H_CLOSE_DATE VARCHAR(8),
H_FIVE_CATE VARCHAR(1),
H_FIVE_CATE_ADJ_DATE VARCHAR(8),
H_LAT_AGRR_RPY_AMT NUMBER(15),
H_LAT_AGRR_RPY_AMT_LCY NUMBER(15),
H_LAT_AGRR_RPY_DATE VARCHAR(8),
H_LAT_RPY_AMT NUMBER(15),
H_LAT_RPY_AMT_LCY NUMBER(15),
H_LAT_RPY_DATE VARCHAR(8),
H_LAT_RPY_PRINC_AMT NUMBER(15),
H_LAT_RPY_PRINC_AMT_LCY NUMBER(15),
H_NXT_AGRR_RPY_DATE VARCHAR(8),
H_OVERD_DY NUMBER(3),
H_OVERD_PRINC NUMBER(15),
H_OVERD_PRINC_LCY NUMBER(15),
H_PYMT_PRD NUMBER(3),
H_RPMT_TYPE VARCHAR(2),
H_TOT_OVERD NUMBER(15),
H_TOT_OVERD_LCY NUMBER(15),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_410_H is '企业借贷账户信息-还款表现信息段';
comment on column MBT_PM_410_H.DATA_ID is '数据ID';
comment on column MBT_PM_410_H.DATA_DATE is '数据日期';
comment on column MBT_PM_410_H.CORP_ID is '法人ID';
comment on column MBT_PM_410_H.ORG_ID is '机构ID';
comment on column MBT_PM_410_H.GROUP_ID is '数据分组';
comment on column MBT_PM_410_H.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_410_H.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_410_H.H_ACCT_BAL is '余额';
comment on column MBT_PM_410_H.H_ACCT_BAL_LCY is '余额人民币金额';
comment on column MBT_PM_410_H.H_ACCT_STATUS is '账户状态';
comment on column MBT_PM_410_H.H_BAL_CHG_DATE is '余额变化日期';
comment on column MBT_PM_410_H.H_CLOSE_DATE is '账户关闭日期';
comment on column MBT_PM_410_H.H_FIVE_CATE is '五级分类';
comment on column MBT_PM_410_H.H_FIVE_CATE_ADJ_DATE is '五级分类认定日期';
comment on column MBT_PM_410_H.H_LAT_AGRR_RPY_AMT is '最近一次约定还款金额';
comment on column MBT_PM_410_H.H_LAT_AGRR_RPY_AMT_LCY is '最近一次约定还款金额人民币金额';
comment on column MBT_PM_410_H.H_LAT_AGRR_RPY_DATE is '最近一次约定还款日';
comment on column MBT_PM_410_H.H_LAT_RPY_AMT is '最近一次实际还款金额';
comment on column MBT_PM_410_H.H_LAT_RPY_AMT_LCY is '最近一次实际还款金额人民币金额';
comment on column MBT_PM_410_H.H_LAT_RPY_DATE is '最近一次实际还款日期';
comment on column MBT_PM_410_H.H_LAT_RPY_PRINC_AMT is '最近一次实际归还本金';
comment on column MBT_PM_410_H.H_LAT_RPY_PRINC_AMT_LCY is '最近一次实际归还本金人民币金额';
comment on column MBT_PM_410_H.H_NXT_AGRR_RPY_DATE is '下一次约定还款日期';
comment on column MBT_PM_410_H.H_OVERD_DY is '当前逾期天数';
comment on column MBT_PM_410_H.H_OVERD_PRINC is '当前逾期本金';
comment on column MBT_PM_410_H.H_OVERD_PRINC_LCY is '当前逾期本金人民币金额';
comment on column MBT_PM_410_H.H_PYMT_PRD is '剩余还款月数';
comment on column MBT_PM_410_H.H_RPMT_TYPE is '还款形式';
comment on column MBT_PM_410_H.H_TOT_OVERD is '当前逾期总额';
comment on column MBT_PM_410_H.H_TOT_OVERD_LCY is '当前逾期总额人民币金额';
comment on column MBT_PM_410_H.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_410_H.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_410_H.CUST_NO is '客户号';
comment on column MBT_PM_410_H.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_410_H.PART_TYPE is '段标识';
comment on column MBT_PM_410_H.PART_NAME is '段名称';
comment on column MBT_PM_410_H.START_DATE is '起始日期';
comment on column MBT_PM_410_H.END_DATE is '结束日期';
comment on column MBT_PM_410_H.BATCH_NO is '批次号';
comment on column MBT_PM_410_H.ROW_NUM is '行号';
comment on column MBT_PM_410_H.IS_RPT is '是否报送';
comment on column MBT_PM_410_H.IS_VALID is '是否有效';
comment on column MBT_PM_410_H.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_410_H.OPT_FLAG is '操作标识';
comment on column MBT_PM_410_H.RPT_DATE is '报送日期';
comment on column MBT_PM_410_H.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_410_H.RPT_STATUS is '报送状态';
comment on column MBT_PM_410_H.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_410_H.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_410_H.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_410_H.REMARKS is '备注';
comment on column MBT_PM_410_H.CHECK_FLAG is '校验标志';
comment on column MBT_PM_410_H.CHECK_DESC is '校验说明';
comment on column MBT_PM_410_H.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_410_H.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_410_H.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_410_H.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_410_H.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_410_H.DATA_FLAG is '数据标志';
comment on column MBT_PM_410_H.DATA_OP is '操作标志';
comment on column MBT_PM_410_H.DATA_SOURCE is '数据来源';
comment on column MBT_PM_410_H.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_410_H.DATA_HASH is '数据HASH';
comment on column MBT_PM_410_H.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_H.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_H.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_410_H.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_410_H.DATA_CRT_USER is '创建人';
comment on column MBT_PM_410_H.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_410_H.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_410_H.DATA_CHG_USER is '修改人';
comment on column MBT_PM_410_H.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_410_H.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_410_H.DATA_APV_USER is '审核人';
comment on column MBT_PM_410_H.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_410_H.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_410_H.RSV1 is '备用字段';
comment on column MBT_PM_410_H.RSV2 is '备用字段';
comment on column MBT_PM_410_H.RSV3 is '备用字段';
comment on column MBT_PM_410_H.RSV4 is '备用字段';
comment on column MBT_PM_410_H.RSV5 is '备用字段';
create table MBT_PM_410_I (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
I_CHAN_TRAN_TYPE VARCHAR(2),
I_DET_INFO VARCHAR(400),
I_DUE_TRAN_MON NUMBER(3),
I_TRAN_AMT NUMBER(15),
I_TRAN_AMT_ORG NUMBER(15),
I_TRAN_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_410_I is '企业借贷账户信息-特定交易说明段';
comment on column MBT_PM_410_I.DATA_ID is '数据ID';
comment on column MBT_PM_410_I.DATA_DATE is '数据日期';
comment on column MBT_PM_410_I.CORP_ID is '法人ID';
comment on column MBT_PM_410_I.ORG_ID is '机构ID';
comment on column MBT_PM_410_I.GROUP_ID is '数据分组';
comment on column MBT_PM_410_I.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_410_I.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_410_I.I_CHAN_TRAN_TYPE is '交易类型';
comment on column MBT_PM_410_I.I_DET_INFO is '交易明细信息';
comment on column MBT_PM_410_I.I_DUE_TRAN_MON is '到期日期变更月数';
comment on column MBT_PM_410_I.I_TRAN_AMT is '交易金额';
comment on column MBT_PM_410_I.I_TRAN_AMT_ORG is '交易金额_原始数据金额';
comment on column MBT_PM_410_I.I_TRAN_DATE is '交易日期';
comment on column MBT_PM_410_I.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_410_I.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_410_I.CUST_NO is '客户号';
comment on column MBT_PM_410_I.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_410_I.PART_TYPE is '段标识';
comment on column MBT_PM_410_I.PART_NAME is '段名称';
comment on column MBT_PM_410_I.START_DATE is '起始日期';
comment on column MBT_PM_410_I.END_DATE is '结束日期';
comment on column MBT_PM_410_I.BATCH_NO is '批次号';
comment on column MBT_PM_410_I.ROW_NUM is '行号';
comment on column MBT_PM_410_I.IS_RPT is '是否报送';
comment on column MBT_PM_410_I.IS_VALID is '是否有效';
comment on column MBT_PM_410_I.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_410_I.OPT_FLAG is '操作标识';
comment on column MBT_PM_410_I.RPT_DATE is '报送日期';
comment on column MBT_PM_410_I.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_410_I.RPT_STATUS is '报送状态';
comment on column MBT_PM_410_I.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_410_I.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_410_I.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_410_I.REMARKS is '备注';
comment on column MBT_PM_410_I.CHECK_FLAG is '校验标志';
comment on column MBT_PM_410_I.CHECK_DESC is '校验说明';
comment on column MBT_PM_410_I.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_410_I.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_410_I.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_410_I.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_410_I.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_410_I.DATA_FLAG is '数据标志';
comment on column MBT_PM_410_I.DATA_OP is '操作标志';
comment on column MBT_PM_410_I.DATA_SOURCE is '数据来源';
comment on column MBT_PM_410_I.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_410_I.DATA_HASH is '数据HASH';
comment on column MBT_PM_410_I.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_I.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_410_I.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_410_I.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_410_I.DATA_CRT_USER is '创建人';
comment on column MBT_PM_410_I.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_410_I.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_410_I.DATA_CHG_USER is '修改人';
comment on column MBT_PM_410_I.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_410_I.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_410_I.DATA_APV_USER is '审核人';
comment on column MBT_PM_410_I.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_410_I.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_410_I.RSV1 is '备用字段';
comment on column MBT_PM_410_I.RSV2 is '备用字段';
comment on column MBT_PM_410_I.RSV3 is '备用字段';
comment on column MBT_PM_410_I.RSV4 is '备用字段';
comment on column MBT_PM_410_I.RSV5 is '备用字段';
create table MBT_RPT_410 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
O_BIZ_CODE VARCHAR(60),
N_BIZ_CODE VARCHAR(60),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_410 is '企业借贷账户信息';
comment on column MBT_RPT_410.DATA_ID is '数据ID';
comment on column MBT_RPT_410.DATA_DATE is '数据日期';
comment on column MBT_RPT_410.CORP_ID is '法人ID';
comment on column MBT_RPT_410.ORG_ID is '机构ID';
comment on column MBT_RPT_410.GROUP_ID is '数据分组';
comment on column MBT_RPT_410.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_410.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_410.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_410.O_BIZ_CODE is '原业务标识码';
comment on column MBT_RPT_410.N_BIZ_CODE is '新业务标识码';
comment on column MBT_RPT_410.SECTION_CHG_CNT is '段变更';
comment on column MBT_RPT_410.SECTION_DEL_CNT is '段删除';
comment on column MBT_RPT_410.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_RPT_410.IDN_CHG_CNT is '标识项变更';
comment on column MBT_RPT_410.CUST_NO is '客户号';
comment on column MBT_RPT_410.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_410.PART_TYPE is '段标识';
comment on column MBT_RPT_410.PART_NAME is '段名称';
comment on column MBT_RPT_410.START_DATE is '起始日期';
comment on column MBT_RPT_410.END_DATE is '结束日期';
comment on column MBT_RPT_410.BATCH_NO is '批次号';
comment on column MBT_RPT_410.ROW_NUM is '行号';
comment on column MBT_RPT_410.IS_RPT is '是否报送';
comment on column MBT_RPT_410.IS_VALID is '是否有效';
comment on column MBT_RPT_410.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_410.OPT_FLAG is '操作标识';
comment on column MBT_RPT_410.RPT_DATE is '报送日期';
comment on column MBT_RPT_410.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_410.RPT_STATUS is '报送状态';
comment on column MBT_RPT_410.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_410.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_410.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_410.REMARKS is '备注';
comment on column MBT_RPT_410.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_410.CHECK_DESC is '校验说明';
comment on column MBT_RPT_410.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_410.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_410.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_410.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_410.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_410.DATA_FLAG is '数据标志';
comment on column MBT_RPT_410.DATA_OP is '操作标志';
comment on column MBT_RPT_410.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_410.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_410.DATA_HASH is '数据HASH';
comment on column MBT_RPT_410.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_410.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_410.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_410.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_410.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_410.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_410.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_410.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_410.DATA_APV_USER is '审核人';
comment on column MBT_RPT_410.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_410.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_410.RSV1 is '备用字段';
comment on column MBT_RPT_410.RSV2 is '备用字段';
comment on column MBT_RPT_410.RSV3 is '备用字段';
comment on column MBT_RPT_410.RSV4 is '备用字段';
comment on column MBT_RPT_410.RSV5 is '备用字段';
create table MBT_RPT_410_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
B_ACCT_TYPE VARCHAR(2),
B_ID_NUM VARCHAR(80),
B_ID_TYPE VARCHAR(2),
B_INFO_UP_DATE VARCHAR(8),
B_INF_REC_TYPE VARCHAR(3),
B_MNGMT_ORG_CODE VARCHAR(14),
B_MONTH VARCHAR(8),
B_NAME VARCHAR(160),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
MON_SETTLE_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_410_B is '企业借贷账户信息-基础段';
comment on column MBT_RPT_410_B.DATA_ID is '数据ID';
comment on column MBT_RPT_410_B.DATA_DATE is '数据日期';
comment on column MBT_RPT_410_B.CORP_ID is '法人ID';
comment on column MBT_RPT_410_B.ORG_ID is '机构ID';
comment on column MBT_RPT_410_B.GROUP_ID is '数据分组';
comment on column MBT_RPT_410_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_410_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_410_B.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_410_B.B_ACCT_TYPE is '账户类型';
comment on column MBT_RPT_410_B.B_ID_NUM is '借款人身份标识号码';
comment on column MBT_RPT_410_B.B_ID_TYPE is '借款人身份标识类型';
comment on column MBT_RPT_410_B.B_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_410_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_RPT_410_B.B_MNGMT_ORG_CODE is '业务管理机构代码';
comment on column MBT_RPT_410_B.B_MONTH is '月份';
comment on column MBT_RPT_410_B.B_NAME is '借款人名称';
comment on column MBT_RPT_410_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_410_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_RPT_410_B.MON_SETTLE_DATE is '月结日';
comment on column MBT_RPT_410_B.CUST_NO is '客户号';
comment on column MBT_RPT_410_B.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_410_B.PART_TYPE is '段标识';
comment on column MBT_RPT_410_B.PART_NAME is '段名称';
comment on column MBT_RPT_410_B.START_DATE is '起始日期';
comment on column MBT_RPT_410_B.END_DATE is '结束日期';
comment on column MBT_RPT_410_B.BATCH_NO is '批次号';
comment on column MBT_RPT_410_B.ROW_NUM is '行号';
comment on column MBT_RPT_410_B.IS_RPT is '是否报送';
comment on column MBT_RPT_410_B.IS_VALID is '是否有效';
comment on column MBT_RPT_410_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_410_B.OPT_FLAG is '操作标识';
comment on column MBT_RPT_410_B.RPT_DATE is '报送日期';
comment on column MBT_RPT_410_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_410_B.RPT_STATUS is '报送状态';
comment on column MBT_RPT_410_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_410_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_410_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_410_B.REMARKS is '备注';
comment on column MBT_RPT_410_B.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_410_B.CHECK_DESC is '校验说明';
comment on column MBT_RPT_410_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_410_B.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_410_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_410_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_410_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_410_B.DATA_FLAG is '数据标志';
comment on column MBT_RPT_410_B.DATA_OP is '操作标志';
comment on column MBT_RPT_410_B.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_410_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_410_B.DATA_HASH is '数据HASH';
comment on column MBT_RPT_410_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_410_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_410_B.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_410_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_410_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_410_B.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_410_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_410_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_410_B.DATA_APV_USER is '审核人';
comment on column MBT_RPT_410_B.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_410_B.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_410_B.RSV1 is '备用字段';
comment on column MBT_RPT_410_B.RSV2 is '备用字段';
comment on column MBT_RPT_410_B.RSV3 is '备用字段';
comment on column MBT_RPT_410_B.RSV4 is '备用字段';
comment on column MBT_RPT_410_B.RSV5 is '备用字段';
create table MBT_RPT_410_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ACCT_CRED_LINE_AMT NUMBER(15),
C_ACCT_CRED_LINE_AMT_LCY NUMBER(15),
C_ACT_INVEST VARCHAR(5),
C_APPLY_BUSI_DIST VARCHAR(6),
C_ASSET_TRAND_FLAG VARCHAR(1),
C_BUSI_DTL_LINES VARCHAR(2),
C_BUSI_LINES VARCHAR(2),
C_CY VARCHAR(3),
C_DUE_DATE VARCHAR(8),
C_FLAG VARCHAR(1),
C_FUND_SOU VARCHAR(2),
C_GUAR_MODE VARCHAR(1),
C_LOAN_AMT NUMBER(15),
C_LOAN_AMT_LCY NUMBER(15),
C_LOAN_TIME_LIM_CAT VARCHAR(2),
C_LOA_FRM VARCHAR(1),
C_OPEN_DATE VARCHAR(8),
C_OTH_REPY_GUAR_WAY VARCHAR(1),
C_REPAY_FREQCY VARCHAR(2),
C_REPAY_MODE VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_410_C is '企业借贷账户信息-基本信息段';
comment on column MBT_RPT_410_C.DATA_ID is '数据ID';
comment on column MBT_RPT_410_C.DATA_DATE is '数据日期';
comment on column MBT_RPT_410_C.CORP_ID is '法人ID';
comment on column MBT_RPT_410_C.ORG_ID is '机构ID';
comment on column MBT_RPT_410_C.GROUP_ID is '数据分组';
comment on column MBT_RPT_410_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_410_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_410_C.C_ACCT_CRED_LINE_AMT is '信用额度';
comment on column MBT_RPT_410_C.C_ACCT_CRED_LINE_AMT_LCY is '信用额度人民币金额';
comment on column MBT_RPT_410_C.C_ACT_INVEST is '贷款实际投向';
comment on column MBT_RPT_410_C.C_APPLY_BUSI_DIST is '业务申请地行政区划代码';
comment on column MBT_RPT_410_C.C_ASSET_TRAND_FLAG is '资产转让标志';
comment on column MBT_RPT_410_C.C_BUSI_DTL_LINES is '借贷业务种类细分';
comment on column MBT_RPT_410_C.C_BUSI_LINES is '借贷业务大类';
comment on column MBT_RPT_410_C.C_CY is '币种';
comment on column MBT_RPT_410_C.C_DUE_DATE is '到期日期';
comment on column MBT_RPT_410_C.C_FLAG is '分次放款标志';
comment on column MBT_RPT_410_C.C_FUND_SOU is '业务经营类型';
comment on column MBT_RPT_410_C.C_GUAR_MODE is '担保方式';
comment on column MBT_RPT_410_C.C_LOAN_AMT is '借款金额';
comment on column MBT_RPT_410_C.C_LOAN_AMT_LCY is '借款金额人民币金额';
comment on column MBT_RPT_410_C.C_LOAN_TIME_LIM_CAT is '借款期限分类';
comment on column MBT_RPT_410_C.C_LOA_FRM is '贷款发放形式';
comment on column MBT_RPT_410_C.C_OPEN_DATE is '开户日期';
comment on column MBT_RPT_410_C.C_OTH_REPY_GUAR_WAY is '其他还款保证方式';
comment on column MBT_RPT_410_C.C_REPAY_FREQCY is '还款频率';
comment on column MBT_RPT_410_C.C_REPAY_MODE is '还款方式';
comment on column MBT_RPT_410_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_410_C.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_410_C.CUST_NO is '客户号';
comment on column MBT_RPT_410_C.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_410_C.PART_TYPE is '段标识';
comment on column MBT_RPT_410_C.PART_NAME is '段名称';
comment on column MBT_RPT_410_C.START_DATE is '起始日期';
comment on column MBT_RPT_410_C.END_DATE is '结束日期';
comment on column MBT_RPT_410_C.BATCH_NO is '批次号';
comment on column MBT_RPT_410_C.ROW_NUM is '行号';
comment on column MBT_RPT_410_C.IS_RPT is '是否报送';
comment on column MBT_RPT_410_C.IS_VALID is '是否有效';
comment on column MBT_RPT_410_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_410_C.OPT_FLAG is '操作标识';
comment on column MBT_RPT_410_C.RPT_DATE is '报送日期';
comment on column MBT_RPT_410_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_410_C.RPT_STATUS is '报送状态';
comment on column MBT_RPT_410_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_410_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_410_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_410_C.REMARKS is '备注';
comment on column MBT_RPT_410_C.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_410_C.CHECK_DESC is '校验说明';
comment on column MBT_RPT_410_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_410_C.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_410_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_410_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_410_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_410_C.DATA_FLAG is '数据标志';
comment on column MBT_RPT_410_C.DATA_OP is '操作标志';
comment on column MBT_RPT_410_C.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_410_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_410_C.DATA_HASH is '数据HASH';
comment on column MBT_RPT_410_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_410_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_410_C.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_410_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_410_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_410_C.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_410_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_410_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_410_C.DATA_APV_USER is '审核人';
comment on column MBT_RPT_410_C.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_410_C.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_410_C.RSV1 is '备用字段';
comment on column MBT_RPT_410_C.RSV2 is '备用字段';
comment on column MBT_RPT_410_C.RSV3 is '备用字段';
comment on column MBT_RPT_410_C.RSV4 is '备用字段';
comment on column MBT_RPT_410_C.RSV5 is '备用字段';
create table MBT_RPT_410_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ARLP_AMT NUMBER(15),
D_ARLP_AMT_ORG NUMBER(15),
D_ARLP_CERT_NUM VARCHAR(80),
D_ARLP_CERT_TYPE VARCHAR(2),
D_ARLP_ID_TYPE VARCHAR(1),
D_ARLP_NAME VARCHAR(160),
D_ARLP_TYPE VARCHAR(1),
D_MAX_GUAR_MCC VARCHAR(60),
D_WARTY_SIGN VARCHAR(1),
ACTU_COTRL_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_410_D is '企业借贷账户信息-相关还款责任人段';
comment on column MBT_RPT_410_D.DATA_ID is '数据ID';
comment on column MBT_RPT_410_D.DATA_DATE is '数据日期';
comment on column MBT_RPT_410_D.CORP_ID is '法人ID';
comment on column MBT_RPT_410_D.ORG_ID is '机构ID';
comment on column MBT_RPT_410_D.GROUP_ID is '数据分组';
comment on column MBT_RPT_410_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_410_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_410_D.D_ARLP_AMT is '还款责任金额';
comment on column MBT_RPT_410_D.D_ARLP_AMT_ORG is '还款责任金额_原始数据金额';
comment on column MBT_RPT_410_D.D_ARLP_CERT_NUM is '责任人身份标识号码';
comment on column MBT_RPT_410_D.D_ARLP_CERT_TYPE is '责任人身份标识类型';
comment on column MBT_RPT_410_D.D_ARLP_ID_TYPE is '身份类别';
comment on column MBT_RPT_410_D.D_ARLP_NAME is '责任人名称';
comment on column MBT_RPT_410_D.D_ARLP_TYPE is '还款责任人类型';
comment on column MBT_RPT_410_D.D_MAX_GUAR_MCC is '保证合同编号';
comment on column MBT_RPT_410_D.D_WARTY_SIGN is '联保标志';
comment on column MBT_RPT_410_D.ACTU_COTRL_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_410_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_410_D.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_410_D.CUST_NO is '客户号';
comment on column MBT_RPT_410_D.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_410_D.PART_TYPE is '段标识';
comment on column MBT_RPT_410_D.PART_NAME is '段名称';
comment on column MBT_RPT_410_D.START_DATE is '起始日期';
comment on column MBT_RPT_410_D.END_DATE is '结束日期';
comment on column MBT_RPT_410_D.BATCH_NO is '批次号';
comment on column MBT_RPT_410_D.ROW_NUM is '行号';
comment on column MBT_RPT_410_D.IS_RPT is '是否报送';
comment on column MBT_RPT_410_D.IS_VALID is '是否有效';
comment on column MBT_RPT_410_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_410_D.OPT_FLAG is '操作标识';
comment on column MBT_RPT_410_D.RPT_DATE is '报送日期';
comment on column MBT_RPT_410_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_410_D.RPT_STATUS is '报送状态';
comment on column MBT_RPT_410_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_410_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_410_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_410_D.REMARKS is '备注';
comment on column MBT_RPT_410_D.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_410_D.CHECK_DESC is '校验说明';
comment on column MBT_RPT_410_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_410_D.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_410_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_410_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_410_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_410_D.DATA_FLAG is '数据标志';
comment on column MBT_RPT_410_D.DATA_OP is '操作标志';
comment on column MBT_RPT_410_D.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_410_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_410_D.DATA_HASH is '数据HASH';
comment on column MBT_RPT_410_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_410_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_410_D.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_410_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_410_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_410_D.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_410_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_410_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_410_D.DATA_APV_USER is '审核人';
comment on column MBT_RPT_410_D.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_410_D.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_410_D.RSV1 is '备用字段';
comment on column MBT_RPT_410_D.RSV2 is '备用字段';
comment on column MBT_RPT_410_D.RSV3 is '备用字段';
comment on column MBT_RPT_410_D.RSV4 is '备用字段';
comment on column MBT_RPT_410_D.RSV5 is '备用字段';
create table MBT_RPT_410_E (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
E_CCC VARCHAR(60),
ACTU_COTRL_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_410_E is '企业借贷账户信息-抵质押物信息段';
comment on column MBT_RPT_410_E.DATA_ID is '数据ID';
comment on column MBT_RPT_410_E.DATA_DATE is '数据日期';
comment on column MBT_RPT_410_E.CORP_ID is '法人ID';
comment on column MBT_RPT_410_E.ORG_ID is '机构ID';
comment on column MBT_RPT_410_E.GROUP_ID is '数据分组';
comment on column MBT_RPT_410_E.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_410_E.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_410_E.E_CCC is '抵（质）押合同标识码';
comment on column MBT_RPT_410_E.ACTU_COTRL_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_410_E.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_410_E.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_410_E.CUST_NO is '客户号';
comment on column MBT_RPT_410_E.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_410_E.PART_TYPE is '段标识';
comment on column MBT_RPT_410_E.PART_NAME is '段名称';
comment on column MBT_RPT_410_E.START_DATE is '起始日期';
comment on column MBT_RPT_410_E.END_DATE is '结束日期';
comment on column MBT_RPT_410_E.BATCH_NO is '批次号';
comment on column MBT_RPT_410_E.ROW_NUM is '行号';
comment on column MBT_RPT_410_E.IS_RPT is '是否报送';
comment on column MBT_RPT_410_E.IS_VALID is '是否有效';
comment on column MBT_RPT_410_E.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_410_E.OPT_FLAG is '操作标识';
comment on column MBT_RPT_410_E.RPT_DATE is '报送日期';
comment on column MBT_RPT_410_E.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_410_E.RPT_STATUS is '报送状态';
comment on column MBT_RPT_410_E.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_410_E.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_410_E.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_410_E.REMARKS is '备注';
comment on column MBT_RPT_410_E.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_410_E.CHECK_DESC is '校验说明';
comment on column MBT_RPT_410_E.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_410_E.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_410_E.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_410_E.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_410_E.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_410_E.DATA_FLAG is '数据标志';
comment on column MBT_RPT_410_E.DATA_OP is '操作标志';
comment on column MBT_RPT_410_E.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_410_E.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_410_E.DATA_HASH is '数据HASH';
comment on column MBT_RPT_410_E.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_E.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_E.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_410_E.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_410_E.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_410_E.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_410_E.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_410_E.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_410_E.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_410_E.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_410_E.DATA_APV_USER is '审核人';
comment on column MBT_RPT_410_E.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_410_E.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_410_E.RSV1 is '备用字段';
comment on column MBT_RPT_410_E.RSV2 is '备用字段';
comment on column MBT_RPT_410_E.RSV3 is '备用字段';
comment on column MBT_RPT_410_E.RSV4 is '备用字段';
comment on column MBT_RPT_410_E.RSV5 is '备用字段';
create table MBT_RPT_410_F (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
F_MCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_410_F is '企业借贷账户信息-授信额度信息段';
comment on column MBT_RPT_410_F.DATA_ID is '数据ID';
comment on column MBT_RPT_410_F.DATA_DATE is '数据日期';
comment on column MBT_RPT_410_F.CORP_ID is '法人ID';
comment on column MBT_RPT_410_F.ORG_ID is '机构ID';
comment on column MBT_RPT_410_F.GROUP_ID is '数据分组';
comment on column MBT_RPT_410_F.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_410_F.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_410_F.F_MCC is '授信协议标识码';
comment on column MBT_RPT_410_F.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_410_F.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_410_F.CUST_NO is '客户号';
comment on column MBT_RPT_410_F.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_410_F.PART_TYPE is '段标识';
comment on column MBT_RPT_410_F.PART_NAME is '段名称';
comment on column MBT_RPT_410_F.START_DATE is '起始日期';
comment on column MBT_RPT_410_F.END_DATE is '结束日期';
comment on column MBT_RPT_410_F.BATCH_NO is '批次号';
comment on column MBT_RPT_410_F.ROW_NUM is '行号';
comment on column MBT_RPT_410_F.IS_RPT is '是否报送';
comment on column MBT_RPT_410_F.IS_VALID is '是否有效';
comment on column MBT_RPT_410_F.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_410_F.OPT_FLAG is '操作标识';
comment on column MBT_RPT_410_F.RPT_DATE is '报送日期';
comment on column MBT_RPT_410_F.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_410_F.RPT_STATUS is '报送状态';
comment on column MBT_RPT_410_F.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_410_F.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_410_F.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_410_F.REMARKS is '备注';
comment on column MBT_RPT_410_F.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_410_F.CHECK_DESC is '校验说明';
comment on column MBT_RPT_410_F.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_410_F.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_410_F.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_410_F.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_410_F.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_410_F.DATA_FLAG is '数据标志';
comment on column MBT_RPT_410_F.DATA_OP is '操作标志';
comment on column MBT_RPT_410_F.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_410_F.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_410_F.DATA_HASH is '数据HASH';
comment on column MBT_RPT_410_F.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_F.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_F.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_410_F.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_410_F.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_410_F.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_410_F.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_410_F.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_410_F.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_410_F.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_410_F.DATA_APV_USER is '审核人';
comment on column MBT_RPT_410_F.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_410_F.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_410_F.RSV1 is '备用字段';
comment on column MBT_RPT_410_F.RSV2 is '备用字段';
comment on column MBT_RPT_410_F.RSV3 is '备用字段';
comment on column MBT_RPT_410_F.RSV4 is '备用字段';
comment on column MBT_RPT_410_F.RSV5 is '备用字段';
create table MBT_RPT_410_G (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_INIT_CED_ORG_CODE VARCHAR(18),
G_INIT_CRED_NAME VARCHAR(160),
G_INIT_RPY_STS VARCHAR(1),
G_ORIG_DBT_CATE VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_410_G is '企业借贷账户信息-初始债权说明段';
comment on column MBT_RPT_410_G.DATA_ID is '数据ID';
comment on column MBT_RPT_410_G.DATA_DATE is '数据日期';
comment on column MBT_RPT_410_G.CORP_ID is '法人ID';
comment on column MBT_RPT_410_G.ORG_ID is '机构ID';
comment on column MBT_RPT_410_G.GROUP_ID is '数据分组';
comment on column MBT_RPT_410_G.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_410_G.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_410_G.G_INIT_CED_ORG_CODE is '初始债权人机构代码';
comment on column MBT_RPT_410_G.G_INIT_CRED_NAME is '初始债权人名称';
comment on column MBT_RPT_410_G.G_INIT_RPY_STS is '债权转移时的还款状态';
comment on column MBT_RPT_410_G.G_ORIG_DBT_CATE is '原债务种类';
comment on column MBT_RPT_410_G.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_410_G.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_410_G.CUST_NO is '客户号';
comment on column MBT_RPT_410_G.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_410_G.PART_TYPE is '段标识';
comment on column MBT_RPT_410_G.PART_NAME is '段名称';
comment on column MBT_RPT_410_G.START_DATE is '起始日期';
comment on column MBT_RPT_410_G.END_DATE is '结束日期';
comment on column MBT_RPT_410_G.BATCH_NO is '批次号';
comment on column MBT_RPT_410_G.ROW_NUM is '行号';
comment on column MBT_RPT_410_G.IS_RPT is '是否报送';
comment on column MBT_RPT_410_G.IS_VALID is '是否有效';
comment on column MBT_RPT_410_G.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_410_G.OPT_FLAG is '操作标识';
comment on column MBT_RPT_410_G.RPT_DATE is '报送日期';
comment on column MBT_RPT_410_G.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_410_G.RPT_STATUS is '报送状态';
comment on column MBT_RPT_410_G.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_410_G.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_410_G.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_410_G.REMARKS is '备注';
comment on column MBT_RPT_410_G.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_410_G.CHECK_DESC is '校验说明';
comment on column MBT_RPT_410_G.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_410_G.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_410_G.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_410_G.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_410_G.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_410_G.DATA_FLAG is '数据标志';
comment on column MBT_RPT_410_G.DATA_OP is '操作标志';
comment on column MBT_RPT_410_G.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_410_G.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_410_G.DATA_HASH is '数据HASH';
comment on column MBT_RPT_410_G.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_G.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_G.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_410_G.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_410_G.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_410_G.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_410_G.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_410_G.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_410_G.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_410_G.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_410_G.DATA_APV_USER is '审核人';
comment on column MBT_RPT_410_G.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_410_G.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_410_G.RSV1 is '备用字段';
comment on column MBT_RPT_410_G.RSV2 is '备用字段';
comment on column MBT_RPT_410_G.RSV3 is '备用字段';
comment on column MBT_RPT_410_G.RSV4 is '备用字段';
comment on column MBT_RPT_410_G.RSV5 is '备用字段';
create table MBT_RPT_410_H (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
H_ACCT_BAL NUMBER(15),
H_ACCT_BAL_LCY NUMBER(15),
H_ACCT_STATUS VARCHAR(2),
H_BAL_CHG_DATE VARCHAR(8),
H_CLOSE_DATE VARCHAR(8),
H_FIVE_CATE VARCHAR(1),
H_FIVE_CATE_ADJ_DATE VARCHAR(8),
H_LAT_AGRR_RPY_AMT NUMBER(15),
H_LAT_AGRR_RPY_AMT_LCY NUMBER(15),
H_LAT_AGRR_RPY_DATE VARCHAR(8),
H_LAT_RPY_AMT NUMBER(15),
H_LAT_RPY_AMT_LCY NUMBER(15),
H_LAT_RPY_DATE VARCHAR(8),
H_LAT_RPY_PRINC_AMT NUMBER(15),
H_LAT_RPY_PRINC_AMT_LCY NUMBER(15),
H_NXT_AGRR_RPY_DATE VARCHAR(8),
H_OVERD_DY NUMBER(3),
H_OVERD_PRINC NUMBER(15),
H_OVERD_PRINC_LCY NUMBER(15),
H_PYMT_PRD NUMBER(3),
H_RPMT_TYPE VARCHAR(2),
H_TOT_OVERD NUMBER(15),
H_TOT_OVERD_LCY NUMBER(15),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_410_H is '企业借贷账户信息-还款表现信息段';
comment on column MBT_RPT_410_H.DATA_ID is '数据ID';
comment on column MBT_RPT_410_H.DATA_DATE is '数据日期';
comment on column MBT_RPT_410_H.CORP_ID is '法人ID';
comment on column MBT_RPT_410_H.ORG_ID is '机构ID';
comment on column MBT_RPT_410_H.GROUP_ID is '数据分组';
comment on column MBT_RPT_410_H.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_410_H.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_410_H.H_ACCT_BAL is '余额';
comment on column MBT_RPT_410_H.H_ACCT_BAL_LCY is '余额人民币金额';
comment on column MBT_RPT_410_H.H_ACCT_STATUS is '账户状态';
comment on column MBT_RPT_410_H.H_BAL_CHG_DATE is '余额变化日期';
comment on column MBT_RPT_410_H.H_CLOSE_DATE is '账户关闭日期';
comment on column MBT_RPT_410_H.H_FIVE_CATE is '五级分类';
comment on column MBT_RPT_410_H.H_FIVE_CATE_ADJ_DATE is '五级分类认定日期';
comment on column MBT_RPT_410_H.H_LAT_AGRR_RPY_AMT is '最近一次约定还款金额';
comment on column MBT_RPT_410_H.H_LAT_AGRR_RPY_AMT_LCY is '最近一次约定还款金额人民币金额';
comment on column MBT_RPT_410_H.H_LAT_AGRR_RPY_DATE is '最近一次约定还款日';
comment on column MBT_RPT_410_H.H_LAT_RPY_AMT is '最近一次实际还款金额';
comment on column MBT_RPT_410_H.H_LAT_RPY_AMT_LCY is '最近一次实际还款金额人民币金额';
comment on column MBT_RPT_410_H.H_LAT_RPY_DATE is '最近一次实际还款日期';
comment on column MBT_RPT_410_H.H_LAT_RPY_PRINC_AMT is '最近一次实际归还本金';
comment on column MBT_RPT_410_H.H_LAT_RPY_PRINC_AMT_LCY is '最近一次实际归还本金人民币金额';
comment on column MBT_RPT_410_H.H_NXT_AGRR_RPY_DATE is '下一次约定还款日期';
comment on column MBT_RPT_410_H.H_OVERD_DY is '当前逾期天数';
comment on column MBT_RPT_410_H.H_OVERD_PRINC is '当前逾期本金';
comment on column MBT_RPT_410_H.H_OVERD_PRINC_LCY is '当前逾期本金人民币金额';
comment on column MBT_RPT_410_H.H_PYMT_PRD is '剩余还款月数';
comment on column MBT_RPT_410_H.H_RPMT_TYPE is '还款形式';
comment on column MBT_RPT_410_H.H_TOT_OVERD is '当前逾期总额';
comment on column MBT_RPT_410_H.H_TOT_OVERD_LCY is '当前逾期总额人民币金额';
comment on column MBT_RPT_410_H.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_410_H.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_410_H.CUST_NO is '客户号';
comment on column MBT_RPT_410_H.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_410_H.PART_TYPE is '段标识';
comment on column MBT_RPT_410_H.PART_NAME is '段名称';
comment on column MBT_RPT_410_H.START_DATE is '起始日期';
comment on column MBT_RPT_410_H.END_DATE is '结束日期';
comment on column MBT_RPT_410_H.BATCH_NO is '批次号';
comment on column MBT_RPT_410_H.ROW_NUM is '行号';
comment on column MBT_RPT_410_H.IS_RPT is '是否报送';
comment on column MBT_RPT_410_H.IS_VALID is '是否有效';
comment on column MBT_RPT_410_H.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_410_H.OPT_FLAG is '操作标识';
comment on column MBT_RPT_410_H.RPT_DATE is '报送日期';
comment on column MBT_RPT_410_H.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_410_H.RPT_STATUS is '报送状态';
comment on column MBT_RPT_410_H.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_410_H.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_410_H.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_410_H.REMARKS is '备注';
comment on column MBT_RPT_410_H.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_410_H.CHECK_DESC is '校验说明';
comment on column MBT_RPT_410_H.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_410_H.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_410_H.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_410_H.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_410_H.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_410_H.DATA_FLAG is '数据标志';
comment on column MBT_RPT_410_H.DATA_OP is '操作标志';
comment on column MBT_RPT_410_H.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_410_H.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_410_H.DATA_HASH is '数据HASH';
comment on column MBT_RPT_410_H.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_H.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_H.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_410_H.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_410_H.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_410_H.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_410_H.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_410_H.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_410_H.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_410_H.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_410_H.DATA_APV_USER is '审核人';
comment on column MBT_RPT_410_H.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_410_H.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_410_H.RSV1 is '备用字段';
comment on column MBT_RPT_410_H.RSV2 is '备用字段';
comment on column MBT_RPT_410_H.RSV3 is '备用字段';
comment on column MBT_RPT_410_H.RSV4 is '备用字段';
comment on column MBT_RPT_410_H.RSV5 is '备用字段';
create table MBT_RPT_410_I (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
I_CHAN_TRAN_TYPE VARCHAR(2),
I_DET_INFO VARCHAR(400),
I_DUE_TRAN_MON NUMBER(3),
I_TRAN_AMT NUMBER(15),
I_TRAN_AMT_ORG NUMBER(15),
I_TRAN_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_410_I is '企业借贷账户信息-特定交易说明段';
comment on column MBT_RPT_410_I.DATA_ID is '数据ID';
comment on column MBT_RPT_410_I.DATA_DATE is '数据日期';
comment on column MBT_RPT_410_I.CORP_ID is '法人ID';
comment on column MBT_RPT_410_I.ORG_ID is '机构ID';
comment on column MBT_RPT_410_I.GROUP_ID is '数据分组';
comment on column MBT_RPT_410_I.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_410_I.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_410_I.I_CHAN_TRAN_TYPE is '交易类型';
comment on column MBT_RPT_410_I.I_DET_INFO is '交易明细信息';
comment on column MBT_RPT_410_I.I_DUE_TRAN_MON is '到期日期变更月数';
comment on column MBT_RPT_410_I.I_TRAN_AMT is '交易金额';
comment on column MBT_RPT_410_I.I_TRAN_AMT_ORG is '交易金额_原始数据金额';
comment on column MBT_RPT_410_I.I_TRAN_DATE is '交易日期';
comment on column MBT_RPT_410_I.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_410_I.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_410_I.CUST_NO is '客户号';
comment on column MBT_RPT_410_I.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_410_I.PART_TYPE is '段标识';
comment on column MBT_RPT_410_I.PART_NAME is '段名称';
comment on column MBT_RPT_410_I.START_DATE is '起始日期';
comment on column MBT_RPT_410_I.END_DATE is '结束日期';
comment on column MBT_RPT_410_I.BATCH_NO is '批次号';
comment on column MBT_RPT_410_I.ROW_NUM is '行号';
comment on column MBT_RPT_410_I.IS_RPT is '是否报送';
comment on column MBT_RPT_410_I.IS_VALID is '是否有效';
comment on column MBT_RPT_410_I.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_410_I.OPT_FLAG is '操作标识';
comment on column MBT_RPT_410_I.RPT_DATE is '报送日期';
comment on column MBT_RPT_410_I.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_410_I.RPT_STATUS is '报送状态';
comment on column MBT_RPT_410_I.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_410_I.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_410_I.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_410_I.REMARKS is '备注';
comment on column MBT_RPT_410_I.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_410_I.CHECK_DESC is '校验说明';
comment on column MBT_RPT_410_I.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_410_I.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_410_I.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_410_I.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_410_I.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_410_I.DATA_FLAG is '数据标志';
comment on column MBT_RPT_410_I.DATA_OP is '操作标志';
comment on column MBT_RPT_410_I.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_410_I.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_410_I.DATA_HASH is '数据HASH';
comment on column MBT_RPT_410_I.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_I.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_410_I.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_410_I.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_410_I.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_410_I.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_410_I.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_410_I.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_410_I.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_410_I.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_410_I.DATA_APV_USER is '审核人';
comment on column MBT_RPT_410_I.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_410_I.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_410_I.RSV1 is '备用字段';
comment on column MBT_RPT_410_I.RSV2 is '备用字段';
comment on column MBT_RPT_410_I.RSV3 is '备用字段';
comment on column MBT_RPT_410_I.RSV4 is '备用字段';
comment on column MBT_RPT_410_I.RSV5 is '备用字段';
