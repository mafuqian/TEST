create table MBT_DM_620 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_620 is '企业利润及利润分配表信息';
comment on column MBT_DM_620.DATA_ID is '数据ID';
comment on column MBT_DM_620.DATA_DATE is '数据日期';
comment on column MBT_DM_620.CORP_ID is '法人ID';
comment on column MBT_DM_620.ORG_ID is '机构ID';
comment on column MBT_DM_620.GROUP_ID is '数据分组';
comment on column MBT_DM_620.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_620.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_620.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_620.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_620.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_620.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_620.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_620.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_620.B_ENT_NAME is '企业名称';
comment on column MBT_DM_620.SECTION_CHG_CNT is '段变更';
comment on column MBT_DM_620.SECTION_DEL_CNT is '段删除';
comment on column MBT_DM_620.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_DM_620.IDN_CHG_CNT is '标识项变更';
comment on column MBT_DM_620.CUST_NO is '客户号';
comment on column MBT_DM_620.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_620.PART_TYPE is '段标识';
comment on column MBT_DM_620.PART_NAME is '段名称';
comment on column MBT_DM_620.START_DATE is '起始日期';
comment on column MBT_DM_620.END_DATE is '结束日期';
comment on column MBT_DM_620.BATCH_NO is '批次号';
comment on column MBT_DM_620.ROW_NUM is '行号';
comment on column MBT_DM_620.IS_RPT is '是否报送';
comment on column MBT_DM_620.IS_VALID is '是否有效';
comment on column MBT_DM_620.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_620.OPT_FLAG is '操作标识';
comment on column MBT_DM_620.RPT_DATE is '报送日期';
comment on column MBT_DM_620.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_620.RPT_STATUS is '报送状态';
comment on column MBT_DM_620.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_620.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_620.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_620.REMARKS is '备注';
comment on column MBT_DM_620.CHECK_FLAG is '校验标志';
comment on column MBT_DM_620.CHECK_DESC is '校验说明';
comment on column MBT_DM_620.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_620.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_620.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_620.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_620.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_620.DATA_FLAG is '数据标志';
comment on column MBT_DM_620.DATA_OP is '操作标志';
comment on column MBT_DM_620.DATA_SOURCE is '数据来源';
comment on column MBT_DM_620.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_620.DATA_HASH is '数据HASH';
comment on column MBT_DM_620.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_620.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_620.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_620.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_620.DATA_CRT_USER is '创建人';
comment on column MBT_DM_620.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_620.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_620.DATA_CHG_USER is '修改人';
comment on column MBT_DM_620.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_620.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_620.DATA_APV_USER is '审核人';
comment on column MBT_DM_620.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_620.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_620.RSV1 is '备用字段';
comment on column MBT_DM_620.RSV2 is '备用字段';
comment on column MBT_DM_620.RSV3 is '备用字段';
comment on column MBT_DM_620.RSV4 is '备用字段';
comment on column MBT_DM_620.RSV5 is '备用字段';
create table MBT_DM_620_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_620_B is '企业利润及利润分配表信息-基础段';
comment on column MBT_DM_620_B.DATA_ID is '数据ID';
comment on column MBT_DM_620_B.DATA_DATE is '数据日期';
comment on column MBT_DM_620_B.CORP_ID is '法人ID';
comment on column MBT_DM_620_B.ORG_ID is '机构ID';
comment on column MBT_DM_620_B.GROUP_ID is '数据分组';
comment on column MBT_DM_620_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_620_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_620_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_620_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_620_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_620_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_620_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_620_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_620_B.B_ENT_NAME is '企业名称';
comment on column MBT_DM_620_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_DM_620_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_DM_620_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_DM_620_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_DM_620_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_DM_620_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_620_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_DM_620_B.CUST_NO is '客户号';
comment on column MBT_DM_620_B.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_620_B.PART_TYPE is '段标识';
comment on column MBT_DM_620_B.PART_NAME is '段名称';
comment on column MBT_DM_620_B.START_DATE is '起始日期';
comment on column MBT_DM_620_B.END_DATE is '结束日期';
comment on column MBT_DM_620_B.BATCH_NO is '批次号';
comment on column MBT_DM_620_B.ROW_NUM is '行号';
comment on column MBT_DM_620_B.IS_RPT is '是否报送';
comment on column MBT_DM_620_B.IS_VALID is '是否有效';
comment on column MBT_DM_620_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_620_B.OPT_FLAG is '操作标识';
comment on column MBT_DM_620_B.RPT_DATE is '报送日期';
comment on column MBT_DM_620_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_620_B.RPT_STATUS is '报送状态';
comment on column MBT_DM_620_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_620_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_620_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_620_B.REMARKS is '备注';
comment on column MBT_DM_620_B.CHECK_FLAG is '校验标志';
comment on column MBT_DM_620_B.CHECK_DESC is '校验说明';
comment on column MBT_DM_620_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_620_B.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_620_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_620_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_620_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_620_B.DATA_FLAG is '数据标志';
comment on column MBT_DM_620_B.DATA_OP is '操作标志';
comment on column MBT_DM_620_B.DATA_SOURCE is '数据来源';
comment on column MBT_DM_620_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_620_B.DATA_HASH is '数据HASH';
comment on column MBT_DM_620_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_620_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_620_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_620_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_620_B.DATA_CRT_USER is '创建人';
comment on column MBT_DM_620_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_620_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_620_B.DATA_CHG_USER is '修改人';
comment on column MBT_DM_620_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_620_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_620_B.DATA_APV_USER is '审核人';
comment on column MBT_DM_620_B.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_620_B.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_620_B.RSV1 is '备用字段';
comment on column MBT_DM_620_B.RSV2 is '备用字段';
comment on column MBT_DM_620_B.RSV3 is '备用字段';
comment on column MBT_DM_620_B.RSV4 is '备用字段';
comment on column MBT_DM_620_B.RSV5 is '备用字段';
create table MBT_DM_620_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ALLOWANCE_INCOME NUMBER(17),
C_ALLOWANCE_INCOME_B_ALLOWANCE NUMBER(17),
C_APPR_ENTERPRISE_EXP_FUND NUMBER(17),
C_APPR_RESERVE_FUND NUMBER(17),
C_APPR_STAFF_INC_WELFARE_FUND NUMBER(17),
C_APPR_STATUTORY_SURPLUS_RES NUMBER(17),
C_APPR_STATUTORY_WELFAREFUND NUMBER(17),
C_BALANCE_OF_CONTENTSALARY NUMBER(17),
C_CALCULATING_CONTENT_SALARY_B NUMBER(17),
C_COMPENSATION_SURPLUS_RES NUMBER(17),
C_DEFERRED_INCOME NUMBER(17),
C_DISCOUNT_ALLOWANCE NUMBER(17),
C_EXCHANGE_NON_MONETARY_ASS_L NUMBER(17),
C_FINANCIAL_EXPENSES NUMBER(17),
C_FUTURES_INCOME NUMBER(17),
C_GENERAL_ADMIN_EXPENSES NUMBER(17),
C_IMPARIMENT_LOSS NUMBER(17),
C_INCOMETAX NUMBER(17),
C_INCOME_FROM_PENALTY NUMBER(17),
C_INCOME_NON_CURRENCY_TRADE NUMBER(17),
C_INCOME_SALES_AGENCY NUMBER(17),
C_INCOME_SALES_INTANGIBLE_ASS NUMBER(17),
C_INVESTMENT_INCOME NUMBER(17),
C_LOSS_COMPENSATED_BEFORE_TAX NUMBER(17),
C_LOSS_DISPOSAL_FIXED_ASSETS NUMBER(17),
C_LOSS_LAWSUITS NUMBER(17),
C_MAIN_OPERATING_COST NUMBER(17),
C_MAIN_REVENUEF_REVENUE NUMBER(17),
C_NET_AMOUNT_INCOME_MAIN_BUSI NUMBER(17),
C_NET_GAIN_DISPOSAL_FIXED_ASS NUMBER(17),
C_NET_PROFIT NUMBER(17),
C_NON_OPERATING_EXPENSES NUMBER(17),
C_NON_OPERATING_INCOME NUMBER(17),
C_OPERATING_PROFITS NUMBER(17),
C_OPERATION_EXPENSE NUMBER(17),
C_OTHERS NUMBER(17),
C_OTHERS_EXPENSES NUMBER(17),
C_OTHERS_INCOME NUMBER(17),
C_OTHERS_OPERATING_COST NUMBER(17),
C_OTHERS_OWNERS NUMBER(17),
C_OTHER_ADJUSTMENT_FACTORS NUMBER(17),
C_OTHER_BUSINESS_PROFIT NUMBER(17),
C_OTHER_OPERATING_INCOME NUMBER(17),
C_OTHER_PAYMENTS NUMBER(17),
C_PAYABLE_DIVIDENDS_COMMON_STO NUMBER(17),
C_PAYMENT_FOR_DONATION NUMBER(17),
C_PREFERRED_STOCK_DIVIDEND_PAY NUMBER(17),
C_PRINCIPLE_BUSINESS_PROFIT NUMBER(17),
C_PRINCIPLE_B_TAX_EXTRA_CHARGE NUMBER(17),
C_PROFIT_AVAILABLE_DISTRIBUTI NUMBER(17),
C_PROFIT_AVAILABLE_OWNERS_DIST NUMBER(17),
C_PROFIT_DISTRIBUTION_B_PERIOD NUMBER(17),
C_PROFIT_RESERVED_A_SINGLEIT NUMBER(17),
C_PRO_CAP_RETURN_INVESTMENT NUMBER(17),
C_SALES_INCOME_E_GOODS_PRODUCT NUMBER(17),
C_SALES_INCOME_E_PRODUCTS NUMBER(17),
C_SALES_INCOME_I_GOODS_PRODUCT NUMBER(17),
C_SELLING_EXPENSES NUMBER(17),
C_SUPPLEMENTARY_CURRENT_CAPIT NUMBER(17),
C_TOTAL_PROFIT NUMBER(17),
C_TRANSFER_ORDINARY_SHARES_DP NUMBER(17),
C_UNAPPROPRIATED_PROFIT NUMBER(17),
C_UNREALIZED_INVESTMENT_LOSSES NUMBER(17),
C_WITHDRAWAL_OTHER_COMM_ACC_FU NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_620_C is '企业利润及利润分配表信息-2002版利润及利润分配表段';
comment on column MBT_DM_620_C.DATA_ID is '数据ID';
comment on column MBT_DM_620_C.DATA_DATE is '数据日期';
comment on column MBT_DM_620_C.CORP_ID is '法人ID';
comment on column MBT_DM_620_C.ORG_ID is '机构ID';
comment on column MBT_DM_620_C.GROUP_ID is '数据分组';
comment on column MBT_DM_620_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_620_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_620_C.C_ALLOWANCE_INCOME is '补贴收入';
comment on column MBT_DM_620_C.C_ALLOWANCE_INCOME_B_ALLOWANCE is '（补贴收入科目下）补贴前亏损的企业补贴收入';
comment on column MBT_DM_620_C.C_APPR_ENTERPRISE_EXP_FUND is '提取企业发展基金';
comment on column MBT_DM_620_C.C_APPR_RESERVE_FUND is '提取储备基金';
comment on column MBT_DM_620_C.C_APPR_STAFF_INC_WELFARE_FUND is '提取职工奖励及福利基金';
comment on column MBT_DM_620_C.C_APPR_STATUTORY_SURPLUS_RES is '提取法定盈余公积';
comment on column MBT_DM_620_C.C_APPR_STATUTORY_WELFAREFUND is '提取法定公益金';
comment on column MBT_DM_620_C.C_BALANCE_OF_CONTENTSALARY is '（其他支出）结转的含量工资包干节余';
comment on column MBT_DM_620_C.C_CALCULATING_CONTENT_SALARY_B is '（其他科目下）用以前年度含量工资节余弥补利润';
comment on column MBT_DM_620_C.C_COMPENSATION_SURPLUS_RES is '盈余公积补亏';
comment on column MBT_DM_620_C.C_DEFERRED_INCOME is '递延收益';
comment on column MBT_DM_620_C.C_DISCOUNT_ALLOWANCE is '销售折扣与折让';
comment on column MBT_DM_620_C.C_EXCHANGE_NON_MONETARY_ASS_L is '（营业外支出科目下）债务重组损失';
comment on column MBT_DM_620_C.C_FINANCIAL_EXPENSES is '财务费用';
comment on column MBT_DM_620_C.C_FUTURES_INCOME is '期货收益';
comment on column MBT_DM_620_C.C_GENERAL_ADMIN_EXPENSES is '管理费用';
comment on column MBT_DM_620_C.C_IMPARIMENT_LOSS is '少数股东损益';
comment on column MBT_DM_620_C.C_INCOMETAX is '所得税';
comment on column MBT_DM_620_C.C_INCOME_FROM_PENALTY is '（营业外收入科目下）罚款净收入';
comment on column MBT_DM_620_C.C_INCOME_NON_CURRENCY_TRADE is '（营业外收入科目下）非货币性交易收益';
comment on column MBT_DM_620_C.C_INCOME_SALES_AGENCY is '代购代销收入';
comment on column MBT_DM_620_C.C_INCOME_SALES_INTANGIBLE_ASS is '（营业外收入科目下）出售无形资产收益';
comment on column MBT_DM_620_C.C_INVESTMENT_INCOME is '投资收益';
comment on column MBT_DM_620_C.C_LOSS_COMPENSATED_BEFORE_TAX is '（未分配利润科目下）应由以后年度税前利润弥补的亏损';
comment on column MBT_DM_620_C.C_LOSS_DISPOSAL_FIXED_ASSETS is '（营业外支出科目下）处置固定资产净损失';
comment on column MBT_DM_620_C.C_LOSS_LAWSUITS is '（营业外支出科目下）罚款支出';
comment on column MBT_DM_620_C.C_MAIN_OPERATING_COST is '主营业务成本';
comment on column MBT_DM_620_C.C_MAIN_REVENUEF_REVENUE is '主营业务收入';
comment on column MBT_DM_620_C.C_NET_AMOUNT_INCOME_MAIN_BUSI is '主营业务收入净额';
comment on column MBT_DM_620_C.C_NET_GAIN_DISPOSAL_FIXED_ASS is '（营业外收入科目下）处置固定资产净收益';
comment on column MBT_DM_620_C.C_NET_PROFIT is '净利润';
comment on column MBT_DM_620_C.C_NON_OPERATING_EXPENSES is '营业外支出';
comment on column MBT_DM_620_C.C_NON_OPERATING_INCOME is '营业外收入';
comment on column MBT_DM_620_C.C_OPERATING_PROFITS is '营业利润';
comment on column MBT_DM_620_C.C_OPERATION_EXPENSE is '经营费用';
comment on column MBT_DM_620_C.C_OTHERS is '（可供分配的利润科目下）其他';
comment on column MBT_DM_620_C.C_OTHERS_EXPENSES is '其他（费用）';
comment on column MBT_DM_620_C.C_OTHERS_INCOME is '其他（利润）';
comment on column MBT_DM_620_C.C_OTHERS_OPERATING_COST is '其他（业务成本）';
comment on column MBT_DM_620_C.C_OTHERS_OWNERS is '（可供投资者分配的利润科目下）其他';
comment on column MBT_DM_620_C.C_OTHER_ADJUSTMENT_FACTORS is '其他调整因素';
comment on column MBT_DM_620_C.C_OTHER_BUSINESS_PROFIT is '其他业务利润';
comment on column MBT_DM_620_C.C_OTHER_OPERATING_INCOME is '其他（收入）';
comment on column MBT_DM_620_C.C_OTHER_PAYMENTS is '其他支出';
comment on column MBT_DM_620_C.C_PAYABLE_DIVIDENDS_COMMON_STO is '应付普通股股利';
comment on column MBT_DM_620_C.C_PAYMENT_FOR_DONATION is '（营业外支出科目下）捐赠支出';
comment on column MBT_DM_620_C.C_PREFERRED_STOCK_DIVIDEND_PAY is '应付优先股股利';
comment on column MBT_DM_620_C.C_PRINCIPLE_BUSINESS_PROFIT is '主营业务利润';
comment on column MBT_DM_620_C.C_PRINCIPLE_B_TAX_EXTRA_CHARGE is '主营业务税金及附加';
comment on column MBT_DM_620_C.C_PROFIT_AVAILABLE_DISTRIBUTI is '可供分配的利润';
comment on column MBT_DM_620_C.C_PROFIT_AVAILABLE_OWNERS_DIST is '可供投资者分配的利润';
comment on column MBT_DM_620_C.C_PROFIT_DISTRIBUTION_B_PERIOD is '年初未分配利润';
comment on column MBT_DM_620_C.C_PROFIT_RESERVED_A_SINGLEIT is '单项留用的利润';
comment on column MBT_DM_620_C.C_PRO_CAP_RETURN_INVESTMENT is '利润归还投资';
comment on column MBT_DM_620_C.C_SALES_INCOME_E_GOODS_PRODUCT is '（主营业务收入科目下）出口产品销售收入';
comment on column MBT_DM_620_C.C_SALES_INCOME_E_PRODUCTS is '（主营业务成本科目下）出口产品销售成本';
comment on column MBT_DM_620_C.C_SALES_INCOME_I_GOODS_PRODUCT is '（主营业务收入科目下）进口产品销售收入';
comment on column MBT_DM_620_C.C_SELLING_EXPENSES is '营业费用';
comment on column MBT_DM_620_C.C_SUPPLEMENTARY_CURRENT_CAPIT is '补充流动资本';
comment on column MBT_DM_620_C.C_TOTAL_PROFIT is '利润总额';
comment on column MBT_DM_620_C.C_TRANSFER_ORDINARY_SHARES_DP is '转作资本的普通股股利';
comment on column MBT_DM_620_C.C_UNAPPROPRIATED_PROFIT is '未分配利润';
comment on column MBT_DM_620_C.C_UNREALIZED_INVESTMENT_LOSSES is '未确认的投资损失';
comment on column MBT_DM_620_C.C_WITHDRAWAL_OTHER_COMM_ACC_FU is '提取任意盈余公积';
comment on column MBT_DM_620_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_620_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_620_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_620_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_620_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_620_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_620_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_620_C.CUST_NO is '客户号';
comment on column MBT_DM_620_C.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_620_C.PART_TYPE is '段标识';
comment on column MBT_DM_620_C.PART_NAME is '段名称';
comment on column MBT_DM_620_C.START_DATE is '起始日期';
comment on column MBT_DM_620_C.END_DATE is '结束日期';
comment on column MBT_DM_620_C.BATCH_NO is '批次号';
comment on column MBT_DM_620_C.ROW_NUM is '行号';
comment on column MBT_DM_620_C.IS_RPT is '是否报送';
comment on column MBT_DM_620_C.IS_VALID is '是否有效';
comment on column MBT_DM_620_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_620_C.OPT_FLAG is '操作标识';
comment on column MBT_DM_620_C.RPT_DATE is '报送日期';
comment on column MBT_DM_620_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_620_C.RPT_STATUS is '报送状态';
comment on column MBT_DM_620_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_620_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_620_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_620_C.REMARKS is '备注';
comment on column MBT_DM_620_C.CHECK_FLAG is '校验标志';
comment on column MBT_DM_620_C.CHECK_DESC is '校验说明';
comment on column MBT_DM_620_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_620_C.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_620_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_620_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_620_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_620_C.DATA_FLAG is '数据标志';
comment on column MBT_DM_620_C.DATA_OP is '操作标志';
comment on column MBT_DM_620_C.DATA_SOURCE is '数据来源';
comment on column MBT_DM_620_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_620_C.DATA_HASH is '数据HASH';
comment on column MBT_DM_620_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_620_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_620_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_620_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_620_C.DATA_CRT_USER is '创建人';
comment on column MBT_DM_620_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_620_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_620_C.DATA_CHG_USER is '修改人';
comment on column MBT_DM_620_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_620_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_620_C.DATA_APV_USER is '审核人';
comment on column MBT_DM_620_C.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_620_C.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_620_C.RSV1 is '备用字段';
comment on column MBT_DM_620_C.RSV2 is '备用字段';
comment on column MBT_DM_620_C.RSV3 is '备用字段';
comment on column MBT_DM_620_C.RSV4 is '备用字段';
comment on column MBT_DM_620_C.RSV5 is '备用字段';
create table MBT_DM_620_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_BASIC_EARNINGS_PER_SHARE NUMBER(17),
D_BUSINESS_OTHER_TAXES NUMBER(17),
D_COST_OF_SALES NUMBER(17),
D_DILUTED_EARNINGS_PER_SHARE NUMBER(17),
D_FINANCIAL_EXPENSE NUMBER(17),
D_GENERAL_ADMIN_EXPENSES NUMBER(17),
D_IMPAIRMENT_LOSS_OF_ASSETS NUMBER(17),
D_INCOME_TAX_EXPENSE NUMBER(17),
D_INVESTMENT_INCOME NUMBER(17),
D_INVESTMENT_INCOME_ENTERPRISE NUMBER(17),
D_NET_PROFIT NUMBER(17),
D_NON_CURRENT_ASSETS NUMBER(17),
D_NON_OPERATING_EXPENSES NUMBER(17),
D_NON_OPERATING_INCOME NUMBER(17),
D_OPERATING_PROFITS NUMBER(17),
D_PROFIT_BEFORE_TAX NUMBER(17),
D_PROFIT_LOSS_ARISING_FAIR_VAL NUMBER(17),
D_REVENUE_OF_SALES NUMBER(17),
D_SELLING_EXPENSES NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_620_D is '企业利润及利润分配表信息-2007版利润及利润分配表段';
comment on column MBT_DM_620_D.DATA_ID is '数据ID';
comment on column MBT_DM_620_D.DATA_DATE is '数据日期';
comment on column MBT_DM_620_D.CORP_ID is '法人ID';
comment on column MBT_DM_620_D.ORG_ID is '机构ID';
comment on column MBT_DM_620_D.GROUP_ID is '数据分组';
comment on column MBT_DM_620_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_620_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_620_D.D_BASIC_EARNINGS_PER_SHARE is '基本每股收益';
comment on column MBT_DM_620_D.D_BUSINESS_OTHER_TAXES is '营业税金及附加';
comment on column MBT_DM_620_D.D_COST_OF_SALES is '营业成本';
comment on column MBT_DM_620_D.D_DILUTED_EARNINGS_PER_SHARE is '稀释每股收益';
comment on column MBT_DM_620_D.D_FINANCIAL_EXPENSE is '财务费用';
comment on column MBT_DM_620_D.D_GENERAL_ADMIN_EXPENSES is '管理费用';
comment on column MBT_DM_620_D.D_IMPAIRMENT_LOSS_OF_ASSETS is '资产减值损失';
comment on column MBT_DM_620_D.D_INCOME_TAX_EXPENSE is '所得税费用';
comment on column MBT_DM_620_D.D_INVESTMENT_INCOME is '投资净收益';
comment on column MBT_DM_620_D.D_INVESTMENT_INCOME_ENTERPRISE is '对联营企业和合营企业的投资收益';
comment on column MBT_DM_620_D.D_NET_PROFIT is '净利润';
comment on column MBT_DM_620_D.D_NON_CURRENT_ASSETS is '非流动资产损失（其中：非流动资产处置损失）';
comment on column MBT_DM_620_D.D_NON_OPERATING_EXPENSES is '营业外支出';
comment on column MBT_DM_620_D.D_NON_OPERATING_INCOME is '营业外收入';
comment on column MBT_DM_620_D.D_OPERATING_PROFITS is '营业利润';
comment on column MBT_DM_620_D.D_PROFIT_BEFORE_TAX is '利润总额';
comment on column MBT_DM_620_D.D_PROFIT_LOSS_ARISING_FAIR_VAL is '公允价值变动净收益';
comment on column MBT_DM_620_D.D_REVENUE_OF_SALES is '营业收入';
comment on column MBT_DM_620_D.D_SELLING_EXPENSES is '销售费用';
comment on column MBT_DM_620_D.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_620_D.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_620_D.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_620_D.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_620_D.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_620_D.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_620_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_620_D.CUST_NO is '客户号';
comment on column MBT_DM_620_D.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_620_D.PART_TYPE is '段标识';
comment on column MBT_DM_620_D.PART_NAME is '段名称';
comment on column MBT_DM_620_D.START_DATE is '起始日期';
comment on column MBT_DM_620_D.END_DATE is '结束日期';
comment on column MBT_DM_620_D.BATCH_NO is '批次号';
comment on column MBT_DM_620_D.ROW_NUM is '行号';
comment on column MBT_DM_620_D.IS_RPT is '是否报送';
comment on column MBT_DM_620_D.IS_VALID is '是否有效';
comment on column MBT_DM_620_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_620_D.OPT_FLAG is '操作标识';
comment on column MBT_DM_620_D.RPT_DATE is '报送日期';
comment on column MBT_DM_620_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_620_D.RPT_STATUS is '报送状态';
comment on column MBT_DM_620_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_620_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_620_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_620_D.REMARKS is '备注';
comment on column MBT_DM_620_D.CHECK_FLAG is '校验标志';
comment on column MBT_DM_620_D.CHECK_DESC is '校验说明';
comment on column MBT_DM_620_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_620_D.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_620_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_620_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_620_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_620_D.DATA_FLAG is '数据标志';
comment on column MBT_DM_620_D.DATA_OP is '操作标志';
comment on column MBT_DM_620_D.DATA_SOURCE is '数据来源';
comment on column MBT_DM_620_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_620_D.DATA_HASH is '数据HASH';
comment on column MBT_DM_620_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_620_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_620_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_620_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_620_D.DATA_CRT_USER is '创建人';
comment on column MBT_DM_620_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_620_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_620_D.DATA_CHG_USER is '修改人';
comment on column MBT_DM_620_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_620_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_620_D.DATA_APV_USER is '审核人';
comment on column MBT_DM_620_D.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_620_D.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_620_D.RSV1 is '备用字段';
comment on column MBT_DM_620_D.RSV2 is '备用字段';
comment on column MBT_DM_620_D.RSV3 is '备用字段';
comment on column MBT_DM_620_D.RSV4 is '备用字段';
comment on column MBT_DM_620_D.RSV5 is '备用字段';
create table MBT_PM_620 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_620 is '企业利润及利润分配表信息';
comment on column MBT_PM_620.DATA_ID is '数据ID';
comment on column MBT_PM_620.DATA_DATE is '数据日期';
comment on column MBT_PM_620.CORP_ID is '法人ID';
comment on column MBT_PM_620.ORG_ID is '机构ID';
comment on column MBT_PM_620.GROUP_ID is '数据分组';
comment on column MBT_PM_620.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_620.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_620.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_620.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_620.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_620.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_620.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_620.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_620.B_ENT_NAME is '企业名称';
comment on column MBT_PM_620.SECTION_CHG_CNT is '段变更';
comment on column MBT_PM_620.SECTION_DEL_CNT is '段删除';
comment on column MBT_PM_620.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_PM_620.IDN_CHG_CNT is '标识项变更';
comment on column MBT_PM_620.CUST_NO is '客户号';
comment on column MBT_PM_620.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_620.PART_TYPE is '段标识';
comment on column MBT_PM_620.PART_NAME is '段名称';
comment on column MBT_PM_620.START_DATE is '起始日期';
comment on column MBT_PM_620.END_DATE is '结束日期';
comment on column MBT_PM_620.BATCH_NO is '批次号';
comment on column MBT_PM_620.ROW_NUM is '行号';
comment on column MBT_PM_620.IS_RPT is '是否报送';
comment on column MBT_PM_620.IS_VALID is '是否有效';
comment on column MBT_PM_620.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_620.OPT_FLAG is '操作标识';
comment on column MBT_PM_620.RPT_DATE is '报送日期';
comment on column MBT_PM_620.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_620.RPT_STATUS is '报送状态';
comment on column MBT_PM_620.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_620.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_620.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_620.REMARKS is '备注';
comment on column MBT_PM_620.CHECK_FLAG is '校验标志';
comment on column MBT_PM_620.CHECK_DESC is '校验说明';
comment on column MBT_PM_620.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_620.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_620.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_620.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_620.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_620.DATA_FLAG is '数据标志';
comment on column MBT_PM_620.DATA_OP is '操作标志';
comment on column MBT_PM_620.DATA_SOURCE is '数据来源';
comment on column MBT_PM_620.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_620.DATA_HASH is '数据HASH';
comment on column MBT_PM_620.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_620.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_620.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_620.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_620.DATA_CRT_USER is '创建人';
comment on column MBT_PM_620.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_620.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_620.DATA_CHG_USER is '修改人';
comment on column MBT_PM_620.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_620.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_620.DATA_APV_USER is '审核人';
comment on column MBT_PM_620.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_620.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_620.RSV1 is '备用字段';
comment on column MBT_PM_620.RSV2 is '备用字段';
comment on column MBT_PM_620.RSV3 is '备用字段';
comment on column MBT_PM_620.RSV4 is '备用字段';
comment on column MBT_PM_620.RSV5 is '备用字段';
create table MBT_PM_620_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_620_B is '企业利润及利润分配表信息-基础段';
comment on column MBT_PM_620_B.DATA_ID is '数据ID';
comment on column MBT_PM_620_B.DATA_DATE is '数据日期';
comment on column MBT_PM_620_B.CORP_ID is '法人ID';
comment on column MBT_PM_620_B.ORG_ID is '机构ID';
comment on column MBT_PM_620_B.GROUP_ID is '数据分组';
comment on column MBT_PM_620_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_620_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_620_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_620_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_620_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_620_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_620_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_620_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_620_B.B_ENT_NAME is '企业名称';
comment on column MBT_PM_620_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_PM_620_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_PM_620_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_PM_620_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_PM_620_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_PM_620_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_620_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_PM_620_B.CUST_NO is '客户号';
comment on column MBT_PM_620_B.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_620_B.PART_TYPE is '段标识';
comment on column MBT_PM_620_B.PART_NAME is '段名称';
comment on column MBT_PM_620_B.START_DATE is '起始日期';
comment on column MBT_PM_620_B.END_DATE is '结束日期';
comment on column MBT_PM_620_B.BATCH_NO is '批次号';
comment on column MBT_PM_620_B.ROW_NUM is '行号';
comment on column MBT_PM_620_B.IS_RPT is '是否报送';
comment on column MBT_PM_620_B.IS_VALID is '是否有效';
comment on column MBT_PM_620_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_620_B.OPT_FLAG is '操作标识';
comment on column MBT_PM_620_B.RPT_DATE is '报送日期';
comment on column MBT_PM_620_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_620_B.RPT_STATUS is '报送状态';
comment on column MBT_PM_620_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_620_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_620_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_620_B.REMARKS is '备注';
comment on column MBT_PM_620_B.CHECK_FLAG is '校验标志';
comment on column MBT_PM_620_B.CHECK_DESC is '校验说明';
comment on column MBT_PM_620_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_620_B.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_620_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_620_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_620_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_620_B.DATA_FLAG is '数据标志';
comment on column MBT_PM_620_B.DATA_OP is '操作标志';
comment on column MBT_PM_620_B.DATA_SOURCE is '数据来源';
comment on column MBT_PM_620_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_620_B.DATA_HASH is '数据HASH';
comment on column MBT_PM_620_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_620_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_620_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_620_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_620_B.DATA_CRT_USER is '创建人';
comment on column MBT_PM_620_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_620_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_620_B.DATA_CHG_USER is '修改人';
comment on column MBT_PM_620_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_620_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_620_B.DATA_APV_USER is '审核人';
comment on column MBT_PM_620_B.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_620_B.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_620_B.RSV1 is '备用字段';
comment on column MBT_PM_620_B.RSV2 is '备用字段';
comment on column MBT_PM_620_B.RSV3 is '备用字段';
comment on column MBT_PM_620_B.RSV4 is '备用字段';
comment on column MBT_PM_620_B.RSV5 is '备用字段';
create table MBT_PM_620_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ALLOWANCE_INCOME NUMBER(17),
C_ALLOWANCE_INCOME_B_ALLOWANCE NUMBER(17),
C_APPR_ENTERPRISE_EXP_FUND NUMBER(17),
C_APPR_RESERVE_FUND NUMBER(17),
C_APPR_STAFF_INC_WELFARE_FUND NUMBER(17),
C_APPR_STATUTORY_SURPLUS_RES NUMBER(17),
C_APPR_STATUTORY_WELFAREFUND NUMBER(17),
C_BALANCE_OF_CONTENTSALARY NUMBER(17),
C_CALCULATING_CONTENT_SALARY_B NUMBER(17),
C_COMPENSATION_SURPLUS_RES NUMBER(17),
C_DEFERRED_INCOME NUMBER(17),
C_DISCOUNT_ALLOWANCE NUMBER(17),
C_EXCHANGE_NON_MONETARY_ASS_L NUMBER(17),
C_FINANCIAL_EXPENSES NUMBER(17),
C_FUTURES_INCOME NUMBER(17),
C_GENERAL_ADMIN_EXPENSES NUMBER(17),
C_IMPARIMENT_LOSS NUMBER(17),
C_INCOMETAX NUMBER(17),
C_INCOME_FROM_PENALTY NUMBER(17),
C_INCOME_NON_CURRENCY_TRADE NUMBER(17),
C_INCOME_SALES_AGENCY NUMBER(17),
C_INCOME_SALES_INTANGIBLE_ASS NUMBER(17),
C_INVESTMENT_INCOME NUMBER(17),
C_LOSS_COMPENSATED_BEFORE_TAX NUMBER(17),
C_LOSS_DISPOSAL_FIXED_ASSETS NUMBER(17),
C_LOSS_LAWSUITS NUMBER(17),
C_MAIN_OPERATING_COST NUMBER(17),
C_MAIN_REVENUEF_REVENUE NUMBER(17),
C_NET_AMOUNT_INCOME_MAIN_BUSI NUMBER(17),
C_NET_GAIN_DISPOSAL_FIXED_ASS NUMBER(17),
C_NET_PROFIT NUMBER(17),
C_NON_OPERATING_EXPENSES NUMBER(17),
C_NON_OPERATING_INCOME NUMBER(17),
C_OPERATING_PROFITS NUMBER(17),
C_OPERATION_EXPENSE NUMBER(17),
C_OTHERS NUMBER(17),
C_OTHERS_EXPENSES NUMBER(17),
C_OTHERS_INCOME NUMBER(17),
C_OTHERS_OPERATING_COST NUMBER(17),
C_OTHERS_OWNERS NUMBER(17),
C_OTHER_ADJUSTMENT_FACTORS NUMBER(17),
C_OTHER_BUSINESS_PROFIT NUMBER(17),
C_OTHER_OPERATING_INCOME NUMBER(17),
C_OTHER_PAYMENTS NUMBER(17),
C_PAYABLE_DIVIDENDS_COMMON_STO NUMBER(17),
C_PAYMENT_FOR_DONATION NUMBER(17),
C_PREFERRED_STOCK_DIVIDEND_PAY NUMBER(17),
C_PRINCIPLE_BUSINESS_PROFIT NUMBER(17),
C_PRINCIPLE_B_TAX_EXTRA_CHARGE NUMBER(17),
C_PROFIT_AVAILABLE_DISTRIBUTI NUMBER(17),
C_PROFIT_AVAILABLE_OWNERS_DIST NUMBER(17),
C_PROFIT_DISTRIBUTION_B_PERIOD NUMBER(17),
C_PROFIT_RESERVED_A_SINGLEIT NUMBER(17),
C_PRO_CAP_RETURN_INVESTMENT NUMBER(17),
C_SALES_INCOME_E_GOODS_PRODUCT NUMBER(17),
C_SALES_INCOME_E_PRODUCTS NUMBER(17),
C_SALES_INCOME_I_GOODS_PRODUCT NUMBER(17),
C_SELLING_EXPENSES NUMBER(17),
C_SUPPLEMENTARY_CURRENT_CAPIT NUMBER(17),
C_TOTAL_PROFIT NUMBER(17),
C_TRANSFER_ORDINARY_SHARES_DP NUMBER(17),
C_UNAPPROPRIATED_PROFIT NUMBER(17),
C_UNREALIZED_INVESTMENT_LOSSES NUMBER(17),
C_WITHDRAWAL_OTHER_COMM_ACC_FU NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_620_C is '企业利润及利润分配表信息-2002版利润及利润分配表段';
comment on column MBT_PM_620_C.DATA_ID is '数据ID';
comment on column MBT_PM_620_C.DATA_DATE is '数据日期';
comment on column MBT_PM_620_C.CORP_ID is '法人ID';
comment on column MBT_PM_620_C.ORG_ID is '机构ID';
comment on column MBT_PM_620_C.GROUP_ID is '数据分组';
comment on column MBT_PM_620_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_620_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_620_C.C_ALLOWANCE_INCOME is '补贴收入';
comment on column MBT_PM_620_C.C_ALLOWANCE_INCOME_B_ALLOWANCE is '（补贴收入科目下）补贴前亏损的企业补贴收入';
comment on column MBT_PM_620_C.C_APPR_ENTERPRISE_EXP_FUND is '提取企业发展基金';
comment on column MBT_PM_620_C.C_APPR_RESERVE_FUND is '提取储备基金';
comment on column MBT_PM_620_C.C_APPR_STAFF_INC_WELFARE_FUND is '提取职工奖励及福利基金';
comment on column MBT_PM_620_C.C_APPR_STATUTORY_SURPLUS_RES is '提取法定盈余公积';
comment on column MBT_PM_620_C.C_APPR_STATUTORY_WELFAREFUND is '提取法定公益金';
comment on column MBT_PM_620_C.C_BALANCE_OF_CONTENTSALARY is '（其他支出）结转的含量工资包干节余';
comment on column MBT_PM_620_C.C_CALCULATING_CONTENT_SALARY_B is '（其他科目下）用以前年度含量工资节余弥补利润';
comment on column MBT_PM_620_C.C_COMPENSATION_SURPLUS_RES is '盈余公积补亏';
comment on column MBT_PM_620_C.C_DEFERRED_INCOME is '递延收益';
comment on column MBT_PM_620_C.C_DISCOUNT_ALLOWANCE is '销售折扣与折让';
comment on column MBT_PM_620_C.C_EXCHANGE_NON_MONETARY_ASS_L is '（营业外支出科目下）债务重组损失';
comment on column MBT_PM_620_C.C_FINANCIAL_EXPENSES is '财务费用';
comment on column MBT_PM_620_C.C_FUTURES_INCOME is '期货收益';
comment on column MBT_PM_620_C.C_GENERAL_ADMIN_EXPENSES is '管理费用';
comment on column MBT_PM_620_C.C_IMPARIMENT_LOSS is '少数股东损益';
comment on column MBT_PM_620_C.C_INCOMETAX is '所得税';
comment on column MBT_PM_620_C.C_INCOME_FROM_PENALTY is '（营业外收入科目下）罚款净收入';
comment on column MBT_PM_620_C.C_INCOME_NON_CURRENCY_TRADE is '（营业外收入科目下）非货币性交易收益';
comment on column MBT_PM_620_C.C_INCOME_SALES_AGENCY is '代购代销收入';
comment on column MBT_PM_620_C.C_INCOME_SALES_INTANGIBLE_ASS is '（营业外收入科目下）出售无形资产收益';
comment on column MBT_PM_620_C.C_INVESTMENT_INCOME is '投资收益';
comment on column MBT_PM_620_C.C_LOSS_COMPENSATED_BEFORE_TAX is '（未分配利润科目下）应由以后年度税前利润弥补的亏损';
comment on column MBT_PM_620_C.C_LOSS_DISPOSAL_FIXED_ASSETS is '（营业外支出科目下）处置固定资产净损失';
comment on column MBT_PM_620_C.C_LOSS_LAWSUITS is '（营业外支出科目下）罚款支出';
comment on column MBT_PM_620_C.C_MAIN_OPERATING_COST is '主营业务成本';
comment on column MBT_PM_620_C.C_MAIN_REVENUEF_REVENUE is '主营业务收入';
comment on column MBT_PM_620_C.C_NET_AMOUNT_INCOME_MAIN_BUSI is '主营业务收入净额';
comment on column MBT_PM_620_C.C_NET_GAIN_DISPOSAL_FIXED_ASS is '（营业外收入科目下）处置固定资产净收益';
comment on column MBT_PM_620_C.C_NET_PROFIT is '净利润';
comment on column MBT_PM_620_C.C_NON_OPERATING_EXPENSES is '营业外支出';
comment on column MBT_PM_620_C.C_NON_OPERATING_INCOME is '营业外收入';
comment on column MBT_PM_620_C.C_OPERATING_PROFITS is '营业利润';
comment on column MBT_PM_620_C.C_OPERATION_EXPENSE is '经营费用';
comment on column MBT_PM_620_C.C_OTHERS is '（可供分配的利润科目下）其他';
comment on column MBT_PM_620_C.C_OTHERS_EXPENSES is '其他（费用）';
comment on column MBT_PM_620_C.C_OTHERS_INCOME is '其他（利润）';
comment on column MBT_PM_620_C.C_OTHERS_OPERATING_COST is '其他（业务成本）';
comment on column MBT_PM_620_C.C_OTHERS_OWNERS is '（可供投资者分配的利润科目下）其他';
comment on column MBT_PM_620_C.C_OTHER_ADJUSTMENT_FACTORS is '其他调整因素';
comment on column MBT_PM_620_C.C_OTHER_BUSINESS_PROFIT is '其他业务利润';
comment on column MBT_PM_620_C.C_OTHER_OPERATING_INCOME is '其他（收入）';
comment on column MBT_PM_620_C.C_OTHER_PAYMENTS is '其他支出';
comment on column MBT_PM_620_C.C_PAYABLE_DIVIDENDS_COMMON_STO is '应付普通股股利';
comment on column MBT_PM_620_C.C_PAYMENT_FOR_DONATION is '（营业外支出科目下）捐赠支出';
comment on column MBT_PM_620_C.C_PREFERRED_STOCK_DIVIDEND_PAY is '应付优先股股利';
comment on column MBT_PM_620_C.C_PRINCIPLE_BUSINESS_PROFIT is '主营业务利润';
comment on column MBT_PM_620_C.C_PRINCIPLE_B_TAX_EXTRA_CHARGE is '主营业务税金及附加';
comment on column MBT_PM_620_C.C_PROFIT_AVAILABLE_DISTRIBUTI is '可供分配的利润';
comment on column MBT_PM_620_C.C_PROFIT_AVAILABLE_OWNERS_DIST is '可供投资者分配的利润';
comment on column MBT_PM_620_C.C_PROFIT_DISTRIBUTION_B_PERIOD is '年初未分配利润';
comment on column MBT_PM_620_C.C_PROFIT_RESERVED_A_SINGLEIT is '单项留用的利润';
comment on column MBT_PM_620_C.C_PRO_CAP_RETURN_INVESTMENT is '利润归还投资';
comment on column MBT_PM_620_C.C_SALES_INCOME_E_GOODS_PRODUCT is '（主营业务收入科目下）出口产品销售收入';
comment on column MBT_PM_620_C.C_SALES_INCOME_E_PRODUCTS is '（主营业务成本科目下）出口产品销售成本';
comment on column MBT_PM_620_C.C_SALES_INCOME_I_GOODS_PRODUCT is '（主营业务收入科目下）进口产品销售收入';
comment on column MBT_PM_620_C.C_SELLING_EXPENSES is '营业费用';
comment on column MBT_PM_620_C.C_SUPPLEMENTARY_CURRENT_CAPIT is '补充流动资本';
comment on column MBT_PM_620_C.C_TOTAL_PROFIT is '利润总额';
comment on column MBT_PM_620_C.C_TRANSFER_ORDINARY_SHARES_DP is '转作资本的普通股股利';
comment on column MBT_PM_620_C.C_UNAPPROPRIATED_PROFIT is '未分配利润';
comment on column MBT_PM_620_C.C_UNREALIZED_INVESTMENT_LOSSES is '未确认的投资损失';
comment on column MBT_PM_620_C.C_WITHDRAWAL_OTHER_COMM_ACC_FU is '提取任意盈余公积';
comment on column MBT_PM_620_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_620_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_620_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_620_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_620_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_620_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_620_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_620_C.CUST_NO is '客户号';
comment on column MBT_PM_620_C.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_620_C.PART_TYPE is '段标识';
comment on column MBT_PM_620_C.PART_NAME is '段名称';
comment on column MBT_PM_620_C.START_DATE is '起始日期';
comment on column MBT_PM_620_C.END_DATE is '结束日期';
comment on column MBT_PM_620_C.BATCH_NO is '批次号';
comment on column MBT_PM_620_C.ROW_NUM is '行号';
comment on column MBT_PM_620_C.IS_RPT is '是否报送';
comment on column MBT_PM_620_C.IS_VALID is '是否有效';
comment on column MBT_PM_620_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_620_C.OPT_FLAG is '操作标识';
comment on column MBT_PM_620_C.RPT_DATE is '报送日期';
comment on column MBT_PM_620_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_620_C.RPT_STATUS is '报送状态';
comment on column MBT_PM_620_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_620_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_620_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_620_C.REMARKS is '备注';
comment on column MBT_PM_620_C.CHECK_FLAG is '校验标志';
comment on column MBT_PM_620_C.CHECK_DESC is '校验说明';
comment on column MBT_PM_620_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_620_C.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_620_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_620_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_620_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_620_C.DATA_FLAG is '数据标志';
comment on column MBT_PM_620_C.DATA_OP is '操作标志';
comment on column MBT_PM_620_C.DATA_SOURCE is '数据来源';
comment on column MBT_PM_620_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_620_C.DATA_HASH is '数据HASH';
comment on column MBT_PM_620_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_620_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_620_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_620_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_620_C.DATA_CRT_USER is '创建人';
comment on column MBT_PM_620_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_620_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_620_C.DATA_CHG_USER is '修改人';
comment on column MBT_PM_620_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_620_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_620_C.DATA_APV_USER is '审核人';
comment on column MBT_PM_620_C.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_620_C.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_620_C.RSV1 is '备用字段';
comment on column MBT_PM_620_C.RSV2 is '备用字段';
comment on column MBT_PM_620_C.RSV3 is '备用字段';
comment on column MBT_PM_620_C.RSV4 is '备用字段';
comment on column MBT_PM_620_C.RSV5 is '备用字段';
create table MBT_PM_620_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_BASIC_EARNINGS_PER_SHARE NUMBER(17),
D_BUSINESS_OTHER_TAXES NUMBER(17),
D_COST_OF_SALES NUMBER(17),
D_DILUTED_EARNINGS_PER_SHARE NUMBER(17),
D_FINANCIAL_EXPENSE NUMBER(17),
D_GENERAL_ADMIN_EXPENSES NUMBER(17),
D_IMPAIRMENT_LOSS_OF_ASSETS NUMBER(17),
D_INCOME_TAX_EXPENSE NUMBER(17),
D_INVESTMENT_INCOME NUMBER(17),
D_INVESTMENT_INCOME_ENTERPRISE NUMBER(17),
D_NET_PROFIT NUMBER(17),
D_NON_CURRENT_ASSETS NUMBER(17),
D_NON_OPERATING_EXPENSES NUMBER(17),
D_NON_OPERATING_INCOME NUMBER(17),
D_OPERATING_PROFITS NUMBER(17),
D_PROFIT_BEFORE_TAX NUMBER(17),
D_PROFIT_LOSS_ARISING_FAIR_VAL NUMBER(17),
D_REVENUE_OF_SALES NUMBER(17),
D_SELLING_EXPENSES NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_620_D is '企业利润及利润分配表信息-2007版利润及利润分配表段';
comment on column MBT_PM_620_D.DATA_ID is '数据ID';
comment on column MBT_PM_620_D.DATA_DATE is '数据日期';
comment on column MBT_PM_620_D.CORP_ID is '法人ID';
comment on column MBT_PM_620_D.ORG_ID is '机构ID';
comment on column MBT_PM_620_D.GROUP_ID is '数据分组';
comment on column MBT_PM_620_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_620_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_620_D.D_BASIC_EARNINGS_PER_SHARE is '基本每股收益';
comment on column MBT_PM_620_D.D_BUSINESS_OTHER_TAXES is '营业税金及附加';
comment on column MBT_PM_620_D.D_COST_OF_SALES is '营业成本';
comment on column MBT_PM_620_D.D_DILUTED_EARNINGS_PER_SHARE is '稀释每股收益';
comment on column MBT_PM_620_D.D_FINANCIAL_EXPENSE is '财务费用';
comment on column MBT_PM_620_D.D_GENERAL_ADMIN_EXPENSES is '管理费用';
comment on column MBT_PM_620_D.D_IMPAIRMENT_LOSS_OF_ASSETS is '资产减值损失';
comment on column MBT_PM_620_D.D_INCOME_TAX_EXPENSE is '所得税费用';
comment on column MBT_PM_620_D.D_INVESTMENT_INCOME is '投资净收益';
comment on column MBT_PM_620_D.D_INVESTMENT_INCOME_ENTERPRISE is '对联营企业和合营企业的投资收益';
comment on column MBT_PM_620_D.D_NET_PROFIT is '净利润';
comment on column MBT_PM_620_D.D_NON_CURRENT_ASSETS is '非流动资产损失（其中：非流动资产处置损失）';
comment on column MBT_PM_620_D.D_NON_OPERATING_EXPENSES is '营业外支出';
comment on column MBT_PM_620_D.D_NON_OPERATING_INCOME is '营业外收入';
comment on column MBT_PM_620_D.D_OPERATING_PROFITS is '营业利润';
comment on column MBT_PM_620_D.D_PROFIT_BEFORE_TAX is '利润总额';
comment on column MBT_PM_620_D.D_PROFIT_LOSS_ARISING_FAIR_VAL is '公允价值变动净收益';
comment on column MBT_PM_620_D.D_REVENUE_OF_SALES is '营业收入';
comment on column MBT_PM_620_D.D_SELLING_EXPENSES is '销售费用';
comment on column MBT_PM_620_D.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_620_D.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_620_D.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_620_D.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_620_D.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_620_D.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_620_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_620_D.CUST_NO is '客户号';
comment on column MBT_PM_620_D.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_620_D.PART_TYPE is '段标识';
comment on column MBT_PM_620_D.PART_NAME is '段名称';
comment on column MBT_PM_620_D.START_DATE is '起始日期';
comment on column MBT_PM_620_D.END_DATE is '结束日期';
comment on column MBT_PM_620_D.BATCH_NO is '批次号';
comment on column MBT_PM_620_D.ROW_NUM is '行号';
comment on column MBT_PM_620_D.IS_RPT is '是否报送';
comment on column MBT_PM_620_D.IS_VALID is '是否有效';
comment on column MBT_PM_620_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_620_D.OPT_FLAG is '操作标识';
comment on column MBT_PM_620_D.RPT_DATE is '报送日期';
comment on column MBT_PM_620_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_620_D.RPT_STATUS is '报送状态';
comment on column MBT_PM_620_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_620_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_620_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_620_D.REMARKS is '备注';
comment on column MBT_PM_620_D.CHECK_FLAG is '校验标志';
comment on column MBT_PM_620_D.CHECK_DESC is '校验说明';
comment on column MBT_PM_620_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_620_D.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_620_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_620_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_620_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_620_D.DATA_FLAG is '数据标志';
comment on column MBT_PM_620_D.DATA_OP is '操作标志';
comment on column MBT_PM_620_D.DATA_SOURCE is '数据来源';
comment on column MBT_PM_620_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_620_D.DATA_HASH is '数据HASH';
comment on column MBT_PM_620_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_620_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_620_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_620_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_620_D.DATA_CRT_USER is '创建人';
comment on column MBT_PM_620_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_620_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_620_D.DATA_CHG_USER is '修改人';
comment on column MBT_PM_620_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_620_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_620_D.DATA_APV_USER is '审核人';
comment on column MBT_PM_620_D.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_620_D.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_620_D.RSV1 is '备用字段';
comment on column MBT_PM_620_D.RSV2 is '备用字段';
comment on column MBT_PM_620_D.RSV3 is '备用字段';
comment on column MBT_PM_620_D.RSV4 is '备用字段';
comment on column MBT_PM_620_D.RSV5 is '备用字段';
create table MBT_RPT_620 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_620 is '企业利润及利润分配表信息';
comment on column MBT_RPT_620.DATA_ID is '数据ID';
comment on column MBT_RPT_620.DATA_DATE is '数据日期';
comment on column MBT_RPT_620.CORP_ID is '法人ID';
comment on column MBT_RPT_620.ORG_ID is '机构ID';
comment on column MBT_RPT_620.GROUP_ID is '数据分组';
comment on column MBT_RPT_620.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_620.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_620.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_620.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_620.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_620.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_620.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_620.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_620.B_ENT_NAME is '企业名称';
comment on column MBT_RPT_620.SECTION_CHG_CNT is '段变更';
comment on column MBT_RPT_620.SECTION_DEL_CNT is '段删除';
comment on column MBT_RPT_620.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_RPT_620.IDN_CHG_CNT is '标识项变更';
comment on column MBT_RPT_620.CUST_NO is '客户号';
comment on column MBT_RPT_620.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_620.PART_TYPE is '段标识';
comment on column MBT_RPT_620.PART_NAME is '段名称';
comment on column MBT_RPT_620.START_DATE is '起始日期';
comment on column MBT_RPT_620.END_DATE is '结束日期';
comment on column MBT_RPT_620.BATCH_NO is '批次号';
comment on column MBT_RPT_620.ROW_NUM is '行号';
comment on column MBT_RPT_620.IS_RPT is '是否报送';
comment on column MBT_RPT_620.IS_VALID is '是否有效';
comment on column MBT_RPT_620.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_620.OPT_FLAG is '操作标识';
comment on column MBT_RPT_620.RPT_DATE is '报送日期';
comment on column MBT_RPT_620.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_620.RPT_STATUS is '报送状态';
comment on column MBT_RPT_620.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_620.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_620.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_620.REMARKS is '备注';
comment on column MBT_RPT_620.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_620.CHECK_DESC is '校验说明';
comment on column MBT_RPT_620.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_620.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_620.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_620.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_620.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_620.DATA_FLAG is '数据标志';
comment on column MBT_RPT_620.DATA_OP is '操作标志';
comment on column MBT_RPT_620.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_620.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_620.DATA_HASH is '数据HASH';
comment on column MBT_RPT_620.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_620.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_620.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_620.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_620.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_620.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_620.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_620.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_620.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_620.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_620.DATA_APV_USER is '审核人';
comment on column MBT_RPT_620.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_620.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_620.RSV1 is '备用字段';
comment on column MBT_RPT_620.RSV2 is '备用字段';
comment on column MBT_RPT_620.RSV3 is '备用字段';
comment on column MBT_RPT_620.RSV4 is '备用字段';
comment on column MBT_RPT_620.RSV5 is '备用字段';
create table MBT_RPT_620_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_620_B is '企业利润及利润分配表信息-基础段';
comment on column MBT_RPT_620_B.DATA_ID is '数据ID';
comment on column MBT_RPT_620_B.DATA_DATE is '数据日期';
comment on column MBT_RPT_620_B.CORP_ID is '法人ID';
comment on column MBT_RPT_620_B.ORG_ID is '机构ID';
comment on column MBT_RPT_620_B.GROUP_ID is '数据分组';
comment on column MBT_RPT_620_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_620_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_620_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_620_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_620_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_620_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_620_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_620_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_620_B.B_ENT_NAME is '企业名称';
comment on column MBT_RPT_620_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_RPT_620_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_RPT_620_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_RPT_620_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_RPT_620_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_RPT_620_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_620_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_RPT_620_B.CUST_NO is '客户号';
comment on column MBT_RPT_620_B.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_620_B.PART_TYPE is '段标识';
comment on column MBT_RPT_620_B.PART_NAME is '段名称';
comment on column MBT_RPT_620_B.START_DATE is '起始日期';
comment on column MBT_RPT_620_B.END_DATE is '结束日期';
comment on column MBT_RPT_620_B.BATCH_NO is '批次号';
comment on column MBT_RPT_620_B.ROW_NUM is '行号';
comment on column MBT_RPT_620_B.IS_RPT is '是否报送';
comment on column MBT_RPT_620_B.IS_VALID is '是否有效';
comment on column MBT_RPT_620_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_620_B.OPT_FLAG is '操作标识';
comment on column MBT_RPT_620_B.RPT_DATE is '报送日期';
comment on column MBT_RPT_620_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_620_B.RPT_STATUS is '报送状态';
comment on column MBT_RPT_620_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_620_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_620_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_620_B.REMARKS is '备注';
comment on column MBT_RPT_620_B.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_620_B.CHECK_DESC is '校验说明';
comment on column MBT_RPT_620_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_620_B.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_620_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_620_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_620_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_620_B.DATA_FLAG is '数据标志';
comment on column MBT_RPT_620_B.DATA_OP is '操作标志';
comment on column MBT_RPT_620_B.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_620_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_620_B.DATA_HASH is '数据HASH';
comment on column MBT_RPT_620_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_620_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_620_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_620_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_620_B.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_620_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_620_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_620_B.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_620_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_620_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_620_B.DATA_APV_USER is '审核人';
comment on column MBT_RPT_620_B.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_620_B.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_620_B.RSV1 is '备用字段';
comment on column MBT_RPT_620_B.RSV2 is '备用字段';
comment on column MBT_RPT_620_B.RSV3 is '备用字段';
comment on column MBT_RPT_620_B.RSV4 is '备用字段';
comment on column MBT_RPT_620_B.RSV5 is '备用字段';
create table MBT_RPT_620_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ALLOWANCE_INCOME NUMBER(17),
C_ALLOWANCE_INCOME_B_ALLOWANCE NUMBER(17),
C_APPR_ENTERPRISE_EXP_FUND NUMBER(17),
C_APPR_RESERVE_FUND NUMBER(17),
C_APPR_STAFF_INC_WELFARE_FUND NUMBER(17),
C_APPR_STATUTORY_SURPLUS_RES NUMBER(17),
C_APPR_STATUTORY_WELFAREFUND NUMBER(17),
C_BALANCE_OF_CONTENTSALARY NUMBER(17),
C_CALCULATING_CONTENT_SALARY_B NUMBER(17),
C_COMPENSATION_SURPLUS_RES NUMBER(17),
C_DEFERRED_INCOME NUMBER(17),
C_DISCOUNT_ALLOWANCE NUMBER(17),
C_EXCHANGE_NON_MONETARY_ASS_L NUMBER(17),
C_FINANCIAL_EXPENSES NUMBER(17),
C_FUTURES_INCOME NUMBER(17),
C_GENERAL_ADMIN_EXPENSES NUMBER(17),
C_IMPARIMENT_LOSS NUMBER(17),
C_INCOMETAX NUMBER(17),
C_INCOME_FROM_PENALTY NUMBER(17),
C_INCOME_NON_CURRENCY_TRADE NUMBER(17),
C_INCOME_SALES_AGENCY NUMBER(17),
C_INCOME_SALES_INTANGIBLE_ASS NUMBER(17),
C_INVESTMENT_INCOME NUMBER(17),
C_LOSS_COMPENSATED_BEFORE_TAX NUMBER(17),
C_LOSS_DISPOSAL_FIXED_ASSETS NUMBER(17),
C_LOSS_LAWSUITS NUMBER(17),
C_MAIN_OPERATING_COST NUMBER(17),
C_MAIN_REVENUEF_REVENUE NUMBER(17),
C_NET_AMOUNT_INCOME_MAIN_BUSI NUMBER(17),
C_NET_GAIN_DISPOSAL_FIXED_ASS NUMBER(17),
C_NET_PROFIT NUMBER(17),
C_NON_OPERATING_EXPENSES NUMBER(17),
C_NON_OPERATING_INCOME NUMBER(17),
C_OPERATING_PROFITS NUMBER(17),
C_OPERATION_EXPENSE NUMBER(17),
C_OTHERS NUMBER(17),
C_OTHERS_EXPENSES NUMBER(17),
C_OTHERS_INCOME NUMBER(17),
C_OTHERS_OPERATING_COST NUMBER(17),
C_OTHERS_OWNERS NUMBER(17),
C_OTHER_ADJUSTMENT_FACTORS NUMBER(17),
C_OTHER_BUSINESS_PROFIT NUMBER(17),
C_OTHER_OPERATING_INCOME NUMBER(17),
C_OTHER_PAYMENTS NUMBER(17),
C_PAYABLE_DIVIDENDS_COMMON_STO NUMBER(17),
C_PAYMENT_FOR_DONATION NUMBER(17),
C_PREFERRED_STOCK_DIVIDEND_PAY NUMBER(17),
C_PRINCIPLE_BUSINESS_PROFIT NUMBER(17),
C_PRINCIPLE_B_TAX_EXTRA_CHARGE NUMBER(17),
C_PROFIT_AVAILABLE_DISTRIBUTI NUMBER(17),
C_PROFIT_AVAILABLE_OWNERS_DIST NUMBER(17),
C_PROFIT_DISTRIBUTION_B_PERIOD NUMBER(17),
C_PROFIT_RESERVED_A_SINGLEIT NUMBER(17),
C_PRO_CAP_RETURN_INVESTMENT NUMBER(17),
C_SALES_INCOME_E_GOODS_PRODUCT NUMBER(17),
C_SALES_INCOME_E_PRODUCTS NUMBER(17),
C_SALES_INCOME_I_GOODS_PRODUCT NUMBER(17),
C_SELLING_EXPENSES NUMBER(17),
C_SUPPLEMENTARY_CURRENT_CAPIT NUMBER(17),
C_TOTAL_PROFIT NUMBER(17),
C_TRANSFER_ORDINARY_SHARES_DP NUMBER(17),
C_UNAPPROPRIATED_PROFIT NUMBER(17),
C_UNREALIZED_INVESTMENT_LOSSES NUMBER(17),
C_WITHDRAWAL_OTHER_COMM_ACC_FU NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_620_C is '企业利润及利润分配表信息-2002版利润及利润分配表段';
comment on column MBT_RPT_620_C.DATA_ID is '数据ID';
comment on column MBT_RPT_620_C.DATA_DATE is '数据日期';
comment on column MBT_RPT_620_C.CORP_ID is '法人ID';
comment on column MBT_RPT_620_C.ORG_ID is '机构ID';
comment on column MBT_RPT_620_C.GROUP_ID is '数据分组';
comment on column MBT_RPT_620_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_620_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_620_C.C_ALLOWANCE_INCOME is '补贴收入';
comment on column MBT_RPT_620_C.C_ALLOWANCE_INCOME_B_ALLOWANCE is '（补贴收入科目下）补贴前亏损的企业补贴收入';
comment on column MBT_RPT_620_C.C_APPR_ENTERPRISE_EXP_FUND is '提取企业发展基金';
comment on column MBT_RPT_620_C.C_APPR_RESERVE_FUND is '提取储备基金';
comment on column MBT_RPT_620_C.C_APPR_STAFF_INC_WELFARE_FUND is '提取职工奖励及福利基金';
comment on column MBT_RPT_620_C.C_APPR_STATUTORY_SURPLUS_RES is '提取法定盈余公积';
comment on column MBT_RPT_620_C.C_APPR_STATUTORY_WELFAREFUND is '提取法定公益金';
comment on column MBT_RPT_620_C.C_BALANCE_OF_CONTENTSALARY is '（其他支出）结转的含量工资包干节余';
comment on column MBT_RPT_620_C.C_CALCULATING_CONTENT_SALARY_B is '（其他科目下）用以前年度含量工资节余弥补利润';
comment on column MBT_RPT_620_C.C_COMPENSATION_SURPLUS_RES is '盈余公积补亏';
comment on column MBT_RPT_620_C.C_DEFERRED_INCOME is '递延收益';
comment on column MBT_RPT_620_C.C_DISCOUNT_ALLOWANCE is '销售折扣与折让';
comment on column MBT_RPT_620_C.C_EXCHANGE_NON_MONETARY_ASS_L is '（营业外支出科目下）债务重组损失';
comment on column MBT_RPT_620_C.C_FINANCIAL_EXPENSES is '财务费用';
comment on column MBT_RPT_620_C.C_FUTURES_INCOME is '期货收益';
comment on column MBT_RPT_620_C.C_GENERAL_ADMIN_EXPENSES is '管理费用';
comment on column MBT_RPT_620_C.C_IMPARIMENT_LOSS is '少数股东损益';
comment on column MBT_RPT_620_C.C_INCOMETAX is '所得税';
comment on column MBT_RPT_620_C.C_INCOME_FROM_PENALTY is '（营业外收入科目下）罚款净收入';
comment on column MBT_RPT_620_C.C_INCOME_NON_CURRENCY_TRADE is '（营业外收入科目下）非货币性交易收益';
comment on column MBT_RPT_620_C.C_INCOME_SALES_AGENCY is '代购代销收入';
comment on column MBT_RPT_620_C.C_INCOME_SALES_INTANGIBLE_ASS is '（营业外收入科目下）出售无形资产收益';
comment on column MBT_RPT_620_C.C_INVESTMENT_INCOME is '投资收益';
comment on column MBT_RPT_620_C.C_LOSS_COMPENSATED_BEFORE_TAX is '（未分配利润科目下）应由以后年度税前利润弥补的亏损';
comment on column MBT_RPT_620_C.C_LOSS_DISPOSAL_FIXED_ASSETS is '（营业外支出科目下）处置固定资产净损失';
comment on column MBT_RPT_620_C.C_LOSS_LAWSUITS is '（营业外支出科目下）罚款支出';
comment on column MBT_RPT_620_C.C_MAIN_OPERATING_COST is '主营业务成本';
comment on column MBT_RPT_620_C.C_MAIN_REVENUEF_REVENUE is '主营业务收入';
comment on column MBT_RPT_620_C.C_NET_AMOUNT_INCOME_MAIN_BUSI is '主营业务收入净额';
comment on column MBT_RPT_620_C.C_NET_GAIN_DISPOSAL_FIXED_ASS is '（营业外收入科目下）处置固定资产净收益';
comment on column MBT_RPT_620_C.C_NET_PROFIT is '净利润';
comment on column MBT_RPT_620_C.C_NON_OPERATING_EXPENSES is '营业外支出';
comment on column MBT_RPT_620_C.C_NON_OPERATING_INCOME is '营业外收入';
comment on column MBT_RPT_620_C.C_OPERATING_PROFITS is '营业利润';
comment on column MBT_RPT_620_C.C_OPERATION_EXPENSE is '经营费用';
comment on column MBT_RPT_620_C.C_OTHERS is '（可供分配的利润科目下）其他';
comment on column MBT_RPT_620_C.C_OTHERS_EXPENSES is '其他（费用）';
comment on column MBT_RPT_620_C.C_OTHERS_INCOME is '其他（利润）';
comment on column MBT_RPT_620_C.C_OTHERS_OPERATING_COST is '其他（业务成本）';
comment on column MBT_RPT_620_C.C_OTHERS_OWNERS is '（可供投资者分配的利润科目下）其他';
comment on column MBT_RPT_620_C.C_OTHER_ADJUSTMENT_FACTORS is '其他调整因素';
comment on column MBT_RPT_620_C.C_OTHER_BUSINESS_PROFIT is '其他业务利润';
comment on column MBT_RPT_620_C.C_OTHER_OPERATING_INCOME is '其他（收入）';
comment on column MBT_RPT_620_C.C_OTHER_PAYMENTS is '其他支出';
comment on column MBT_RPT_620_C.C_PAYABLE_DIVIDENDS_COMMON_STO is '应付普通股股利';
comment on column MBT_RPT_620_C.C_PAYMENT_FOR_DONATION is '（营业外支出科目下）捐赠支出';
comment on column MBT_RPT_620_C.C_PREFERRED_STOCK_DIVIDEND_PAY is '应付优先股股利';
comment on column MBT_RPT_620_C.C_PRINCIPLE_BUSINESS_PROFIT is '主营业务利润';
comment on column MBT_RPT_620_C.C_PRINCIPLE_B_TAX_EXTRA_CHARGE is '主营业务税金及附加';
comment on column MBT_RPT_620_C.C_PROFIT_AVAILABLE_DISTRIBUTI is '可供分配的利润';
comment on column MBT_RPT_620_C.C_PROFIT_AVAILABLE_OWNERS_DIST is '可供投资者分配的利润';
comment on column MBT_RPT_620_C.C_PROFIT_DISTRIBUTION_B_PERIOD is '年初未分配利润';
comment on column MBT_RPT_620_C.C_PROFIT_RESERVED_A_SINGLEIT is '单项留用的利润';
comment on column MBT_RPT_620_C.C_PRO_CAP_RETURN_INVESTMENT is '利润归还投资';
comment on column MBT_RPT_620_C.C_SALES_INCOME_E_GOODS_PRODUCT is '（主营业务收入科目下）出口产品销售收入';
comment on column MBT_RPT_620_C.C_SALES_INCOME_E_PRODUCTS is '（主营业务成本科目下）出口产品销售成本';
comment on column MBT_RPT_620_C.C_SALES_INCOME_I_GOODS_PRODUCT is '（主营业务收入科目下）进口产品销售收入';
comment on column MBT_RPT_620_C.C_SELLING_EXPENSES is '营业费用';
comment on column MBT_RPT_620_C.C_SUPPLEMENTARY_CURRENT_CAPIT is '补充流动资本';
comment on column MBT_RPT_620_C.C_TOTAL_PROFIT is '利润总额';
comment on column MBT_RPT_620_C.C_TRANSFER_ORDINARY_SHARES_DP is '转作资本的普通股股利';
comment on column MBT_RPT_620_C.C_UNAPPROPRIATED_PROFIT is '未分配利润';
comment on column MBT_RPT_620_C.C_UNREALIZED_INVESTMENT_LOSSES is '未确认的投资损失';
comment on column MBT_RPT_620_C.C_WITHDRAWAL_OTHER_COMM_ACC_FU is '提取任意盈余公积';
comment on column MBT_RPT_620_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_620_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_620_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_620_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_620_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_620_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_620_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_620_C.CUST_NO is '客户号';
comment on column MBT_RPT_620_C.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_620_C.PART_TYPE is '段标识';
comment on column MBT_RPT_620_C.PART_NAME is '段名称';
comment on column MBT_RPT_620_C.START_DATE is '起始日期';
comment on column MBT_RPT_620_C.END_DATE is '结束日期';
comment on column MBT_RPT_620_C.BATCH_NO is '批次号';
comment on column MBT_RPT_620_C.ROW_NUM is '行号';
comment on column MBT_RPT_620_C.IS_RPT is '是否报送';
comment on column MBT_RPT_620_C.IS_VALID is '是否有效';
comment on column MBT_RPT_620_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_620_C.OPT_FLAG is '操作标识';
comment on column MBT_RPT_620_C.RPT_DATE is '报送日期';
comment on column MBT_RPT_620_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_620_C.RPT_STATUS is '报送状态';
comment on column MBT_RPT_620_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_620_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_620_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_620_C.REMARKS is '备注';
comment on column MBT_RPT_620_C.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_620_C.CHECK_DESC is '校验说明';
comment on column MBT_RPT_620_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_620_C.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_620_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_620_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_620_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_620_C.DATA_FLAG is '数据标志';
comment on column MBT_RPT_620_C.DATA_OP is '操作标志';
comment on column MBT_RPT_620_C.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_620_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_620_C.DATA_HASH is '数据HASH';
comment on column MBT_RPT_620_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_620_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_620_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_620_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_620_C.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_620_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_620_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_620_C.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_620_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_620_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_620_C.DATA_APV_USER is '审核人';
comment on column MBT_RPT_620_C.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_620_C.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_620_C.RSV1 is '备用字段';
comment on column MBT_RPT_620_C.RSV2 is '备用字段';
comment on column MBT_RPT_620_C.RSV3 is '备用字段';
comment on column MBT_RPT_620_C.RSV4 is '备用字段';
comment on column MBT_RPT_620_C.RSV5 is '备用字段';
create table MBT_RPT_620_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_BASIC_EARNINGS_PER_SHARE NUMBER(17),
D_BUSINESS_OTHER_TAXES NUMBER(17),
D_COST_OF_SALES NUMBER(17),
D_DILUTED_EARNINGS_PER_SHARE NUMBER(17),
D_FINANCIAL_EXPENSE NUMBER(17),
D_GENERAL_ADMIN_EXPENSES NUMBER(17),
D_IMPAIRMENT_LOSS_OF_ASSETS NUMBER(17),
D_INCOME_TAX_EXPENSE NUMBER(17),
D_INVESTMENT_INCOME NUMBER(17),
D_INVESTMENT_INCOME_ENTERPRISE NUMBER(17),
D_NET_PROFIT NUMBER(17),
D_NON_CURRENT_ASSETS NUMBER(17),
D_NON_OPERATING_EXPENSES NUMBER(17),
D_NON_OPERATING_INCOME NUMBER(17),
D_OPERATING_PROFITS NUMBER(17),
D_PROFIT_BEFORE_TAX NUMBER(17),
D_PROFIT_LOSS_ARISING_FAIR_VAL NUMBER(17),
D_REVENUE_OF_SALES NUMBER(17),
D_SELLING_EXPENSES NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_620_D is '企业利润及利润分配表信息-2007版利润及利润分配表段';
comment on column MBT_RPT_620_D.DATA_ID is '数据ID';
comment on column MBT_RPT_620_D.DATA_DATE is '数据日期';
comment on column MBT_RPT_620_D.CORP_ID is '法人ID';
comment on column MBT_RPT_620_D.ORG_ID is '机构ID';
comment on column MBT_RPT_620_D.GROUP_ID is '数据分组';
comment on column MBT_RPT_620_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_620_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_620_D.D_BASIC_EARNINGS_PER_SHARE is '基本每股收益';
comment on column MBT_RPT_620_D.D_BUSINESS_OTHER_TAXES is '营业税金及附加';
comment on column MBT_RPT_620_D.D_COST_OF_SALES is '营业成本';
comment on column MBT_RPT_620_D.D_DILUTED_EARNINGS_PER_SHARE is '稀释每股收益';
comment on column MBT_RPT_620_D.D_FINANCIAL_EXPENSE is '财务费用';
comment on column MBT_RPT_620_D.D_GENERAL_ADMIN_EXPENSES is '管理费用';
comment on column MBT_RPT_620_D.D_IMPAIRMENT_LOSS_OF_ASSETS is '资产减值损失';
comment on column MBT_RPT_620_D.D_INCOME_TAX_EXPENSE is '所得税费用';
comment on column MBT_RPT_620_D.D_INVESTMENT_INCOME is '投资净收益';
comment on column MBT_RPT_620_D.D_INVESTMENT_INCOME_ENTERPRISE is '对联营企业和合营企业的投资收益';
comment on column MBT_RPT_620_D.D_NET_PROFIT is '净利润';
comment on column MBT_RPT_620_D.D_NON_CURRENT_ASSETS is '非流动资产损失（其中：非流动资产处置损失）';
comment on column MBT_RPT_620_D.D_NON_OPERATING_EXPENSES is '营业外支出';
comment on column MBT_RPT_620_D.D_NON_OPERATING_INCOME is '营业外收入';
comment on column MBT_RPT_620_D.D_OPERATING_PROFITS is '营业利润';
comment on column MBT_RPT_620_D.D_PROFIT_BEFORE_TAX is '利润总额';
comment on column MBT_RPT_620_D.D_PROFIT_LOSS_ARISING_FAIR_VAL is '公允价值变动净收益';
comment on column MBT_RPT_620_D.D_REVENUE_OF_SALES is '营业收入';
comment on column MBT_RPT_620_D.D_SELLING_EXPENSES is '销售费用';
comment on column MBT_RPT_620_D.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_620_D.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_620_D.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_620_D.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_620_D.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_620_D.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_620_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_620_D.CUST_NO is '客户号';
comment on column MBT_RPT_620_D.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_620_D.PART_TYPE is '段标识';
comment on column MBT_RPT_620_D.PART_NAME is '段名称';
comment on column MBT_RPT_620_D.START_DATE is '起始日期';
comment on column MBT_RPT_620_D.END_DATE is '结束日期';
comment on column MBT_RPT_620_D.BATCH_NO is '批次号';
comment on column MBT_RPT_620_D.ROW_NUM is '行号';
comment on column MBT_RPT_620_D.IS_RPT is '是否报送';
comment on column MBT_RPT_620_D.IS_VALID is '是否有效';
comment on column MBT_RPT_620_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_620_D.OPT_FLAG is '操作标识';
comment on column MBT_RPT_620_D.RPT_DATE is '报送日期';
comment on column MBT_RPT_620_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_620_D.RPT_STATUS is '报送状态';
comment on column MBT_RPT_620_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_620_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_620_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_620_D.REMARKS is '备注';
comment on column MBT_RPT_620_D.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_620_D.CHECK_DESC is '校验说明';
comment on column MBT_RPT_620_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_620_D.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_620_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_620_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_620_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_620_D.DATA_FLAG is '数据标志';
comment on column MBT_RPT_620_D.DATA_OP is '操作标志';
comment on column MBT_RPT_620_D.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_620_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_620_D.DATA_HASH is '数据HASH';
comment on column MBT_RPT_620_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_620_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_620_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_620_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_620_D.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_620_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_620_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_620_D.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_620_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_620_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_620_D.DATA_APV_USER is '审核人';
comment on column MBT_RPT_620_D.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_620_D.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_620_D.RSV1 is '备用字段';
comment on column MBT_RPT_620_D.RSV2 is '备用字段';
comment on column MBT_RPT_620_D.RSV3 is '备用字段';
comment on column MBT_RPT_620_D.RSV4 is '备用字段';
comment on column MBT_RPT_620_D.RSV5 is '备用字段';
