create table MBT_DM_130 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
ID_NUM VARCHAR(40),
ID_TYPE VARCHAR(2),
INF_SURC_CODE VARCHAR(20),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_130 is '个人证件有效期信息';
comment on column MBT_DM_130.DATA_ID is '数据ID';
comment on column MBT_DM_130.DATA_DATE is '数据日期';
comment on column MBT_DM_130.CORP_ID is '法人ID';
comment on column MBT_DM_130.ORG_ID is '机构ID';
comment on column MBT_DM_130.GROUP_ID is '数据分组';
comment on column MBT_DM_130.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_130.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_130.ID_NUM is '证件号码';
comment on column MBT_DM_130.ID_TYPE is '证件类型';
comment on column MBT_DM_130.INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_130.SECTION_CHG_CNT is '段变更';
comment on column MBT_DM_130.SECTION_DEL_CNT is '段删除';
comment on column MBT_DM_130.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_DM_130.IDN_CHG_CNT is '标识项变更';
comment on column MBT_DM_130.CUST_NO is '客户号';
comment on column MBT_DM_130.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_130.PART_TYPE is '段标识';
comment on column MBT_DM_130.PART_NAME is '段名称';
comment on column MBT_DM_130.START_DATE is '起始日期';
comment on column MBT_DM_130.END_DATE is '结束日期';
comment on column MBT_DM_130.BATCH_NO is '批次号';
comment on column MBT_DM_130.ROW_NUM is '行号';
comment on column MBT_DM_130.IS_RPT is '是否报送';
comment on column MBT_DM_130.IS_VALID is '是否有效';
comment on column MBT_DM_130.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_130.OPT_FLAG is '操作标识';
comment on column MBT_DM_130.RPT_DATE is '报送日期';
comment on column MBT_DM_130.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_130.RPT_STATUS is '报送状态';
comment on column MBT_DM_130.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_130.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_130.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_130.REMARKS is '备注';
comment on column MBT_DM_130.CHECK_FLAG is '校验标志';
comment on column MBT_DM_130.CHECK_DESC is '校验说明';
comment on column MBT_DM_130.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_130.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_130.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_130.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_130.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_130.DATA_FLAG is '数据标志';
comment on column MBT_DM_130.DATA_OP is '操作标志';
comment on column MBT_DM_130.DATA_SOURCE is '数据来源';
comment on column MBT_DM_130.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_130.DATA_HASH is '数据HASH';
comment on column MBT_DM_130.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_130.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_130.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_130.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_130.DATA_CRT_USER is '创建人';
comment on column MBT_DM_130.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_130.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_130.DATA_CHG_USER is '修改人';
comment on column MBT_DM_130.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_130.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_130.DATA_APV_USER is '审核人';
comment on column MBT_DM_130.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_130.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_130.RSV1 is '备用字段';
comment on column MBT_DM_130.RSV2 is '备用字段';
comment on column MBT_DM_130.RSV3 is '备用字段';
comment on column MBT_DM_130.RSV4 is '备用字段';
comment on column MBT_DM_130.RSV5 is '备用字段';
create table MBT_DM_130_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
ID_DIST VARCHAR(6),
ID_DUE_DATE VARCHAR(8),
ID_EFCT_DATE VARCHAR(8),
NAME VARCHAR(60),
ID_ORG_NAME VARCHAR(160),
CIMOC VARCHAR(14),
INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
ID_NUM VARCHAR(40),
ID_TYPE VARCHAR(2),
INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_130_B is '个人证件有效期信息-基础段';
comment on column MBT_DM_130_B.DATA_ID is '数据ID';
comment on column MBT_DM_130_B.DATA_DATE is '数据日期';
comment on column MBT_DM_130_B.CORP_ID is '法人ID';
comment on column MBT_DM_130_B.ORG_ID is '机构ID';
comment on column MBT_DM_130_B.GROUP_ID is '数据分组';
comment on column MBT_DM_130_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_130_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_130_B.ID_DIST is '证件签发机关所在地行政区划';
comment on column MBT_DM_130_B.ID_DUE_DATE is '证件有效期终止日期';
comment on column MBT_DM_130_B.ID_EFCT_DATE is '证件有效期起始日期';
comment on column MBT_DM_130_B.NAME is '姓名';
comment on column MBT_DM_130_B.ID_ORG_NAME is '证件签发机关名称';
comment on column MBT_DM_130_B.CIMOC is '客户资料维护机构代码';
comment on column MBT_DM_130_B.INF_REC_TYPE is '信息记录类型';
comment on column MBT_DM_130_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_130_B.ID_NUM is '证件号码';
comment on column MBT_DM_130_B.ID_TYPE is '证件类型';
comment on column MBT_DM_130_B.INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_130_B.CUST_NO is '客户号';
comment on column MBT_DM_130_B.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_130_B.PART_TYPE is '段标识';
comment on column MBT_DM_130_B.PART_NAME is '段名称';
comment on column MBT_DM_130_B.START_DATE is '起始日期';
comment on column MBT_DM_130_B.END_DATE is '结束日期';
comment on column MBT_DM_130_B.BATCH_NO is '批次号';
comment on column MBT_DM_130_B.ROW_NUM is '行号';
comment on column MBT_DM_130_B.IS_RPT is '是否报送';
comment on column MBT_DM_130_B.IS_VALID is '是否有效';
comment on column MBT_DM_130_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_130_B.OPT_FLAG is '操作标识';
comment on column MBT_DM_130_B.RPT_DATE is '报送日期';
comment on column MBT_DM_130_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_130_B.RPT_STATUS is '报送状态';
comment on column MBT_DM_130_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_130_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_130_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_130_B.REMARKS is '备注';
comment on column MBT_DM_130_B.CHECK_FLAG is '校验标志';
comment on column MBT_DM_130_B.CHECK_DESC is '校验说明';
comment on column MBT_DM_130_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_130_B.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_130_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_130_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_130_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_130_B.DATA_FLAG is '数据标志';
comment on column MBT_DM_130_B.DATA_OP is '操作标志';
comment on column MBT_DM_130_B.DATA_SOURCE is '数据来源';
comment on column MBT_DM_130_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_130_B.DATA_HASH is '数据HASH';
comment on column MBT_DM_130_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_130_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_130_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_130_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_130_B.DATA_CRT_USER is '创建人';
comment on column MBT_DM_130_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_130_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_130_B.DATA_CHG_USER is '修改人';
comment on column MBT_DM_130_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_130_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_130_B.DATA_APV_USER is '审核人';
comment on column MBT_DM_130_B.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_130_B.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_130_B.RSV1 is '备用字段';
comment on column MBT_DM_130_B.RSV2 is '备用字段';
comment on column MBT_DM_130_B.RSV3 is '备用字段';
comment on column MBT_DM_130_B.RSV4 is '备用字段';
comment on column MBT_DM_130_B.RSV5 is '备用字段';
create table MBT_PM_130 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
ID_NUM VARCHAR(40),
ID_TYPE VARCHAR(2),
INF_SURC_CODE VARCHAR(20),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_130 is '个人证件有效期信息';
comment on column MBT_PM_130.DATA_ID is '数据ID';
comment on column MBT_PM_130.DATA_DATE is '数据日期';
comment on column MBT_PM_130.CORP_ID is '法人ID';
comment on column MBT_PM_130.ORG_ID is '机构ID';
comment on column MBT_PM_130.GROUP_ID is '数据分组';
comment on column MBT_PM_130.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_130.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_130.ID_NUM is '证件号码';
comment on column MBT_PM_130.ID_TYPE is '证件类型';
comment on column MBT_PM_130.INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_130.SECTION_CHG_CNT is '段变更';
comment on column MBT_PM_130.SECTION_DEL_CNT is '段删除';
comment on column MBT_PM_130.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_PM_130.IDN_CHG_CNT is '标识项变更';
comment on column MBT_PM_130.CUST_NO is '客户号';
comment on column MBT_PM_130.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_130.PART_TYPE is '段标识';
comment on column MBT_PM_130.PART_NAME is '段名称';
comment on column MBT_PM_130.START_DATE is '起始日期';
comment on column MBT_PM_130.END_DATE is '结束日期';
comment on column MBT_PM_130.BATCH_NO is '批次号';
comment on column MBT_PM_130.ROW_NUM is '行号';
comment on column MBT_PM_130.IS_RPT is '是否报送';
comment on column MBT_PM_130.IS_VALID is '是否有效';
comment on column MBT_PM_130.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_130.OPT_FLAG is '操作标识';
comment on column MBT_PM_130.RPT_DATE is '报送日期';
comment on column MBT_PM_130.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_130.RPT_STATUS is '报送状态';
comment on column MBT_PM_130.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_130.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_130.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_130.REMARKS is '备注';
comment on column MBT_PM_130.CHECK_FLAG is '校验标志';
comment on column MBT_PM_130.CHECK_DESC is '校验说明';
comment on column MBT_PM_130.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_130.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_130.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_130.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_130.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_130.DATA_FLAG is '数据标志';
comment on column MBT_PM_130.DATA_OP is '操作标志';
comment on column MBT_PM_130.DATA_SOURCE is '数据来源';
comment on column MBT_PM_130.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_130.DATA_HASH is '数据HASH';
comment on column MBT_PM_130.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_130.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_130.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_130.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_130.DATA_CRT_USER is '创建人';
comment on column MBT_PM_130.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_130.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_130.DATA_CHG_USER is '修改人';
comment on column MBT_PM_130.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_130.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_130.DATA_APV_USER is '审核人';
comment on column MBT_PM_130.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_130.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_130.RSV1 is '备用字段';
comment on column MBT_PM_130.RSV2 is '备用字段';
comment on column MBT_PM_130.RSV3 is '备用字段';
comment on column MBT_PM_130.RSV4 is '备用字段';
comment on column MBT_PM_130.RSV5 is '备用字段';
create table MBT_PM_130_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
ID_DIST VARCHAR(6),
ID_DUE_DATE VARCHAR(8),
ID_EFCT_DATE VARCHAR(8),
NAME VARCHAR(60),
ID_ORG_NAME VARCHAR(160),
CIMOC VARCHAR(14),
INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
ID_NUM VARCHAR(40),
ID_TYPE VARCHAR(2),
INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_130_B is '个人证件有效期信息-基础段';
comment on column MBT_PM_130_B.DATA_ID is '数据ID';
comment on column MBT_PM_130_B.DATA_DATE is '数据日期';
comment on column MBT_PM_130_B.CORP_ID is '法人ID';
comment on column MBT_PM_130_B.ORG_ID is '机构ID';
comment on column MBT_PM_130_B.GROUP_ID is '数据分组';
comment on column MBT_PM_130_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_130_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_130_B.ID_DIST is '证件签发机关所在地行政区划';
comment on column MBT_PM_130_B.ID_DUE_DATE is '证件有效期终止日期';
comment on column MBT_PM_130_B.ID_EFCT_DATE is '证件有效期起始日期';
comment on column MBT_PM_130_B.NAME is '姓名';
comment on column MBT_PM_130_B.ID_ORG_NAME is '证件签发机关名称';
comment on column MBT_PM_130_B.CIMOC is '客户资料维护机构代码';
comment on column MBT_PM_130_B.INF_REC_TYPE is '信息记录类型';
comment on column MBT_PM_130_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_130_B.ID_NUM is '证件号码';
comment on column MBT_PM_130_B.ID_TYPE is '证件类型';
comment on column MBT_PM_130_B.INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_130_B.CUST_NO is '客户号';
comment on column MBT_PM_130_B.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_130_B.PART_TYPE is '段标识';
comment on column MBT_PM_130_B.PART_NAME is '段名称';
comment on column MBT_PM_130_B.START_DATE is '起始日期';
comment on column MBT_PM_130_B.END_DATE is '结束日期';
comment on column MBT_PM_130_B.BATCH_NO is '批次号';
comment on column MBT_PM_130_B.ROW_NUM is '行号';
comment on column MBT_PM_130_B.IS_RPT is '是否报送';
comment on column MBT_PM_130_B.IS_VALID is '是否有效';
comment on column MBT_PM_130_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_130_B.OPT_FLAG is '操作标识';
comment on column MBT_PM_130_B.RPT_DATE is '报送日期';
comment on column MBT_PM_130_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_130_B.RPT_STATUS is '报送状态';
comment on column MBT_PM_130_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_130_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_130_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_130_B.REMARKS is '备注';
comment on column MBT_PM_130_B.CHECK_FLAG is '校验标志';
comment on column MBT_PM_130_B.CHECK_DESC is '校验说明';
comment on column MBT_PM_130_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_130_B.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_130_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_130_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_130_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_130_B.DATA_FLAG is '数据标志';
comment on column MBT_PM_130_B.DATA_OP is '操作标志';
comment on column MBT_PM_130_B.DATA_SOURCE is '数据来源';
comment on column MBT_PM_130_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_130_B.DATA_HASH is '数据HASH';
comment on column MBT_PM_130_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_130_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_130_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_130_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_130_B.DATA_CRT_USER is '创建人';
comment on column MBT_PM_130_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_130_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_130_B.DATA_CHG_USER is '修改人';
comment on column MBT_PM_130_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_130_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_130_B.DATA_APV_USER is '审核人';
comment on column MBT_PM_130_B.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_130_B.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_130_B.RSV1 is '备用字段';
comment on column MBT_PM_130_B.RSV2 is '备用字段';
comment on column MBT_PM_130_B.RSV3 is '备用字段';
comment on column MBT_PM_130_B.RSV4 is '备用字段';
comment on column MBT_PM_130_B.RSV5 is '备用字段';
create table MBT_RPT_130 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
ID_NUM VARCHAR(40),
ID_TYPE VARCHAR(2),
INF_SURC_CODE VARCHAR(20),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_130 is '个人证件有效期信息';
comment on column MBT_RPT_130.DATA_ID is '数据ID';
comment on column MBT_RPT_130.DATA_DATE is '数据日期';
comment on column MBT_RPT_130.CORP_ID is '法人ID';
comment on column MBT_RPT_130.ORG_ID is '机构ID';
comment on column MBT_RPT_130.GROUP_ID is '数据分组';
comment on column MBT_RPT_130.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_130.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_130.ID_NUM is '证件号码';
comment on column MBT_RPT_130.ID_TYPE is '证件类型';
comment on column MBT_RPT_130.INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_130.SECTION_CHG_CNT is '段变更';
comment on column MBT_RPT_130.SECTION_DEL_CNT is '段删除';
comment on column MBT_RPT_130.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_RPT_130.IDN_CHG_CNT is '标识项变更';
comment on column MBT_RPT_130.CUST_NO is '客户号';
comment on column MBT_RPT_130.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_130.PART_TYPE is '段标识';
comment on column MBT_RPT_130.PART_NAME is '段名称';
comment on column MBT_RPT_130.START_DATE is '起始日期';
comment on column MBT_RPT_130.END_DATE is '结束日期';
comment on column MBT_RPT_130.BATCH_NO is '批次号';
comment on column MBT_RPT_130.ROW_NUM is '行号';
comment on column MBT_RPT_130.IS_RPT is '是否报送';
comment on column MBT_RPT_130.IS_VALID is '是否有效';
comment on column MBT_RPT_130.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_130.OPT_FLAG is '操作标识';
comment on column MBT_RPT_130.RPT_DATE is '报送日期';
comment on column MBT_RPT_130.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_130.RPT_STATUS is '报送状态';
comment on column MBT_RPT_130.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_130.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_130.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_130.REMARKS is '备注';
comment on column MBT_RPT_130.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_130.CHECK_DESC is '校验说明';
comment on column MBT_RPT_130.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_130.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_130.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_130.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_130.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_130.DATA_FLAG is '数据标志';
comment on column MBT_RPT_130.DATA_OP is '操作标志';
comment on column MBT_RPT_130.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_130.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_130.DATA_HASH is '数据HASH';
comment on column MBT_RPT_130.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_130.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_130.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_130.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_130.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_130.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_130.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_130.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_130.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_130.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_130.DATA_APV_USER is '审核人';
comment on column MBT_RPT_130.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_130.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_130.RSV1 is '备用字段';
comment on column MBT_RPT_130.RSV2 is '备用字段';
comment on column MBT_RPT_130.RSV3 is '备用字段';
comment on column MBT_RPT_130.RSV4 is '备用字段';
comment on column MBT_RPT_130.RSV5 is '备用字段';
create table MBT_RPT_130_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
ID_DIST VARCHAR(6),
ID_DUE_DATE VARCHAR(8),
ID_EFCT_DATE VARCHAR(8),
NAME VARCHAR(60),
ID_ORG_NAME VARCHAR(160),
CIMOC VARCHAR(14),
INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
ID_NUM VARCHAR(40),
ID_TYPE VARCHAR(2),
INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_130_B is '个人证件有效期信息-基础段';
comment on column MBT_RPT_130_B.DATA_ID is '数据ID';
comment on column MBT_RPT_130_B.DATA_DATE is '数据日期';
comment on column MBT_RPT_130_B.CORP_ID is '法人ID';
comment on column MBT_RPT_130_B.ORG_ID is '机构ID';
comment on column MBT_RPT_130_B.GROUP_ID is '数据分组';
comment on column MBT_RPT_130_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_130_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_130_B.ID_DIST is '证件签发机关所在地行政区划';
comment on column MBT_RPT_130_B.ID_DUE_DATE is '证件有效期终止日期';
comment on column MBT_RPT_130_B.ID_EFCT_DATE is '证件有效期起始日期';
comment on column MBT_RPT_130_B.NAME is '姓名';
comment on column MBT_RPT_130_B.ID_ORG_NAME is '证件签发机关名称';
comment on column MBT_RPT_130_B.CIMOC is '客户资料维护机构代码';
comment on column MBT_RPT_130_B.INF_REC_TYPE is '信息记录类型';
comment on column MBT_RPT_130_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_130_B.ID_NUM is '证件号码';
comment on column MBT_RPT_130_B.ID_TYPE is '证件类型';
comment on column MBT_RPT_130_B.INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_130_B.CUST_NO is '客户号';
comment on column MBT_RPT_130_B.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_130_B.PART_TYPE is '段标识';
comment on column MBT_RPT_130_B.PART_NAME is '段名称';
comment on column MBT_RPT_130_B.START_DATE is '起始日期';
comment on column MBT_RPT_130_B.END_DATE is '结束日期';
comment on column MBT_RPT_130_B.BATCH_NO is '批次号';
comment on column MBT_RPT_130_B.ROW_NUM is '行号';
comment on column MBT_RPT_130_B.IS_RPT is '是否报送';
comment on column MBT_RPT_130_B.IS_VALID is '是否有效';
comment on column MBT_RPT_130_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_130_B.OPT_FLAG is '操作标识';
comment on column MBT_RPT_130_B.RPT_DATE is '报送日期';
comment on column MBT_RPT_130_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_130_B.RPT_STATUS is '报送状态';
comment on column MBT_RPT_130_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_130_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_130_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_130_B.REMARKS is '备注';
comment on column MBT_RPT_130_B.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_130_B.CHECK_DESC is '校验说明';
comment on column MBT_RPT_130_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_130_B.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_130_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_130_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_130_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_130_B.DATA_FLAG is '数据标志';
comment on column MBT_RPT_130_B.DATA_OP is '操作标志';
comment on column MBT_RPT_130_B.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_130_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_130_B.DATA_HASH is '数据HASH';
comment on column MBT_RPT_130_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_130_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_130_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_130_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_130_B.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_130_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_130_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_130_B.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_130_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_130_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_130_B.DATA_APV_USER is '审核人';
comment on column MBT_RPT_130_B.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_130_B.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_130_B.RSV1 is '备用字段';
comment on column MBT_RPT_130_B.RSV2 is '备用字段';
comment on column MBT_RPT_130_B.RSV3 is '备用字段';
comment on column MBT_RPT_130_B.RSV4 is '备用字段';
comment on column MBT_RPT_130_B.RSV5 is '备用字段';
