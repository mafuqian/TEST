create table MBT_DM_650 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_650 is '事业单位收入支出表信息';
comment on column MBT_DM_650.DATA_ID is '数据ID';
comment on column MBT_DM_650.DATA_DATE is '数据日期';
comment on column MBT_DM_650.CORP_ID is '法人ID';
comment on column MBT_DM_650.ORG_ID is '机构ID';
comment on column MBT_DM_650.GROUP_ID is '数据分组';
comment on column MBT_DM_650.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_650.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_650.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_650.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_650.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_650.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_650.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_650.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_650.B_ENT_NAME is '企业名称';
comment on column MBT_DM_650.SECTION_CHG_CNT is '段变更';
comment on column MBT_DM_650.SECTION_DEL_CNT is '段删除';
comment on column MBT_DM_650.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_DM_650.IDN_CHG_CNT is '标识项变更';
comment on column MBT_DM_650.CUST_NO is '客户号';
comment on column MBT_DM_650.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_650.PART_TYPE is '段标识';
comment on column MBT_DM_650.PART_NAME is '段名称';
comment on column MBT_DM_650.START_DATE is '起始日期';
comment on column MBT_DM_650.END_DATE is '结束日期';
comment on column MBT_DM_650.BATCH_NO is '批次号';
comment on column MBT_DM_650.ROW_NUM is '行号';
comment on column MBT_DM_650.IS_RPT is '是否报送';
comment on column MBT_DM_650.IS_VALID is '是否有效';
comment on column MBT_DM_650.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_650.OPT_FLAG is '操作标识';
comment on column MBT_DM_650.RPT_DATE is '报送日期';
comment on column MBT_DM_650.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_650.RPT_STATUS is '报送状态';
comment on column MBT_DM_650.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_650.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_650.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_650.REMARKS is '备注';
comment on column MBT_DM_650.CHECK_FLAG is '校验标志';
comment on column MBT_DM_650.CHECK_DESC is '校验说明';
comment on column MBT_DM_650.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_650.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_650.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_650.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_650.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_650.DATA_FLAG is '数据标志';
comment on column MBT_DM_650.DATA_OP is '操作标志';
comment on column MBT_DM_650.DATA_SOURCE is '数据来源';
comment on column MBT_DM_650.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_650.DATA_HASH is '数据HASH';
comment on column MBT_DM_650.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_650.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_650.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_650.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_650.DATA_CRT_USER is '创建人';
comment on column MBT_DM_650.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_650.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_650.DATA_CHG_USER is '修改人';
comment on column MBT_DM_650.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_650.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_650.DATA_APV_USER is '审核人';
comment on column MBT_DM_650.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_650.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_650.RSV1 is '备用字段';
comment on column MBT_DM_650.RSV2 is '备用字段';
comment on column MBT_DM_650.RSV3 is '备用字段';
comment on column MBT_DM_650.RSV4 is '备用字段';
comment on column MBT_DM_650.RSV5 is '备用字段';
create table MBT_DM_650_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_650_B is '事业单位收入支出表信息-基础段';
comment on column MBT_DM_650_B.DATA_ID is '数据ID';
comment on column MBT_DM_650_B.DATA_DATE is '数据日期';
comment on column MBT_DM_650_B.CORP_ID is '法人ID';
comment on column MBT_DM_650_B.ORG_ID is '机构ID';
comment on column MBT_DM_650_B.GROUP_ID is '数据分组';
comment on column MBT_DM_650_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_650_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_650_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_650_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_650_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_650_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_650_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_650_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_650_B.B_ENT_NAME is '企业名称';
comment on column MBT_DM_650_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_DM_650_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_DM_650_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_DM_650_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_DM_650_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_DM_650_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_650_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_DM_650_B.CUST_NO is '客户号';
comment on column MBT_DM_650_B.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_650_B.PART_TYPE is '段标识';
comment on column MBT_DM_650_B.PART_NAME is '段名称';
comment on column MBT_DM_650_B.START_DATE is '起始日期';
comment on column MBT_DM_650_B.END_DATE is '结束日期';
comment on column MBT_DM_650_B.BATCH_NO is '批次号';
comment on column MBT_DM_650_B.ROW_NUM is '行号';
comment on column MBT_DM_650_B.IS_RPT is '是否报送';
comment on column MBT_DM_650_B.IS_VALID is '是否有效';
comment on column MBT_DM_650_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_650_B.OPT_FLAG is '操作标识';
comment on column MBT_DM_650_B.RPT_DATE is '报送日期';
comment on column MBT_DM_650_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_650_B.RPT_STATUS is '报送状态';
comment on column MBT_DM_650_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_650_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_650_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_650_B.REMARKS is '备注';
comment on column MBT_DM_650_B.CHECK_FLAG is '校验标志';
comment on column MBT_DM_650_B.CHECK_DESC is '校验说明';
comment on column MBT_DM_650_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_650_B.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_650_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_650_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_650_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_650_B.DATA_FLAG is '数据标志';
comment on column MBT_DM_650_B.DATA_OP is '操作标志';
comment on column MBT_DM_650_B.DATA_SOURCE is '数据来源';
comment on column MBT_DM_650_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_650_B.DATA_HASH is '数据HASH';
comment on column MBT_DM_650_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_650_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_650_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_650_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_650_B.DATA_CRT_USER is '创建人';
comment on column MBT_DM_650_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_650_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_650_B.DATA_CHG_USER is '修改人';
comment on column MBT_DM_650_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_650_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_650_B.DATA_APV_USER is '审核人';
comment on column MBT_DM_650_B.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_650_B.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_650_B.RSV1 is '备用字段';
comment on column MBT_DM_650_B.RSV2 is '备用字段';
comment on column MBT_DM_650_B.RSV3 is '备用字段';
comment on column MBT_DM_650_B.RSV4 is '备用字段';
comment on column MBT_DM_650_B.RSV5 is '备用字段';
create table MBT_DM_650_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_CURRENT_FINAN_SUB_CAR_OVER_B NUMBER(17),
C_CURRENT_OPERATING_BALANCE NUMBER(17),
C_CURRENT_UNDERTAK_CAR_OVER_B NUMBER(17),
C_DONATION_INCOME NUMBER(17),
C_ENTERPRISE_INCOME_TAX_PAYABL NUMBER(17),
C_FINANCIAL_SUBSIDY_REVENUE NUMBER(17),
C_GRANT_AUXILIARY_ORGANIZATION NUMBER(17),
C_NON_FINANCIAL_AID_BAL_TYEAR NUMBER(17),
C_NON_FINANCIAL_AID_CARRIED_O NUMBER(17),
C_NON_FINA_SUB_CAR_O_BAL_TYEAR NUMBER(17),
C_OPERATING_BALANCE_P_YO_LOSS NUMBER(17),
C_OPERATING_EXPENDITURE NUMBER(17),
C_OPERATING_REVENUE NUMBER(17),
C_OTHER_EXPENDITURE NUMBER(17),
C_OTHER_REVENUE NUMBER(17),
C_PAYMENT_THE_HIGHER_AUTHORITY NUMBER(17),
C_PUBLIC_FUND_TURNED_INTO NUMBER(17),
C_REVENUE_TURNED_OVER_SUB_UNIT NUMBER(17),
C_SPECIAL_FUNDS_TO_EXTRACT NUMBER(17),
C_SUPERIOR_SUBSIDY_REVENUE NUMBER(17),
C_UNDERTAKINGS_CLASS_EXPENDIT NUMBER(17),
C_UNDERTAKINGS_CLASS_REVENUE NUMBER(17),
C_UNDERTAKINGS_EXP_FIN_SUB_EXP NUMBER(17),
C_UNDERTAKINGS_NON_FIN_SUB_EXP NUMBER(17),
C_UNDERTAKINGS_REVENUE NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_650_C is '事业单位收入支出表信息-事业单位收入支出表段';
comment on column MBT_DM_650_C.DATA_ID is '数据ID';
comment on column MBT_DM_650_C.DATA_DATE is '数据日期';
comment on column MBT_DM_650_C.CORP_ID is '法人ID';
comment on column MBT_DM_650_C.ORG_ID is '机构ID';
comment on column MBT_DM_650_C.GROUP_ID is '数据分组';
comment on column MBT_DM_650_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_650_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_650_C.C_CURRENT_FINAN_SUB_CAR_OVER_B is '本期财政补助结转余';
comment on column MBT_DM_650_C.C_CURRENT_OPERATING_BALANCE is '本期经营结余';
comment on column MBT_DM_650_C.C_CURRENT_UNDERTAK_CAR_OVER_B is '本期事业结转余';
comment on column MBT_DM_650_C.C_DONATION_INCOME is '（其他收入科目下）捐赠';
comment on column MBT_DM_650_C.C_ENTERPRISE_INCOME_TAX_PAYABL is '应缴企业所得税';
comment on column MBT_DM_650_C.C_FINANCIAL_SUBSIDY_REVENUE is '财政补助收入';
comment on column MBT_DM_650_C.C_GRANT_AUXILIARY_ORGANIZATION is '对附属单位补助支出';
comment on column MBT_DM_650_C.C_NON_FINANCIAL_AID_BAL_TYEAR is '本年非财政补助结余';
comment on column MBT_DM_650_C.C_NON_FINANCIAL_AID_CARRIED_O is '非财政补助结转';
comment on column MBT_DM_650_C.C_NON_FINA_SUB_CAR_O_BAL_TYEAR is '本年非财政补助结转余';
comment on column MBT_DM_650_C.C_OPERATING_BALANCE_P_YO_LOSS is '弥补以前年度亏损后的经营结余';
comment on column MBT_DM_650_C.C_OPERATING_EXPENDITURE is '经营支出';
comment on column MBT_DM_650_C.C_OPERATING_REVENUE is '经营收入';
comment on column MBT_DM_650_C.C_OTHER_EXPENDITURE is '其他支出';
comment on column MBT_DM_650_C.C_OTHER_REVENUE is '其他收入';
comment on column MBT_DM_650_C.C_PAYMENT_THE_HIGHER_AUTHORITY is '上缴级支出';
comment on column MBT_DM_650_C.C_PUBLIC_FUND_TURNED_INTO is '转入事业基金';
comment on column MBT_DM_650_C.C_REVENUE_TURNED_OVER_SUB_UNIT is '附属单位上缴收入';
comment on column MBT_DM_650_C.C_SPECIAL_FUNDS_TO_EXTRACT is '提取专用基金';
comment on column MBT_DM_650_C.C_SUPERIOR_SUBSIDY_REVENUE is '上级补助收入';
comment on column MBT_DM_650_C.C_UNDERTAKINGS_CLASS_EXPENDIT is '事业类支出';
comment on column MBT_DM_650_C.C_UNDERTAKINGS_CLASS_REVENUE is '事业类收入';
comment on column MBT_DM_650_C.C_UNDERTAKINGS_EXP_FIN_SUB_EXP is '事业支出（财政补助）';
comment on column MBT_DM_650_C.C_UNDERTAKINGS_NON_FIN_SUB_EXP is '事业支出（非财政补助）';
comment on column MBT_DM_650_C.C_UNDERTAKINGS_REVENUE is '事业收入';
comment on column MBT_DM_650_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_650_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_650_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_650_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_650_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_650_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_650_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_650_C.CUST_NO is '客户号';
comment on column MBT_DM_650_C.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_650_C.PART_TYPE is '段标识';
comment on column MBT_DM_650_C.PART_NAME is '段名称';
comment on column MBT_DM_650_C.START_DATE is '起始日期';
comment on column MBT_DM_650_C.END_DATE is '结束日期';
comment on column MBT_DM_650_C.BATCH_NO is '批次号';
comment on column MBT_DM_650_C.ROW_NUM is '行号';
comment on column MBT_DM_650_C.IS_RPT is '是否报送';
comment on column MBT_DM_650_C.IS_VALID is '是否有效';
comment on column MBT_DM_650_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_650_C.OPT_FLAG is '操作标识';
comment on column MBT_DM_650_C.RPT_DATE is '报送日期';
comment on column MBT_DM_650_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_650_C.RPT_STATUS is '报送状态';
comment on column MBT_DM_650_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_650_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_650_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_650_C.REMARKS is '备注';
comment on column MBT_DM_650_C.CHECK_FLAG is '校验标志';
comment on column MBT_DM_650_C.CHECK_DESC is '校验说明';
comment on column MBT_DM_650_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_650_C.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_650_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_650_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_650_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_650_C.DATA_FLAG is '数据标志';
comment on column MBT_DM_650_C.DATA_OP is '操作标志';
comment on column MBT_DM_650_C.DATA_SOURCE is '数据来源';
comment on column MBT_DM_650_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_650_C.DATA_HASH is '数据HASH';
comment on column MBT_DM_650_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_650_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_650_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_650_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_650_C.DATA_CRT_USER is '创建人';
comment on column MBT_DM_650_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_650_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_650_C.DATA_CHG_USER is '修改人';
comment on column MBT_DM_650_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_650_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_650_C.DATA_APV_USER is '审核人';
comment on column MBT_DM_650_C.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_650_C.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_650_C.RSV1 is '备用字段';
comment on column MBT_DM_650_C.RSV2 is '备用字段';
comment on column MBT_DM_650_C.RSV3 is '备用字段';
comment on column MBT_DM_650_C.RSV4 is '备用字段';
comment on column MBT_DM_650_C.RSV5 is '备用字段';
create table MBT_PM_650 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_650 is '事业单位收入支出表信息';
comment on column MBT_PM_650.DATA_ID is '数据ID';
comment on column MBT_PM_650.DATA_DATE is '数据日期';
comment on column MBT_PM_650.CORP_ID is '法人ID';
comment on column MBT_PM_650.ORG_ID is '机构ID';
comment on column MBT_PM_650.GROUP_ID is '数据分组';
comment on column MBT_PM_650.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_650.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_650.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_650.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_650.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_650.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_650.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_650.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_650.B_ENT_NAME is '企业名称';
comment on column MBT_PM_650.SECTION_CHG_CNT is '段变更';
comment on column MBT_PM_650.SECTION_DEL_CNT is '段删除';
comment on column MBT_PM_650.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_PM_650.IDN_CHG_CNT is '标识项变更';
comment on column MBT_PM_650.CUST_NO is '客户号';
comment on column MBT_PM_650.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_650.PART_TYPE is '段标识';
comment on column MBT_PM_650.PART_NAME is '段名称';
comment on column MBT_PM_650.START_DATE is '起始日期';
comment on column MBT_PM_650.END_DATE is '结束日期';
comment on column MBT_PM_650.BATCH_NO is '批次号';
comment on column MBT_PM_650.ROW_NUM is '行号';
comment on column MBT_PM_650.IS_RPT is '是否报送';
comment on column MBT_PM_650.IS_VALID is '是否有效';
comment on column MBT_PM_650.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_650.OPT_FLAG is '操作标识';
comment on column MBT_PM_650.RPT_DATE is '报送日期';
comment on column MBT_PM_650.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_650.RPT_STATUS is '报送状态';
comment on column MBT_PM_650.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_650.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_650.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_650.REMARKS is '备注';
comment on column MBT_PM_650.CHECK_FLAG is '校验标志';
comment on column MBT_PM_650.CHECK_DESC is '校验说明';
comment on column MBT_PM_650.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_650.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_650.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_650.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_650.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_650.DATA_FLAG is '数据标志';
comment on column MBT_PM_650.DATA_OP is '操作标志';
comment on column MBT_PM_650.DATA_SOURCE is '数据来源';
comment on column MBT_PM_650.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_650.DATA_HASH is '数据HASH';
comment on column MBT_PM_650.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_650.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_650.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_650.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_650.DATA_CRT_USER is '创建人';
comment on column MBT_PM_650.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_650.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_650.DATA_CHG_USER is '修改人';
comment on column MBT_PM_650.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_650.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_650.DATA_APV_USER is '审核人';
comment on column MBT_PM_650.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_650.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_650.RSV1 is '备用字段';
comment on column MBT_PM_650.RSV2 is '备用字段';
comment on column MBT_PM_650.RSV3 is '备用字段';
comment on column MBT_PM_650.RSV4 is '备用字段';
comment on column MBT_PM_650.RSV5 is '备用字段';
create table MBT_PM_650_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_650_B is '事业单位收入支出表信息-基础段';
comment on column MBT_PM_650_B.DATA_ID is '数据ID';
comment on column MBT_PM_650_B.DATA_DATE is '数据日期';
comment on column MBT_PM_650_B.CORP_ID is '法人ID';
comment on column MBT_PM_650_B.ORG_ID is '机构ID';
comment on column MBT_PM_650_B.GROUP_ID is '数据分组';
comment on column MBT_PM_650_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_650_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_650_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_650_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_650_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_650_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_650_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_650_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_650_B.B_ENT_NAME is '企业名称';
comment on column MBT_PM_650_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_PM_650_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_PM_650_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_PM_650_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_PM_650_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_PM_650_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_650_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_PM_650_B.CUST_NO is '客户号';
comment on column MBT_PM_650_B.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_650_B.PART_TYPE is '段标识';
comment on column MBT_PM_650_B.PART_NAME is '段名称';
comment on column MBT_PM_650_B.START_DATE is '起始日期';
comment on column MBT_PM_650_B.END_DATE is '结束日期';
comment on column MBT_PM_650_B.BATCH_NO is '批次号';
comment on column MBT_PM_650_B.ROW_NUM is '行号';
comment on column MBT_PM_650_B.IS_RPT is '是否报送';
comment on column MBT_PM_650_B.IS_VALID is '是否有效';
comment on column MBT_PM_650_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_650_B.OPT_FLAG is '操作标识';
comment on column MBT_PM_650_B.RPT_DATE is '报送日期';
comment on column MBT_PM_650_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_650_B.RPT_STATUS is '报送状态';
comment on column MBT_PM_650_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_650_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_650_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_650_B.REMARKS is '备注';
comment on column MBT_PM_650_B.CHECK_FLAG is '校验标志';
comment on column MBT_PM_650_B.CHECK_DESC is '校验说明';
comment on column MBT_PM_650_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_650_B.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_650_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_650_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_650_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_650_B.DATA_FLAG is '数据标志';
comment on column MBT_PM_650_B.DATA_OP is '操作标志';
comment on column MBT_PM_650_B.DATA_SOURCE is '数据来源';
comment on column MBT_PM_650_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_650_B.DATA_HASH is '数据HASH';
comment on column MBT_PM_650_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_650_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_650_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_650_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_650_B.DATA_CRT_USER is '创建人';
comment on column MBT_PM_650_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_650_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_650_B.DATA_CHG_USER is '修改人';
comment on column MBT_PM_650_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_650_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_650_B.DATA_APV_USER is '审核人';
comment on column MBT_PM_650_B.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_650_B.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_650_B.RSV1 is '备用字段';
comment on column MBT_PM_650_B.RSV2 is '备用字段';
comment on column MBT_PM_650_B.RSV3 is '备用字段';
comment on column MBT_PM_650_B.RSV4 is '备用字段';
comment on column MBT_PM_650_B.RSV5 is '备用字段';
create table MBT_PM_650_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_CURRENT_FINAN_SUB_CAR_OVER_B NUMBER(17),
C_CURRENT_OPERATING_BALANCE NUMBER(17),
C_CURRENT_UNDERTAK_CAR_OVER_B NUMBER(17),
C_DONATION_INCOME NUMBER(17),
C_ENTERPRISE_INCOME_TAX_PAYABL NUMBER(17),
C_FINANCIAL_SUBSIDY_REVENUE NUMBER(17),
C_GRANT_AUXILIARY_ORGANIZATION NUMBER(17),
C_NON_FINANCIAL_AID_BAL_TYEAR NUMBER(17),
C_NON_FINANCIAL_AID_CARRIED_O NUMBER(17),
C_NON_FINA_SUB_CAR_O_BAL_TYEAR NUMBER(17),
C_OPERATING_BALANCE_P_YO_LOSS NUMBER(17),
C_OPERATING_EXPENDITURE NUMBER(17),
C_OPERATING_REVENUE NUMBER(17),
C_OTHER_EXPENDITURE NUMBER(17),
C_OTHER_REVENUE NUMBER(17),
C_PAYMENT_THE_HIGHER_AUTHORITY NUMBER(17),
C_PUBLIC_FUND_TURNED_INTO NUMBER(17),
C_REVENUE_TURNED_OVER_SUB_UNIT NUMBER(17),
C_SPECIAL_FUNDS_TO_EXTRACT NUMBER(17),
C_SUPERIOR_SUBSIDY_REVENUE NUMBER(17),
C_UNDERTAKINGS_CLASS_EXPENDIT NUMBER(17),
C_UNDERTAKINGS_CLASS_REVENUE NUMBER(17),
C_UNDERTAKINGS_EXP_FIN_SUB_EXP NUMBER(17),
C_UNDERTAKINGS_NON_FIN_SUB_EXP NUMBER(17),
C_UNDERTAKINGS_REVENUE NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_650_C is '事业单位收入支出表信息-事业单位收入支出表段';
comment on column MBT_PM_650_C.DATA_ID is '数据ID';
comment on column MBT_PM_650_C.DATA_DATE is '数据日期';
comment on column MBT_PM_650_C.CORP_ID is '法人ID';
comment on column MBT_PM_650_C.ORG_ID is '机构ID';
comment on column MBT_PM_650_C.GROUP_ID is '数据分组';
comment on column MBT_PM_650_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_650_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_650_C.C_CURRENT_FINAN_SUB_CAR_OVER_B is '本期财政补助结转余';
comment on column MBT_PM_650_C.C_CURRENT_OPERATING_BALANCE is '本期经营结余';
comment on column MBT_PM_650_C.C_CURRENT_UNDERTAK_CAR_OVER_B is '本期事业结转余';
comment on column MBT_PM_650_C.C_DONATION_INCOME is '（其他收入科目下）捐赠';
comment on column MBT_PM_650_C.C_ENTERPRISE_INCOME_TAX_PAYABL is '应缴企业所得税';
comment on column MBT_PM_650_C.C_FINANCIAL_SUBSIDY_REVENUE is '财政补助收入';
comment on column MBT_PM_650_C.C_GRANT_AUXILIARY_ORGANIZATION is '对附属单位补助支出';
comment on column MBT_PM_650_C.C_NON_FINANCIAL_AID_BAL_TYEAR is '本年非财政补助结余';
comment on column MBT_PM_650_C.C_NON_FINANCIAL_AID_CARRIED_O is '非财政补助结转';
comment on column MBT_PM_650_C.C_NON_FINA_SUB_CAR_O_BAL_TYEAR is '本年非财政补助结转余';
comment on column MBT_PM_650_C.C_OPERATING_BALANCE_P_YO_LOSS is '弥补以前年度亏损后的经营结余';
comment on column MBT_PM_650_C.C_OPERATING_EXPENDITURE is '经营支出';
comment on column MBT_PM_650_C.C_OPERATING_REVENUE is '经营收入';
comment on column MBT_PM_650_C.C_OTHER_EXPENDITURE is '其他支出';
comment on column MBT_PM_650_C.C_OTHER_REVENUE is '其他收入';
comment on column MBT_PM_650_C.C_PAYMENT_THE_HIGHER_AUTHORITY is '上缴级支出';
comment on column MBT_PM_650_C.C_PUBLIC_FUND_TURNED_INTO is '转入事业基金';
comment on column MBT_PM_650_C.C_REVENUE_TURNED_OVER_SUB_UNIT is '附属单位上缴收入';
comment on column MBT_PM_650_C.C_SPECIAL_FUNDS_TO_EXTRACT is '提取专用基金';
comment on column MBT_PM_650_C.C_SUPERIOR_SUBSIDY_REVENUE is '上级补助收入';
comment on column MBT_PM_650_C.C_UNDERTAKINGS_CLASS_EXPENDIT is '事业类支出';
comment on column MBT_PM_650_C.C_UNDERTAKINGS_CLASS_REVENUE is '事业类收入';
comment on column MBT_PM_650_C.C_UNDERTAKINGS_EXP_FIN_SUB_EXP is '事业支出（财政补助）';
comment on column MBT_PM_650_C.C_UNDERTAKINGS_NON_FIN_SUB_EXP is '事业支出（非财政补助）';
comment on column MBT_PM_650_C.C_UNDERTAKINGS_REVENUE is '事业收入';
comment on column MBT_PM_650_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_650_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_650_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_650_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_650_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_650_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_650_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_650_C.CUST_NO is '客户号';
comment on column MBT_PM_650_C.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_650_C.PART_TYPE is '段标识';
comment on column MBT_PM_650_C.PART_NAME is '段名称';
comment on column MBT_PM_650_C.START_DATE is '起始日期';
comment on column MBT_PM_650_C.END_DATE is '结束日期';
comment on column MBT_PM_650_C.BATCH_NO is '批次号';
comment on column MBT_PM_650_C.ROW_NUM is '行号';
comment on column MBT_PM_650_C.IS_RPT is '是否报送';
comment on column MBT_PM_650_C.IS_VALID is '是否有效';
comment on column MBT_PM_650_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_650_C.OPT_FLAG is '操作标识';
comment on column MBT_PM_650_C.RPT_DATE is '报送日期';
comment on column MBT_PM_650_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_650_C.RPT_STATUS is '报送状态';
comment on column MBT_PM_650_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_650_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_650_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_650_C.REMARKS is '备注';
comment on column MBT_PM_650_C.CHECK_FLAG is '校验标志';
comment on column MBT_PM_650_C.CHECK_DESC is '校验说明';
comment on column MBT_PM_650_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_650_C.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_650_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_650_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_650_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_650_C.DATA_FLAG is '数据标志';
comment on column MBT_PM_650_C.DATA_OP is '操作标志';
comment on column MBT_PM_650_C.DATA_SOURCE is '数据来源';
comment on column MBT_PM_650_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_650_C.DATA_HASH is '数据HASH';
comment on column MBT_PM_650_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_650_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_650_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_650_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_650_C.DATA_CRT_USER is '创建人';
comment on column MBT_PM_650_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_650_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_650_C.DATA_CHG_USER is '修改人';
comment on column MBT_PM_650_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_650_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_650_C.DATA_APV_USER is '审核人';
comment on column MBT_PM_650_C.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_650_C.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_650_C.RSV1 is '备用字段';
comment on column MBT_PM_650_C.RSV2 is '备用字段';
comment on column MBT_PM_650_C.RSV3 is '备用字段';
comment on column MBT_PM_650_C.RSV4 is '备用字段';
comment on column MBT_PM_650_C.RSV5 is '备用字段';
create table MBT_RPT_650 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_650 is '事业单位收入支出表信息';
comment on column MBT_RPT_650.DATA_ID is '数据ID';
comment on column MBT_RPT_650.DATA_DATE is '数据日期';
comment on column MBT_RPT_650.CORP_ID is '法人ID';
comment on column MBT_RPT_650.ORG_ID is '机构ID';
comment on column MBT_RPT_650.GROUP_ID is '数据分组';
comment on column MBT_RPT_650.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_650.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_650.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_650.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_650.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_650.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_650.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_650.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_650.B_ENT_NAME is '企业名称';
comment on column MBT_RPT_650.SECTION_CHG_CNT is '段变更';
comment on column MBT_RPT_650.SECTION_DEL_CNT is '段删除';
comment on column MBT_RPT_650.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_RPT_650.IDN_CHG_CNT is '标识项变更';
comment on column MBT_RPT_650.CUST_NO is '客户号';
comment on column MBT_RPT_650.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_650.PART_TYPE is '段标识';
comment on column MBT_RPT_650.PART_NAME is '段名称';
comment on column MBT_RPT_650.START_DATE is '起始日期';
comment on column MBT_RPT_650.END_DATE is '结束日期';
comment on column MBT_RPT_650.BATCH_NO is '批次号';
comment on column MBT_RPT_650.ROW_NUM is '行号';
comment on column MBT_RPT_650.IS_RPT is '是否报送';
comment on column MBT_RPT_650.IS_VALID is '是否有效';
comment on column MBT_RPT_650.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_650.OPT_FLAG is '操作标识';
comment on column MBT_RPT_650.RPT_DATE is '报送日期';
comment on column MBT_RPT_650.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_650.RPT_STATUS is '报送状态';
comment on column MBT_RPT_650.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_650.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_650.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_650.REMARKS is '备注';
comment on column MBT_RPT_650.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_650.CHECK_DESC is '校验说明';
comment on column MBT_RPT_650.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_650.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_650.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_650.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_650.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_650.DATA_FLAG is '数据标志';
comment on column MBT_RPT_650.DATA_OP is '操作标志';
comment on column MBT_RPT_650.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_650.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_650.DATA_HASH is '数据HASH';
comment on column MBT_RPT_650.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_650.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_650.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_650.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_650.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_650.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_650.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_650.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_650.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_650.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_650.DATA_APV_USER is '审核人';
comment on column MBT_RPT_650.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_650.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_650.RSV1 is '备用字段';
comment on column MBT_RPT_650.RSV2 is '备用字段';
comment on column MBT_RPT_650.RSV3 is '备用字段';
comment on column MBT_RPT_650.RSV4 is '备用字段';
comment on column MBT_RPT_650.RSV5 is '备用字段';
create table MBT_RPT_650_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_650_B is '事业单位收入支出表信息-基础段';
comment on column MBT_RPT_650_B.DATA_ID is '数据ID';
comment on column MBT_RPT_650_B.DATA_DATE is '数据日期';
comment on column MBT_RPT_650_B.CORP_ID is '法人ID';
comment on column MBT_RPT_650_B.ORG_ID is '机构ID';
comment on column MBT_RPT_650_B.GROUP_ID is '数据分组';
comment on column MBT_RPT_650_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_650_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_650_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_650_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_650_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_650_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_650_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_650_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_650_B.B_ENT_NAME is '企业名称';
comment on column MBT_RPT_650_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_RPT_650_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_RPT_650_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_RPT_650_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_RPT_650_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_RPT_650_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_650_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_RPT_650_B.CUST_NO is '客户号';
comment on column MBT_RPT_650_B.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_650_B.PART_TYPE is '段标识';
comment on column MBT_RPT_650_B.PART_NAME is '段名称';
comment on column MBT_RPT_650_B.START_DATE is '起始日期';
comment on column MBT_RPT_650_B.END_DATE is '结束日期';
comment on column MBT_RPT_650_B.BATCH_NO is '批次号';
comment on column MBT_RPT_650_B.ROW_NUM is '行号';
comment on column MBT_RPT_650_B.IS_RPT is '是否报送';
comment on column MBT_RPT_650_B.IS_VALID is '是否有效';
comment on column MBT_RPT_650_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_650_B.OPT_FLAG is '操作标识';
comment on column MBT_RPT_650_B.RPT_DATE is '报送日期';
comment on column MBT_RPT_650_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_650_B.RPT_STATUS is '报送状态';
comment on column MBT_RPT_650_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_650_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_650_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_650_B.REMARKS is '备注';
comment on column MBT_RPT_650_B.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_650_B.CHECK_DESC is '校验说明';
comment on column MBT_RPT_650_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_650_B.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_650_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_650_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_650_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_650_B.DATA_FLAG is '数据标志';
comment on column MBT_RPT_650_B.DATA_OP is '操作标志';
comment on column MBT_RPT_650_B.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_650_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_650_B.DATA_HASH is '数据HASH';
comment on column MBT_RPT_650_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_650_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_650_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_650_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_650_B.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_650_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_650_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_650_B.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_650_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_650_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_650_B.DATA_APV_USER is '审核人';
comment on column MBT_RPT_650_B.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_650_B.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_650_B.RSV1 is '备用字段';
comment on column MBT_RPT_650_B.RSV2 is '备用字段';
comment on column MBT_RPT_650_B.RSV3 is '备用字段';
comment on column MBT_RPT_650_B.RSV4 is '备用字段';
comment on column MBT_RPT_650_B.RSV5 is '备用字段';
create table MBT_RPT_650_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_CURRENT_FINAN_SUB_CAR_OVER_B NUMBER(17),
C_CURRENT_OPERATING_BALANCE NUMBER(17),
C_CURRENT_UNDERTAK_CAR_OVER_B NUMBER(17),
C_DONATION_INCOME NUMBER(17),
C_ENTERPRISE_INCOME_TAX_PAYABL NUMBER(17),
C_FINANCIAL_SUBSIDY_REVENUE NUMBER(17),
C_GRANT_AUXILIARY_ORGANIZATION NUMBER(17),
C_NON_FINANCIAL_AID_BAL_TYEAR NUMBER(17),
C_NON_FINANCIAL_AID_CARRIED_O NUMBER(17),
C_NON_FINA_SUB_CAR_O_BAL_TYEAR NUMBER(17),
C_OPERATING_BALANCE_P_YO_LOSS NUMBER(17),
C_OPERATING_EXPENDITURE NUMBER(17),
C_OPERATING_REVENUE NUMBER(17),
C_OTHER_EXPENDITURE NUMBER(17),
C_OTHER_REVENUE NUMBER(17),
C_PAYMENT_THE_HIGHER_AUTHORITY NUMBER(17),
C_PUBLIC_FUND_TURNED_INTO NUMBER(17),
C_REVENUE_TURNED_OVER_SUB_UNIT NUMBER(17),
C_SPECIAL_FUNDS_TO_EXTRACT NUMBER(17),
C_SUPERIOR_SUBSIDY_REVENUE NUMBER(17),
C_UNDERTAKINGS_CLASS_EXPENDIT NUMBER(17),
C_UNDERTAKINGS_CLASS_REVENUE NUMBER(17),
C_UNDERTAKINGS_EXP_FIN_SUB_EXP NUMBER(17),
C_UNDERTAKINGS_NON_FIN_SUB_EXP NUMBER(17),
C_UNDERTAKINGS_REVENUE NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_650_C is '事业单位收入支出表信息-事业单位收入支出表段';
comment on column MBT_RPT_650_C.DATA_ID is '数据ID';
comment on column MBT_RPT_650_C.DATA_DATE is '数据日期';
comment on column MBT_RPT_650_C.CORP_ID is '法人ID';
comment on column MBT_RPT_650_C.ORG_ID is '机构ID';
comment on column MBT_RPT_650_C.GROUP_ID is '数据分组';
comment on column MBT_RPT_650_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_650_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_650_C.C_CURRENT_FINAN_SUB_CAR_OVER_B is '本期财政补助结转余';
comment on column MBT_RPT_650_C.C_CURRENT_OPERATING_BALANCE is '本期经营结余';
comment on column MBT_RPT_650_C.C_CURRENT_UNDERTAK_CAR_OVER_B is '本期事业结转余';
comment on column MBT_RPT_650_C.C_DONATION_INCOME is '（其他收入科目下）捐赠';
comment on column MBT_RPT_650_C.C_ENTERPRISE_INCOME_TAX_PAYABL is '应缴企业所得税';
comment on column MBT_RPT_650_C.C_FINANCIAL_SUBSIDY_REVENUE is '财政补助收入';
comment on column MBT_RPT_650_C.C_GRANT_AUXILIARY_ORGANIZATION is '对附属单位补助支出';
comment on column MBT_RPT_650_C.C_NON_FINANCIAL_AID_BAL_TYEAR is '本年非财政补助结余';
comment on column MBT_RPT_650_C.C_NON_FINANCIAL_AID_CARRIED_O is '非财政补助结转';
comment on column MBT_RPT_650_C.C_NON_FINA_SUB_CAR_O_BAL_TYEAR is '本年非财政补助结转余';
comment on column MBT_RPT_650_C.C_OPERATING_BALANCE_P_YO_LOSS is '弥补以前年度亏损后的经营结余';
comment on column MBT_RPT_650_C.C_OPERATING_EXPENDITURE is '经营支出';
comment on column MBT_RPT_650_C.C_OPERATING_REVENUE is '经营收入';
comment on column MBT_RPT_650_C.C_OTHER_EXPENDITURE is '其他支出';
comment on column MBT_RPT_650_C.C_OTHER_REVENUE is '其他收入';
comment on column MBT_RPT_650_C.C_PAYMENT_THE_HIGHER_AUTHORITY is '上缴级支出';
comment on column MBT_RPT_650_C.C_PUBLIC_FUND_TURNED_INTO is '转入事业基金';
comment on column MBT_RPT_650_C.C_REVENUE_TURNED_OVER_SUB_UNIT is '附属单位上缴收入';
comment on column MBT_RPT_650_C.C_SPECIAL_FUNDS_TO_EXTRACT is '提取专用基金';
comment on column MBT_RPT_650_C.C_SUPERIOR_SUBSIDY_REVENUE is '上级补助收入';
comment on column MBT_RPT_650_C.C_UNDERTAKINGS_CLASS_EXPENDIT is '事业类支出';
comment on column MBT_RPT_650_C.C_UNDERTAKINGS_CLASS_REVENUE is '事业类收入';
comment on column MBT_RPT_650_C.C_UNDERTAKINGS_EXP_FIN_SUB_EXP is '事业支出（财政补助）';
comment on column MBT_RPT_650_C.C_UNDERTAKINGS_NON_FIN_SUB_EXP is '事业支出（非财政补助）';
comment on column MBT_RPT_650_C.C_UNDERTAKINGS_REVENUE is '事业收入';
comment on column MBT_RPT_650_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_650_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_650_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_650_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_650_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_650_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_650_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_650_C.CUST_NO is '客户号';
comment on column MBT_RPT_650_C.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_650_C.PART_TYPE is '段标识';
comment on column MBT_RPT_650_C.PART_NAME is '段名称';
comment on column MBT_RPT_650_C.START_DATE is '起始日期';
comment on column MBT_RPT_650_C.END_DATE is '结束日期';
comment on column MBT_RPT_650_C.BATCH_NO is '批次号';
comment on column MBT_RPT_650_C.ROW_NUM is '行号';
comment on column MBT_RPT_650_C.IS_RPT is '是否报送';
comment on column MBT_RPT_650_C.IS_VALID is '是否有效';
comment on column MBT_RPT_650_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_650_C.OPT_FLAG is '操作标识';
comment on column MBT_RPT_650_C.RPT_DATE is '报送日期';
comment on column MBT_RPT_650_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_650_C.RPT_STATUS is '报送状态';
comment on column MBT_RPT_650_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_650_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_650_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_650_C.REMARKS is '备注';
comment on column MBT_RPT_650_C.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_650_C.CHECK_DESC is '校验说明';
comment on column MBT_RPT_650_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_650_C.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_650_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_650_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_650_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_650_C.DATA_FLAG is '数据标志';
comment on column MBT_RPT_650_C.DATA_OP is '操作标志';
comment on column MBT_RPT_650_C.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_650_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_650_C.DATA_HASH is '数据HASH';
comment on column MBT_RPT_650_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_650_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_650_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_650_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_650_C.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_650_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_650_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_650_C.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_650_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_650_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_650_C.DATA_APV_USER is '审核人';
comment on column MBT_RPT_650_C.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_650_C.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_650_C.RSV1 is '备用字段';
comment on column MBT_RPT_650_C.RSV2 is '备用字段';
comment on column MBT_RPT_650_C.RSV3 is '备用字段';
comment on column MBT_RPT_650_C.RSV4 is '备用字段';
comment on column MBT_RPT_650_C.RSV5 is '备用字段';
