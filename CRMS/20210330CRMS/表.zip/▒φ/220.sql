create table MBT_DM_220 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_CONTRACT_CODE VARCHAR(60),
O_BIZ_CODE VARCHAR(60),
N_BIZ_CODE VARCHAR(60),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_220 is '个人授信协议信息';
comment on column MBT_DM_220.DATA_ID is '数据ID';
comment on column MBT_DM_220.DATA_DATE is '数据日期';
comment on column MBT_DM_220.CORP_ID is '法人ID';
comment on column MBT_DM_220.ORG_ID is '机构ID';
comment on column MBT_DM_220.GROUP_ID is '数据分组';
comment on column MBT_DM_220.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_220.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_220.B_CONTRACT_CODE is '授信协议标识码';
comment on column MBT_DM_220.O_BIZ_CODE is '原业务标识码';
comment on column MBT_DM_220.N_BIZ_CODE is '新业务标识码';
comment on column MBT_DM_220.SECTION_CHG_CNT is '段变更';
comment on column MBT_DM_220.SECTION_DEL_CNT is '段删除';
comment on column MBT_DM_220.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_DM_220.IDN_CHG_CNT is '标识项变更';
comment on column MBT_DM_220.CUST_NO is '客户号';
comment on column MBT_DM_220.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_220.PART_TYPE is '段标识';
comment on column MBT_DM_220.PART_NAME is '段名称';
comment on column MBT_DM_220.START_DATE is '起始日期';
comment on column MBT_DM_220.END_DATE is '结束日期';
comment on column MBT_DM_220.BATCH_NO is '批次号';
comment on column MBT_DM_220.ROW_NUM is '行号';
comment on column MBT_DM_220.IS_RPT is '是否报送';
comment on column MBT_DM_220.IS_VALID is '是否有效';
comment on column MBT_DM_220.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_220.OPT_FLAG is '操作标识';
comment on column MBT_DM_220.RPT_DATE is '报送日期';
comment on column MBT_DM_220.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_220.RPT_STATUS is '报送状态';
comment on column MBT_DM_220.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_220.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_220.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_220.REMARKS is '备注';
comment on column MBT_DM_220.CHECK_FLAG is '校验标志';
comment on column MBT_DM_220.CHECK_DESC is '校验说明';
comment on column MBT_DM_220.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_220.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_220.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_220.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_220.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_220.DATA_FLAG is '数据标志';
comment on column MBT_DM_220.DATA_OP is '操作标志';
comment on column MBT_DM_220.DATA_SOURCE is '数据来源';
comment on column MBT_DM_220.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_220.DATA_HASH is '数据HASH';
comment on column MBT_DM_220.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_220.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_220.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_220.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_220.DATA_CRT_USER is '创建人';
comment on column MBT_DM_220.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_220.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_220.DATA_CHG_USER is '修改人';
comment on column MBT_DM_220.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_220.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_220.DATA_APV_USER is '审核人';
comment on column MBT_DM_220.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_220.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_220.RSV1 is '备用字段';
comment on column MBT_DM_220.RSV2 is '备用字段';
comment on column MBT_DM_220.RSV3 is '备用字段';
comment on column MBT_DM_220.RSV4 is '备用字段';
comment on column MBT_DM_220.RSV5 is '备用字段';
create table MBT_DM_220_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_CONTRACT_CODE VARCHAR(60),
B_CONTRACT_NO VARCHAR(32),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(10),
B_INF_REC_TYPE VARCHAR(3),
B_MNGMT_ORG_CODE VARCHAR(14),
B_NAME VARCHAR(160),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_220_B is '个人授信协议信息-基础段';
comment on column MBT_DM_220_B.DATA_ID is '数据ID';
comment on column MBT_DM_220_B.DATA_DATE is '数据日期';
comment on column MBT_DM_220_B.CORP_ID is '法人ID';
comment on column MBT_DM_220_B.ORG_ID is '机构ID';
comment on column MBT_DM_220_B.GROUP_ID is '数据分组';
comment on column MBT_DM_220_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_220_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_220_B.B_CONTRACT_CODE is '授信协议标识码';
comment on column MBT_DM_220_B.B_CONTRACT_NO is '授信协议编号';
comment on column MBT_DM_220_B.B_ID_NUM is '受信人身份标识证件号码';
comment on column MBT_DM_220_B.B_ID_TYPE is '受信人身份标识类型';
comment on column MBT_DM_220_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_DM_220_B.B_MNGMT_ORG_CODE is '业务管理机构代码';
comment on column MBT_DM_220_B.B_NAME is '受信人名称';
comment on column MBT_DM_220_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_220_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_DM_220_B.CUST_NO is '客户号';
comment on column MBT_DM_220_B.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_220_B.PART_TYPE is '段标识';
comment on column MBT_DM_220_B.PART_NAME is '段名称';
comment on column MBT_DM_220_B.START_DATE is '起始日期';
comment on column MBT_DM_220_B.END_DATE is '结束日期';
comment on column MBT_DM_220_B.BATCH_NO is '批次号';
comment on column MBT_DM_220_B.ROW_NUM is '行号';
comment on column MBT_DM_220_B.IS_RPT is '是否报送';
comment on column MBT_DM_220_B.IS_VALID is '是否有效';
comment on column MBT_DM_220_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_220_B.OPT_FLAG is '操作标识';
comment on column MBT_DM_220_B.RPT_DATE is '报送日期';
comment on column MBT_DM_220_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_220_B.RPT_STATUS is '报送状态';
comment on column MBT_DM_220_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_220_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_220_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_220_B.REMARKS is '备注';
comment on column MBT_DM_220_B.CHECK_FLAG is '校验标志';
comment on column MBT_DM_220_B.CHECK_DESC is '校验说明';
comment on column MBT_DM_220_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_220_B.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_220_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_220_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_220_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_220_B.DATA_FLAG is '数据标志';
comment on column MBT_DM_220_B.DATA_OP is '操作标志';
comment on column MBT_DM_220_B.DATA_SOURCE is '数据来源';
comment on column MBT_DM_220_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_220_B.DATA_HASH is '数据HASH';
comment on column MBT_DM_220_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_220_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_220_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_220_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_220_B.DATA_CRT_USER is '创建人';
comment on column MBT_DM_220_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_220_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_220_B.DATA_CHG_USER is '修改人';
comment on column MBT_DM_220_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_220_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_220_B.DATA_APV_USER is '审核人';
comment on column MBT_DM_220_B.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_220_B.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_220_B.RSV1 is '备用字段';
comment on column MBT_DM_220_B.RSV2 is '备用字段';
comment on column MBT_DM_220_B.RSV3 is '备用字段';
comment on column MBT_DM_220_B.RSV4 is '备用字段';
comment on column MBT_DM_220_B.RSV5 is '备用字段';
create table MBT_DM_220_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_BRER_TYPE VARCHAR(1),
C_CERT_REL_ID_NUM VARCHAR(40),
C_CERT_REL_ID_TYPE VARCHAR(2),
C_CERT_REL_NAME VARCHAR(160),
B_RPT_DATE VARCHAR(8),
B_CONTRACT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_220_C is '个人授信协议信息-共同受信人信息段';
comment on column MBT_DM_220_C.DATA_ID is '数据ID';
comment on column MBT_DM_220_C.DATA_DATE is '数据日期';
comment on column MBT_DM_220_C.CORP_ID is '法人ID';
comment on column MBT_DM_220_C.ORG_ID is '机构ID';
comment on column MBT_DM_220_C.GROUP_ID is '数据分组';
comment on column MBT_DM_220_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_220_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_220_C.C_BRER_TYPE is '共同受信人身份类别';
comment on column MBT_DM_220_C.C_CERT_REL_ID_NUM is '共同受信人身份标识号码';
comment on column MBT_DM_220_C.C_CERT_REL_ID_TYPE is '共同受信人身份标识类别';
comment on column MBT_DM_220_C.C_CERT_REL_NAME is '共同受信人名称';
comment on column MBT_DM_220_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_220_C.B_CONTRACT_CODE is '授信协议标识码';
comment on column MBT_DM_220_C.CUST_NO is '客户号';
comment on column MBT_DM_220_C.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_220_C.PART_TYPE is '段标识';
comment on column MBT_DM_220_C.PART_NAME is '段名称';
comment on column MBT_DM_220_C.START_DATE is '起始日期';
comment on column MBT_DM_220_C.END_DATE is '结束日期';
comment on column MBT_DM_220_C.BATCH_NO is '批次号';
comment on column MBT_DM_220_C.ROW_NUM is '行号';
comment on column MBT_DM_220_C.IS_RPT is '是否报送';
comment on column MBT_DM_220_C.IS_VALID is '是否有效';
comment on column MBT_DM_220_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_220_C.OPT_FLAG is '操作标识';
comment on column MBT_DM_220_C.RPT_DATE is '报送日期';
comment on column MBT_DM_220_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_220_C.RPT_STATUS is '报送状态';
comment on column MBT_DM_220_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_220_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_220_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_220_C.REMARKS is '备注';
comment on column MBT_DM_220_C.CHECK_FLAG is '校验标志';
comment on column MBT_DM_220_C.CHECK_DESC is '校验说明';
comment on column MBT_DM_220_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_220_C.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_220_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_220_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_220_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_220_C.DATA_FLAG is '数据标志';
comment on column MBT_DM_220_C.DATA_OP is '操作标志';
comment on column MBT_DM_220_C.DATA_SOURCE is '数据来源';
comment on column MBT_DM_220_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_220_C.DATA_HASH is '数据HASH';
comment on column MBT_DM_220_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_220_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_220_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_220_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_220_C.DATA_CRT_USER is '创建人';
comment on column MBT_DM_220_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_220_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_220_C.DATA_CHG_USER is '修改人';
comment on column MBT_DM_220_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_220_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_220_C.DATA_APV_USER is '审核人';
comment on column MBT_DM_220_C.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_220_C.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_220_C.RSV1 is '备用字段';
comment on column MBT_DM_220_C.RSV2 is '备用字段';
comment on column MBT_DM_220_C.RSV3 is '备用字段';
comment on column MBT_DM_220_C.RSV4 is '备用字段';
comment on column MBT_DM_220_C.RSV5 is '备用字段';
create table MBT_DM_220_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_CON_EFF_DATE VARCHAR(8),
D_CON_EXP_DATE VARCHAR(8),
D_CON_STATUS VARCHAR(2),
D_CREDIT_LIM NUMBER(15),
D_CREDIT_LIM_LCY NUMBER(15),
D_CREDIT_LIM_ORG NUMBER(15),
D_CREDIT_LIM_TYPE VARCHAR(2),
D_CREDIT_REST_CODE VARCHAR(60),
D_CREDIT_REST NUMBER(15),
D_CREDIT_REST_LCY NUMBER(15),
D_CREDIT_REST_ORG NUMBER(15),
C_CY VARCHAR(3),
D_LIM_LOOP_FLG VARCHAR(1),
B_RPT_DATE VARCHAR(8),
B_CONTRACT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_220_D is '个人授信协议信息-额度信息段';
comment on column MBT_DM_220_D.DATA_ID is '数据ID';
comment on column MBT_DM_220_D.DATA_DATE is '数据日期';
comment on column MBT_DM_220_D.CORP_ID is '法人ID';
comment on column MBT_DM_220_D.ORG_ID is '机构ID';
comment on column MBT_DM_220_D.GROUP_ID is '数据分组';
comment on column MBT_DM_220_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_220_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_220_D.D_CON_EFF_DATE is '额度生效日期';
comment on column MBT_DM_220_D.D_CON_EXP_DATE is '额度到期日期';
comment on column MBT_DM_220_D.D_CON_STATUS is '额度状态';
comment on column MBT_DM_220_D.D_CREDIT_LIM is '授信额度';
comment on column MBT_DM_220_D.D_CREDIT_LIM_LCY is '授信额度人民币金额';
comment on column MBT_DM_220_D.D_CREDIT_LIM_ORG is '授信额度_原始数据金额';
comment on column MBT_DM_220_D.D_CREDIT_LIM_TYPE is '授信额度类型';
comment on column MBT_DM_220_D.D_CREDIT_REST_CODE is '授信限额编号';
comment on column MBT_DM_220_D.D_CREDIT_REST is '授信限额';
comment on column MBT_DM_220_D.D_CREDIT_REST_LCY is '授信限额人民币金额';
comment on column MBT_DM_220_D.D_CREDIT_REST_ORG is '授信限额_原始数据金额';
comment on column MBT_DM_220_D.C_CY is '币种';
comment on column MBT_DM_220_D.D_LIM_LOOP_FLG is '额度循环标志';
comment on column MBT_DM_220_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_220_D.B_CONTRACT_CODE is '授信协议标识码';
comment on column MBT_DM_220_D.CUST_NO is '客户号';
comment on column MBT_DM_220_D.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_220_D.PART_TYPE is '段标识';
comment on column MBT_DM_220_D.PART_NAME is '段名称';
comment on column MBT_DM_220_D.START_DATE is '起始日期';
comment on column MBT_DM_220_D.END_DATE is '结束日期';
comment on column MBT_DM_220_D.BATCH_NO is '批次号';
comment on column MBT_DM_220_D.ROW_NUM is '行号';
comment on column MBT_DM_220_D.IS_RPT is '是否报送';
comment on column MBT_DM_220_D.IS_VALID is '是否有效';
comment on column MBT_DM_220_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_220_D.OPT_FLAG is '操作标识';
comment on column MBT_DM_220_D.RPT_DATE is '报送日期';
comment on column MBT_DM_220_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_220_D.RPT_STATUS is '报送状态';
comment on column MBT_DM_220_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_220_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_220_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_220_D.REMARKS is '备注';
comment on column MBT_DM_220_D.CHECK_FLAG is '校验标志';
comment on column MBT_DM_220_D.CHECK_DESC is '校验说明';
comment on column MBT_DM_220_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_220_D.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_220_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_220_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_220_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_220_D.DATA_FLAG is '数据标志';
comment on column MBT_DM_220_D.DATA_OP is '操作标志';
comment on column MBT_DM_220_D.DATA_SOURCE is '数据来源';
comment on column MBT_DM_220_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_220_D.DATA_HASH is '数据HASH';
comment on column MBT_DM_220_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_220_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_220_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_220_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_220_D.DATA_CRT_USER is '创建人';
comment on column MBT_DM_220_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_220_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_220_D.DATA_CHG_USER is '修改人';
comment on column MBT_DM_220_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_220_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_220_D.DATA_APV_USER is '审核人';
comment on column MBT_DM_220_D.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_220_D.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_220_D.RSV1 is '备用字段';
comment on column MBT_DM_220_D.RSV2 is '备用字段';
comment on column MBT_DM_220_D.RSV3 is '备用字段';
comment on column MBT_DM_220_D.RSV4 is '备用字段';
comment on column MBT_DM_220_D.RSV5 is '备用字段';
create table MBT_PM_220 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_CONTRACT_CODE VARCHAR(60),
O_BIZ_CODE VARCHAR(60),
N_BIZ_CODE VARCHAR(60),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_220 is '个人授信协议信息';
comment on column MBT_PM_220.DATA_ID is '数据ID';
comment on column MBT_PM_220.DATA_DATE is '数据日期';
comment on column MBT_PM_220.CORP_ID is '法人ID';
comment on column MBT_PM_220.ORG_ID is '机构ID';
comment on column MBT_PM_220.GROUP_ID is '数据分组';
comment on column MBT_PM_220.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_220.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_220.B_CONTRACT_CODE is '授信协议标识码';
comment on column MBT_PM_220.O_BIZ_CODE is '原业务标识码';
comment on column MBT_PM_220.N_BIZ_CODE is '新业务标识码';
comment on column MBT_PM_220.SECTION_CHG_CNT is '段变更';
comment on column MBT_PM_220.SECTION_DEL_CNT is '段删除';
comment on column MBT_PM_220.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_PM_220.IDN_CHG_CNT is '标识项变更';
comment on column MBT_PM_220.CUST_NO is '客户号';
comment on column MBT_PM_220.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_220.PART_TYPE is '段标识';
comment on column MBT_PM_220.PART_NAME is '段名称';
comment on column MBT_PM_220.START_DATE is '起始日期';
comment on column MBT_PM_220.END_DATE is '结束日期';
comment on column MBT_PM_220.BATCH_NO is '批次号';
comment on column MBT_PM_220.ROW_NUM is '行号';
comment on column MBT_PM_220.IS_RPT is '是否报送';
comment on column MBT_PM_220.IS_VALID is '是否有效';
comment on column MBT_PM_220.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_220.OPT_FLAG is '操作标识';
comment on column MBT_PM_220.RPT_DATE is '报送日期';
comment on column MBT_PM_220.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_220.RPT_STATUS is '报送状态';
comment on column MBT_PM_220.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_220.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_220.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_220.REMARKS is '备注';
comment on column MBT_PM_220.CHECK_FLAG is '校验标志';
comment on column MBT_PM_220.CHECK_DESC is '校验说明';
comment on column MBT_PM_220.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_220.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_220.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_220.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_220.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_220.DATA_FLAG is '数据标志';
comment on column MBT_PM_220.DATA_OP is '操作标志';
comment on column MBT_PM_220.DATA_SOURCE is '数据来源';
comment on column MBT_PM_220.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_220.DATA_HASH is '数据HASH';
comment on column MBT_PM_220.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_220.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_220.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_220.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_220.DATA_CRT_USER is '创建人';
comment on column MBT_PM_220.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_220.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_220.DATA_CHG_USER is '修改人';
comment on column MBT_PM_220.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_220.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_220.DATA_APV_USER is '审核人';
comment on column MBT_PM_220.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_220.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_220.RSV1 is '备用字段';
comment on column MBT_PM_220.RSV2 is '备用字段';
comment on column MBT_PM_220.RSV3 is '备用字段';
comment on column MBT_PM_220.RSV4 is '备用字段';
comment on column MBT_PM_220.RSV5 is '备用字段';
create table MBT_PM_220_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_CONTRACT_CODE VARCHAR(60),
B_CONTRACT_NO VARCHAR(32),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(10),
B_INF_REC_TYPE VARCHAR(3),
B_MNGMT_ORG_CODE VARCHAR(14),
B_NAME VARCHAR(160),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_220_B is '个人授信协议信息-基础段';
comment on column MBT_PM_220_B.DATA_ID is '数据ID';
comment on column MBT_PM_220_B.DATA_DATE is '数据日期';
comment on column MBT_PM_220_B.CORP_ID is '法人ID';
comment on column MBT_PM_220_B.ORG_ID is '机构ID';
comment on column MBT_PM_220_B.GROUP_ID is '数据分组';
comment on column MBT_PM_220_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_220_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_220_B.B_CONTRACT_CODE is '授信协议标识码';
comment on column MBT_PM_220_B.B_CONTRACT_NO is '授信协议编号';
comment on column MBT_PM_220_B.B_ID_NUM is '受信人身份标识证件号码';
comment on column MBT_PM_220_B.B_ID_TYPE is '受信人身份标识类型';
comment on column MBT_PM_220_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_PM_220_B.B_MNGMT_ORG_CODE is '业务管理机构代码';
comment on column MBT_PM_220_B.B_NAME is '受信人名称';
comment on column MBT_PM_220_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_220_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_PM_220_B.CUST_NO is '客户号';
comment on column MBT_PM_220_B.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_220_B.PART_TYPE is '段标识';
comment on column MBT_PM_220_B.PART_NAME is '段名称';
comment on column MBT_PM_220_B.START_DATE is '起始日期';
comment on column MBT_PM_220_B.END_DATE is '结束日期';
comment on column MBT_PM_220_B.BATCH_NO is '批次号';
comment on column MBT_PM_220_B.ROW_NUM is '行号';
comment on column MBT_PM_220_B.IS_RPT is '是否报送';
comment on column MBT_PM_220_B.IS_VALID is '是否有效';
comment on column MBT_PM_220_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_220_B.OPT_FLAG is '操作标识';
comment on column MBT_PM_220_B.RPT_DATE is '报送日期';
comment on column MBT_PM_220_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_220_B.RPT_STATUS is '报送状态';
comment on column MBT_PM_220_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_220_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_220_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_220_B.REMARKS is '备注';
comment on column MBT_PM_220_B.CHECK_FLAG is '校验标志';
comment on column MBT_PM_220_B.CHECK_DESC is '校验说明';
comment on column MBT_PM_220_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_220_B.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_220_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_220_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_220_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_220_B.DATA_FLAG is '数据标志';
comment on column MBT_PM_220_B.DATA_OP is '操作标志';
comment on column MBT_PM_220_B.DATA_SOURCE is '数据来源';
comment on column MBT_PM_220_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_220_B.DATA_HASH is '数据HASH';
comment on column MBT_PM_220_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_220_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_220_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_220_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_220_B.DATA_CRT_USER is '创建人';
comment on column MBT_PM_220_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_220_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_220_B.DATA_CHG_USER is '修改人';
comment on column MBT_PM_220_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_220_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_220_B.DATA_APV_USER is '审核人';
comment on column MBT_PM_220_B.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_220_B.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_220_B.RSV1 is '备用字段';
comment on column MBT_PM_220_B.RSV2 is '备用字段';
comment on column MBT_PM_220_B.RSV3 is '备用字段';
comment on column MBT_PM_220_B.RSV4 is '备用字段';
comment on column MBT_PM_220_B.RSV5 is '备用字段';
create table MBT_PM_220_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_BRER_TYPE VARCHAR(1),
C_CERT_REL_ID_NUM VARCHAR(40),
C_CERT_REL_ID_TYPE VARCHAR(2),
C_CERT_REL_NAME VARCHAR(160),
B_RPT_DATE VARCHAR(8),
B_CONTRACT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_220_C is '个人授信协议信息-共同受信人信息段';
comment on column MBT_PM_220_C.DATA_ID is '数据ID';
comment on column MBT_PM_220_C.DATA_DATE is '数据日期';
comment on column MBT_PM_220_C.CORP_ID is '法人ID';
comment on column MBT_PM_220_C.ORG_ID is '机构ID';
comment on column MBT_PM_220_C.GROUP_ID is '数据分组';
comment on column MBT_PM_220_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_220_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_220_C.C_BRER_TYPE is '共同受信人身份类别';
comment on column MBT_PM_220_C.C_CERT_REL_ID_NUM is '共同受信人身份标识号码';
comment on column MBT_PM_220_C.C_CERT_REL_ID_TYPE is '共同受信人身份标识类别';
comment on column MBT_PM_220_C.C_CERT_REL_NAME is '共同受信人名称';
comment on column MBT_PM_220_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_220_C.B_CONTRACT_CODE is '授信协议标识码';
comment on column MBT_PM_220_C.CUST_NO is '客户号';
comment on column MBT_PM_220_C.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_220_C.PART_TYPE is '段标识';
comment on column MBT_PM_220_C.PART_NAME is '段名称';
comment on column MBT_PM_220_C.START_DATE is '起始日期';
comment on column MBT_PM_220_C.END_DATE is '结束日期';
comment on column MBT_PM_220_C.BATCH_NO is '批次号';
comment on column MBT_PM_220_C.ROW_NUM is '行号';
comment on column MBT_PM_220_C.IS_RPT is '是否报送';
comment on column MBT_PM_220_C.IS_VALID is '是否有效';
comment on column MBT_PM_220_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_220_C.OPT_FLAG is '操作标识';
comment on column MBT_PM_220_C.RPT_DATE is '报送日期';
comment on column MBT_PM_220_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_220_C.RPT_STATUS is '报送状态';
comment on column MBT_PM_220_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_220_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_220_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_220_C.REMARKS is '备注';
comment on column MBT_PM_220_C.CHECK_FLAG is '校验标志';
comment on column MBT_PM_220_C.CHECK_DESC is '校验说明';
comment on column MBT_PM_220_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_220_C.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_220_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_220_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_220_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_220_C.DATA_FLAG is '数据标志';
comment on column MBT_PM_220_C.DATA_OP is '操作标志';
comment on column MBT_PM_220_C.DATA_SOURCE is '数据来源';
comment on column MBT_PM_220_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_220_C.DATA_HASH is '数据HASH';
comment on column MBT_PM_220_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_220_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_220_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_220_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_220_C.DATA_CRT_USER is '创建人';
comment on column MBT_PM_220_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_220_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_220_C.DATA_CHG_USER is '修改人';
comment on column MBT_PM_220_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_220_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_220_C.DATA_APV_USER is '审核人';
comment on column MBT_PM_220_C.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_220_C.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_220_C.RSV1 is '备用字段';
comment on column MBT_PM_220_C.RSV2 is '备用字段';
comment on column MBT_PM_220_C.RSV3 is '备用字段';
comment on column MBT_PM_220_C.RSV4 is '备用字段';
comment on column MBT_PM_220_C.RSV5 is '备用字段';
create table MBT_PM_220_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_CON_EFF_DATE VARCHAR(8),
D_CON_EXP_DATE VARCHAR(8),
D_CON_STATUS VARCHAR(2),
D_CREDIT_LIM NUMBER(15),
D_CREDIT_LIM_LCY NUMBER(15),
D_CREDIT_LIM_ORG NUMBER(15),
D_CREDIT_LIM_TYPE VARCHAR(2),
D_CREDIT_REST_CODE VARCHAR(60),
D_CREDIT_REST NUMBER(15),
D_CREDIT_REST_LCY NUMBER(15),
D_CREDIT_REST_ORG NUMBER(15),
C_CY VARCHAR(3),
D_LIM_LOOP_FLG VARCHAR(1),
B_RPT_DATE VARCHAR(8),
B_CONTRACT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_220_D is '个人授信协议信息-额度信息段';
comment on column MBT_PM_220_D.DATA_ID is '数据ID';
comment on column MBT_PM_220_D.DATA_DATE is '数据日期';
comment on column MBT_PM_220_D.CORP_ID is '法人ID';
comment on column MBT_PM_220_D.ORG_ID is '机构ID';
comment on column MBT_PM_220_D.GROUP_ID is '数据分组';
comment on column MBT_PM_220_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_220_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_220_D.D_CON_EFF_DATE is '额度生效日期';
comment on column MBT_PM_220_D.D_CON_EXP_DATE is '额度到期日期';
comment on column MBT_PM_220_D.D_CON_STATUS is '额度状态';
comment on column MBT_PM_220_D.D_CREDIT_LIM is '授信额度';
comment on column MBT_PM_220_D.D_CREDIT_LIM_LCY is '授信额度人民币金额';
comment on column MBT_PM_220_D.D_CREDIT_LIM_ORG is '授信额度_原始数据金额';
comment on column MBT_PM_220_D.D_CREDIT_LIM_TYPE is '授信额度类型';
comment on column MBT_PM_220_D.D_CREDIT_REST_CODE is '授信限额编号';
comment on column MBT_PM_220_D.D_CREDIT_REST is '授信限额';
comment on column MBT_PM_220_D.D_CREDIT_REST_LCY is '授信限额人民币金额';
comment on column MBT_PM_220_D.D_CREDIT_REST_ORG is '授信限额_原始数据金额';
comment on column MBT_PM_220_D.C_CY is '币种';
comment on column MBT_PM_220_D.D_LIM_LOOP_FLG is '额度循环标志';
comment on column MBT_PM_220_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_220_D.B_CONTRACT_CODE is '授信协议标识码';
comment on column MBT_PM_220_D.CUST_NO is '客户号';
comment on column MBT_PM_220_D.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_220_D.PART_TYPE is '段标识';
comment on column MBT_PM_220_D.PART_NAME is '段名称';
comment on column MBT_PM_220_D.START_DATE is '起始日期';
comment on column MBT_PM_220_D.END_DATE is '结束日期';
comment on column MBT_PM_220_D.BATCH_NO is '批次号';
comment on column MBT_PM_220_D.ROW_NUM is '行号';
comment on column MBT_PM_220_D.IS_RPT is '是否报送';
comment on column MBT_PM_220_D.IS_VALID is '是否有效';
comment on column MBT_PM_220_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_220_D.OPT_FLAG is '操作标识';
comment on column MBT_PM_220_D.RPT_DATE is '报送日期';
comment on column MBT_PM_220_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_220_D.RPT_STATUS is '报送状态';
comment on column MBT_PM_220_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_220_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_220_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_220_D.REMARKS is '备注';
comment on column MBT_PM_220_D.CHECK_FLAG is '校验标志';
comment on column MBT_PM_220_D.CHECK_DESC is '校验说明';
comment on column MBT_PM_220_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_220_D.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_220_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_220_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_220_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_220_D.DATA_FLAG is '数据标志';
comment on column MBT_PM_220_D.DATA_OP is '操作标志';
comment on column MBT_PM_220_D.DATA_SOURCE is '数据来源';
comment on column MBT_PM_220_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_220_D.DATA_HASH is '数据HASH';
comment on column MBT_PM_220_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_220_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_220_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_220_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_220_D.DATA_CRT_USER is '创建人';
comment on column MBT_PM_220_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_220_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_220_D.DATA_CHG_USER is '修改人';
comment on column MBT_PM_220_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_220_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_220_D.DATA_APV_USER is '审核人';
comment on column MBT_PM_220_D.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_220_D.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_220_D.RSV1 is '备用字段';
comment on column MBT_PM_220_D.RSV2 is '备用字段';
comment on column MBT_PM_220_D.RSV3 is '备用字段';
comment on column MBT_PM_220_D.RSV4 is '备用字段';
comment on column MBT_PM_220_D.RSV5 is '备用字段';
create table MBT_RPT_220 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_CONTRACT_CODE VARCHAR(60),
O_BIZ_CODE VARCHAR(60),
N_BIZ_CODE VARCHAR(60),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_220 is '个人授信协议信息';
comment on column MBT_RPT_220.DATA_ID is '数据ID';
comment on column MBT_RPT_220.DATA_DATE is '数据日期';
comment on column MBT_RPT_220.CORP_ID is '法人ID';
comment on column MBT_RPT_220.ORG_ID is '机构ID';
comment on column MBT_RPT_220.GROUP_ID is '数据分组';
comment on column MBT_RPT_220.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_220.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_220.B_CONTRACT_CODE is '授信协议标识码';
comment on column MBT_RPT_220.O_BIZ_CODE is '原业务标识码';
comment on column MBT_RPT_220.N_BIZ_CODE is '新业务标识码';
comment on column MBT_RPT_220.SECTION_CHG_CNT is '段变更';
comment on column MBT_RPT_220.SECTION_DEL_CNT is '段删除';
comment on column MBT_RPT_220.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_RPT_220.IDN_CHG_CNT is '标识项变更';
comment on column MBT_RPT_220.CUST_NO is '客户号';
comment on column MBT_RPT_220.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_220.PART_TYPE is '段标识';
comment on column MBT_RPT_220.PART_NAME is '段名称';
comment on column MBT_RPT_220.START_DATE is '起始日期';
comment on column MBT_RPT_220.END_DATE is '结束日期';
comment on column MBT_RPT_220.BATCH_NO is '批次号';
comment on column MBT_RPT_220.ROW_NUM is '行号';
comment on column MBT_RPT_220.IS_RPT is '是否报送';
comment on column MBT_RPT_220.IS_VALID is '是否有效';
comment on column MBT_RPT_220.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_220.OPT_FLAG is '操作标识';
comment on column MBT_RPT_220.RPT_DATE is '报送日期';
comment on column MBT_RPT_220.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_220.RPT_STATUS is '报送状态';
comment on column MBT_RPT_220.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_220.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_220.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_220.REMARKS is '备注';
comment on column MBT_RPT_220.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_220.CHECK_DESC is '校验说明';
comment on column MBT_RPT_220.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_220.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_220.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_220.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_220.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_220.DATA_FLAG is '数据标志';
comment on column MBT_RPT_220.DATA_OP is '操作标志';
comment on column MBT_RPT_220.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_220.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_220.DATA_HASH is '数据HASH';
comment on column MBT_RPT_220.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_220.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_220.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_220.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_220.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_220.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_220.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_220.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_220.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_220.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_220.DATA_APV_USER is '审核人';
comment on column MBT_RPT_220.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_220.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_220.RSV1 is '备用字段';
comment on column MBT_RPT_220.RSV2 is '备用字段';
comment on column MBT_RPT_220.RSV3 is '备用字段';
comment on column MBT_RPT_220.RSV4 is '备用字段';
comment on column MBT_RPT_220.RSV5 is '备用字段';
create table MBT_RPT_220_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_CONTRACT_CODE VARCHAR(60),
B_CONTRACT_NO VARCHAR(32),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(10),
B_INF_REC_TYPE VARCHAR(3),
B_MNGMT_ORG_CODE VARCHAR(14),
B_NAME VARCHAR(160),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_220_B is '个人授信协议信息-基础段';
comment on column MBT_RPT_220_B.DATA_ID is '数据ID';
comment on column MBT_RPT_220_B.DATA_DATE is '数据日期';
comment on column MBT_RPT_220_B.CORP_ID is '法人ID';
comment on column MBT_RPT_220_B.ORG_ID is '机构ID';
comment on column MBT_RPT_220_B.GROUP_ID is '数据分组';
comment on column MBT_RPT_220_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_220_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_220_B.B_CONTRACT_CODE is '授信协议标识码';
comment on column MBT_RPT_220_B.B_CONTRACT_NO is '授信协议编号';
comment on column MBT_RPT_220_B.B_ID_NUM is '受信人身份标识证件号码';
comment on column MBT_RPT_220_B.B_ID_TYPE is '受信人身份标识类型';
comment on column MBT_RPT_220_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_RPT_220_B.B_MNGMT_ORG_CODE is '业务管理机构代码';
comment on column MBT_RPT_220_B.B_NAME is '受信人名称';
comment on column MBT_RPT_220_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_220_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_RPT_220_B.CUST_NO is '客户号';
comment on column MBT_RPT_220_B.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_220_B.PART_TYPE is '段标识';
comment on column MBT_RPT_220_B.PART_NAME is '段名称';
comment on column MBT_RPT_220_B.START_DATE is '起始日期';
comment on column MBT_RPT_220_B.END_DATE is '结束日期';
comment on column MBT_RPT_220_B.BATCH_NO is '批次号';
comment on column MBT_RPT_220_B.ROW_NUM is '行号';
comment on column MBT_RPT_220_B.IS_RPT is '是否报送';
comment on column MBT_RPT_220_B.IS_VALID is '是否有效';
comment on column MBT_RPT_220_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_220_B.OPT_FLAG is '操作标识';
comment on column MBT_RPT_220_B.RPT_DATE is '报送日期';
comment on column MBT_RPT_220_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_220_B.RPT_STATUS is '报送状态';
comment on column MBT_RPT_220_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_220_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_220_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_220_B.REMARKS is '备注';
comment on column MBT_RPT_220_B.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_220_B.CHECK_DESC is '校验说明';
comment on column MBT_RPT_220_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_220_B.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_220_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_220_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_220_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_220_B.DATA_FLAG is '数据标志';
comment on column MBT_RPT_220_B.DATA_OP is '操作标志';
comment on column MBT_RPT_220_B.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_220_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_220_B.DATA_HASH is '数据HASH';
comment on column MBT_RPT_220_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_220_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_220_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_220_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_220_B.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_220_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_220_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_220_B.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_220_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_220_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_220_B.DATA_APV_USER is '审核人';
comment on column MBT_RPT_220_B.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_220_B.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_220_B.RSV1 is '备用字段';
comment on column MBT_RPT_220_B.RSV2 is '备用字段';
comment on column MBT_RPT_220_B.RSV3 is '备用字段';
comment on column MBT_RPT_220_B.RSV4 is '备用字段';
comment on column MBT_RPT_220_B.RSV5 is '备用字段';
create table MBT_RPT_220_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_BRER_TYPE VARCHAR(1),
C_CERT_REL_ID_NUM VARCHAR(40),
C_CERT_REL_ID_TYPE VARCHAR(2),
C_CERT_REL_NAME VARCHAR(160),
B_RPT_DATE VARCHAR(8),
B_CONTRACT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_220_C is '个人授信协议信息-共同受信人信息段';
comment on column MBT_RPT_220_C.DATA_ID is '数据ID';
comment on column MBT_RPT_220_C.DATA_DATE is '数据日期';
comment on column MBT_RPT_220_C.CORP_ID is '法人ID';
comment on column MBT_RPT_220_C.ORG_ID is '机构ID';
comment on column MBT_RPT_220_C.GROUP_ID is '数据分组';
comment on column MBT_RPT_220_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_220_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_220_C.C_BRER_TYPE is '共同受信人身份类别';
comment on column MBT_RPT_220_C.C_CERT_REL_ID_NUM is '共同受信人身份标识号码';
comment on column MBT_RPT_220_C.C_CERT_REL_ID_TYPE is '共同受信人身份标识类别';
comment on column MBT_RPT_220_C.C_CERT_REL_NAME is '共同受信人名称';
comment on column MBT_RPT_220_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_220_C.B_CONTRACT_CODE is '授信协议标识码';
comment on column MBT_RPT_220_C.CUST_NO is '客户号';
comment on column MBT_RPT_220_C.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_220_C.PART_TYPE is '段标识';
comment on column MBT_RPT_220_C.PART_NAME is '段名称';
comment on column MBT_RPT_220_C.START_DATE is '起始日期';
comment on column MBT_RPT_220_C.END_DATE is '结束日期';
comment on column MBT_RPT_220_C.BATCH_NO is '批次号';
comment on column MBT_RPT_220_C.ROW_NUM is '行号';
comment on column MBT_RPT_220_C.IS_RPT is '是否报送';
comment on column MBT_RPT_220_C.IS_VALID is '是否有效';
comment on column MBT_RPT_220_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_220_C.OPT_FLAG is '操作标识';
comment on column MBT_RPT_220_C.RPT_DATE is '报送日期';
comment on column MBT_RPT_220_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_220_C.RPT_STATUS is '报送状态';
comment on column MBT_RPT_220_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_220_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_220_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_220_C.REMARKS is '备注';
comment on column MBT_RPT_220_C.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_220_C.CHECK_DESC is '校验说明';
comment on column MBT_RPT_220_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_220_C.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_220_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_220_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_220_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_220_C.DATA_FLAG is '数据标志';
comment on column MBT_RPT_220_C.DATA_OP is '操作标志';
comment on column MBT_RPT_220_C.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_220_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_220_C.DATA_HASH is '数据HASH';
comment on column MBT_RPT_220_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_220_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_220_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_220_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_220_C.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_220_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_220_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_220_C.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_220_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_220_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_220_C.DATA_APV_USER is '审核人';
comment on column MBT_RPT_220_C.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_220_C.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_220_C.RSV1 is '备用字段';
comment on column MBT_RPT_220_C.RSV2 is '备用字段';
comment on column MBT_RPT_220_C.RSV3 is '备用字段';
comment on column MBT_RPT_220_C.RSV4 is '备用字段';
comment on column MBT_RPT_220_C.RSV5 is '备用字段';
create table MBT_RPT_220_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_CON_EFF_DATE VARCHAR(8),
D_CON_EXP_DATE VARCHAR(8),
D_CON_STATUS VARCHAR(2),
D_CREDIT_LIM NUMBER(15),
D_CREDIT_LIM_LCY NUMBER(15),
D_CREDIT_LIM_ORG NUMBER(15),
D_CREDIT_LIM_TYPE VARCHAR(2),
D_CREDIT_REST_CODE VARCHAR(60),
D_CREDIT_REST NUMBER(15),
D_CREDIT_REST_LCY NUMBER(15),
D_CREDIT_REST_ORG NUMBER(15),
C_CY VARCHAR(3),
D_LIM_LOOP_FLG VARCHAR(1),
B_RPT_DATE VARCHAR(8),
B_CONTRACT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_220_D is '个人授信协议信息-额度信息段';
comment on column MBT_RPT_220_D.DATA_ID is '数据ID';
comment on column MBT_RPT_220_D.DATA_DATE is '数据日期';
comment on column MBT_RPT_220_D.CORP_ID is '法人ID';
comment on column MBT_RPT_220_D.ORG_ID is '机构ID';
comment on column MBT_RPT_220_D.GROUP_ID is '数据分组';
comment on column MBT_RPT_220_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_220_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_220_D.D_CON_EFF_DATE is '额度生效日期';
comment on column MBT_RPT_220_D.D_CON_EXP_DATE is '额度到期日期';
comment on column MBT_RPT_220_D.D_CON_STATUS is '额度状态';
comment on column MBT_RPT_220_D.D_CREDIT_LIM is '授信额度';
comment on column MBT_RPT_220_D.D_CREDIT_LIM_LCY is '授信额度人民币金额';
comment on column MBT_RPT_220_D.D_CREDIT_LIM_ORG is '授信额度_原始数据金额';
comment on column MBT_RPT_220_D.D_CREDIT_LIM_TYPE is '授信额度类型';
comment on column MBT_RPT_220_D.D_CREDIT_REST_CODE is '授信限额编号';
comment on column MBT_RPT_220_D.D_CREDIT_REST is '授信限额';
comment on column MBT_RPT_220_D.D_CREDIT_REST_LCY is '授信限额人民币金额';
comment on column MBT_RPT_220_D.D_CREDIT_REST_ORG is '授信限额_原始数据金额';
comment on column MBT_RPT_220_D.C_CY is '币种';
comment on column MBT_RPT_220_D.D_LIM_LOOP_FLG is '额度循环标志';
comment on column MBT_RPT_220_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_220_D.B_CONTRACT_CODE is '授信协议标识码';
comment on column MBT_RPT_220_D.CUST_NO is '客户号';
comment on column MBT_RPT_220_D.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_220_D.PART_TYPE is '段标识';
comment on column MBT_RPT_220_D.PART_NAME is '段名称';
comment on column MBT_RPT_220_D.START_DATE is '起始日期';
comment on column MBT_RPT_220_D.END_DATE is '结束日期';
comment on column MBT_RPT_220_D.BATCH_NO is '批次号';
comment on column MBT_RPT_220_D.ROW_NUM is '行号';
comment on column MBT_RPT_220_D.IS_RPT is '是否报送';
comment on column MBT_RPT_220_D.IS_VALID is '是否有效';
comment on column MBT_RPT_220_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_220_D.OPT_FLAG is '操作标识';
comment on column MBT_RPT_220_D.RPT_DATE is '报送日期';
comment on column MBT_RPT_220_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_220_D.RPT_STATUS is '报送状态';
comment on column MBT_RPT_220_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_220_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_220_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_220_D.REMARKS is '备注';
comment on column MBT_RPT_220_D.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_220_D.CHECK_DESC is '校验说明';
comment on column MBT_RPT_220_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_220_D.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_220_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_220_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_220_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_220_D.DATA_FLAG is '数据标志';
comment on column MBT_RPT_220_D.DATA_OP is '操作标志';
comment on column MBT_RPT_220_D.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_220_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_220_D.DATA_HASH is '数据HASH';
comment on column MBT_RPT_220_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_220_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_220_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_220_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_220_D.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_220_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_220_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_220_D.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_220_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_220_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_220_D.DATA_APV_USER is '审核人';
comment on column MBT_RPT_220_D.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_220_D.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_220_D.RSV1 is '备用字段';
comment on column MBT_RPT_220_D.RSV2 is '备用字段';
comment on column MBT_RPT_220_D.RSV3 is '备用字段';
comment on column MBT_RPT_220_D.RSV4 is '备用字段';
comment on column MBT_RPT_220_D.RSV5 is '备用字段';
