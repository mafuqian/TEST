create table MBT_DM_630 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_630 is '企业现金流量表信息';
comment on column MBT_DM_630.DATA_ID is '数据ID';
comment on column MBT_DM_630.DATA_DATE is '数据日期';
comment on column MBT_DM_630.CORP_ID is '法人ID';
comment on column MBT_DM_630.ORG_ID is '机构ID';
comment on column MBT_DM_630.GROUP_ID is '数据分组';
comment on column MBT_DM_630.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_630.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_630.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_630.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_630.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_630.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_630.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_630.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_630.B_ENT_NAME is '企业名称';
comment on column MBT_DM_630.SECTION_CHG_CNT is '段变更';
comment on column MBT_DM_630.SECTION_DEL_CNT is '段删除';
comment on column MBT_DM_630.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_DM_630.IDN_CHG_CNT is '标识项变更';
comment on column MBT_DM_630.CUST_NO is '客户号';
comment on column MBT_DM_630.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_630.PART_TYPE is '段标识';
comment on column MBT_DM_630.PART_NAME is '段名称';
comment on column MBT_DM_630.START_DATE is '起始日期';
comment on column MBT_DM_630.END_DATE is '结束日期';
comment on column MBT_DM_630.BATCH_NO is '批次号';
comment on column MBT_DM_630.ROW_NUM is '行号';
comment on column MBT_DM_630.IS_RPT is '是否报送';
comment on column MBT_DM_630.IS_VALID is '是否有效';
comment on column MBT_DM_630.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_630.OPT_FLAG is '操作标识';
comment on column MBT_DM_630.RPT_DATE is '报送日期';
comment on column MBT_DM_630.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_630.RPT_STATUS is '报送状态';
comment on column MBT_DM_630.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_630.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_630.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_630.REMARKS is '备注';
comment on column MBT_DM_630.CHECK_FLAG is '校验标志';
comment on column MBT_DM_630.CHECK_DESC is '校验说明';
comment on column MBT_DM_630.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_630.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_630.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_630.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_630.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_630.DATA_FLAG is '数据标志';
comment on column MBT_DM_630.DATA_OP is '操作标志';
comment on column MBT_DM_630.DATA_SOURCE is '数据来源';
comment on column MBT_DM_630.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_630.DATA_HASH is '数据HASH';
comment on column MBT_DM_630.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_630.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_630.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_630.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_630.DATA_CRT_USER is '创建人';
comment on column MBT_DM_630.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_630.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_630.DATA_CHG_USER is '修改人';
comment on column MBT_DM_630.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_630.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_630.DATA_APV_USER is '审核人';
comment on column MBT_DM_630.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_630.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_630.RSV1 is '备用字段';
comment on column MBT_DM_630.RSV2 is '备用字段';
comment on column MBT_DM_630.RSV3 is '备用字段';
comment on column MBT_DM_630.RSV4 is '备用字段';
comment on column MBT_DM_630.RSV5 is '备用字段';
create table MBT_DM_630_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_630_B is '企业现金流量表信息-基础段';
comment on column MBT_DM_630_B.DATA_ID is '数据ID';
comment on column MBT_DM_630_B.DATA_DATE is '数据日期';
comment on column MBT_DM_630_B.CORP_ID is '法人ID';
comment on column MBT_DM_630_B.ORG_ID is '机构ID';
comment on column MBT_DM_630_B.GROUP_ID is '数据分组';
comment on column MBT_DM_630_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_630_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_630_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_630_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_630_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_630_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_630_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_630_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_630_B.B_ENT_NAME is '企业名称';
comment on column MBT_DM_630_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_DM_630_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_DM_630_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_DM_630_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_DM_630_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_DM_630_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_630_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_DM_630_B.CUST_NO is '客户号';
comment on column MBT_DM_630_B.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_630_B.PART_TYPE is '段标识';
comment on column MBT_DM_630_B.PART_NAME is '段名称';
comment on column MBT_DM_630_B.START_DATE is '起始日期';
comment on column MBT_DM_630_B.END_DATE is '结束日期';
comment on column MBT_DM_630_B.BATCH_NO is '批次号';
comment on column MBT_DM_630_B.ROW_NUM is '行号';
comment on column MBT_DM_630_B.IS_RPT is '是否报送';
comment on column MBT_DM_630_B.IS_VALID is '是否有效';
comment on column MBT_DM_630_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_630_B.OPT_FLAG is '操作标识';
comment on column MBT_DM_630_B.RPT_DATE is '报送日期';
comment on column MBT_DM_630_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_630_B.RPT_STATUS is '报送状态';
comment on column MBT_DM_630_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_630_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_630_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_630_B.REMARKS is '备注';
comment on column MBT_DM_630_B.CHECK_FLAG is '校验标志';
comment on column MBT_DM_630_B.CHECK_DESC is '校验说明';
comment on column MBT_DM_630_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_630_B.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_630_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_630_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_630_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_630_B.DATA_FLAG is '数据标志';
comment on column MBT_DM_630_B.DATA_OP is '操作标志';
comment on column MBT_DM_630_B.DATA_SOURCE is '数据来源';
comment on column MBT_DM_630_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_630_B.DATA_HASH is '数据HASH';
comment on column MBT_DM_630_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_630_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_630_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_630_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_630_B.DATA_CRT_USER is '创建人';
comment on column MBT_DM_630_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_630_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_630_B.DATA_CHG_USER is '修改人';
comment on column MBT_DM_630_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_630_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_630_B.DATA_APV_USER is '审核人';
comment on column MBT_DM_630_B.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_630_B.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_630_B.RSV1 is '备用字段';
comment on column MBT_DM_630_B.RSV2 is '备用字段';
comment on column MBT_DM_630_B.RSV3 is '备用字段';
comment on column MBT_DM_630_B.RSV4 is '备用字段';
comment on column MBT_DM_630_B.RSV5 is '备用字段';
create table MBT_DM_630_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ADDITION_ACCUED_EXPENSE NUMBER(17),
C_AMORTISATION_INTANGIBLE_ASS NUMBER(17),
C_CASH_AT_THE_BEGINNING_PERIOD NUMBER(17),
C_CASH_AT_THE_END_OF_PERIOD NUMBER(17),
C_CASH_EQUIVALENTS_END_PERIOD NUMBER(17),
C_CASH_FROM_BORROWINGS NUMBER(17),
C_CASH_PAID_BEHALF_EMPLOYEES NUMBER(17),
C_CASH_PAID_GOODS_SERVICES NUMBER(17),
C_CASH_PAYMENTS_D_D_PRO_I_EXP NUMBER(17),
C_CASH_PAYMENTS_INVESTMENTS NUMBER(17),
C_CASH_PAYMENTS_RELATED_O_ACT NUMBER(17),
C_CASH_PAYMENTS_REL_O_FIN_AC NUMBER(17),
C_CASH_P_A_F_ASS_I_ASS_OLT_ASS NUMBER(17),
C_CASH_RECEIVED_FROM_INVESTORS NUMBER(17),
C_CASH_RECEIVED_ONVESTMENTS NUMBER(17),
C_CASH_RECEIVED_REL_OTHER_ACT NUMBER(17),
C_CASH_REC_RETURN_INVESTMENT NUMBER(17),
C_CASH_REC_SALES_GOODS_REN_SER NUMBER(17),
C_CASH_REPAYMENTS_FOR_DEBTS NUMBER(17),
C_CASH_RQUIVALENTS_BEGIN_PERIO NUMBER(17),
C_DEBTS_TRANSFER_TO_CAPITAL NUMBER(17),
C_DECREASE_DEFFERED_EXPENSES NUMBER(17),
C_DECREASE_IN_INVENTORIES NUMBER(17),
C_DECREASE_OPERATING_RECEIVABL NUMBER(17),
C_DEFERRED_TAX_CREDIT NUMBER(17),
C_DEPRECIATION_FIXED_ASSETS NUMBER(17),
C_EFFECT_EX_RATE_CHANGES_CASH NUMBER(17),
C_FINANCE_EXPENSE NUMBER(17),
C_FINANCING_RENT_THE_FIXED_ASS NUMBER(17),
C_INCREASE_OPERATING_RECEIVABL NUMBER(17),
C_LONG_TERM_DEFERRED_EXP_AMOR NUMBER(17),
C_LOSSES_ARSING_INVESTMENT NUMBER(17),
C_LOSSES_D_F_ASS_I_ASS_OLT_ASS NUMBER(17),
C_LOSSES_SCRAPPING_FIXED_ASS NUMBER(17),
C_NET_CASH_FLOWS_FINANCING_AC NUMBER(17),
C_NET_CASH_FLOWS_INVESTING_ACT NUMBER(17),
C_NET_CASH_FLOWS_OPERAT_ACT NUMBER(17),
C_NET_CASH_FLOWS_OPERA_ACT_MI NUMBER(17),
C_NET_CASH_REC_D_F_A_I_A_O_LT NUMBER(17),
C_NET_INCREASE_CASH_CASH_EQU_M NUMBER(17),
C_NET_INC_CASH_CASH_EQUIVALENT NUMBER(17),
C_NET_PROFIT NUMBER(17),
C_NON_CASH_OTHERS NUMBER(17),
C_ONE_YEAR_DUE_CONVERTIBLE_BO NUMBER(17),
C_ONE_YEAR_DUE_CONVERTIBLE_BON NUMBER(17),
C_OTHERS NUMBER(17),
C_OTHER_CASH_PAYMENTS_OPERA_AC NUMBER(17),
C_OTHER_CASH_REC_REL_FIN_ACT NUMBER(17),
C_OTHER_CASH_REC_REL_OPERA_ACT NUMBER(17),
C_PAYMENTS_OF_ALL_TYPES_TAXES NUMBER(17),
C_PROVISION_FOR_ASSETS NUMBER(17),
C_TAX_REFUNDS NUMBER(17),
C_TOTAL_CASH_INFLOWS_OPERA_ACT NUMBER(17),
C_TOTAL_CASH_INF_FINANCING_ACT NUMBER(17),
C_TOTAL_CASH_INF_INVESTING_ACT NUMBER(17),
C_TOTAL_CASH_OUTFLOWS_FIN_AC NUMBER(17),
C_TOTAL_CASH_OUTFLOWS_INV_ACT NUMBER(17),
C_TOTAL_CASH_OUTFLOWS_OPERA_AC NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_630_C is '企业现金流量表信息-2002版现金流量表段';
comment on column MBT_DM_630_C.DATA_ID is '数据ID';
comment on column MBT_DM_630_C.DATA_DATE is '数据日期';
comment on column MBT_DM_630_C.CORP_ID is '法人ID';
comment on column MBT_DM_630_C.ORG_ID is '机构ID';
comment on column MBT_DM_630_C.GROUP_ID is '数据分组';
comment on column MBT_DM_630_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_630_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_630_C.C_ADDITION_ACCUED_EXPENSE is '预提费用增加';
comment on column MBT_DM_630_C.C_AMORTISATION_INTANGIBLE_ASS is '无形资产摊销';
comment on column MBT_DM_630_C.C_CASH_AT_THE_BEGINNING_PERIOD is '现金的期初余额';
comment on column MBT_DM_630_C.C_CASH_AT_THE_END_OF_PERIOD is '现金的期末余额';
comment on column MBT_DM_630_C.C_CASH_EQUIVALENTS_END_PERIOD is '现金等价物的期末余额';
comment on column MBT_DM_630_C.C_CASH_FROM_BORROWINGS is '借款所收到的现金';
comment on column MBT_DM_630_C.C_CASH_PAID_BEHALF_EMPLOYEES is '支付给职工以及为职工支付的现金';
comment on column MBT_DM_630_C.C_CASH_PAID_GOODS_SERVICES is '购买商品、接受劳务支付的现金';
comment on column MBT_DM_630_C.C_CASH_PAYMENTS_D_D_PRO_I_EXP is '分配股利、利润或偿付利息所支付的现金';
comment on column MBT_DM_630_C.C_CASH_PAYMENTS_INVESTMENTS is '投资所支付的现金';
comment on column MBT_DM_630_C.C_CASH_PAYMENTS_RELATED_O_ACT is '支付的其他与投资活动有关现金';
comment on column MBT_DM_630_C.C_CASH_PAYMENTS_REL_O_FIN_AC is '支付的其他与筹资活动有关现金';
comment on column MBT_DM_630_C.C_CASH_P_A_F_ASS_I_ASS_OLT_ASS is '购建固定资产无形资产和其他长期资产所支付的现金';
comment on column MBT_DM_630_C.C_CASH_RECEIVED_FROM_INVESTORS is '吸收投资所收到的现金';
comment on column MBT_DM_630_C.C_CASH_RECEIVED_ONVESTMENTS is '取得投资收益所收到的现金';
comment on column MBT_DM_630_C.C_CASH_RECEIVED_REL_OTHER_ACT is '收到的其他与投资活动有关的现金';
comment on column MBT_DM_630_C.C_CASH_REC_RETURN_INVESTMENT is '收回投资所收到的现金';
comment on column MBT_DM_630_C.C_CASH_REC_SALES_GOODS_REN_SER is '销售商品和提供劳务收到的现金';
comment on column MBT_DM_630_C.C_CASH_REPAYMENTS_FOR_DEBTS is '偿还债务所支付的现金';
comment on column MBT_DM_630_C.C_CASH_RQUIVALENTS_BEGIN_PERIO is '现金等价物的期初余额';
comment on column MBT_DM_630_C.C_DEBTS_TRANSFER_TO_CAPITAL is '债务转为资本';
comment on column MBT_DM_630_C.C_DECREASE_DEFFERED_EXPENSES is '待摊费用减少';
comment on column MBT_DM_630_C.C_DECREASE_IN_INVENTORIES is '存货的减少';
comment on column MBT_DM_630_C.C_DECREASE_OPERATING_RECEIVABL is '经营性应收项目的减少';
comment on column MBT_DM_630_C.C_DEFERRED_TAX_CREDIT is '递延税款贷项';
comment on column MBT_DM_630_C.C_DEPRECIATION_FIXED_ASSETS is '固定资产拆旧';
comment on column MBT_DM_630_C.C_EFFECT_EX_RATE_CHANGES_CASH is '汇率变动对现金的影响';
comment on column MBT_DM_630_C.C_FINANCE_EXPENSE is '财务费用';
comment on column MBT_DM_630_C.C_FINANCING_RENT_THE_FIXED_ASS is '融资租入固定产';
comment on column MBT_DM_630_C.C_INCREASE_OPERATING_RECEIVABL is '经营性应付项目的增加';
comment on column MBT_DM_630_C.C_LONG_TERM_DEFERRED_EXP_AMOR is '长期待摊费用销';
comment on column MBT_DM_630_C.C_LOSSES_ARSING_INVESTMENT is '投资损失';
comment on column MBT_DM_630_C.C_LOSSES_D_F_ASS_I_ASS_OLT_ASS is '处置固定资产无形和其他长期的损失';
comment on column MBT_DM_630_C.C_LOSSES_SCRAPPING_FIXED_ASS is '固定资产报废损失';
comment on column MBT_DM_630_C.C_NET_CASH_FLOWS_FINANCING_AC is '筹集活动产生的现金流量净额';
comment on column MBT_DM_630_C.C_NET_CASH_FLOWS_INVESTING_ACT is '投资活动产生的现金流量净额';
comment on column MBT_DM_630_C.C_NET_CASH_FLOWS_OPERAT_ACT is '经营活动产生的现金流量净额';
comment on column MBT_DM_630_C.C_NET_CASH_FLOWS_OPERA_ACT_MI is '经营活动产生的现金流量净额';
comment on column MBT_DM_630_C.C_NET_CASH_REC_D_F_A_I_A_O_LT is '处置固定资产无形资产和其他长期所收回的现金净额';
comment on column MBT_DM_630_C.C_NET_INCREASE_CASH_CASH_EQU_M is '现金及现等价物净增加额';
comment on column MBT_DM_630_C.C_NET_INC_CASH_CASH_EQUIVALENT is '现金及现金等价物净增加额';
comment on column MBT_DM_630_C.C_NET_PROFIT is '净利润';
comment on column MBT_DM_630_C.C_NON_CASH_OTHERS is '（不涉及现金收支的投资和筹活动科目下）其他';
comment on column MBT_DM_630_C.C_ONE_YEAR_DUE_CONVERTIBLE_BO is '一年内到期的可转换公司债券';
comment on column MBT_DM_630_C.C_ONE_YEAR_DUE_CONVERTIBLE_BON is '一年内到期的可转换公司债券';
comment on column MBT_DM_630_C.C_OTHERS is '（净利润调节为经营活动现金流量科目下）其他';
comment on column MBT_DM_630_C.C_OTHER_CASH_PAYMENTS_OPERA_AC is '支付的其他与经营活动有关的现金';
comment on column MBT_DM_630_C.C_OTHER_CASH_REC_REL_FIN_ACT is '收到的其他与筹资活动有关的现金';
comment on column MBT_DM_630_C.C_OTHER_CASH_REC_REL_OPERA_ACT is '收到的其他与经营活动有关的现金';
comment on column MBT_DM_630_C.C_PAYMENTS_OF_ALL_TYPES_TAXES is '支付的各项税费';
comment on column MBT_DM_630_C.C_PROVISION_FOR_ASSETS is '计提的资产减值准备';
comment on column MBT_DM_630_C.C_TAX_REFUNDS is '收到的税费返还';
comment on column MBT_DM_630_C.C_TOTAL_CASH_INFLOWS_OPERA_ACT is '经营活动现金流入小计';
comment on column MBT_DM_630_C.C_TOTAL_CASH_INF_FINANCING_ACT is '筹资活动现金流入小计';
comment on column MBT_DM_630_C.C_TOTAL_CASH_INF_INVESTING_ACT is '投资活动现金流入小计';
comment on column MBT_DM_630_C.C_TOTAL_CASH_OUTFLOWS_FIN_AC is '筹资活动现金流出小计';
comment on column MBT_DM_630_C.C_TOTAL_CASH_OUTFLOWS_INV_ACT is '投资活动现金流出小计';
comment on column MBT_DM_630_C.C_TOTAL_CASH_OUTFLOWS_OPERA_AC is '经营活动现金流出小计';
comment on column MBT_DM_630_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_630_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_630_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_630_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_630_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_630_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_630_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_630_C.CUST_NO is '客户号';
comment on column MBT_DM_630_C.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_630_C.PART_TYPE is '段标识';
comment on column MBT_DM_630_C.PART_NAME is '段名称';
comment on column MBT_DM_630_C.START_DATE is '起始日期';
comment on column MBT_DM_630_C.END_DATE is '结束日期';
comment on column MBT_DM_630_C.BATCH_NO is '批次号';
comment on column MBT_DM_630_C.ROW_NUM is '行号';
comment on column MBT_DM_630_C.IS_RPT is '是否报送';
comment on column MBT_DM_630_C.IS_VALID is '是否有效';
comment on column MBT_DM_630_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_630_C.OPT_FLAG is '操作标识';
comment on column MBT_DM_630_C.RPT_DATE is '报送日期';
comment on column MBT_DM_630_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_630_C.RPT_STATUS is '报送状态';
comment on column MBT_DM_630_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_630_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_630_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_630_C.REMARKS is '备注';
comment on column MBT_DM_630_C.CHECK_FLAG is '校验标志';
comment on column MBT_DM_630_C.CHECK_DESC is '校验说明';
comment on column MBT_DM_630_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_630_C.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_630_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_630_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_630_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_630_C.DATA_FLAG is '数据标志';
comment on column MBT_DM_630_C.DATA_OP is '操作标志';
comment on column MBT_DM_630_C.DATA_SOURCE is '数据来源';
comment on column MBT_DM_630_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_630_C.DATA_HASH is '数据HASH';
comment on column MBT_DM_630_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_630_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_630_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_630_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_630_C.DATA_CRT_USER is '创建人';
comment on column MBT_DM_630_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_630_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_630_C.DATA_CHG_USER is '修改人';
comment on column MBT_DM_630_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_630_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_630_C.DATA_APV_USER is '审核人';
comment on column MBT_DM_630_C.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_630_C.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_630_C.RSV1 is '备用字段';
comment on column MBT_DM_630_C.RSV2 is '备用字段';
comment on column MBT_DM_630_C.RSV3 is '备用字段';
comment on column MBT_DM_630_C.RSV4 is '备用字段';
comment on column MBT_DM_630_C.RSV5 is '备用字段';
create table MBT_DM_630_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ADDITION_OF_ACCUED_EXPENSE NUMBER(17),
D_AMORTISATION_INTANGIBLE_ASS NUMBER(17),
D_AMORTISATION_LT_DEFFERED_EXP NUMBER(17),
D_CASH_AT_THE_BEGINNING_PERIOD NUMBER(17),
D_CASH_AT_THE_END_OF_PERIOD NUMBER(17),
D_CASH_EQUIVALENTS_AT_THE_PERI NUMBER(17),
D_CASH_FROM_BORROWINGS NUMBER(17),
D_CASH_PAID_ACQ_FASS_IASS_ASS NUMBER(17),
D_CASH_PAID_BEHALF_OF_EMPLOYEE NUMBER(17),
D_CASH_PAID_FOR_GOODS_SERVICES NUMBER(17),
D_CASH_PAYMENTS_D_DI_P_INT_EXP NUMBER(17),
D_CASH_PAYMENTS_INVESTMENTS NUMBER(17),
D_CASH_PAYMENTS_REL_O_F_ACT NUMBER(17),
D_CASH_PAYMENTS_REL_O_I_ACT NUMBER(17),
D_CASH_RECEIVED_INVESTORS NUMBER(17),
D_CASH_REC_ONVESTMENTS NUMBER(17),
D_CASH_REC_REL_OTHER_INVEST_AC NUMBER(17),
D_CASH_REC_RETURN_INVESTMENT NUMBER(17),
D_CASH_REC_SAL_GOO_REN_SERVICE NUMBER(17),
D_CASH_REPAYMENTS_FOR_DEBTS NUMBER(17),
D_CASH_RQUIVALENTS_BEGIN_PERIO NUMBER(17),
D_DEBTS_TRANSFER_TO_CAPITAL NUMBER(17),
D_DECREASE_DEFFERED_EXPENSES NUMBER(17),
D_DECREASE_IN_INVENTORIES NUMBER(17),
D_DECREASE_OPERATING_RECEIVABL NUMBER(17),
D_DEFERRED_INCOME_TAX_ASSETS NUMBER(17),
D_DEFERRED_INCOME_TAX_LIABILIT NUMBER(17),
D_DEPRECIATION_FIXED_ASSETS NUMBER(17),
D_EFFECT_EXC_RATE_CHANGES_CASH NUMBER(17),
D_FINANCE_EXPENSE NUMBER(17),
D_FINANCING_RENT_FIXED_ASSET NUMBER(17),
D_INCREASE_OPERATING_RECEIVABL NUMBER(17),
D_INITIAL_CASH_CASH_EQU_BALANC NUMBER(17),
D_LOSSES_ARSING_INVESTMENT NUMBER(17),
D_LOSSES_DISP_FASS_IASS_OLTASS NUMBER(17),
D_LOSSES_SCRAPPING_FIXED_ASS NUMBER(17),
D_NET_CASH_FLOWS_FINANCING_ACT NUMBER(17),
D_NET_CASH_FLOWS_INVEST_ACT NUMBER(17),
D_NET_CASH_FLOWS_OPERATING_ACT NUMBER(17),
D_NET_CASH_FLOWS_OPERAT_ACT_MI NUMBER(17),
D_NET_CASH_INF_DIS_SUB_O_B_ENT NUMBER(17),
D_NET_CASH_OUTF_PRO_SUB_OBUNIT NUMBER(17),
D_NET_CASH_R_DFASS_IASS_OLTASS NUMBER(17),
D_NET_INCREASE_CASH_EQUIVAL_MI NUMBER(17),
D_NET_INC_CASH_CASH_EQUIVALENT NUMBER(17),
D_NET_PROFIT NUMBER(17),
D_NON_CASH_OTHERS NUMBER(17),
D_ONE_YEAR_DUE_CONVER_BONDS NUMBER(17),
D_OTHERS NUMBER(17),
D_OTHER_CASH_PAYMENTS_OPERA_AC NUMBER(17),
D_OTHER_CASH_REC_REL_FINA_ACT NUMBER(17),
D_OTHER_CASH_REC_REL_OPERA_ACT NUMBER(17),
D_PAYMENTS_OF_ALL_TYPES_TAXES NUMBER(17),
D_PROFIT_LOSS_CHANGES_FAIR_VAL NUMBER(17),
D_PROVISION_ASSET_IMPAIRMENT NUMBER(17),
D_SUB_TOTAL_CASH_OUTFLOWS NUMBER(17),
D_TAX_REFUNDS NUMBER(17),
D_THE_FINAL_CASH_EQU_BALANCE NUMBER(17),
D_TOTAL_CASH_INFLOWS_FINA_ACT NUMBER(17),
D_TOTAL_CASH_INFLOWS_INVEST_AC NUMBER(17),
D_TOTAL_CASH_INFLOWS_OPERAT_AC NUMBER(17),
D_TOTAL_CASH_OUTFLOWS_FINA_ACT NUMBER(17),
D_TOTAL_CASH_OUTFLOWS_OPERA_AC NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_630_D is '企业现金流量表信息-2007版现金流量表段';
comment on column MBT_DM_630_D.DATA_ID is '数据ID';
comment on column MBT_DM_630_D.DATA_DATE is '数据日期';
comment on column MBT_DM_630_D.CORP_ID is '法人ID';
comment on column MBT_DM_630_D.ORG_ID is '机构ID';
comment on column MBT_DM_630_D.GROUP_ID is '数据分组';
comment on column MBT_DM_630_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_630_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_630_D.D_ADDITION_OF_ACCUED_EXPENSE is '预提费用增加';
comment on column MBT_DM_630_D.D_AMORTISATION_INTANGIBLE_ASS is '无形资产摊销';
comment on column MBT_DM_630_D.D_AMORTISATION_LT_DEFFERED_EXP is '长期待摊费用销';
comment on column MBT_DM_630_D.D_CASH_AT_THE_BEGINNING_PERIOD is '现金的期初余额';
comment on column MBT_DM_630_D.D_CASH_AT_THE_END_OF_PERIOD is '现金的期末余额';
comment on column MBT_DM_630_D.D_CASH_EQUIVALENTS_AT_THE_PERI is '现金等价物的期末余额';
comment on column MBT_DM_630_D.D_CASH_FROM_BORROWINGS is '取得借款收到的现金';
comment on column MBT_DM_630_D.D_CASH_PAID_ACQ_FASS_IASS_ASS is '购建固定资产无形资产和其他长期资产所支付的现金';
comment on column MBT_DM_630_D.D_CASH_PAID_BEHALF_OF_EMPLOYEE is '支付给职工以及为支付的现金';
comment on column MBT_DM_630_D.D_CASH_PAID_FOR_GOODS_SERVICES is '购买商品、接受劳务支付的现金';
comment on column MBT_DM_630_D.D_CASH_PAYMENTS_D_DI_P_INT_EXP is '分配股利、利润或偿付利息所支付的现金';
comment on column MBT_DM_630_D.D_CASH_PAYMENTS_INVESTMENTS is '投资所支付的现金投资所支付的现金';
comment on column MBT_DM_630_D.D_CASH_PAYMENTS_REL_O_F_ACT is '支付的其他与筹资活动有关现金';
comment on column MBT_DM_630_D.D_CASH_PAYMENTS_REL_O_I_ACT is '支付的其他与投资活动有关现金';
comment on column MBT_DM_630_D.D_CASH_RECEIVED_INVESTORS is '吸收投资所收到的现金';
comment on column MBT_DM_630_D.D_CASH_REC_ONVESTMENTS is '取得投资收益所收到的现金';
comment on column MBT_DM_630_D.D_CASH_REC_REL_OTHER_INVEST_AC is '收到的其他与投资活动有关的现金';
comment on column MBT_DM_630_D.D_CASH_REC_RETURN_INVESTMENT is '收回投资所收到的现金';
comment on column MBT_DM_630_D.D_CASH_REC_SAL_GOO_REN_SERVICE is '销售商品和提供劳务收到的现金';
comment on column MBT_DM_630_D.D_CASH_REPAYMENTS_FOR_DEBTS is '偿还债务所支付的现金';
comment on column MBT_DM_630_D.D_CASH_RQUIVALENTS_BEGIN_PERIO is '现金等价物的期初余额';
comment on column MBT_DM_630_D.D_DEBTS_TRANSFER_TO_CAPITAL is '债务转为资本';
comment on column MBT_DM_630_D.D_DECREASE_DEFFERED_EXPENSES is '待摊费用减少';
comment on column MBT_DM_630_D.D_DECREASE_IN_INVENTORIES is '存货的减少';
comment on column MBT_DM_630_D.D_DECREASE_OPERATING_RECEIVABL is '经营性应收项目的减少';
comment on column MBT_DM_630_D.D_DEFERRED_INCOME_TAX_ASSETS is '递延所得税资产减少';
comment on column MBT_DM_630_D.D_DEFERRED_INCOME_TAX_LIABILIT is '递延所得税负债增加';
comment on column MBT_DM_630_D.D_DEPRECIATION_FIXED_ASSETS is '固定资产折旧、油气资产折耗、生产性生物资产折旧';
comment on column MBT_DM_630_D.D_EFFECT_EXC_RATE_CHANGES_CASH is '汇率变动对现金的影响';
comment on column MBT_DM_630_D.D_FINANCE_EXPENSE is '财务费用';
comment on column MBT_DM_630_D.D_FINANCING_RENT_FIXED_ASSET is '融资租入固定产';
comment on column MBT_DM_630_D.D_INCREASE_OPERATING_RECEIVABL is '经营性应付项目的增加';
comment on column MBT_DM_630_D.D_INITIAL_CASH_CASH_EQU_BALANC is '期初现金及等价物余额';
comment on column MBT_DM_630_D.D_LOSSES_ARSING_INVESTMENT is '投资损失';
comment on column MBT_DM_630_D.D_LOSSES_DISP_FASS_IASS_OLTASS is '处置固定资产无形和其他长期的损失';
comment on column MBT_DM_630_D.D_LOSSES_SCRAPPING_FIXED_ASS is '固定资产报废损失';
comment on column MBT_DM_630_D.D_NET_CASH_FLOWS_FINANCING_ACT is '筹集活动产生的现金流量净额';
comment on column MBT_DM_630_D.D_NET_CASH_FLOWS_INVEST_ACT is '投资活动产生的现金流量净额';
comment on column MBT_DM_630_D.D_NET_CASH_FLOWS_OPERATING_ACT is '经营活动产生的现金流量净额';
comment on column MBT_DM_630_D.D_NET_CASH_FLOWS_OPERAT_ACT_MI is '经营活动产生的现金流量净额';
comment on column MBT_DM_630_D.D_NET_CASH_INF_DIS_SUB_O_B_ENT is '处置子公司及其他营业单位收到的现金净额';
comment on column MBT_DM_630_D.D_NET_CASH_OUTF_PRO_SUB_OBUNIT is '取得子公司及其他营业单位支付的现金净额';
comment on column MBT_DM_630_D.D_NET_CASH_R_DFASS_IASS_OLTASS is '处置固定资产无形资产和其他长期资产所收回的现金净额';
comment on column MBT_DM_630_D.D_NET_INCREASE_CASH_EQUIVAL_MI is '现金及现等价物净增加额';
comment on column MBT_DM_630_D.D_NET_INC_CASH_CASH_EQUIVALENT is '现金及现金等价物净增加额';
comment on column MBT_DM_630_D.D_NET_PROFIT is '净利润';
comment on column MBT_DM_630_D.D_NON_CASH_OTHERS is '（不涉及现金收支的投资和筹活动科目下）其他';
comment on column MBT_DM_630_D.D_ONE_YEAR_DUE_CONVER_BONDS is '一年内到期的可转换公司债券';
comment on column MBT_DM_630_D.D_OTHERS is '（净利润调节为经营活动现金流量科目下）其他';
comment on column MBT_DM_630_D.D_OTHER_CASH_PAYMENTS_OPERA_AC is '支付其他与经营活动有关的现金';
comment on column MBT_DM_630_D.D_OTHER_CASH_REC_REL_FINA_ACT is '收到的其他与筹资活动有关的现金';
comment on column MBT_DM_630_D.D_OTHER_CASH_REC_REL_OPERA_ACT is '收到的其他与经营活动有关的现金';
comment on column MBT_DM_630_D.D_PAYMENTS_OF_ALL_TYPES_TAXES is '支付的各项税费支付的各项税费';
comment on column MBT_DM_630_D.D_PROFIT_LOSS_CHANGES_FAIR_VAL is '公允价值变动损失';
comment on column MBT_DM_630_D.D_PROVISION_ASSET_IMPAIRMENT is '资产减值准备';
comment on column MBT_DM_630_D.D_SUB_TOTAL_CASH_OUTFLOWS is '投资活动现金流出小计';
comment on column MBT_DM_630_D.D_TAX_REFUNDS is '收到的税费返还';
comment on column MBT_DM_630_D.D_THE_FINAL_CASH_EQU_BALANCE is '期末现金及等价物余额';
comment on column MBT_DM_630_D.D_TOTAL_CASH_INFLOWS_FINA_ACT is '筹资活动现金流入小计';
comment on column MBT_DM_630_D.D_TOTAL_CASH_INFLOWS_INVEST_AC is '投资活动现金流入小计';
comment on column MBT_DM_630_D.D_TOTAL_CASH_INFLOWS_OPERAT_AC is '经营活动现金流入小计';
comment on column MBT_DM_630_D.D_TOTAL_CASH_OUTFLOWS_FINA_ACT is '筹资活动现金流出小计';
comment on column MBT_DM_630_D.D_TOTAL_CASH_OUTFLOWS_OPERA_AC is '经营活动现金流出小计';
comment on column MBT_DM_630_D.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_630_D.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_630_D.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_630_D.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_630_D.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_630_D.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_630_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_630_D.CUST_NO is '客户号';
comment on column MBT_DM_630_D.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_630_D.PART_TYPE is '段标识';
comment on column MBT_DM_630_D.PART_NAME is '段名称';
comment on column MBT_DM_630_D.START_DATE is '起始日期';
comment on column MBT_DM_630_D.END_DATE is '结束日期';
comment on column MBT_DM_630_D.BATCH_NO is '批次号';
comment on column MBT_DM_630_D.ROW_NUM is '行号';
comment on column MBT_DM_630_D.IS_RPT is '是否报送';
comment on column MBT_DM_630_D.IS_VALID is '是否有效';
comment on column MBT_DM_630_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_630_D.OPT_FLAG is '操作标识';
comment on column MBT_DM_630_D.RPT_DATE is '报送日期';
comment on column MBT_DM_630_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_630_D.RPT_STATUS is '报送状态';
comment on column MBT_DM_630_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_630_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_630_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_630_D.REMARKS is '备注';
comment on column MBT_DM_630_D.CHECK_FLAG is '校验标志';
comment on column MBT_DM_630_D.CHECK_DESC is '校验说明';
comment on column MBT_DM_630_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_630_D.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_630_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_630_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_630_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_630_D.DATA_FLAG is '数据标志';
comment on column MBT_DM_630_D.DATA_OP is '操作标志';
comment on column MBT_DM_630_D.DATA_SOURCE is '数据来源';
comment on column MBT_DM_630_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_630_D.DATA_HASH is '数据HASH';
comment on column MBT_DM_630_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_630_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_630_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_630_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_630_D.DATA_CRT_USER is '创建人';
comment on column MBT_DM_630_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_630_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_630_D.DATA_CHG_USER is '修改人';
comment on column MBT_DM_630_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_630_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_630_D.DATA_APV_USER is '审核人';
comment on column MBT_DM_630_D.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_630_D.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_630_D.RSV1 is '备用字段';
comment on column MBT_DM_630_D.RSV2 is '备用字段';
comment on column MBT_DM_630_D.RSV3 is '备用字段';
comment on column MBT_DM_630_D.RSV4 is '备用字段';
comment on column MBT_DM_630_D.RSV5 is '备用字段';
create table MBT_PM_630 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_630 is '企业现金流量表信息';
comment on column MBT_PM_630.DATA_ID is '数据ID';
comment on column MBT_PM_630.DATA_DATE is '数据日期';
comment on column MBT_PM_630.CORP_ID is '法人ID';
comment on column MBT_PM_630.ORG_ID is '机构ID';
comment on column MBT_PM_630.GROUP_ID is '数据分组';
comment on column MBT_PM_630.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_630.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_630.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_630.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_630.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_630.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_630.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_630.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_630.B_ENT_NAME is '企业名称';
comment on column MBT_PM_630.SECTION_CHG_CNT is '段变更';
comment on column MBT_PM_630.SECTION_DEL_CNT is '段删除';
comment on column MBT_PM_630.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_PM_630.IDN_CHG_CNT is '标识项变更';
comment on column MBT_PM_630.CUST_NO is '客户号';
comment on column MBT_PM_630.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_630.PART_TYPE is '段标识';
comment on column MBT_PM_630.PART_NAME is '段名称';
comment on column MBT_PM_630.START_DATE is '起始日期';
comment on column MBT_PM_630.END_DATE is '结束日期';
comment on column MBT_PM_630.BATCH_NO is '批次号';
comment on column MBT_PM_630.ROW_NUM is '行号';
comment on column MBT_PM_630.IS_RPT is '是否报送';
comment on column MBT_PM_630.IS_VALID is '是否有效';
comment on column MBT_PM_630.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_630.OPT_FLAG is '操作标识';
comment on column MBT_PM_630.RPT_DATE is '报送日期';
comment on column MBT_PM_630.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_630.RPT_STATUS is '报送状态';
comment on column MBT_PM_630.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_630.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_630.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_630.REMARKS is '备注';
comment on column MBT_PM_630.CHECK_FLAG is '校验标志';
comment on column MBT_PM_630.CHECK_DESC is '校验说明';
comment on column MBT_PM_630.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_630.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_630.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_630.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_630.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_630.DATA_FLAG is '数据标志';
comment on column MBT_PM_630.DATA_OP is '操作标志';
comment on column MBT_PM_630.DATA_SOURCE is '数据来源';
comment on column MBT_PM_630.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_630.DATA_HASH is '数据HASH';
comment on column MBT_PM_630.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_630.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_630.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_630.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_630.DATA_CRT_USER is '创建人';
comment on column MBT_PM_630.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_630.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_630.DATA_CHG_USER is '修改人';
comment on column MBT_PM_630.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_630.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_630.DATA_APV_USER is '审核人';
comment on column MBT_PM_630.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_630.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_630.RSV1 is '备用字段';
comment on column MBT_PM_630.RSV2 is '备用字段';
comment on column MBT_PM_630.RSV3 is '备用字段';
comment on column MBT_PM_630.RSV4 is '备用字段';
comment on column MBT_PM_630.RSV5 is '备用字段';
create table MBT_PM_630_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_630_B is '企业现金流量表信息-基础段';
comment on column MBT_PM_630_B.DATA_ID is '数据ID';
comment on column MBT_PM_630_B.DATA_DATE is '数据日期';
comment on column MBT_PM_630_B.CORP_ID is '法人ID';
comment on column MBT_PM_630_B.ORG_ID is '机构ID';
comment on column MBT_PM_630_B.GROUP_ID is '数据分组';
comment on column MBT_PM_630_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_630_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_630_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_630_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_630_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_630_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_630_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_630_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_630_B.B_ENT_NAME is '企业名称';
comment on column MBT_PM_630_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_PM_630_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_PM_630_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_PM_630_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_PM_630_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_PM_630_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_630_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_PM_630_B.CUST_NO is '客户号';
comment on column MBT_PM_630_B.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_630_B.PART_TYPE is '段标识';
comment on column MBT_PM_630_B.PART_NAME is '段名称';
comment on column MBT_PM_630_B.START_DATE is '起始日期';
comment on column MBT_PM_630_B.END_DATE is '结束日期';
comment on column MBT_PM_630_B.BATCH_NO is '批次号';
comment on column MBT_PM_630_B.ROW_NUM is '行号';
comment on column MBT_PM_630_B.IS_RPT is '是否报送';
comment on column MBT_PM_630_B.IS_VALID is '是否有效';
comment on column MBT_PM_630_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_630_B.OPT_FLAG is '操作标识';
comment on column MBT_PM_630_B.RPT_DATE is '报送日期';
comment on column MBT_PM_630_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_630_B.RPT_STATUS is '报送状态';
comment on column MBT_PM_630_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_630_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_630_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_630_B.REMARKS is '备注';
comment on column MBT_PM_630_B.CHECK_FLAG is '校验标志';
comment on column MBT_PM_630_B.CHECK_DESC is '校验说明';
comment on column MBT_PM_630_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_630_B.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_630_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_630_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_630_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_630_B.DATA_FLAG is '数据标志';
comment on column MBT_PM_630_B.DATA_OP is '操作标志';
comment on column MBT_PM_630_B.DATA_SOURCE is '数据来源';
comment on column MBT_PM_630_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_630_B.DATA_HASH is '数据HASH';
comment on column MBT_PM_630_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_630_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_630_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_630_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_630_B.DATA_CRT_USER is '创建人';
comment on column MBT_PM_630_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_630_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_630_B.DATA_CHG_USER is '修改人';
comment on column MBT_PM_630_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_630_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_630_B.DATA_APV_USER is '审核人';
comment on column MBT_PM_630_B.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_630_B.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_630_B.RSV1 is '备用字段';
comment on column MBT_PM_630_B.RSV2 is '备用字段';
comment on column MBT_PM_630_B.RSV3 is '备用字段';
comment on column MBT_PM_630_B.RSV4 is '备用字段';
comment on column MBT_PM_630_B.RSV5 is '备用字段';
create table MBT_PM_630_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ADDITION_ACCUED_EXPENSE NUMBER(17),
C_AMORTISATION_INTANGIBLE_ASS NUMBER(17),
C_CASH_AT_THE_BEGINNING_PERIOD NUMBER(17),
C_CASH_AT_THE_END_OF_PERIOD NUMBER(17),
C_CASH_EQUIVALENTS_END_PERIOD NUMBER(17),
C_CASH_FROM_BORROWINGS NUMBER(17),
C_CASH_PAID_BEHALF_EMPLOYEES NUMBER(17),
C_CASH_PAID_GOODS_SERVICES NUMBER(17),
C_CASH_PAYMENTS_D_D_PRO_I_EXP NUMBER(17),
C_CASH_PAYMENTS_INVESTMENTS NUMBER(17),
C_CASH_PAYMENTS_RELATED_O_ACT NUMBER(17),
C_CASH_PAYMENTS_REL_O_FIN_AC NUMBER(17),
C_CASH_P_A_F_ASS_I_ASS_OLT_ASS NUMBER(17),
C_CASH_RECEIVED_FROM_INVESTORS NUMBER(17),
C_CASH_RECEIVED_ONVESTMENTS NUMBER(17),
C_CASH_RECEIVED_REL_OTHER_ACT NUMBER(17),
C_CASH_REC_RETURN_INVESTMENT NUMBER(17),
C_CASH_REC_SALES_GOODS_REN_SER NUMBER(17),
C_CASH_REPAYMENTS_FOR_DEBTS NUMBER(17),
C_CASH_RQUIVALENTS_BEGIN_PERIO NUMBER(17),
C_DEBTS_TRANSFER_TO_CAPITAL NUMBER(17),
C_DECREASE_DEFFERED_EXPENSES NUMBER(17),
C_DECREASE_IN_INVENTORIES NUMBER(17),
C_DECREASE_OPERATING_RECEIVABL NUMBER(17),
C_DEFERRED_TAX_CREDIT NUMBER(17),
C_DEPRECIATION_FIXED_ASSETS NUMBER(17),
C_EFFECT_EX_RATE_CHANGES_CASH NUMBER(17),
C_FINANCE_EXPENSE NUMBER(17),
C_FINANCING_RENT_THE_FIXED_ASS NUMBER(17),
C_INCREASE_OPERATING_RECEIVABL NUMBER(17),
C_LONG_TERM_DEFERRED_EXP_AMOR NUMBER(17),
C_LOSSES_ARSING_INVESTMENT NUMBER(17),
C_LOSSES_D_F_ASS_I_ASS_OLT_ASS NUMBER(17),
C_LOSSES_SCRAPPING_FIXED_ASS NUMBER(17),
C_NET_CASH_FLOWS_FINANCING_AC NUMBER(17),
C_NET_CASH_FLOWS_INVESTING_ACT NUMBER(17),
C_NET_CASH_FLOWS_OPERAT_ACT NUMBER(17),
C_NET_CASH_FLOWS_OPERA_ACT_MI NUMBER(17),
C_NET_CASH_REC_D_F_A_I_A_O_LT NUMBER(17),
C_NET_INCREASE_CASH_CASH_EQU_M NUMBER(17),
C_NET_INC_CASH_CASH_EQUIVALENT NUMBER(17),
C_NET_PROFIT NUMBER(17),
C_NON_CASH_OTHERS NUMBER(17),
C_ONE_YEAR_DUE_CONVERTIBLE_BO NUMBER(17),
C_ONE_YEAR_DUE_CONVERTIBLE_BON NUMBER(17),
C_OTHERS NUMBER(17),
C_OTHER_CASH_PAYMENTS_OPERA_AC NUMBER(17),
C_OTHER_CASH_REC_REL_FIN_ACT NUMBER(17),
C_OTHER_CASH_REC_REL_OPERA_ACT NUMBER(17),
C_PAYMENTS_OF_ALL_TYPES_TAXES NUMBER(17),
C_PROVISION_FOR_ASSETS NUMBER(17),
C_TAX_REFUNDS NUMBER(17),
C_TOTAL_CASH_INFLOWS_OPERA_ACT NUMBER(17),
C_TOTAL_CASH_INF_FINANCING_ACT NUMBER(17),
C_TOTAL_CASH_INF_INVESTING_ACT NUMBER(17),
C_TOTAL_CASH_OUTFLOWS_FIN_AC NUMBER(17),
C_TOTAL_CASH_OUTFLOWS_INV_ACT NUMBER(17),
C_TOTAL_CASH_OUTFLOWS_OPERA_AC NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_630_C is '企业现金流量表信息-2002版现金流量表段';
comment on column MBT_PM_630_C.DATA_ID is '数据ID';
comment on column MBT_PM_630_C.DATA_DATE is '数据日期';
comment on column MBT_PM_630_C.CORP_ID is '法人ID';
comment on column MBT_PM_630_C.ORG_ID is '机构ID';
comment on column MBT_PM_630_C.GROUP_ID is '数据分组';
comment on column MBT_PM_630_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_630_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_630_C.C_ADDITION_ACCUED_EXPENSE is '预提费用增加';
comment on column MBT_PM_630_C.C_AMORTISATION_INTANGIBLE_ASS is '无形资产摊销';
comment on column MBT_PM_630_C.C_CASH_AT_THE_BEGINNING_PERIOD is '现金的期初余额';
comment on column MBT_PM_630_C.C_CASH_AT_THE_END_OF_PERIOD is '现金的期末余额';
comment on column MBT_PM_630_C.C_CASH_EQUIVALENTS_END_PERIOD is '现金等价物的期末余额';
comment on column MBT_PM_630_C.C_CASH_FROM_BORROWINGS is '借款所收到的现金';
comment on column MBT_PM_630_C.C_CASH_PAID_BEHALF_EMPLOYEES is '支付给职工以及为职工支付的现金';
comment on column MBT_PM_630_C.C_CASH_PAID_GOODS_SERVICES is '购买商品、接受劳务支付的现金';
comment on column MBT_PM_630_C.C_CASH_PAYMENTS_D_D_PRO_I_EXP is '分配股利、利润或偿付利息所支付的现金';
comment on column MBT_PM_630_C.C_CASH_PAYMENTS_INVESTMENTS is '投资所支付的现金';
comment on column MBT_PM_630_C.C_CASH_PAYMENTS_RELATED_O_ACT is '支付的其他与投资活动有关现金';
comment on column MBT_PM_630_C.C_CASH_PAYMENTS_REL_O_FIN_AC is '支付的其他与筹资活动有关现金';
comment on column MBT_PM_630_C.C_CASH_P_A_F_ASS_I_ASS_OLT_ASS is '购建固定资产无形资产和其他长期资产所支付的现金';
comment on column MBT_PM_630_C.C_CASH_RECEIVED_FROM_INVESTORS is '吸收投资所收到的现金';
comment on column MBT_PM_630_C.C_CASH_RECEIVED_ONVESTMENTS is '取得投资收益所收到的现金';
comment on column MBT_PM_630_C.C_CASH_RECEIVED_REL_OTHER_ACT is '收到的其他与投资活动有关的现金';
comment on column MBT_PM_630_C.C_CASH_REC_RETURN_INVESTMENT is '收回投资所收到的现金';
comment on column MBT_PM_630_C.C_CASH_REC_SALES_GOODS_REN_SER is '销售商品和提供劳务收到的现金';
comment on column MBT_PM_630_C.C_CASH_REPAYMENTS_FOR_DEBTS is '偿还债务所支付的现金';
comment on column MBT_PM_630_C.C_CASH_RQUIVALENTS_BEGIN_PERIO is '现金等价物的期初余额';
comment on column MBT_PM_630_C.C_DEBTS_TRANSFER_TO_CAPITAL is '债务转为资本';
comment on column MBT_PM_630_C.C_DECREASE_DEFFERED_EXPENSES is '待摊费用减少';
comment on column MBT_PM_630_C.C_DECREASE_IN_INVENTORIES is '存货的减少';
comment on column MBT_PM_630_C.C_DECREASE_OPERATING_RECEIVABL is '经营性应收项目的减少';
comment on column MBT_PM_630_C.C_DEFERRED_TAX_CREDIT is '递延税款贷项';
comment on column MBT_PM_630_C.C_DEPRECIATION_FIXED_ASSETS is '固定资产拆旧';
comment on column MBT_PM_630_C.C_EFFECT_EX_RATE_CHANGES_CASH is '汇率变动对现金的影响';
comment on column MBT_PM_630_C.C_FINANCE_EXPENSE is '财务费用';
comment on column MBT_PM_630_C.C_FINANCING_RENT_THE_FIXED_ASS is '融资租入固定产';
comment on column MBT_PM_630_C.C_INCREASE_OPERATING_RECEIVABL is '经营性应付项目的增加';
comment on column MBT_PM_630_C.C_LONG_TERM_DEFERRED_EXP_AMOR is '长期待摊费用销';
comment on column MBT_PM_630_C.C_LOSSES_ARSING_INVESTMENT is '投资损失';
comment on column MBT_PM_630_C.C_LOSSES_D_F_ASS_I_ASS_OLT_ASS is '处置固定资产无形和其他长期的损失';
comment on column MBT_PM_630_C.C_LOSSES_SCRAPPING_FIXED_ASS is '固定资产报废损失';
comment on column MBT_PM_630_C.C_NET_CASH_FLOWS_FINANCING_AC is '筹集活动产生的现金流量净额';
comment on column MBT_PM_630_C.C_NET_CASH_FLOWS_INVESTING_ACT is '投资活动产生的现金流量净额';
comment on column MBT_PM_630_C.C_NET_CASH_FLOWS_OPERAT_ACT is '经营活动产生的现金流量净额';
comment on column MBT_PM_630_C.C_NET_CASH_FLOWS_OPERA_ACT_MI is '经营活动产生的现金流量净额';
comment on column MBT_PM_630_C.C_NET_CASH_REC_D_F_A_I_A_O_LT is '处置固定资产无形资产和其他长期所收回的现金净额';
comment on column MBT_PM_630_C.C_NET_INCREASE_CASH_CASH_EQU_M is '现金及现等价物净增加额';
comment on column MBT_PM_630_C.C_NET_INC_CASH_CASH_EQUIVALENT is '现金及现金等价物净增加额';
comment on column MBT_PM_630_C.C_NET_PROFIT is '净利润';
comment on column MBT_PM_630_C.C_NON_CASH_OTHERS is '（不涉及现金收支的投资和筹活动科目下）其他';
comment on column MBT_PM_630_C.C_ONE_YEAR_DUE_CONVERTIBLE_BO is '一年内到期的可转换公司债券';
comment on column MBT_PM_630_C.C_ONE_YEAR_DUE_CONVERTIBLE_BON is '一年内到期的可转换公司债券';
comment on column MBT_PM_630_C.C_OTHERS is '（净利润调节为经营活动现金流量科目下）其他';
comment on column MBT_PM_630_C.C_OTHER_CASH_PAYMENTS_OPERA_AC is '支付的其他与经营活动有关的现金';
comment on column MBT_PM_630_C.C_OTHER_CASH_REC_REL_FIN_ACT is '收到的其他与筹资活动有关的现金';
comment on column MBT_PM_630_C.C_OTHER_CASH_REC_REL_OPERA_ACT is '收到的其他与经营活动有关的现金';
comment on column MBT_PM_630_C.C_PAYMENTS_OF_ALL_TYPES_TAXES is '支付的各项税费';
comment on column MBT_PM_630_C.C_PROVISION_FOR_ASSETS is '计提的资产减值准备';
comment on column MBT_PM_630_C.C_TAX_REFUNDS is '收到的税费返还';
comment on column MBT_PM_630_C.C_TOTAL_CASH_INFLOWS_OPERA_ACT is '经营活动现金流入小计';
comment on column MBT_PM_630_C.C_TOTAL_CASH_INF_FINANCING_ACT is '筹资活动现金流入小计';
comment on column MBT_PM_630_C.C_TOTAL_CASH_INF_INVESTING_ACT is '投资活动现金流入小计';
comment on column MBT_PM_630_C.C_TOTAL_CASH_OUTFLOWS_FIN_AC is '筹资活动现金流出小计';
comment on column MBT_PM_630_C.C_TOTAL_CASH_OUTFLOWS_INV_ACT is '投资活动现金流出小计';
comment on column MBT_PM_630_C.C_TOTAL_CASH_OUTFLOWS_OPERA_AC is '经营活动现金流出小计';
comment on column MBT_PM_630_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_630_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_630_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_630_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_630_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_630_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_630_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_630_C.CUST_NO is '客户号';
comment on column MBT_PM_630_C.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_630_C.PART_TYPE is '段标识';
comment on column MBT_PM_630_C.PART_NAME is '段名称';
comment on column MBT_PM_630_C.START_DATE is '起始日期';
comment on column MBT_PM_630_C.END_DATE is '结束日期';
comment on column MBT_PM_630_C.BATCH_NO is '批次号';
comment on column MBT_PM_630_C.ROW_NUM is '行号';
comment on column MBT_PM_630_C.IS_RPT is '是否报送';
comment on column MBT_PM_630_C.IS_VALID is '是否有效';
comment on column MBT_PM_630_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_630_C.OPT_FLAG is '操作标识';
comment on column MBT_PM_630_C.RPT_DATE is '报送日期';
comment on column MBT_PM_630_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_630_C.RPT_STATUS is '报送状态';
comment on column MBT_PM_630_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_630_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_630_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_630_C.REMARKS is '备注';
comment on column MBT_PM_630_C.CHECK_FLAG is '校验标志';
comment on column MBT_PM_630_C.CHECK_DESC is '校验说明';
comment on column MBT_PM_630_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_630_C.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_630_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_630_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_630_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_630_C.DATA_FLAG is '数据标志';
comment on column MBT_PM_630_C.DATA_OP is '操作标志';
comment on column MBT_PM_630_C.DATA_SOURCE is '数据来源';
comment on column MBT_PM_630_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_630_C.DATA_HASH is '数据HASH';
comment on column MBT_PM_630_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_630_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_630_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_630_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_630_C.DATA_CRT_USER is '创建人';
comment on column MBT_PM_630_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_630_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_630_C.DATA_CHG_USER is '修改人';
comment on column MBT_PM_630_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_630_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_630_C.DATA_APV_USER is '审核人';
comment on column MBT_PM_630_C.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_630_C.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_630_C.RSV1 is '备用字段';
comment on column MBT_PM_630_C.RSV2 is '备用字段';
comment on column MBT_PM_630_C.RSV3 is '备用字段';
comment on column MBT_PM_630_C.RSV4 is '备用字段';
comment on column MBT_PM_630_C.RSV5 is '备用字段';
create table MBT_PM_630_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ADDITION_OF_ACCUED_EXPENSE NUMBER(17),
D_AMORTISATION_INTANGIBLE_ASS NUMBER(17),
D_AMORTISATION_LT_DEFFERED_EXP NUMBER(17),
D_CASH_AT_THE_BEGINNING_PERIOD NUMBER(17),
D_CASH_AT_THE_END_OF_PERIOD NUMBER(17),
D_CASH_EQUIVALENTS_AT_THE_PERI NUMBER(17),
D_CASH_FROM_BORROWINGS NUMBER(17),
D_CASH_PAID_ACQ_FASS_IASS_ASS NUMBER(17),
D_CASH_PAID_BEHALF_OF_EMPLOYEE NUMBER(17),
D_CASH_PAID_FOR_GOODS_SERVICES NUMBER(17),
D_CASH_PAYMENTS_D_DI_P_INT_EXP NUMBER(17),
D_CASH_PAYMENTS_INVESTMENTS NUMBER(17),
D_CASH_PAYMENTS_REL_O_F_ACT NUMBER(17),
D_CASH_PAYMENTS_REL_O_I_ACT NUMBER(17),
D_CASH_RECEIVED_INVESTORS NUMBER(17),
D_CASH_REC_ONVESTMENTS NUMBER(17),
D_CASH_REC_REL_OTHER_INVEST_AC NUMBER(17),
D_CASH_REC_RETURN_INVESTMENT NUMBER(17),
D_CASH_REC_SAL_GOO_REN_SERVICE NUMBER(17),
D_CASH_REPAYMENTS_FOR_DEBTS NUMBER(17),
D_CASH_RQUIVALENTS_BEGIN_PERIO NUMBER(17),
D_DEBTS_TRANSFER_TO_CAPITAL NUMBER(17),
D_DECREASE_DEFFERED_EXPENSES NUMBER(17),
D_DECREASE_IN_INVENTORIES NUMBER(17),
D_DECREASE_OPERATING_RECEIVABL NUMBER(17),
D_DEFERRED_INCOME_TAX_ASSETS NUMBER(17),
D_DEFERRED_INCOME_TAX_LIABILIT NUMBER(17),
D_DEPRECIATION_FIXED_ASSETS NUMBER(17),
D_EFFECT_EXC_RATE_CHANGES_CASH NUMBER(17),
D_FINANCE_EXPENSE NUMBER(17),
D_FINANCING_RENT_FIXED_ASSET NUMBER(17),
D_INCREASE_OPERATING_RECEIVABL NUMBER(17),
D_INITIAL_CASH_CASH_EQU_BALANC NUMBER(17),
D_LOSSES_ARSING_INVESTMENT NUMBER(17),
D_LOSSES_DISP_FASS_IASS_OLTASS NUMBER(17),
D_LOSSES_SCRAPPING_FIXED_ASS NUMBER(17),
D_NET_CASH_FLOWS_FINANCING_ACT NUMBER(17),
D_NET_CASH_FLOWS_INVEST_ACT NUMBER(17),
D_NET_CASH_FLOWS_OPERATING_ACT NUMBER(17),
D_NET_CASH_FLOWS_OPERAT_ACT_MI NUMBER(17),
D_NET_CASH_INF_DIS_SUB_O_B_ENT NUMBER(17),
D_NET_CASH_OUTF_PRO_SUB_OBUNIT NUMBER(17),
D_NET_CASH_R_DFASS_IASS_OLTASS NUMBER(17),
D_NET_INCREASE_CASH_EQUIVAL_MI NUMBER(17),
D_NET_INC_CASH_CASH_EQUIVALENT NUMBER(17),
D_NET_PROFIT NUMBER(17),
D_NON_CASH_OTHERS NUMBER(17),
D_ONE_YEAR_DUE_CONVER_BONDS NUMBER(17),
D_OTHERS NUMBER(17),
D_OTHER_CASH_PAYMENTS_OPERA_AC NUMBER(17),
D_OTHER_CASH_REC_REL_FINA_ACT NUMBER(17),
D_OTHER_CASH_REC_REL_OPERA_ACT NUMBER(17),
D_PAYMENTS_OF_ALL_TYPES_TAXES NUMBER(17),
D_PROFIT_LOSS_CHANGES_FAIR_VAL NUMBER(17),
D_PROVISION_ASSET_IMPAIRMENT NUMBER(17),
D_SUB_TOTAL_CASH_OUTFLOWS NUMBER(17),
D_TAX_REFUNDS NUMBER(17),
D_THE_FINAL_CASH_EQU_BALANCE NUMBER(17),
D_TOTAL_CASH_INFLOWS_FINA_ACT NUMBER(17),
D_TOTAL_CASH_INFLOWS_INVEST_AC NUMBER(17),
D_TOTAL_CASH_INFLOWS_OPERAT_AC NUMBER(17),
D_TOTAL_CASH_OUTFLOWS_FINA_ACT NUMBER(17),
D_TOTAL_CASH_OUTFLOWS_OPERA_AC NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_630_D is '企业现金流量表信息-2007版现金流量表段';
comment on column MBT_PM_630_D.DATA_ID is '数据ID';
comment on column MBT_PM_630_D.DATA_DATE is '数据日期';
comment on column MBT_PM_630_D.CORP_ID is '法人ID';
comment on column MBT_PM_630_D.ORG_ID is '机构ID';
comment on column MBT_PM_630_D.GROUP_ID is '数据分组';
comment on column MBT_PM_630_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_630_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_630_D.D_ADDITION_OF_ACCUED_EXPENSE is '预提费用增加';
comment on column MBT_PM_630_D.D_AMORTISATION_INTANGIBLE_ASS is '无形资产摊销';
comment on column MBT_PM_630_D.D_AMORTISATION_LT_DEFFERED_EXP is '长期待摊费用销';
comment on column MBT_PM_630_D.D_CASH_AT_THE_BEGINNING_PERIOD is '现金的期初余额';
comment on column MBT_PM_630_D.D_CASH_AT_THE_END_OF_PERIOD is '现金的期末余额';
comment on column MBT_PM_630_D.D_CASH_EQUIVALENTS_AT_THE_PERI is '现金等价物的期末余额';
comment on column MBT_PM_630_D.D_CASH_FROM_BORROWINGS is '取得借款收到的现金';
comment on column MBT_PM_630_D.D_CASH_PAID_ACQ_FASS_IASS_ASS is '购建固定资产无形资产和其他长期资产所支付的现金';
comment on column MBT_PM_630_D.D_CASH_PAID_BEHALF_OF_EMPLOYEE is '支付给职工以及为支付的现金';
comment on column MBT_PM_630_D.D_CASH_PAID_FOR_GOODS_SERVICES is '购买商品、接受劳务支付的现金';
comment on column MBT_PM_630_D.D_CASH_PAYMENTS_D_DI_P_INT_EXP is '分配股利、利润或偿付利息所支付的现金';
comment on column MBT_PM_630_D.D_CASH_PAYMENTS_INVESTMENTS is '投资所支付的现金投资所支付的现金';
comment on column MBT_PM_630_D.D_CASH_PAYMENTS_REL_O_F_ACT is '支付的其他与筹资活动有关现金';
comment on column MBT_PM_630_D.D_CASH_PAYMENTS_REL_O_I_ACT is '支付的其他与投资活动有关现金';
comment on column MBT_PM_630_D.D_CASH_RECEIVED_INVESTORS is '吸收投资所收到的现金';
comment on column MBT_PM_630_D.D_CASH_REC_ONVESTMENTS is '取得投资收益所收到的现金';
comment on column MBT_PM_630_D.D_CASH_REC_REL_OTHER_INVEST_AC is '收到的其他与投资活动有关的现金';
comment on column MBT_PM_630_D.D_CASH_REC_RETURN_INVESTMENT is '收回投资所收到的现金';
comment on column MBT_PM_630_D.D_CASH_REC_SAL_GOO_REN_SERVICE is '销售商品和提供劳务收到的现金';
comment on column MBT_PM_630_D.D_CASH_REPAYMENTS_FOR_DEBTS is '偿还债务所支付的现金';
comment on column MBT_PM_630_D.D_CASH_RQUIVALENTS_BEGIN_PERIO is '现金等价物的期初余额';
comment on column MBT_PM_630_D.D_DEBTS_TRANSFER_TO_CAPITAL is '债务转为资本';
comment on column MBT_PM_630_D.D_DECREASE_DEFFERED_EXPENSES is '待摊费用减少';
comment on column MBT_PM_630_D.D_DECREASE_IN_INVENTORIES is '存货的减少';
comment on column MBT_PM_630_D.D_DECREASE_OPERATING_RECEIVABL is '经营性应收项目的减少';
comment on column MBT_PM_630_D.D_DEFERRED_INCOME_TAX_ASSETS is '递延所得税资产减少';
comment on column MBT_PM_630_D.D_DEFERRED_INCOME_TAX_LIABILIT is '递延所得税负债增加';
comment on column MBT_PM_630_D.D_DEPRECIATION_FIXED_ASSETS is '固定资产折旧、油气资产折耗、生产性生物资产折旧';
comment on column MBT_PM_630_D.D_EFFECT_EXC_RATE_CHANGES_CASH is '汇率变动对现金的影响';
comment on column MBT_PM_630_D.D_FINANCE_EXPENSE is '财务费用';
comment on column MBT_PM_630_D.D_FINANCING_RENT_FIXED_ASSET is '融资租入固定产';
comment on column MBT_PM_630_D.D_INCREASE_OPERATING_RECEIVABL is '经营性应付项目的增加';
comment on column MBT_PM_630_D.D_INITIAL_CASH_CASH_EQU_BALANC is '期初现金及等价物余额';
comment on column MBT_PM_630_D.D_LOSSES_ARSING_INVESTMENT is '投资损失';
comment on column MBT_PM_630_D.D_LOSSES_DISP_FASS_IASS_OLTASS is '处置固定资产无形和其他长期的损失';
comment on column MBT_PM_630_D.D_LOSSES_SCRAPPING_FIXED_ASS is '固定资产报废损失';
comment on column MBT_PM_630_D.D_NET_CASH_FLOWS_FINANCING_ACT is '筹集活动产生的现金流量净额';
comment on column MBT_PM_630_D.D_NET_CASH_FLOWS_INVEST_ACT is '投资活动产生的现金流量净额';
comment on column MBT_PM_630_D.D_NET_CASH_FLOWS_OPERATING_ACT is '经营活动产生的现金流量净额';
comment on column MBT_PM_630_D.D_NET_CASH_FLOWS_OPERAT_ACT_MI is '经营活动产生的现金流量净额';
comment on column MBT_PM_630_D.D_NET_CASH_INF_DIS_SUB_O_B_ENT is '处置子公司及其他营业单位收到的现金净额';
comment on column MBT_PM_630_D.D_NET_CASH_OUTF_PRO_SUB_OBUNIT is '取得子公司及其他营业单位支付的现金净额';
comment on column MBT_PM_630_D.D_NET_CASH_R_DFASS_IASS_OLTASS is '处置固定资产无形资产和其他长期资产所收回的现金净额';
comment on column MBT_PM_630_D.D_NET_INCREASE_CASH_EQUIVAL_MI is '现金及现等价物净增加额';
comment on column MBT_PM_630_D.D_NET_INC_CASH_CASH_EQUIVALENT is '现金及现金等价物净增加额';
comment on column MBT_PM_630_D.D_NET_PROFIT is '净利润';
comment on column MBT_PM_630_D.D_NON_CASH_OTHERS is '（不涉及现金收支的投资和筹活动科目下）其他';
comment on column MBT_PM_630_D.D_ONE_YEAR_DUE_CONVER_BONDS is '一年内到期的可转换公司债券';
comment on column MBT_PM_630_D.D_OTHERS is '（净利润调节为经营活动现金流量科目下）其他';
comment on column MBT_PM_630_D.D_OTHER_CASH_PAYMENTS_OPERA_AC is '支付其他与经营活动有关的现金';
comment on column MBT_PM_630_D.D_OTHER_CASH_REC_REL_FINA_ACT is '收到的其他与筹资活动有关的现金';
comment on column MBT_PM_630_D.D_OTHER_CASH_REC_REL_OPERA_ACT is '收到的其他与经营活动有关的现金';
comment on column MBT_PM_630_D.D_PAYMENTS_OF_ALL_TYPES_TAXES is '支付的各项税费支付的各项税费';
comment on column MBT_PM_630_D.D_PROFIT_LOSS_CHANGES_FAIR_VAL is '公允价值变动损失';
comment on column MBT_PM_630_D.D_PROVISION_ASSET_IMPAIRMENT is '资产减值准备';
comment on column MBT_PM_630_D.D_SUB_TOTAL_CASH_OUTFLOWS is '投资活动现金流出小计';
comment on column MBT_PM_630_D.D_TAX_REFUNDS is '收到的税费返还';
comment on column MBT_PM_630_D.D_THE_FINAL_CASH_EQU_BALANCE is '期末现金及等价物余额';
comment on column MBT_PM_630_D.D_TOTAL_CASH_INFLOWS_FINA_ACT is '筹资活动现金流入小计';
comment on column MBT_PM_630_D.D_TOTAL_CASH_INFLOWS_INVEST_AC is '投资活动现金流入小计';
comment on column MBT_PM_630_D.D_TOTAL_CASH_INFLOWS_OPERAT_AC is '经营活动现金流入小计';
comment on column MBT_PM_630_D.D_TOTAL_CASH_OUTFLOWS_FINA_ACT is '筹资活动现金流出小计';
comment on column MBT_PM_630_D.D_TOTAL_CASH_OUTFLOWS_OPERA_AC is '经营活动现金流出小计';
comment on column MBT_PM_630_D.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_630_D.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_630_D.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_630_D.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_630_D.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_630_D.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_630_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_630_D.CUST_NO is '客户号';
comment on column MBT_PM_630_D.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_630_D.PART_TYPE is '段标识';
comment on column MBT_PM_630_D.PART_NAME is '段名称';
comment on column MBT_PM_630_D.START_DATE is '起始日期';
comment on column MBT_PM_630_D.END_DATE is '结束日期';
comment on column MBT_PM_630_D.BATCH_NO is '批次号';
comment on column MBT_PM_630_D.ROW_NUM is '行号';
comment on column MBT_PM_630_D.IS_RPT is '是否报送';
comment on column MBT_PM_630_D.IS_VALID is '是否有效';
comment on column MBT_PM_630_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_630_D.OPT_FLAG is '操作标识';
comment on column MBT_PM_630_D.RPT_DATE is '报送日期';
comment on column MBT_PM_630_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_630_D.RPT_STATUS is '报送状态';
comment on column MBT_PM_630_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_630_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_630_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_630_D.REMARKS is '备注';
comment on column MBT_PM_630_D.CHECK_FLAG is '校验标志';
comment on column MBT_PM_630_D.CHECK_DESC is '校验说明';
comment on column MBT_PM_630_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_630_D.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_630_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_630_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_630_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_630_D.DATA_FLAG is '数据标志';
comment on column MBT_PM_630_D.DATA_OP is '操作标志';
comment on column MBT_PM_630_D.DATA_SOURCE is '数据来源';
comment on column MBT_PM_630_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_630_D.DATA_HASH is '数据HASH';
comment on column MBT_PM_630_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_630_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_630_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_630_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_630_D.DATA_CRT_USER is '创建人';
comment on column MBT_PM_630_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_630_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_630_D.DATA_CHG_USER is '修改人';
comment on column MBT_PM_630_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_630_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_630_D.DATA_APV_USER is '审核人';
comment on column MBT_PM_630_D.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_630_D.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_630_D.RSV1 is '备用字段';
comment on column MBT_PM_630_D.RSV2 is '备用字段';
comment on column MBT_PM_630_D.RSV3 is '备用字段';
comment on column MBT_PM_630_D.RSV4 is '备用字段';
comment on column MBT_PM_630_D.RSV5 is '备用字段';
create table MBT_RPT_630 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_630 is '企业现金流量表信息';
comment on column MBT_RPT_630.DATA_ID is '数据ID';
comment on column MBT_RPT_630.DATA_DATE is '数据日期';
comment on column MBT_RPT_630.CORP_ID is '法人ID';
comment on column MBT_RPT_630.ORG_ID is '机构ID';
comment on column MBT_RPT_630.GROUP_ID is '数据分组';
comment on column MBT_RPT_630.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_630.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_630.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_630.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_630.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_630.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_630.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_630.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_630.B_ENT_NAME is '企业名称';
comment on column MBT_RPT_630.SECTION_CHG_CNT is '段变更';
comment on column MBT_RPT_630.SECTION_DEL_CNT is '段删除';
comment on column MBT_RPT_630.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_RPT_630.IDN_CHG_CNT is '标识项变更';
comment on column MBT_RPT_630.CUST_NO is '客户号';
comment on column MBT_RPT_630.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_630.PART_TYPE is '段标识';
comment on column MBT_RPT_630.PART_NAME is '段名称';
comment on column MBT_RPT_630.START_DATE is '起始日期';
comment on column MBT_RPT_630.END_DATE is '结束日期';
comment on column MBT_RPT_630.BATCH_NO is '批次号';
comment on column MBT_RPT_630.ROW_NUM is '行号';
comment on column MBT_RPT_630.IS_RPT is '是否报送';
comment on column MBT_RPT_630.IS_VALID is '是否有效';
comment on column MBT_RPT_630.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_630.OPT_FLAG is '操作标识';
comment on column MBT_RPT_630.RPT_DATE is '报送日期';
comment on column MBT_RPT_630.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_630.RPT_STATUS is '报送状态';
comment on column MBT_RPT_630.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_630.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_630.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_630.REMARKS is '备注';
comment on column MBT_RPT_630.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_630.CHECK_DESC is '校验说明';
comment on column MBT_RPT_630.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_630.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_630.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_630.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_630.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_630.DATA_FLAG is '数据标志';
comment on column MBT_RPT_630.DATA_OP is '操作标志';
comment on column MBT_RPT_630.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_630.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_630.DATA_HASH is '数据HASH';
comment on column MBT_RPT_630.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_630.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_630.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_630.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_630.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_630.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_630.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_630.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_630.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_630.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_630.DATA_APV_USER is '审核人';
comment on column MBT_RPT_630.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_630.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_630.RSV1 is '备用字段';
comment on column MBT_RPT_630.RSV2 is '备用字段';
comment on column MBT_RPT_630.RSV3 is '备用字段';
comment on column MBT_RPT_630.RSV4 is '备用字段';
comment on column MBT_RPT_630.RSV5 is '备用字段';
create table MBT_RPT_630_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_630_B is '企业现金流量表信息-基础段';
comment on column MBT_RPT_630_B.DATA_ID is '数据ID';
comment on column MBT_RPT_630_B.DATA_DATE is '数据日期';
comment on column MBT_RPT_630_B.CORP_ID is '法人ID';
comment on column MBT_RPT_630_B.ORG_ID is '机构ID';
comment on column MBT_RPT_630_B.GROUP_ID is '数据分组';
comment on column MBT_RPT_630_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_630_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_630_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_630_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_630_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_630_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_630_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_630_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_630_B.B_ENT_NAME is '企业名称';
comment on column MBT_RPT_630_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_RPT_630_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_RPT_630_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_RPT_630_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_RPT_630_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_RPT_630_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_630_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_RPT_630_B.CUST_NO is '客户号';
comment on column MBT_RPT_630_B.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_630_B.PART_TYPE is '段标识';
comment on column MBT_RPT_630_B.PART_NAME is '段名称';
comment on column MBT_RPT_630_B.START_DATE is '起始日期';
comment on column MBT_RPT_630_B.END_DATE is '结束日期';
comment on column MBT_RPT_630_B.BATCH_NO is '批次号';
comment on column MBT_RPT_630_B.ROW_NUM is '行号';
comment on column MBT_RPT_630_B.IS_RPT is '是否报送';
comment on column MBT_RPT_630_B.IS_VALID is '是否有效';
comment on column MBT_RPT_630_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_630_B.OPT_FLAG is '操作标识';
comment on column MBT_RPT_630_B.RPT_DATE is '报送日期';
comment on column MBT_RPT_630_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_630_B.RPT_STATUS is '报送状态';
comment on column MBT_RPT_630_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_630_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_630_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_630_B.REMARKS is '备注';
comment on column MBT_RPT_630_B.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_630_B.CHECK_DESC is '校验说明';
comment on column MBT_RPT_630_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_630_B.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_630_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_630_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_630_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_630_B.DATA_FLAG is '数据标志';
comment on column MBT_RPT_630_B.DATA_OP is '操作标志';
comment on column MBT_RPT_630_B.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_630_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_630_B.DATA_HASH is '数据HASH';
comment on column MBT_RPT_630_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_630_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_630_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_630_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_630_B.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_630_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_630_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_630_B.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_630_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_630_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_630_B.DATA_APV_USER is '审核人';
comment on column MBT_RPT_630_B.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_630_B.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_630_B.RSV1 is '备用字段';
comment on column MBT_RPT_630_B.RSV2 is '备用字段';
comment on column MBT_RPT_630_B.RSV3 is '备用字段';
comment on column MBT_RPT_630_B.RSV4 is '备用字段';
comment on column MBT_RPT_630_B.RSV5 is '备用字段';
create table MBT_RPT_630_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ADDITION_ACCUED_EXPENSE NUMBER(17),
C_AMORTISATION_INTANGIBLE_ASS NUMBER(17),
C_CASH_AT_THE_BEGINNING_PERIOD NUMBER(17),
C_CASH_AT_THE_END_OF_PERIOD NUMBER(17),
C_CASH_EQUIVALENTS_END_PERIOD NUMBER(17),
C_CASH_FROM_BORROWINGS NUMBER(17),
C_CASH_PAID_BEHALF_EMPLOYEES NUMBER(17),
C_CASH_PAID_GOODS_SERVICES NUMBER(17),
C_CASH_PAYMENTS_D_D_PRO_I_EXP NUMBER(17),
C_CASH_PAYMENTS_INVESTMENTS NUMBER(17),
C_CASH_PAYMENTS_RELATED_O_ACT NUMBER(17),
C_CASH_PAYMENTS_REL_O_FIN_AC NUMBER(17),
C_CASH_P_A_F_ASS_I_ASS_OLT_ASS NUMBER(17),
C_CASH_RECEIVED_FROM_INVESTORS NUMBER(17),
C_CASH_RECEIVED_ONVESTMENTS NUMBER(17),
C_CASH_RECEIVED_REL_OTHER_ACT NUMBER(17),
C_CASH_REC_RETURN_INVESTMENT NUMBER(17),
C_CASH_REC_SALES_GOODS_REN_SER NUMBER(17),
C_CASH_REPAYMENTS_FOR_DEBTS NUMBER(17),
C_CASH_RQUIVALENTS_BEGIN_PERIO NUMBER(17),
C_DEBTS_TRANSFER_TO_CAPITAL NUMBER(17),
C_DECREASE_DEFFERED_EXPENSES NUMBER(17),
C_DECREASE_IN_INVENTORIES NUMBER(17),
C_DECREASE_OPERATING_RECEIVABL NUMBER(17),
C_DEFERRED_TAX_CREDIT NUMBER(17),
C_DEPRECIATION_FIXED_ASSETS NUMBER(17),
C_EFFECT_EX_RATE_CHANGES_CASH NUMBER(17),
C_FINANCE_EXPENSE NUMBER(17),
C_FINANCING_RENT_THE_FIXED_ASS NUMBER(17),
C_INCREASE_OPERATING_RECEIVABL NUMBER(17),
C_LONG_TERM_DEFERRED_EXP_AMOR NUMBER(17),
C_LOSSES_ARSING_INVESTMENT NUMBER(17),
C_LOSSES_D_F_ASS_I_ASS_OLT_ASS NUMBER(17),
C_LOSSES_SCRAPPING_FIXED_ASS NUMBER(17),
C_NET_CASH_FLOWS_FINANCING_AC NUMBER(17),
C_NET_CASH_FLOWS_INVESTING_ACT NUMBER(17),
C_NET_CASH_FLOWS_OPERAT_ACT NUMBER(17),
C_NET_CASH_FLOWS_OPERA_ACT_MI NUMBER(17),
C_NET_CASH_REC_D_F_A_I_A_O_LT NUMBER(17),
C_NET_INCREASE_CASH_CASH_EQU_M NUMBER(17),
C_NET_INC_CASH_CASH_EQUIVALENT NUMBER(17),
C_NET_PROFIT NUMBER(17),
C_NON_CASH_OTHERS NUMBER(17),
C_ONE_YEAR_DUE_CONVERTIBLE_BO NUMBER(17),
C_ONE_YEAR_DUE_CONVERTIBLE_BON NUMBER(17),
C_OTHERS NUMBER(17),
C_OTHER_CASH_PAYMENTS_OPERA_AC NUMBER(17),
C_OTHER_CASH_REC_REL_FIN_ACT NUMBER(17),
C_OTHER_CASH_REC_REL_OPERA_ACT NUMBER(17),
C_PAYMENTS_OF_ALL_TYPES_TAXES NUMBER(17),
C_PROVISION_FOR_ASSETS NUMBER(17),
C_TAX_REFUNDS NUMBER(17),
C_TOTAL_CASH_INFLOWS_OPERA_ACT NUMBER(17),
C_TOTAL_CASH_INF_FINANCING_ACT NUMBER(17),
C_TOTAL_CASH_INF_INVESTING_ACT NUMBER(17),
C_TOTAL_CASH_OUTFLOWS_FIN_AC NUMBER(17),
C_TOTAL_CASH_OUTFLOWS_INV_ACT NUMBER(17),
C_TOTAL_CASH_OUTFLOWS_OPERA_AC NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_630_C is '企业现金流量表信息-2002版现金流量表段';
comment on column MBT_RPT_630_C.DATA_ID is '数据ID';
comment on column MBT_RPT_630_C.DATA_DATE is '数据日期';
comment on column MBT_RPT_630_C.CORP_ID is '法人ID';
comment on column MBT_RPT_630_C.ORG_ID is '机构ID';
comment on column MBT_RPT_630_C.GROUP_ID is '数据分组';
comment on column MBT_RPT_630_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_630_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_630_C.C_ADDITION_ACCUED_EXPENSE is '预提费用增加';
comment on column MBT_RPT_630_C.C_AMORTISATION_INTANGIBLE_ASS is '无形资产摊销';
comment on column MBT_RPT_630_C.C_CASH_AT_THE_BEGINNING_PERIOD is '现金的期初余额';
comment on column MBT_RPT_630_C.C_CASH_AT_THE_END_OF_PERIOD is '现金的期末余额';
comment on column MBT_RPT_630_C.C_CASH_EQUIVALENTS_END_PERIOD is '现金等价物的期末余额';
comment on column MBT_RPT_630_C.C_CASH_FROM_BORROWINGS is '借款所收到的现金';
comment on column MBT_RPT_630_C.C_CASH_PAID_BEHALF_EMPLOYEES is '支付给职工以及为职工支付的现金';
comment on column MBT_RPT_630_C.C_CASH_PAID_GOODS_SERVICES is '购买商品、接受劳务支付的现金';
comment on column MBT_RPT_630_C.C_CASH_PAYMENTS_D_D_PRO_I_EXP is '分配股利、利润或偿付利息所支付的现金';
comment on column MBT_RPT_630_C.C_CASH_PAYMENTS_INVESTMENTS is '投资所支付的现金';
comment on column MBT_RPT_630_C.C_CASH_PAYMENTS_RELATED_O_ACT is '支付的其他与投资活动有关现金';
comment on column MBT_RPT_630_C.C_CASH_PAYMENTS_REL_O_FIN_AC is '支付的其他与筹资活动有关现金';
comment on column MBT_RPT_630_C.C_CASH_P_A_F_ASS_I_ASS_OLT_ASS is '购建固定资产无形资产和其他长期资产所支付的现金';
comment on column MBT_RPT_630_C.C_CASH_RECEIVED_FROM_INVESTORS is '吸收投资所收到的现金';
comment on column MBT_RPT_630_C.C_CASH_RECEIVED_ONVESTMENTS is '取得投资收益所收到的现金';
comment on column MBT_RPT_630_C.C_CASH_RECEIVED_REL_OTHER_ACT is '收到的其他与投资活动有关的现金';
comment on column MBT_RPT_630_C.C_CASH_REC_RETURN_INVESTMENT is '收回投资所收到的现金';
comment on column MBT_RPT_630_C.C_CASH_REC_SALES_GOODS_REN_SER is '销售商品和提供劳务收到的现金';
comment on column MBT_RPT_630_C.C_CASH_REPAYMENTS_FOR_DEBTS is '偿还债务所支付的现金';
comment on column MBT_RPT_630_C.C_CASH_RQUIVALENTS_BEGIN_PERIO is '现金等价物的期初余额';
comment on column MBT_RPT_630_C.C_DEBTS_TRANSFER_TO_CAPITAL is '债务转为资本';
comment on column MBT_RPT_630_C.C_DECREASE_DEFFERED_EXPENSES is '待摊费用减少';
comment on column MBT_RPT_630_C.C_DECREASE_IN_INVENTORIES is '存货的减少';
comment on column MBT_RPT_630_C.C_DECREASE_OPERATING_RECEIVABL is '经营性应收项目的减少';
comment on column MBT_RPT_630_C.C_DEFERRED_TAX_CREDIT is '递延税款贷项';
comment on column MBT_RPT_630_C.C_DEPRECIATION_FIXED_ASSETS is '固定资产拆旧';
comment on column MBT_RPT_630_C.C_EFFECT_EX_RATE_CHANGES_CASH is '汇率变动对现金的影响';
comment on column MBT_RPT_630_C.C_FINANCE_EXPENSE is '财务费用';
comment on column MBT_RPT_630_C.C_FINANCING_RENT_THE_FIXED_ASS is '融资租入固定产';
comment on column MBT_RPT_630_C.C_INCREASE_OPERATING_RECEIVABL is '经营性应付项目的增加';
comment on column MBT_RPT_630_C.C_LONG_TERM_DEFERRED_EXP_AMOR is '长期待摊费用销';
comment on column MBT_RPT_630_C.C_LOSSES_ARSING_INVESTMENT is '投资损失';
comment on column MBT_RPT_630_C.C_LOSSES_D_F_ASS_I_ASS_OLT_ASS is '处置固定资产无形和其他长期的损失';
comment on column MBT_RPT_630_C.C_LOSSES_SCRAPPING_FIXED_ASS is '固定资产报废损失';
comment on column MBT_RPT_630_C.C_NET_CASH_FLOWS_FINANCING_AC is '筹集活动产生的现金流量净额';
comment on column MBT_RPT_630_C.C_NET_CASH_FLOWS_INVESTING_ACT is '投资活动产生的现金流量净额';
comment on column MBT_RPT_630_C.C_NET_CASH_FLOWS_OPERAT_ACT is '经营活动产生的现金流量净额';
comment on column MBT_RPT_630_C.C_NET_CASH_FLOWS_OPERA_ACT_MI is '经营活动产生的现金流量净额';
comment on column MBT_RPT_630_C.C_NET_CASH_REC_D_F_A_I_A_O_LT is '处置固定资产无形资产和其他长期所收回的现金净额';
comment on column MBT_RPT_630_C.C_NET_INCREASE_CASH_CASH_EQU_M is '现金及现等价物净增加额';
comment on column MBT_RPT_630_C.C_NET_INC_CASH_CASH_EQUIVALENT is '现金及现金等价物净增加额';
comment on column MBT_RPT_630_C.C_NET_PROFIT is '净利润';
comment on column MBT_RPT_630_C.C_NON_CASH_OTHERS is '（不涉及现金收支的投资和筹活动科目下）其他';
comment on column MBT_RPT_630_C.C_ONE_YEAR_DUE_CONVERTIBLE_BO is '一年内到期的可转换公司债券';
comment on column MBT_RPT_630_C.C_ONE_YEAR_DUE_CONVERTIBLE_BON is '一年内到期的可转换公司债券';
comment on column MBT_RPT_630_C.C_OTHERS is '（净利润调节为经营活动现金流量科目下）其他';
comment on column MBT_RPT_630_C.C_OTHER_CASH_PAYMENTS_OPERA_AC is '支付的其他与经营活动有关的现金';
comment on column MBT_RPT_630_C.C_OTHER_CASH_REC_REL_FIN_ACT is '收到的其他与筹资活动有关的现金';
comment on column MBT_RPT_630_C.C_OTHER_CASH_REC_REL_OPERA_ACT is '收到的其他与经营活动有关的现金';
comment on column MBT_RPT_630_C.C_PAYMENTS_OF_ALL_TYPES_TAXES is '支付的各项税费';
comment on column MBT_RPT_630_C.C_PROVISION_FOR_ASSETS is '计提的资产减值准备';
comment on column MBT_RPT_630_C.C_TAX_REFUNDS is '收到的税费返还';
comment on column MBT_RPT_630_C.C_TOTAL_CASH_INFLOWS_OPERA_ACT is '经营活动现金流入小计';
comment on column MBT_RPT_630_C.C_TOTAL_CASH_INF_FINANCING_ACT is '筹资活动现金流入小计';
comment on column MBT_RPT_630_C.C_TOTAL_CASH_INF_INVESTING_ACT is '投资活动现金流入小计';
comment on column MBT_RPT_630_C.C_TOTAL_CASH_OUTFLOWS_FIN_AC is '筹资活动现金流出小计';
comment on column MBT_RPT_630_C.C_TOTAL_CASH_OUTFLOWS_INV_ACT is '投资活动现金流出小计';
comment on column MBT_RPT_630_C.C_TOTAL_CASH_OUTFLOWS_OPERA_AC is '经营活动现金流出小计';
comment on column MBT_RPT_630_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_630_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_630_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_630_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_630_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_630_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_630_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_630_C.CUST_NO is '客户号';
comment on column MBT_RPT_630_C.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_630_C.PART_TYPE is '段标识';
comment on column MBT_RPT_630_C.PART_NAME is '段名称';
comment on column MBT_RPT_630_C.START_DATE is '起始日期';
comment on column MBT_RPT_630_C.END_DATE is '结束日期';
comment on column MBT_RPT_630_C.BATCH_NO is '批次号';
comment on column MBT_RPT_630_C.ROW_NUM is '行号';
comment on column MBT_RPT_630_C.IS_RPT is '是否报送';
comment on column MBT_RPT_630_C.IS_VALID is '是否有效';
comment on column MBT_RPT_630_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_630_C.OPT_FLAG is '操作标识';
comment on column MBT_RPT_630_C.RPT_DATE is '报送日期';
comment on column MBT_RPT_630_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_630_C.RPT_STATUS is '报送状态';
comment on column MBT_RPT_630_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_630_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_630_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_630_C.REMARKS is '备注';
comment on column MBT_RPT_630_C.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_630_C.CHECK_DESC is '校验说明';
comment on column MBT_RPT_630_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_630_C.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_630_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_630_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_630_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_630_C.DATA_FLAG is '数据标志';
comment on column MBT_RPT_630_C.DATA_OP is '操作标志';
comment on column MBT_RPT_630_C.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_630_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_630_C.DATA_HASH is '数据HASH';
comment on column MBT_RPT_630_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_630_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_630_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_630_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_630_C.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_630_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_630_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_630_C.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_630_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_630_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_630_C.DATA_APV_USER is '审核人';
comment on column MBT_RPT_630_C.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_630_C.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_630_C.RSV1 is '备用字段';
comment on column MBT_RPT_630_C.RSV2 is '备用字段';
comment on column MBT_RPT_630_C.RSV3 is '备用字段';
comment on column MBT_RPT_630_C.RSV4 is '备用字段';
comment on column MBT_RPT_630_C.RSV5 is '备用字段';
create table MBT_RPT_630_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ADDITION_OF_ACCUED_EXPENSE NUMBER(17),
D_AMORTISATION_INTANGIBLE_ASS NUMBER(17),
D_AMORTISATION_LT_DEFFERED_EXP NUMBER(17),
D_CASH_AT_THE_BEGINNING_PERIOD NUMBER(17),
D_CASH_AT_THE_END_OF_PERIOD NUMBER(17),
D_CASH_EQUIVALENTS_AT_THE_PERI NUMBER(17),
D_CASH_FROM_BORROWINGS NUMBER(17),
D_CASH_PAID_ACQ_FASS_IASS_ASS NUMBER(17),
D_CASH_PAID_BEHALF_OF_EMPLOYEE NUMBER(17),
D_CASH_PAID_FOR_GOODS_SERVICES NUMBER(17),
D_CASH_PAYMENTS_D_DI_P_INT_EXP NUMBER(17),
D_CASH_PAYMENTS_INVESTMENTS NUMBER(17),
D_CASH_PAYMENTS_REL_O_F_ACT NUMBER(17),
D_CASH_PAYMENTS_REL_O_I_ACT NUMBER(17),
D_CASH_RECEIVED_INVESTORS NUMBER(17),
D_CASH_REC_ONVESTMENTS NUMBER(17),
D_CASH_REC_REL_OTHER_INVEST_AC NUMBER(17),
D_CASH_REC_RETURN_INVESTMENT NUMBER(17),
D_CASH_REC_SAL_GOO_REN_SERVICE NUMBER(17),
D_CASH_REPAYMENTS_FOR_DEBTS NUMBER(17),
D_CASH_RQUIVALENTS_BEGIN_PERIO NUMBER(17),
D_DEBTS_TRANSFER_TO_CAPITAL NUMBER(17),
D_DECREASE_DEFFERED_EXPENSES NUMBER(17),
D_DECREASE_IN_INVENTORIES NUMBER(17),
D_DECREASE_OPERATING_RECEIVABL NUMBER(17),
D_DEFERRED_INCOME_TAX_ASSETS NUMBER(17),
D_DEFERRED_INCOME_TAX_LIABILIT NUMBER(17),
D_DEPRECIATION_FIXED_ASSETS NUMBER(17),
D_EFFECT_EXC_RATE_CHANGES_CASH NUMBER(17),
D_FINANCE_EXPENSE NUMBER(17),
D_FINANCING_RENT_FIXED_ASSET NUMBER(17),
D_INCREASE_OPERATING_RECEIVABL NUMBER(17),
D_INITIAL_CASH_CASH_EQU_BALANC NUMBER(17),
D_LOSSES_ARSING_INVESTMENT NUMBER(17),
D_LOSSES_DISP_FASS_IASS_OLTASS NUMBER(17),
D_LOSSES_SCRAPPING_FIXED_ASS NUMBER(17),
D_NET_CASH_FLOWS_FINANCING_ACT NUMBER(17),
D_NET_CASH_FLOWS_INVEST_ACT NUMBER(17),
D_NET_CASH_FLOWS_OPERATING_ACT NUMBER(17),
D_NET_CASH_FLOWS_OPERAT_ACT_MI NUMBER(17),
D_NET_CASH_INF_DIS_SUB_O_B_ENT NUMBER(17),
D_NET_CASH_OUTF_PRO_SUB_OBUNIT NUMBER(17),
D_NET_CASH_R_DFASS_IASS_OLTASS NUMBER(17),
D_NET_INCREASE_CASH_EQUIVAL_MI NUMBER(17),
D_NET_INC_CASH_CASH_EQUIVALENT NUMBER(17),
D_NET_PROFIT NUMBER(17),
D_NON_CASH_OTHERS NUMBER(17),
D_ONE_YEAR_DUE_CONVER_BONDS NUMBER(17),
D_OTHERS NUMBER(17),
D_OTHER_CASH_PAYMENTS_OPERA_AC NUMBER(17),
D_OTHER_CASH_REC_REL_FINA_ACT NUMBER(17),
D_OTHER_CASH_REC_REL_OPERA_ACT NUMBER(17),
D_PAYMENTS_OF_ALL_TYPES_TAXES NUMBER(17),
D_PROFIT_LOSS_CHANGES_FAIR_VAL NUMBER(17),
D_PROVISION_ASSET_IMPAIRMENT NUMBER(17),
D_SUB_TOTAL_CASH_OUTFLOWS NUMBER(17),
D_TAX_REFUNDS NUMBER(17),
D_THE_FINAL_CASH_EQU_BALANCE NUMBER(17),
D_TOTAL_CASH_INFLOWS_FINA_ACT NUMBER(17),
D_TOTAL_CASH_INFLOWS_INVEST_AC NUMBER(17),
D_TOTAL_CASH_INFLOWS_OPERAT_AC NUMBER(17),
D_TOTAL_CASH_OUTFLOWS_FINA_ACT NUMBER(17),
D_TOTAL_CASH_OUTFLOWS_OPERA_AC NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_630_D is '企业现金流量表信息-2007版现金流量表段';
comment on column MBT_RPT_630_D.DATA_ID is '数据ID';
comment on column MBT_RPT_630_D.DATA_DATE is '数据日期';
comment on column MBT_RPT_630_D.CORP_ID is '法人ID';
comment on column MBT_RPT_630_D.ORG_ID is '机构ID';
comment on column MBT_RPT_630_D.GROUP_ID is '数据分组';
comment on column MBT_RPT_630_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_630_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_630_D.D_ADDITION_OF_ACCUED_EXPENSE is '预提费用增加';
comment on column MBT_RPT_630_D.D_AMORTISATION_INTANGIBLE_ASS is '无形资产摊销';
comment on column MBT_RPT_630_D.D_AMORTISATION_LT_DEFFERED_EXP is '长期待摊费用销';
comment on column MBT_RPT_630_D.D_CASH_AT_THE_BEGINNING_PERIOD is '现金的期初余额';
comment on column MBT_RPT_630_D.D_CASH_AT_THE_END_OF_PERIOD is '现金的期末余额';
comment on column MBT_RPT_630_D.D_CASH_EQUIVALENTS_AT_THE_PERI is '现金等价物的期末余额';
comment on column MBT_RPT_630_D.D_CASH_FROM_BORROWINGS is '取得借款收到的现金';
comment on column MBT_RPT_630_D.D_CASH_PAID_ACQ_FASS_IASS_ASS is '购建固定资产无形资产和其他长期资产所支付的现金';
comment on column MBT_RPT_630_D.D_CASH_PAID_BEHALF_OF_EMPLOYEE is '支付给职工以及为支付的现金';
comment on column MBT_RPT_630_D.D_CASH_PAID_FOR_GOODS_SERVICES is '购买商品、接受劳务支付的现金';
comment on column MBT_RPT_630_D.D_CASH_PAYMENTS_D_DI_P_INT_EXP is '分配股利、利润或偿付利息所支付的现金';
comment on column MBT_RPT_630_D.D_CASH_PAYMENTS_INVESTMENTS is '投资所支付的现金投资所支付的现金';
comment on column MBT_RPT_630_D.D_CASH_PAYMENTS_REL_O_F_ACT is '支付的其他与筹资活动有关现金';
comment on column MBT_RPT_630_D.D_CASH_PAYMENTS_REL_O_I_ACT is '支付的其他与投资活动有关现金';
comment on column MBT_RPT_630_D.D_CASH_RECEIVED_INVESTORS is '吸收投资所收到的现金';
comment on column MBT_RPT_630_D.D_CASH_REC_ONVESTMENTS is '取得投资收益所收到的现金';
comment on column MBT_RPT_630_D.D_CASH_REC_REL_OTHER_INVEST_AC is '收到的其他与投资活动有关的现金';
comment on column MBT_RPT_630_D.D_CASH_REC_RETURN_INVESTMENT is '收回投资所收到的现金';
comment on column MBT_RPT_630_D.D_CASH_REC_SAL_GOO_REN_SERVICE is '销售商品和提供劳务收到的现金';
comment on column MBT_RPT_630_D.D_CASH_REPAYMENTS_FOR_DEBTS is '偿还债务所支付的现金';
comment on column MBT_RPT_630_D.D_CASH_RQUIVALENTS_BEGIN_PERIO is '现金等价物的期初余额';
comment on column MBT_RPT_630_D.D_DEBTS_TRANSFER_TO_CAPITAL is '债务转为资本';
comment on column MBT_RPT_630_D.D_DECREASE_DEFFERED_EXPENSES is '待摊费用减少';
comment on column MBT_RPT_630_D.D_DECREASE_IN_INVENTORIES is '存货的减少';
comment on column MBT_RPT_630_D.D_DECREASE_OPERATING_RECEIVABL is '经营性应收项目的减少';
comment on column MBT_RPT_630_D.D_DEFERRED_INCOME_TAX_ASSETS is '递延所得税资产减少';
comment on column MBT_RPT_630_D.D_DEFERRED_INCOME_TAX_LIABILIT is '递延所得税负债增加';
comment on column MBT_RPT_630_D.D_DEPRECIATION_FIXED_ASSETS is '固定资产折旧、油气资产折耗、生产性生物资产折旧';
comment on column MBT_RPT_630_D.D_EFFECT_EXC_RATE_CHANGES_CASH is '汇率变动对现金的影响';
comment on column MBT_RPT_630_D.D_FINANCE_EXPENSE is '财务费用';
comment on column MBT_RPT_630_D.D_FINANCING_RENT_FIXED_ASSET is '融资租入固定产';
comment on column MBT_RPT_630_D.D_INCREASE_OPERATING_RECEIVABL is '经营性应付项目的增加';
comment on column MBT_RPT_630_D.D_INITIAL_CASH_CASH_EQU_BALANC is '期初现金及等价物余额';
comment on column MBT_RPT_630_D.D_LOSSES_ARSING_INVESTMENT is '投资损失';
comment on column MBT_RPT_630_D.D_LOSSES_DISP_FASS_IASS_OLTASS is '处置固定资产无形和其他长期的损失';
comment on column MBT_RPT_630_D.D_LOSSES_SCRAPPING_FIXED_ASS is '固定资产报废损失';
comment on column MBT_RPT_630_D.D_NET_CASH_FLOWS_FINANCING_ACT is '筹集活动产生的现金流量净额';
comment on column MBT_RPT_630_D.D_NET_CASH_FLOWS_INVEST_ACT is '投资活动产生的现金流量净额';
comment on column MBT_RPT_630_D.D_NET_CASH_FLOWS_OPERATING_ACT is '经营活动产生的现金流量净额';
comment on column MBT_RPT_630_D.D_NET_CASH_FLOWS_OPERAT_ACT_MI is '经营活动产生的现金流量净额';
comment on column MBT_RPT_630_D.D_NET_CASH_INF_DIS_SUB_O_B_ENT is '处置子公司及其他营业单位收到的现金净额';
comment on column MBT_RPT_630_D.D_NET_CASH_OUTF_PRO_SUB_OBUNIT is '取得子公司及其他营业单位支付的现金净额';
comment on column MBT_RPT_630_D.D_NET_CASH_R_DFASS_IASS_OLTASS is '处置固定资产无形资产和其他长期资产所收回的现金净额';
comment on column MBT_RPT_630_D.D_NET_INCREASE_CASH_EQUIVAL_MI is '现金及现等价物净增加额';
comment on column MBT_RPT_630_D.D_NET_INC_CASH_CASH_EQUIVALENT is '现金及现金等价物净增加额';
comment on column MBT_RPT_630_D.D_NET_PROFIT is '净利润';
comment on column MBT_RPT_630_D.D_NON_CASH_OTHERS is '（不涉及现金收支的投资和筹活动科目下）其他';
comment on column MBT_RPT_630_D.D_ONE_YEAR_DUE_CONVER_BONDS is '一年内到期的可转换公司债券';
comment on column MBT_RPT_630_D.D_OTHERS is '（净利润调节为经营活动现金流量科目下）其他';
comment on column MBT_RPT_630_D.D_OTHER_CASH_PAYMENTS_OPERA_AC is '支付其他与经营活动有关的现金';
comment on column MBT_RPT_630_D.D_OTHER_CASH_REC_REL_FINA_ACT is '收到的其他与筹资活动有关的现金';
comment on column MBT_RPT_630_D.D_OTHER_CASH_REC_REL_OPERA_ACT is '收到的其他与经营活动有关的现金';
comment on column MBT_RPT_630_D.D_PAYMENTS_OF_ALL_TYPES_TAXES is '支付的各项税费支付的各项税费';
comment on column MBT_RPT_630_D.D_PROFIT_LOSS_CHANGES_FAIR_VAL is '公允价值变动损失';
comment on column MBT_RPT_630_D.D_PROVISION_ASSET_IMPAIRMENT is '资产减值准备';
comment on column MBT_RPT_630_D.D_SUB_TOTAL_CASH_OUTFLOWS is '投资活动现金流出小计';
comment on column MBT_RPT_630_D.D_TAX_REFUNDS is '收到的税费返还';
comment on column MBT_RPT_630_D.D_THE_FINAL_CASH_EQU_BALANCE is '期末现金及等价物余额';
comment on column MBT_RPT_630_D.D_TOTAL_CASH_INFLOWS_FINA_ACT is '筹资活动现金流入小计';
comment on column MBT_RPT_630_D.D_TOTAL_CASH_INFLOWS_INVEST_AC is '投资活动现金流入小计';
comment on column MBT_RPT_630_D.D_TOTAL_CASH_INFLOWS_OPERAT_AC is '经营活动现金流入小计';
comment on column MBT_RPT_630_D.D_TOTAL_CASH_OUTFLOWS_FINA_ACT is '筹资活动现金流出小计';
comment on column MBT_RPT_630_D.D_TOTAL_CASH_OUTFLOWS_OPERA_AC is '经营活动现金流出小计';
comment on column MBT_RPT_630_D.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_630_D.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_630_D.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_630_D.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_630_D.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_630_D.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_630_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_630_D.CUST_NO is '客户号';
comment on column MBT_RPT_630_D.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_630_D.PART_TYPE is '段标识';
comment on column MBT_RPT_630_D.PART_NAME is '段名称';
comment on column MBT_RPT_630_D.START_DATE is '起始日期';
comment on column MBT_RPT_630_D.END_DATE is '结束日期';
comment on column MBT_RPT_630_D.BATCH_NO is '批次号';
comment on column MBT_RPT_630_D.ROW_NUM is '行号';
comment on column MBT_RPT_630_D.IS_RPT is '是否报送';
comment on column MBT_RPT_630_D.IS_VALID is '是否有效';
comment on column MBT_RPT_630_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_630_D.OPT_FLAG is '操作标识';
comment on column MBT_RPT_630_D.RPT_DATE is '报送日期';
comment on column MBT_RPT_630_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_630_D.RPT_STATUS is '报送状态';
comment on column MBT_RPT_630_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_630_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_630_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_630_D.REMARKS is '备注';
comment on column MBT_RPT_630_D.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_630_D.CHECK_DESC is '校验说明';
comment on column MBT_RPT_630_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_630_D.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_630_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_630_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_630_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_630_D.DATA_FLAG is '数据标志';
comment on column MBT_RPT_630_D.DATA_OP is '操作标志';
comment on column MBT_RPT_630_D.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_630_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_630_D.DATA_HASH is '数据HASH';
comment on column MBT_RPT_630_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_630_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_630_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_630_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_630_D.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_630_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_630_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_630_D.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_630_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_630_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_630_D.DATA_APV_USER is '审核人';
comment on column MBT_RPT_630_D.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_630_D.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_630_D.RSV1 is '备用字段';
comment on column MBT_RPT_630_D.RSV2 is '备用字段';
comment on column MBT_RPT_630_D.RSV3 is '备用字段';
comment on column MBT_RPT_630_D.RSV4 is '备用字段';
comment on column MBT_RPT_630_D.RSV5 is '备用字段';
