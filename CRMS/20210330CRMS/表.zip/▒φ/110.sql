create table MBT_DM_110 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110 is '个人基本信息';
comment on column MBT_DM_110.DATA_ID is '数据ID';
comment on column MBT_DM_110.DATA_DATE is '数据日期';
comment on column MBT_DM_110.CORP_ID is '法人ID';
comment on column MBT_DM_110.ORG_ID is '机构ID';
comment on column MBT_DM_110.GROUP_ID is '数据分组';
comment on column MBT_DM_110.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110.B_ID_NUM is '证件号码';
comment on column MBT_DM_110.B_ID_TYPE is '证件类型';
comment on column MBT_DM_110.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110.SECTION_CHG_CNT is '段变更';
comment on column MBT_DM_110.SECTION_DEL_CNT is '段删除';
comment on column MBT_DM_110.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_DM_110.IDN_CHG_CNT is '标识项变更';
comment on column MBT_DM_110.CUST_NO is '客户号';
comment on column MBT_DM_110.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110.PART_TYPE is '段标识';
comment on column MBT_DM_110.PART_NAME is '段名称';
comment on column MBT_DM_110.START_DATE is '起始日期';
comment on column MBT_DM_110.END_DATE is '结束日期';
comment on column MBT_DM_110.BATCH_NO is '批次号';
comment on column MBT_DM_110.ROW_NUM is '行号';
comment on column MBT_DM_110.IS_RPT is '是否报送';
comment on column MBT_DM_110.IS_VALID is '是否有效';
comment on column MBT_DM_110.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110.OPT_FLAG is '操作标识';
comment on column MBT_DM_110.RPT_DATE is '报送日期';
comment on column MBT_DM_110.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110.RPT_STATUS is '报送状态';
comment on column MBT_DM_110.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110.REMARKS is '备注';
comment on column MBT_DM_110.CHECK_FLAG is '校验标志';
comment on column MBT_DM_110.CHECK_DESC is '校验说明';
comment on column MBT_DM_110.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110.DATA_FLAG is '数据标志';
comment on column MBT_DM_110.DATA_OP is '操作标志';
comment on column MBT_DM_110.DATA_SOURCE is '数据来源';
comment on column MBT_DM_110.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110.DATA_HASH is '数据HASH';
comment on column MBT_DM_110.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110.DATA_CRT_USER is '创建人';
comment on column MBT_DM_110.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110.DATA_CHG_USER is '修改人';
comment on column MBT_DM_110.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110.DATA_APV_USER is '审核人';
comment on column MBT_DM_110.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110.RSV1 is '备用字段';
comment on column MBT_DM_110.RSV2 is '备用字段';
comment on column MBT_DM_110.RSV3 is '备用字段';
comment on column MBT_DM_110.RSV4 is '备用字段';
comment on column MBT_DM_110.RSV5 is '备用字段';
create table MBT_DM_110_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_CIMOC VARCHAR(14),
B_CUSTOMER_TYPE VARCHAR(2),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
B_INF_REC_TYPE VARCHAR(3),
B_NAME VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_B is '个人基本信息-基础段';
comment on column MBT_DM_110_B.DATA_ID is '数据ID';
comment on column MBT_DM_110_B.DATA_DATE is '数据日期';
comment on column MBT_DM_110_B.CORP_ID is '法人ID';
comment on column MBT_DM_110_B.ORG_ID is '机构ID';
comment on column MBT_DM_110_B.GROUP_ID is '数据分组';
comment on column MBT_DM_110_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_DM_110_B.B_CUSTOMER_TYPE is '客户资料类型';
comment on column MBT_DM_110_B.B_ID_NUM is '证件号码';
comment on column MBT_DM_110_B.B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_DM_110_B.B_NAME is '姓名';
comment on column MBT_DM_110_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_DM_110_B.CUST_NO is '客户号';
comment on column MBT_DM_110_B.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_B.PART_TYPE is '段标识';
comment on column MBT_DM_110_B.PART_NAME is '段名称';
comment on column MBT_DM_110_B.START_DATE is '起始日期';
comment on column MBT_DM_110_B.END_DATE is '结束日期';
comment on column MBT_DM_110_B.BATCH_NO is '批次号';
comment on column MBT_DM_110_B.ROW_NUM is '行号';
comment on column MBT_DM_110_B.IS_RPT is '是否报送';
comment on column MBT_DM_110_B.IS_VALID is '是否有效';
comment on column MBT_DM_110_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_B.OPT_FLAG is '操作标识';
comment on column MBT_DM_110_B.RPT_DATE is '报送日期';
comment on column MBT_DM_110_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_B.RPT_STATUS is '报送状态';
comment on column MBT_DM_110_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_B.REMARKS is '备注';
comment on column MBT_DM_110_B.CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_B.CHECK_DESC is '校验说明';
comment on column MBT_DM_110_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_B.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_B.DATA_FLAG is '数据标志';
comment on column MBT_DM_110_B.DATA_OP is '操作标志';
comment on column MBT_DM_110_B.DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_B.DATA_HASH is '数据HASH';
comment on column MBT_DM_110_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_B.DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_B.DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_B.DATA_APV_USER is '审核人';
comment on column MBT_DM_110_B.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_B.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_B.RSV1 is '备用字段';
comment on column MBT_DM_110_B.RSV2 is '备用字段';
comment on column MBT_DM_110_B.RSV3 is '备用字段';
comment on column MBT_DM_110_B.RSV4 is '备用字段';
comment on column MBT_DM_110_B.RSV5 is '备用字段';
create table MBT_DM_110_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
OTH_ID_NUM VARCHAR(40),
OTH_ID_TYPE VARCHAR(2),
ALIAS VARCHAR(60),
ID_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_C is '个人基本信息-其他标识段';
comment on column MBT_DM_110_C.DATA_ID is '数据ID';
comment on column MBT_DM_110_C.DATA_DATE is '数据日期';
comment on column MBT_DM_110_C.CORP_ID is '法人ID';
comment on column MBT_DM_110_C.ORG_ID is '机构ID';
comment on column MBT_DM_110_C.GROUP_ID is '数据分组';
comment on column MBT_DM_110_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_C.OTH_ID_NUM is '证件号码';
comment on column MBT_DM_110_C.OTH_ID_TYPE is '证件类型';
comment on column MBT_DM_110_C.ALIAS is '姓名';
comment on column MBT_DM_110_C.ID_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_110_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_C.B_ID_NUM is '证件号码';
comment on column MBT_DM_110_C.B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_C.CUST_NO is '客户号';
comment on column MBT_DM_110_C.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_C.PART_TYPE is '段标识';
comment on column MBT_DM_110_C.PART_NAME is '段名称';
comment on column MBT_DM_110_C.START_DATE is '起始日期';
comment on column MBT_DM_110_C.END_DATE is '结束日期';
comment on column MBT_DM_110_C.BATCH_NO is '批次号';
comment on column MBT_DM_110_C.ROW_NUM is '行号';
comment on column MBT_DM_110_C.IS_RPT is '是否报送';
comment on column MBT_DM_110_C.IS_VALID is '是否有效';
comment on column MBT_DM_110_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_C.OPT_FLAG is '操作标识';
comment on column MBT_DM_110_C.RPT_DATE is '报送日期';
comment on column MBT_DM_110_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_C.RPT_STATUS is '报送状态';
comment on column MBT_DM_110_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_C.REMARKS is '备注';
comment on column MBT_DM_110_C.CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_C.CHECK_DESC is '校验说明';
comment on column MBT_DM_110_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_C.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_C.DATA_FLAG is '数据标志';
comment on column MBT_DM_110_C.DATA_OP is '操作标志';
comment on column MBT_DM_110_C.DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_C.DATA_HASH is '数据HASH';
comment on column MBT_DM_110_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_C.DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_C.DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_C.DATA_APV_USER is '审核人';
comment on column MBT_DM_110_C.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_C.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_C.RSV1 is '备用字段';
comment on column MBT_DM_110_C.RSV2 is '备用字段';
comment on column MBT_DM_110_C.RSV3 is '备用字段';
comment on column MBT_DM_110_C.RSV4 is '备用字段';
comment on column MBT_DM_110_C.RSV5 is '备用字段';
create table MBT_DM_110_D  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_CELL_PHONE VARCHAR(11),
D_DOB VARCHAR(8),
D_EMAIL VARCHAR(120),
D_FCS_INFO_UP_DATE VARCHAR(8),
D_HH_DIST VARCHAR(6),
D_HOUSE_ADD VARCHAR(200),
D_NATION VARCHAR(3),
D_SEX VARCHAR(1),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_D  is '个人基本信息-基本概况段';
comment on column MBT_DM_110_D .DATA_ID is '数据ID';
comment on column MBT_DM_110_D .DATA_DATE is '数据日期';
comment on column MBT_DM_110_D .CORP_ID is '法人ID';
comment on column MBT_DM_110_D .ORG_ID is '机构ID';
comment on column MBT_DM_110_D .GROUP_ID is '数据分组';
comment on column MBT_DM_110_D .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_D .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_D .D_CELL_PHONE is '手机号码';
comment on column MBT_DM_110_D .D_DOB is '出生日期';
comment on column MBT_DM_110_D .D_EMAIL is '电子邮箱';
comment on column MBT_DM_110_D .D_FCS_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_110_D .D_HH_DIST is '户籍所在地行政区划';
comment on column MBT_DM_110_D .D_HOUSE_ADD is '户籍地址';
comment on column MBT_DM_110_D .D_NATION is '国籍';
comment on column MBT_DM_110_D .D_SEX is '性别';
comment on column MBT_DM_110_D .B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_D .B_ID_NUM is '证件号码';
comment on column MBT_DM_110_D .B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_D .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_D .CUST_NO is '客户号';
comment on column MBT_DM_110_D .UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_D .PART_TYPE is '段标识';
comment on column MBT_DM_110_D .PART_NAME is '段名称';
comment on column MBT_DM_110_D .START_DATE is '起始日期';
comment on column MBT_DM_110_D .END_DATE is '结束日期';
comment on column MBT_DM_110_D .BATCH_NO is '批次号';
comment on column MBT_DM_110_D .ROW_NUM is '行号';
comment on column MBT_DM_110_D .IS_RPT is '是否报送';
comment on column MBT_DM_110_D .IS_VALID is '是否有效';
comment on column MBT_DM_110_D .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_D .OPT_FLAG is '操作标识';
comment on column MBT_DM_110_D .RPT_DATE is '报送日期';
comment on column MBT_DM_110_D .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_D .RPT_STATUS is '报送状态';
comment on column MBT_DM_110_D .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_D .RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_D .RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_D .REMARKS is '备注';
comment on column MBT_DM_110_D .CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_D .CHECK_DESC is '校验说明';
comment on column MBT_DM_110_D .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_D .NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_D .DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_D .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_D .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_D .DATA_FLAG is '数据标志';
comment on column MBT_DM_110_D .DATA_OP is '操作标志';
comment on column MBT_DM_110_D .DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_D .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_D .DATA_HASH is '数据HASH';
comment on column MBT_DM_110_D .DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_D .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_D .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_D .DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_D .DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_D .DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_D .DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_D .DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_D .DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_D .DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_D .DATA_APV_USER is '审核人';
comment on column MBT_DM_110_D .DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_D .DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_D .RSV1 is '备用字段';
comment on column MBT_DM_110_D .RSV2 is '备用字段';
comment on column MBT_DM_110_D .RSV3 is '备用字段';
comment on column MBT_DM_110_D .RSV4 is '备用字段';
comment on column MBT_DM_110_D .RSV5 is '备用字段';
create table MBT_DM_110_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_CELL_PHONE VARCHAR(12),
D_DOB VARCHAR(8),
D_EMAIL VARCHAR(120),
D_FCS_INFO_UP_DATE VARCHAR(8),
D_HH_DIST VARCHAR(6),
D_HOUSE_ADD VARCHAR(200),
D_NATION VARCHAR(3),
D_SEX VARCHAR(1),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_D is '个人基本信息-基本概况段';
comment on column MBT_DM_110_D.DATA_ID is '数据ID';
comment on column MBT_DM_110_D.DATA_DATE is '数据日期';
comment on column MBT_DM_110_D.CORP_ID is '法人ID';
comment on column MBT_DM_110_D.ORG_ID is '机构ID';
comment on column MBT_DM_110_D.GROUP_ID is '数据分组';
comment on column MBT_DM_110_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_D.D_CELL_PHONE is '手机号码';
comment on column MBT_DM_110_D.D_DOB is '出生日期';
comment on column MBT_DM_110_D.D_EMAIL is '电子邮箱';
comment on column MBT_DM_110_D.D_FCS_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_110_D.D_HH_DIST is '户籍所在地行政区划';
comment on column MBT_DM_110_D.D_HOUSE_ADD is '户籍地址';
comment on column MBT_DM_110_D.D_NATION is '国籍';
comment on column MBT_DM_110_D.D_SEX is '性别';
comment on column MBT_DM_110_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_D.B_ID_NUM is '证件号码';
comment on column MBT_DM_110_D.B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_D.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_D.CUST_NO is '客户号';
comment on column MBT_DM_110_D.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_D.PART_TYPE is '段标识';
comment on column MBT_DM_110_D.PART_NAME is '段名称';
comment on column MBT_DM_110_D.START_DATE is '起始日期';
comment on column MBT_DM_110_D.END_DATE is '结束日期';
comment on column MBT_DM_110_D.BATCH_NO is '批次号';
comment on column MBT_DM_110_D.ROW_NUM is '行号';
comment on column MBT_DM_110_D.IS_RPT is '是否报送';
comment on column MBT_DM_110_D.IS_VALID is '是否有效';
comment on column MBT_DM_110_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_D.OPT_FLAG is '操作标识';
comment on column MBT_DM_110_D.RPT_DATE is '报送日期';
comment on column MBT_DM_110_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_D.RPT_STATUS is '报送状态';
comment on column MBT_DM_110_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_D.REMARKS is '备注';
comment on column MBT_DM_110_D.CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_D.CHECK_DESC is '校验说明';
comment on column MBT_DM_110_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_D.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_D.DATA_FLAG is '数据标志';
comment on column MBT_DM_110_D.DATA_OP is '操作标志';
comment on column MBT_DM_110_D.DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_D.DATA_HASH is '数据HASH';
comment on column MBT_DM_110_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_D.DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_D.DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_D.DATA_APV_USER is '审核人';
comment on column MBT_DM_110_D.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_D.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_D.RSV1 is '备用字段';
comment on column MBT_DM_110_D.RSV2 is '备用字段';
comment on column MBT_DM_110_D.RSV3 is '备用字段';
comment on column MBT_DM_110_D.RSV4 is '备用字段';
comment on column MBT_DM_110_D.RSV5 is '备用字段';
create table MBT_DM_110_E  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
E_MARI_STATUS VARCHAR(2),
E_SPO_ID_NUM VARCHAR(40),
E_SPO_ID_TYPE VARCHAR(2),
E_SPO_NAME VARCHAR(60),
E_SPO_TEL VARCHAR(50),
E_SPS_CMPY_NM VARCHAR(160),
E_SPS_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_E  is '个人基本信息-婚姻信息段';
comment on column MBT_DM_110_E .DATA_ID is '数据ID';
comment on column MBT_DM_110_E .DATA_DATE is '数据日期';
comment on column MBT_DM_110_E .CORP_ID is '法人ID';
comment on column MBT_DM_110_E .ORG_ID is '机构ID';
comment on column MBT_DM_110_E .GROUP_ID is '数据分组';
comment on column MBT_DM_110_E .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_E .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_E .E_MARI_STATUS is '婚姻状况';
comment on column MBT_DM_110_E .E_SPO_ID_NUM is '配偶证件号码';
comment on column MBT_DM_110_E .E_SPO_ID_TYPE is '配偶证件类型';
comment on column MBT_DM_110_E .E_SPO_NAME is '配偶姓名';
comment on column MBT_DM_110_E .E_SPO_TEL is '配偶联系电话';
comment on column MBT_DM_110_E .E_SPS_CMPY_NM is '配偶工作单位';
comment on column MBT_DM_110_E .E_SPS_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_110_E .B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_E .B_ID_NUM is '证件号码';
comment on column MBT_DM_110_E .B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_E .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_E .CUST_NO is '客户号';
comment on column MBT_DM_110_E .UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_E .PART_TYPE is '段标识';
comment on column MBT_DM_110_E .PART_NAME is '段名称';
comment on column MBT_DM_110_E .START_DATE is '起始日期';
comment on column MBT_DM_110_E .END_DATE is '结束日期';
comment on column MBT_DM_110_E .BATCH_NO is '批次号';
comment on column MBT_DM_110_E .ROW_NUM is '行号';
comment on column MBT_DM_110_E .IS_RPT is '是否报送';
comment on column MBT_DM_110_E .IS_VALID is '是否有效';
comment on column MBT_DM_110_E .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_E .OPT_FLAG is '操作标识';
comment on column MBT_DM_110_E .RPT_DATE is '报送日期';
comment on column MBT_DM_110_E .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_E .RPT_STATUS is '报送状态';
comment on column MBT_DM_110_E .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_E .RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_E .RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_E .REMARKS is '备注';
comment on column MBT_DM_110_E .CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_E .CHECK_DESC is '校验说明';
comment on column MBT_DM_110_E .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_E .NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_E .DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_E .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_E .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_E .DATA_FLAG is '数据标志';
comment on column MBT_DM_110_E .DATA_OP is '操作标志';
comment on column MBT_DM_110_E .DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_E .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_E .DATA_HASH is '数据HASH';
comment on column MBT_DM_110_E .DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_E .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_E .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_E .DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_E .DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_E .DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_E .DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_E .DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_E .DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_E .DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_E .DATA_APV_USER is '审核人';
comment on column MBT_DM_110_E .DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_E .DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_E .RSV1 is '备用字段';
comment on column MBT_DM_110_E .RSV2 is '备用字段';
comment on column MBT_DM_110_E .RSV3 is '备用字段';
comment on column MBT_DM_110_E .RSV4 is '备用字段';
comment on column MBT_DM_110_E .RSV5 is '备用字段';
create table MBT_DM_110_E (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
E_MARI_STATUS VARCHAR(2),
E_SPO_ID_NUM VARCHAR(40),
E_SPO_ID_TYPE VARCHAR(2),
E_SPO_NAME VARCHAR(60),
E_SPO_TEL VARCHAR(50),
E_SPS_CMPY_NM VARCHAR(160),
E_SPS_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_E is '个人基本信息-婚姻信息段';
comment on column MBT_DM_110_E.DATA_ID is '数据ID';
comment on column MBT_DM_110_E.DATA_DATE is '数据日期';
comment on column MBT_DM_110_E.CORP_ID is '法人ID';
comment on column MBT_DM_110_E.ORG_ID is '机构ID';
comment on column MBT_DM_110_E.GROUP_ID is '数据分组';
comment on column MBT_DM_110_E.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_E.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_E.E_MARI_STATUS is '婚姻状况';
comment on column MBT_DM_110_E.E_SPO_ID_NUM is '配偶证件号码';
comment on column MBT_DM_110_E.E_SPO_ID_TYPE is '配偶证件类型';
comment on column MBT_DM_110_E.E_SPO_NAME is '配偶姓名';
comment on column MBT_DM_110_E.E_SPO_TEL is '配偶联系电话';
comment on column MBT_DM_110_E.E_SPS_CMPY_NM is '配偶工作单位';
comment on column MBT_DM_110_E.E_SPS_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_110_E.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_E.B_ID_NUM is '证件号码';
comment on column MBT_DM_110_E.B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_E.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_E.CUST_NO is '客户号';
comment on column MBT_DM_110_E.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_E.PART_TYPE is '段标识';
comment on column MBT_DM_110_E.PART_NAME is '段名称';
comment on column MBT_DM_110_E.START_DATE is '起始日期';
comment on column MBT_DM_110_E.END_DATE is '结束日期';
comment on column MBT_DM_110_E.BATCH_NO is '批次号';
comment on column MBT_DM_110_E.ROW_NUM is '行号';
comment on column MBT_DM_110_E.IS_RPT is '是否报送';
comment on column MBT_DM_110_E.IS_VALID is '是否有效';
comment on column MBT_DM_110_E.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_E.OPT_FLAG is '操作标识';
comment on column MBT_DM_110_E.RPT_DATE is '报送日期';
comment on column MBT_DM_110_E.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_E.RPT_STATUS is '报送状态';
comment on column MBT_DM_110_E.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_E.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_E.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_E.REMARKS is '备注';
comment on column MBT_DM_110_E.CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_E.CHECK_DESC is '校验说明';
comment on column MBT_DM_110_E.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_E.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_E.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_E.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_E.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_E.DATA_FLAG is '数据标志';
comment on column MBT_DM_110_E.DATA_OP is '操作标志';
comment on column MBT_DM_110_E.DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_E.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_E.DATA_HASH is '数据HASH';
comment on column MBT_DM_110_E.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_E.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_E.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_E.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_E.DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_E.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_E.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_E.DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_E.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_E.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_E.DATA_APV_USER is '审核人';
comment on column MBT_DM_110_E.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_E.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_E.RSV1 is '备用字段';
comment on column MBT_DM_110_E.RSV2 is '备用字段';
comment on column MBT_DM_110_E.RSV3 is '备用字段';
comment on column MBT_DM_110_E.RSV4 is '备用字段';
comment on column MBT_DM_110_E.RSV5 is '备用字段';
create table MBT_DM_110_F  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
F_ACA_DEGREE VARCHAR(1),
F_EDU_INFO_UP_DATE VARCHAR(8),
F_EDU_LEVEL VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_F  is '个人基本信息-教育信息段';
comment on column MBT_DM_110_F .DATA_ID is '数据ID';
comment on column MBT_DM_110_F .DATA_DATE is '数据日期';
comment on column MBT_DM_110_F .CORP_ID is '法人ID';
comment on column MBT_DM_110_F .ORG_ID is '机构ID';
comment on column MBT_DM_110_F .GROUP_ID is '数据分组';
comment on column MBT_DM_110_F .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_F .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_F .F_ACA_DEGREE is '学位';
comment on column MBT_DM_110_F .F_EDU_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_110_F .F_EDU_LEVEL is '学历';
comment on column MBT_DM_110_F .B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_F .B_ID_NUM is '证件号码';
comment on column MBT_DM_110_F .B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_F .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_F .CUST_NO is '客户号';
comment on column MBT_DM_110_F .UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_F .PART_TYPE is '段标识';
comment on column MBT_DM_110_F .PART_NAME is '段名称';
comment on column MBT_DM_110_F .START_DATE is '起始日期';
comment on column MBT_DM_110_F .END_DATE is '结束日期';
comment on column MBT_DM_110_F .BATCH_NO is '批次号';
comment on column MBT_DM_110_F .ROW_NUM is '行号';
comment on column MBT_DM_110_F .IS_RPT is '是否报送';
comment on column MBT_DM_110_F .IS_VALID is '是否有效';
comment on column MBT_DM_110_F .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_F .OPT_FLAG is '操作标识';
comment on column MBT_DM_110_F .RPT_DATE is '报送日期';
comment on column MBT_DM_110_F .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_F .RPT_STATUS is '报送状态';
comment on column MBT_DM_110_F .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_F .RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_F .RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_F .REMARKS is '备注';
comment on column MBT_DM_110_F .CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_F .CHECK_DESC is '校验说明';
comment on column MBT_DM_110_F .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_F .NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_F .DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_F .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_F .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_F .DATA_FLAG is '数据标志';
comment on column MBT_DM_110_F .DATA_OP is '操作标志';
comment on column MBT_DM_110_F .DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_F .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_F .DATA_HASH is '数据HASH';
comment on column MBT_DM_110_F .DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_F .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_F .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_F .DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_F .DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_F .DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_F .DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_F .DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_F .DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_F .DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_F .DATA_APV_USER is '审核人';
comment on column MBT_DM_110_F .DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_F .DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_F .RSV1 is '备用字段';
comment on column MBT_DM_110_F .RSV2 is '备用字段';
comment on column MBT_DM_110_F .RSV3 is '备用字段';
comment on column MBT_DM_110_F .RSV4 is '备用字段';
comment on column MBT_DM_110_F .RSV5 is '备用字段';
create table MBT_DM_110_F (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
F_ACA_DEGREE VARCHAR(1),
F_EDU_INFO_UP_DATE VARCHAR(8),
F_EDU_LEVEL VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_F is '个人基本信息-教育信息段';
comment on column MBT_DM_110_F.DATA_ID is '数据ID';
comment on column MBT_DM_110_F.DATA_DATE is '数据日期';
comment on column MBT_DM_110_F.CORP_ID is '法人ID';
comment on column MBT_DM_110_F.ORG_ID is '机构ID';
comment on column MBT_DM_110_F.GROUP_ID is '数据分组';
comment on column MBT_DM_110_F.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_F.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_F.F_ACA_DEGREE is '学位';
comment on column MBT_DM_110_F.F_EDU_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_110_F.F_EDU_LEVEL is '学历';
comment on column MBT_DM_110_F.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_F.B_ID_NUM is '证件号码';
comment on column MBT_DM_110_F.B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_F.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_F.CUST_NO is '客户号';
comment on column MBT_DM_110_F.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_F.PART_TYPE is '段标识';
comment on column MBT_DM_110_F.PART_NAME is '段名称';
comment on column MBT_DM_110_F.START_DATE is '起始日期';
comment on column MBT_DM_110_F.END_DATE is '结束日期';
comment on column MBT_DM_110_F.BATCH_NO is '批次号';
comment on column MBT_DM_110_F.ROW_NUM is '行号';
comment on column MBT_DM_110_F.IS_RPT is '是否报送';
comment on column MBT_DM_110_F.IS_VALID is '是否有效';
comment on column MBT_DM_110_F.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_F.OPT_FLAG is '操作标识';
comment on column MBT_DM_110_F.RPT_DATE is '报送日期';
comment on column MBT_DM_110_F.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_F.RPT_STATUS is '报送状态';
comment on column MBT_DM_110_F.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_F.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_F.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_F.REMARKS is '备注';
comment on column MBT_DM_110_F.CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_F.CHECK_DESC is '校验说明';
comment on column MBT_DM_110_F.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_F.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_F.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_F.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_F.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_F.DATA_FLAG is '数据标志';
comment on column MBT_DM_110_F.DATA_OP is '操作标志';
comment on column MBT_DM_110_F.DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_F.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_F.DATA_HASH is '数据HASH';
comment on column MBT_DM_110_F.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_F.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_F.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_F.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_F.DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_F.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_F.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_F.DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_F.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_F.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_F.DATA_APV_USER is '审核人';
comment on column MBT_DM_110_F.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_F.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_F.RSV1 is '备用字段';
comment on column MBT_DM_110_F.RSV2 is '备用字段';
comment on column MBT_DM_110_F.RSV3 is '备用字段';
comment on column MBT_DM_110_F.RSV4 is '备用字段';
comment on column MBT_DM_110_F.RSV5 is '备用字段';
create table MBT_DM_110_G  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_CPN_ADDR VARCHAR(200),
G_CPN_DIST VARCHAR(6),
G_CPN_NAME VARCHAR(160),
G_CPN_PC VARCHAR(6),
G_CPN_TEL VARCHAR(50),
G_CPN_TYPE VARCHAR(2),
G_EMP_STATUS VARCHAR(2),
G_INDUSTRY VARCHAR(1),
G_OCCUPATION VARCHAR(1),
G_OCTPN_INFO_UP_DATE VARCHAR(8),
G_TECH_TITLE VARCHAR(1),
G_TITLE VARCHAR(1),
G_WORK_START_DATE VARCHAR(4),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_G  is '个人基本信息-职业信息段';
comment on column MBT_DM_110_G .DATA_ID is '数据ID';
comment on column MBT_DM_110_G .DATA_DATE is '数据日期';
comment on column MBT_DM_110_G .CORP_ID is '法人ID';
comment on column MBT_DM_110_G .ORG_ID is '机构ID';
comment on column MBT_DM_110_G .GROUP_ID is '数据分组';
comment on column MBT_DM_110_G .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_G .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_G .G_CPN_ADDR is '单位详细地址';
comment on column MBT_DM_110_G .G_CPN_DIST is '单位所在地行政区划';
comment on column MBT_DM_110_G .G_CPN_NAME is '单位名称';
comment on column MBT_DM_110_G .G_CPN_PC is '单位所在地邮编';
comment on column MBT_DM_110_G .G_CPN_TEL is '单位电话';
comment on column MBT_DM_110_G .G_CPN_TYPE is '单位性质';
comment on column MBT_DM_110_G .G_EMP_STATUS is '就业状况';
comment on column MBT_DM_110_G .G_INDUSTRY is '单位所属行业';
comment on column MBT_DM_110_G .G_OCCUPATION is '职业';
comment on column MBT_DM_110_G .G_OCTPN_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_110_G .G_TECH_TITLE is '职称';
comment on column MBT_DM_110_G .G_TITLE is '职务';
comment on column MBT_DM_110_G .G_WORK_START_DATE is '本单位工作起始年份';
comment on column MBT_DM_110_G .B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_G .B_ID_NUM is '证件号码';
comment on column MBT_DM_110_G .B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_G .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_G .CUST_NO is '客户号';
comment on column MBT_DM_110_G .UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_G .PART_TYPE is '段标识';
comment on column MBT_DM_110_G .PART_NAME is '段名称';
comment on column MBT_DM_110_G .START_DATE is '起始日期';
comment on column MBT_DM_110_G .END_DATE is '结束日期';
comment on column MBT_DM_110_G .BATCH_NO is '批次号';
comment on column MBT_DM_110_G .ROW_NUM is '行号';
comment on column MBT_DM_110_G .IS_RPT is '是否报送';
comment on column MBT_DM_110_G .IS_VALID is '是否有效';
comment on column MBT_DM_110_G .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_G .OPT_FLAG is '操作标识';
comment on column MBT_DM_110_G .RPT_DATE is '报送日期';
comment on column MBT_DM_110_G .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_G .RPT_STATUS is '报送状态';
comment on column MBT_DM_110_G .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_G .RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_G .RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_G .REMARKS is '备注';
comment on column MBT_DM_110_G .CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_G .CHECK_DESC is '校验说明';
comment on column MBT_DM_110_G .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_G .NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_G .DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_G .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_G .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_G .DATA_FLAG is '数据标志';
comment on column MBT_DM_110_G .DATA_OP is '操作标志';
comment on column MBT_DM_110_G .DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_G .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_G .DATA_HASH is '数据HASH';
comment on column MBT_DM_110_G .DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_G .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_G .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_G .DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_G .DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_G .DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_G .DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_G .DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_G .DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_G .DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_G .DATA_APV_USER is '审核人';
comment on column MBT_DM_110_G .DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_G .DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_G .RSV1 is '备用字段';
comment on column MBT_DM_110_G .RSV2 is '备用字段';
comment on column MBT_DM_110_G .RSV3 is '备用字段';
comment on column MBT_DM_110_G .RSV4 is '备用字段';
comment on column MBT_DM_110_G .RSV5 is '备用字段';
create table MBT_DM_110_G (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_CPN_ADDR VARCHAR(200),
G_CPN_DIST VARCHAR(6),
G_CPN_NAME VARCHAR(160),
G_CPN_PC VARCHAR(6),
G_CPN_TEL VARCHAR(50),
G_CPN_TYPE VARCHAR(2),
G_EMP_STATUS VARCHAR(2),
G_INDUSTRY VARCHAR(1),
G_OCCUPATION VARCHAR(1),
G_OCTPN_INFO_UP_DATE VARCHAR(8),
G_TECH_TITLE VARCHAR(1),
G_TITLE VARCHAR(1),
G_WORK_START_DATE VARCHAR(4),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_G is '个人基本信息-职业信息段';
comment on column MBT_DM_110_G.DATA_ID is '数据ID';
comment on column MBT_DM_110_G.DATA_DATE is '数据日期';
comment on column MBT_DM_110_G.CORP_ID is '法人ID';
comment on column MBT_DM_110_G.ORG_ID is '机构ID';
comment on column MBT_DM_110_G.GROUP_ID is '数据分组';
comment on column MBT_DM_110_G.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_G.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_G.G_CPN_ADDR is '单位详细地址';
comment on column MBT_DM_110_G.G_CPN_DIST is '单位所在地行政区划';
comment on column MBT_DM_110_G.G_CPN_NAME is '单位名称';
comment on column MBT_DM_110_G.G_CPN_PC is '单位所在地邮编';
comment on column MBT_DM_110_G.G_CPN_TEL is '单位电话';
comment on column MBT_DM_110_G.G_CPN_TYPE is '单位性质';
comment on column MBT_DM_110_G.G_EMP_STATUS is '就业状况';
comment on column MBT_DM_110_G.G_INDUSTRY is '单位所属行业';
comment on column MBT_DM_110_G.G_OCCUPATION is '职业';
comment on column MBT_DM_110_G.G_OCTPN_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_110_G.G_TECH_TITLE is '职称';
comment on column MBT_DM_110_G.G_TITLE is '职务';
comment on column MBT_DM_110_G.G_WORK_START_DATE is '本单位工作起始年份';
comment on column MBT_DM_110_G.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_G.B_ID_NUM is '证件号码';
comment on column MBT_DM_110_G.B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_G.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_G.CUST_NO is '客户号';
comment on column MBT_DM_110_G.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_G.PART_TYPE is '段标识';
comment on column MBT_DM_110_G.PART_NAME is '段名称';
comment on column MBT_DM_110_G.START_DATE is '起始日期';
comment on column MBT_DM_110_G.END_DATE is '结束日期';
comment on column MBT_DM_110_G.BATCH_NO is '批次号';
comment on column MBT_DM_110_G.ROW_NUM is '行号';
comment on column MBT_DM_110_G.IS_RPT is '是否报送';
comment on column MBT_DM_110_G.IS_VALID is '是否有效';
comment on column MBT_DM_110_G.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_G.OPT_FLAG is '操作标识';
comment on column MBT_DM_110_G.RPT_DATE is '报送日期';
comment on column MBT_DM_110_G.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_G.RPT_STATUS is '报送状态';
comment on column MBT_DM_110_G.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_G.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_G.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_G.REMARKS is '备注';
comment on column MBT_DM_110_G.CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_G.CHECK_DESC is '校验说明';
comment on column MBT_DM_110_G.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_G.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_G.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_G.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_G.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_G.DATA_FLAG is '数据标志';
comment on column MBT_DM_110_G.DATA_OP is '操作标志';
comment on column MBT_DM_110_G.DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_G.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_G.DATA_HASH is '数据HASH';
comment on column MBT_DM_110_G.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_G.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_G.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_G.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_G.DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_G.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_G.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_G.DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_G.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_G.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_G.DATA_APV_USER is '审核人';
comment on column MBT_DM_110_G.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_G.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_G.RSV1 is '备用字段';
comment on column MBT_DM_110_G.RSV2 is '备用字段';
comment on column MBT_DM_110_G.RSV3 is '备用字段';
comment on column MBT_DM_110_G.RSV4 is '备用字段';
comment on column MBT_DM_110_G.RSV5 is '备用字段';
create table MBT_DM_110_H  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
H_HOME_TEL VARCHAR(50),
H_RESI_ADDR VARCHAR(200),
H_RESI_DIST VARCHAR(6),
H_RESI_INFO_UP_DATE VARCHAR(8),
H_RESI_PC VARCHAR(6),
H_RESI_STATUS VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_H  is '个人基本信息-居住地址段';
comment on column MBT_DM_110_H .DATA_ID is '数据ID';
comment on column MBT_DM_110_H .DATA_DATE is '数据日期';
comment on column MBT_DM_110_H .CORP_ID is '法人ID';
comment on column MBT_DM_110_H .ORG_ID is '机构ID';
comment on column MBT_DM_110_H .GROUP_ID is '数据分组';
comment on column MBT_DM_110_H .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_H .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_H .H_HOME_TEL is '住宅电话';
comment on column MBT_DM_110_H .H_RESI_ADDR is '居住地详细地址';
comment on column MBT_DM_110_H .H_RESI_DIST is '居住地行政区划';
comment on column MBT_DM_110_H .H_RESI_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_110_H .H_RESI_PC is '居住地邮编';
comment on column MBT_DM_110_H .H_RESI_STATUS is '居住状况';
comment on column MBT_DM_110_H .B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_H .B_ID_NUM is '证件号码';
comment on column MBT_DM_110_H .B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_H .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_H .CUST_NO is '客户号';
comment on column MBT_DM_110_H .UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_H .PART_TYPE is '段标识';
comment on column MBT_DM_110_H .PART_NAME is '段名称';
comment on column MBT_DM_110_H .START_DATE is '起始日期';
comment on column MBT_DM_110_H .END_DATE is '结束日期';
comment on column MBT_DM_110_H .BATCH_NO is '批次号';
comment on column MBT_DM_110_H .ROW_NUM is '行号';
comment on column MBT_DM_110_H .IS_RPT is '是否报送';
comment on column MBT_DM_110_H .IS_VALID is '是否有效';
comment on column MBT_DM_110_H .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_H .OPT_FLAG is '操作标识';
comment on column MBT_DM_110_H .RPT_DATE is '报送日期';
comment on column MBT_DM_110_H .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_H .RPT_STATUS is '报送状态';
comment on column MBT_DM_110_H .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_H .RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_H .RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_H .REMARKS is '备注';
comment on column MBT_DM_110_H .CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_H .CHECK_DESC is '校验说明';
comment on column MBT_DM_110_H .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_H .NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_H .DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_H .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_H .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_H .DATA_FLAG is '数据标志';
comment on column MBT_DM_110_H .DATA_OP is '操作标志';
comment on column MBT_DM_110_H .DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_H .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_H .DATA_HASH is '数据HASH';
comment on column MBT_DM_110_H .DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_H .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_H .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_H .DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_H .DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_H .DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_H .DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_H .DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_H .DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_H .DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_H .DATA_APV_USER is '审核人';
comment on column MBT_DM_110_H .DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_H .DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_H .RSV1 is '备用字段';
comment on column MBT_DM_110_H .RSV2 is '备用字段';
comment on column MBT_DM_110_H .RSV3 is '备用字段';
comment on column MBT_DM_110_H .RSV4 is '备用字段';
comment on column MBT_DM_110_H .RSV5 is '备用字段';
create table MBT_DM_110_H (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
H_HOME_TEL VARCHAR(50),
H_RESI_ADDR VARCHAR(200),
H_RESI_DIST VARCHAR(6),
H_RESI_INFO_UP_DATE VARCHAR(8),
H_RESI_PC VARCHAR(6),
H_RESI_STATUS VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_H is '个人基本信息-居住地址段';
comment on column MBT_DM_110_H.DATA_ID is '数据ID';
comment on column MBT_DM_110_H.DATA_DATE is '数据日期';
comment on column MBT_DM_110_H.CORP_ID is '法人ID';
comment on column MBT_DM_110_H.ORG_ID is '机构ID';
comment on column MBT_DM_110_H.GROUP_ID is '数据分组';
comment on column MBT_DM_110_H.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_H.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_H.H_HOME_TEL is '住宅电话';
comment on column MBT_DM_110_H.H_RESI_ADDR is '居住地详细地址';
comment on column MBT_DM_110_H.H_RESI_DIST is '居住地行政区划';
comment on column MBT_DM_110_H.H_RESI_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_110_H.H_RESI_PC is '居住地邮编';
comment on column MBT_DM_110_H.H_RESI_STATUS is '居住状况';
comment on column MBT_DM_110_H.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_H.B_ID_NUM is '证件号码';
comment on column MBT_DM_110_H.B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_H.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_H.CUST_NO is '客户号';
comment on column MBT_DM_110_H.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_H.PART_TYPE is '段标识';
comment on column MBT_DM_110_H.PART_NAME is '段名称';
comment on column MBT_DM_110_H.START_DATE is '起始日期';
comment on column MBT_DM_110_H.END_DATE is '结束日期';
comment on column MBT_DM_110_H.BATCH_NO is '批次号';
comment on column MBT_DM_110_H.ROW_NUM is '行号';
comment on column MBT_DM_110_H.IS_RPT is '是否报送';
comment on column MBT_DM_110_H.IS_VALID is '是否有效';
comment on column MBT_DM_110_H.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_H.OPT_FLAG is '操作标识';
comment on column MBT_DM_110_H.RPT_DATE is '报送日期';
comment on column MBT_DM_110_H.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_H.RPT_STATUS is '报送状态';
comment on column MBT_DM_110_H.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_H.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_H.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_H.REMARKS is '备注';
comment on column MBT_DM_110_H.CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_H.CHECK_DESC is '校验说明';
comment on column MBT_DM_110_H.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_H.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_H.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_H.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_H.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_H.DATA_FLAG is '数据标志';
comment on column MBT_DM_110_H.DATA_OP is '操作标志';
comment on column MBT_DM_110_H.DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_H.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_H.DATA_HASH is '数据HASH';
comment on column MBT_DM_110_H.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_H.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_H.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_H.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_H.DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_H.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_H.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_H.DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_H.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_H.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_H.DATA_APV_USER is '审核人';
comment on column MBT_DM_110_H.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_H.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_H.RSV1 is '备用字段';
comment on column MBT_DM_110_H.RSV2 is '备用字段';
comment on column MBT_DM_110_H.RSV3 is '备用字段';
comment on column MBT_DM_110_H.RSV4 is '备用字段';
comment on column MBT_DM_110_H.RSV5 is '备用字段';
create table MBT_DM_110_I  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
I_MAIL_ADDR VARCHAR(200),
I_MAIL_DIST VARCHAR(6),
I_MAIL_PC VARCHAR(6),
I_MLG_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_I  is '个人基本信息-通讯地址段';
comment on column MBT_DM_110_I .DATA_ID is '数据ID';
comment on column MBT_DM_110_I .DATA_DATE is '数据日期';
comment on column MBT_DM_110_I .CORP_ID is '法人ID';
comment on column MBT_DM_110_I .ORG_ID is '机构ID';
comment on column MBT_DM_110_I .GROUP_ID is '数据分组';
comment on column MBT_DM_110_I .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_I .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_I .I_MAIL_ADDR is '通讯地址';
comment on column MBT_DM_110_I .I_MAIL_DIST is '通讯地行政区划';
comment on column MBT_DM_110_I .I_MAIL_PC is '通讯地邮编';
comment on column MBT_DM_110_I .I_MLG_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_110_I .B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_I .B_ID_NUM is '证件号码';
comment on column MBT_DM_110_I .B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_I .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_I .CUST_NO is '客户号';
comment on column MBT_DM_110_I .UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_I .PART_TYPE is '段标识';
comment on column MBT_DM_110_I .PART_NAME is '段名称';
comment on column MBT_DM_110_I .START_DATE is '起始日期';
comment on column MBT_DM_110_I .END_DATE is '结束日期';
comment on column MBT_DM_110_I .BATCH_NO is '批次号';
comment on column MBT_DM_110_I .ROW_NUM is '行号';
comment on column MBT_DM_110_I .IS_RPT is '是否报送';
comment on column MBT_DM_110_I .IS_VALID is '是否有效';
comment on column MBT_DM_110_I .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_I .OPT_FLAG is '操作标识';
comment on column MBT_DM_110_I .RPT_DATE is '报送日期';
comment on column MBT_DM_110_I .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_I .RPT_STATUS is '报送状态';
comment on column MBT_DM_110_I .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_I .RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_I .RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_I .REMARKS is '备注';
comment on column MBT_DM_110_I .CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_I .CHECK_DESC is '校验说明';
comment on column MBT_DM_110_I .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_I .NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_I .DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_I .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_I .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_I .DATA_FLAG is '数据标志';
comment on column MBT_DM_110_I .DATA_OP is '操作标志';
comment on column MBT_DM_110_I .DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_I .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_I .DATA_HASH is '数据HASH';
comment on column MBT_DM_110_I .DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_I .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_I .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_I .DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_I .DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_I .DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_I .DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_I .DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_I .DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_I .DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_I .DATA_APV_USER is '审核人';
comment on column MBT_DM_110_I .DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_I .DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_I .RSV1 is '备用字段';
comment on column MBT_DM_110_I .RSV2 is '备用字段';
comment on column MBT_DM_110_I .RSV3 is '备用字段';
comment on column MBT_DM_110_I .RSV4 is '备用字段';
comment on column MBT_DM_110_I .RSV5 is '备用字段';
create table MBT_DM_110_I (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
I_MAIL_ADDR VARCHAR(200),
I_MAIL_DIST VARCHAR(6),
I_MAIL_PC VARCHAR(6),
I_MLG_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_I is '个人基本信息-通讯地址段';
comment on column MBT_DM_110_I.DATA_ID is '数据ID';
comment on column MBT_DM_110_I.DATA_DATE is '数据日期';
comment on column MBT_DM_110_I.CORP_ID is '法人ID';
comment on column MBT_DM_110_I.ORG_ID is '机构ID';
comment on column MBT_DM_110_I.GROUP_ID is '数据分组';
comment on column MBT_DM_110_I.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_I.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_I.I_MAIL_ADDR is '通讯地址';
comment on column MBT_DM_110_I.I_MAIL_DIST is '通讯地行政区划';
comment on column MBT_DM_110_I.I_MAIL_PC is '通讯地邮编';
comment on column MBT_DM_110_I.I_MLG_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_110_I.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_I.B_ID_NUM is '证件号码';
comment on column MBT_DM_110_I.B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_I.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_I.CUST_NO is '客户号';
comment on column MBT_DM_110_I.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_I.PART_TYPE is '段标识';
comment on column MBT_DM_110_I.PART_NAME is '段名称';
comment on column MBT_DM_110_I.START_DATE is '起始日期';
comment on column MBT_DM_110_I.END_DATE is '结束日期';
comment on column MBT_DM_110_I.BATCH_NO is '批次号';
comment on column MBT_DM_110_I.ROW_NUM is '行号';
comment on column MBT_DM_110_I.IS_RPT is '是否报送';
comment on column MBT_DM_110_I.IS_VALID is '是否有效';
comment on column MBT_DM_110_I.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_I.OPT_FLAG is '操作标识';
comment on column MBT_DM_110_I.RPT_DATE is '报送日期';
comment on column MBT_DM_110_I.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_I.RPT_STATUS is '报送状态';
comment on column MBT_DM_110_I.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_I.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_I.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_I.REMARKS is '备注';
comment on column MBT_DM_110_I.CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_I.CHECK_DESC is '校验说明';
comment on column MBT_DM_110_I.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_I.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_I.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_I.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_I.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_I.DATA_FLAG is '数据标志';
comment on column MBT_DM_110_I.DATA_OP is '操作标志';
comment on column MBT_DM_110_I.DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_I.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_I.DATA_HASH is '数据HASH';
comment on column MBT_DM_110_I.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_I.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_I.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_I.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_I.DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_I.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_I.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_I.DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_I.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_I.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_I.DATA_APV_USER is '审核人';
comment on column MBT_DM_110_I.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_I.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_I.RSV1 is '备用字段';
comment on column MBT_DM_110_I.RSV2 is '备用字段';
comment on column MBT_DM_110_I.RSV3 is '备用字段';
comment on column MBT_DM_110_I.RSV4 is '备用字段';
comment on column MBT_DM_110_I.RSV5 is '备用字段';
create table MBT_DM_110_J (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
J_ANNL_INC NUMBER(15),
J_ANNL_INC_LCY NUMBER(15),
J_ANNL_INC_ORG NUMBER(15),
J_INC_INFO_UP_DATE VARCHAR(8),
J_TAX_INCOME NUMBER(15),
J_TAX_INCOME_LCY NUMBER(15),
J_TAX_INCOME_ORG NUMBER(15),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_110_J is '个人基本信息-收入信息段';
comment on column MBT_DM_110_J.DATA_ID is '数据ID';
comment on column MBT_DM_110_J.DATA_DATE is '数据日期';
comment on column MBT_DM_110_J.CORP_ID is '法人ID';
comment on column MBT_DM_110_J.ORG_ID is '机构ID';
comment on column MBT_DM_110_J.GROUP_ID is '数据分组';
comment on column MBT_DM_110_J.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_110_J.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_110_J.J_ANNL_INC is '自报年收入';
comment on column MBT_DM_110_J.J_ANNL_INC_LCY is '自报年收入人民币金额';
comment on column MBT_DM_110_J.J_ANNL_INC_ORG is '自报年收入_原始数据金额';
comment on column MBT_DM_110_J.J_INC_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_110_J.J_TAX_INCOME is '纳税年收入';
comment on column MBT_DM_110_J.J_TAX_INCOME_LCY is '纳税年收入人民币金额';
comment on column MBT_DM_110_J.J_TAX_INCOME_ORG is '纳税年收入_原始数据金额';
comment on column MBT_DM_110_J.C_CY is '币种';
comment on column MBT_DM_110_J.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_110_J.B_ID_NUM is '证件号码';
comment on column MBT_DM_110_J.B_ID_TYPE is '证件类型';
comment on column MBT_DM_110_J.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_110_J.CUST_NO is '客户号';
comment on column MBT_DM_110_J.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_110_J.PART_TYPE is '段标识';
comment on column MBT_DM_110_J.PART_NAME is '段名称';
comment on column MBT_DM_110_J.START_DATE is '起始日期';
comment on column MBT_DM_110_J.END_DATE is '结束日期';
comment on column MBT_DM_110_J.BATCH_NO is '批次号';
comment on column MBT_DM_110_J.ROW_NUM is '行号';
comment on column MBT_DM_110_J.IS_RPT is '是否报送';
comment on column MBT_DM_110_J.IS_VALID is '是否有效';
comment on column MBT_DM_110_J.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_110_J.OPT_FLAG is '操作标识';
comment on column MBT_DM_110_J.RPT_DATE is '报送日期';
comment on column MBT_DM_110_J.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_110_J.RPT_STATUS is '报送状态';
comment on column MBT_DM_110_J.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_110_J.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_110_J.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_110_J.REMARKS is '备注';
comment on column MBT_DM_110_J.CHECK_FLAG is '校验标志';
comment on column MBT_DM_110_J.CHECK_DESC is '校验说明';
comment on column MBT_DM_110_J.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_110_J.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_110_J.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_110_J.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_110_J.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_110_J.DATA_FLAG is '数据标志';
comment on column MBT_DM_110_J.DATA_OP is '操作标志';
comment on column MBT_DM_110_J.DATA_SOURCE is '数据来源';
comment on column MBT_DM_110_J.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_110_J.DATA_HASH is '数据HASH';
comment on column MBT_DM_110_J.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_J.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_110_J.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_110_J.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_110_J.DATA_CRT_USER is '创建人';
comment on column MBT_DM_110_J.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_110_J.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_110_J.DATA_CHG_USER is '修改人';
comment on column MBT_DM_110_J.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_110_J.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_110_J.DATA_APV_USER is '审核人';
comment on column MBT_DM_110_J.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_110_J.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_110_J.RSV1 is '备用字段';
comment on column MBT_DM_110_J.RSV2 is '备用字段';
comment on column MBT_DM_110_J.RSV3 is '备用字段';
comment on column MBT_DM_110_J.RSV4 is '备用字段';
comment on column MBT_DM_110_J.RSV5 is '备用字段';
create table MBT_PM_110 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110 is '个人基本信息';
comment on column MBT_PM_110.DATA_ID is '数据ID';
comment on column MBT_PM_110.DATA_DATE is '数据日期';
comment on column MBT_PM_110.CORP_ID is '法人ID';
comment on column MBT_PM_110.ORG_ID is '机构ID';
comment on column MBT_PM_110.GROUP_ID is '数据分组';
comment on column MBT_PM_110.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110.B_ID_NUM is '证件号码';
comment on column MBT_PM_110.B_ID_TYPE is '证件类型';
comment on column MBT_PM_110.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110.SECTION_CHG_CNT is '段变更';
comment on column MBT_PM_110.SECTION_DEL_CNT is '段删除';
comment on column MBT_PM_110.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_PM_110.IDN_CHG_CNT is '标识项变更';
comment on column MBT_PM_110.CUST_NO is '客户号';
comment on column MBT_PM_110.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110.PART_TYPE is '段标识';
comment on column MBT_PM_110.PART_NAME is '段名称';
comment on column MBT_PM_110.START_DATE is '起始日期';
comment on column MBT_PM_110.END_DATE is '结束日期';
comment on column MBT_PM_110.BATCH_NO is '批次号';
comment on column MBT_PM_110.ROW_NUM is '行号';
comment on column MBT_PM_110.IS_RPT is '是否报送';
comment on column MBT_PM_110.IS_VALID is '是否有效';
comment on column MBT_PM_110.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110.OPT_FLAG is '操作标识';
comment on column MBT_PM_110.RPT_DATE is '报送日期';
comment on column MBT_PM_110.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110.RPT_STATUS is '报送状态';
comment on column MBT_PM_110.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110.REMARKS is '备注';
comment on column MBT_PM_110.CHECK_FLAG is '校验标志';
comment on column MBT_PM_110.CHECK_DESC is '校验说明';
comment on column MBT_PM_110.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110.DATA_FLAG is '数据标志';
comment on column MBT_PM_110.DATA_OP is '操作标志';
comment on column MBT_PM_110.DATA_SOURCE is '数据来源';
comment on column MBT_PM_110.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110.DATA_HASH is '数据HASH';
comment on column MBT_PM_110.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110.DATA_CRT_USER is '创建人';
comment on column MBT_PM_110.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110.DATA_CHG_USER is '修改人';
comment on column MBT_PM_110.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110.DATA_APV_USER is '审核人';
comment on column MBT_PM_110.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110.RSV1 is '备用字段';
comment on column MBT_PM_110.RSV2 is '备用字段';
comment on column MBT_PM_110.RSV3 is '备用字段';
comment on column MBT_PM_110.RSV4 is '备用字段';
comment on column MBT_PM_110.RSV5 is '备用字段';
create table MBT_PM_110_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_CIMOC VARCHAR(14),
B_CUSTOMER_TYPE VARCHAR(2),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
B_INF_REC_TYPE VARCHAR(3),
B_NAME VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_B is '个人基本信息-基础段';
comment on column MBT_PM_110_B.DATA_ID is '数据ID';
comment on column MBT_PM_110_B.DATA_DATE is '数据日期';
comment on column MBT_PM_110_B.CORP_ID is '法人ID';
comment on column MBT_PM_110_B.ORG_ID is '机构ID';
comment on column MBT_PM_110_B.GROUP_ID is '数据分组';
comment on column MBT_PM_110_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_PM_110_B.B_CUSTOMER_TYPE is '客户资料类型';
comment on column MBT_PM_110_B.B_ID_NUM is '证件号码';
comment on column MBT_PM_110_B.B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_PM_110_B.B_NAME is '姓名';
comment on column MBT_PM_110_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_PM_110_B.CUST_NO is '客户号';
comment on column MBT_PM_110_B.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_B.PART_TYPE is '段标识';
comment on column MBT_PM_110_B.PART_NAME is '段名称';
comment on column MBT_PM_110_B.START_DATE is '起始日期';
comment on column MBT_PM_110_B.END_DATE is '结束日期';
comment on column MBT_PM_110_B.BATCH_NO is '批次号';
comment on column MBT_PM_110_B.ROW_NUM is '行号';
comment on column MBT_PM_110_B.IS_RPT is '是否报送';
comment on column MBT_PM_110_B.IS_VALID is '是否有效';
comment on column MBT_PM_110_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_B.OPT_FLAG is '操作标识';
comment on column MBT_PM_110_B.RPT_DATE is '报送日期';
comment on column MBT_PM_110_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_B.RPT_STATUS is '报送状态';
comment on column MBT_PM_110_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_B.REMARKS is '备注';
comment on column MBT_PM_110_B.CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_B.CHECK_DESC is '校验说明';
comment on column MBT_PM_110_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_B.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_B.DATA_FLAG is '数据标志';
comment on column MBT_PM_110_B.DATA_OP is '操作标志';
comment on column MBT_PM_110_B.DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_B.DATA_HASH is '数据HASH';
comment on column MBT_PM_110_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_B.DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_B.DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_B.DATA_APV_USER is '审核人';
comment on column MBT_PM_110_B.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_B.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_B.RSV1 is '备用字段';
comment on column MBT_PM_110_B.RSV2 is '备用字段';
comment on column MBT_PM_110_B.RSV3 is '备用字段';
comment on column MBT_PM_110_B.RSV4 is '备用字段';
comment on column MBT_PM_110_B.RSV5 is '备用字段';
create table MBT_PM_110_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
OTH_ID_NUM VARCHAR(40),
OTH_ID_TYPE VARCHAR(2),
ALIAS VARCHAR(60),
ID_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_C is '个人基本信息-其他标识段';
comment on column MBT_PM_110_C.DATA_ID is '数据ID';
comment on column MBT_PM_110_C.DATA_DATE is '数据日期';
comment on column MBT_PM_110_C.CORP_ID is '法人ID';
comment on column MBT_PM_110_C.ORG_ID is '机构ID';
comment on column MBT_PM_110_C.GROUP_ID is '数据分组';
comment on column MBT_PM_110_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_C.OTH_ID_NUM is '证件号码';
comment on column MBT_PM_110_C.OTH_ID_TYPE is '证件类型';
comment on column MBT_PM_110_C.ALIAS is '姓名';
comment on column MBT_PM_110_C.ID_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_110_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_C.B_ID_NUM is '证件号码';
comment on column MBT_PM_110_C.B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_C.CUST_NO is '客户号';
comment on column MBT_PM_110_C.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_C.PART_TYPE is '段标识';
comment on column MBT_PM_110_C.PART_NAME is '段名称';
comment on column MBT_PM_110_C.START_DATE is '起始日期';
comment on column MBT_PM_110_C.END_DATE is '结束日期';
comment on column MBT_PM_110_C.BATCH_NO is '批次号';
comment on column MBT_PM_110_C.ROW_NUM is '行号';
comment on column MBT_PM_110_C.IS_RPT is '是否报送';
comment on column MBT_PM_110_C.IS_VALID is '是否有效';
comment on column MBT_PM_110_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_C.OPT_FLAG is '操作标识';
comment on column MBT_PM_110_C.RPT_DATE is '报送日期';
comment on column MBT_PM_110_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_C.RPT_STATUS is '报送状态';
comment on column MBT_PM_110_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_C.REMARKS is '备注';
comment on column MBT_PM_110_C.CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_C.CHECK_DESC is '校验说明';
comment on column MBT_PM_110_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_C.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_C.DATA_FLAG is '数据标志';
comment on column MBT_PM_110_C.DATA_OP is '操作标志';
comment on column MBT_PM_110_C.DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_C.DATA_HASH is '数据HASH';
comment on column MBT_PM_110_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_C.DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_C.DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_C.DATA_APV_USER is '审核人';
comment on column MBT_PM_110_C.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_C.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_C.RSV1 is '备用字段';
comment on column MBT_PM_110_C.RSV2 is '备用字段';
comment on column MBT_PM_110_C.RSV3 is '备用字段';
comment on column MBT_PM_110_C.RSV4 is '备用字段';
comment on column MBT_PM_110_C.RSV5 is '备用字段';
create table MBT_PM_110_D  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_CELL_PHONE VARCHAR(11),
D_DOB VARCHAR(8),
D_EMAIL VARCHAR(120),
D_FCS_INFO_UP_DATE VARCHAR(8),
D_HH_DIST VARCHAR(6),
D_HOUSE_ADD VARCHAR(200),
D_NATION VARCHAR(3),
D_SEX VARCHAR(1),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_D  is '个人基本信息-基本概况段';
comment on column MBT_PM_110_D .DATA_ID is '数据ID';
comment on column MBT_PM_110_D .DATA_DATE is '数据日期';
comment on column MBT_PM_110_D .CORP_ID is '法人ID';
comment on column MBT_PM_110_D .ORG_ID is '机构ID';
comment on column MBT_PM_110_D .GROUP_ID is '数据分组';
comment on column MBT_PM_110_D .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_D .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_D .D_CELL_PHONE is '手机号码';
comment on column MBT_PM_110_D .D_DOB is '出生日期';
comment on column MBT_PM_110_D .D_EMAIL is '电子邮箱';
comment on column MBT_PM_110_D .D_FCS_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_110_D .D_HH_DIST is '户籍所在地行政区划';
comment on column MBT_PM_110_D .D_HOUSE_ADD is '户籍地址';
comment on column MBT_PM_110_D .D_NATION is '国籍';
comment on column MBT_PM_110_D .D_SEX is '性别';
comment on column MBT_PM_110_D .B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_D .B_ID_NUM is '证件号码';
comment on column MBT_PM_110_D .B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_D .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_D .CUST_NO is '客户号';
comment on column MBT_PM_110_D .UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_D .PART_TYPE is '段标识';
comment on column MBT_PM_110_D .PART_NAME is '段名称';
comment on column MBT_PM_110_D .START_DATE is '起始日期';
comment on column MBT_PM_110_D .END_DATE is '结束日期';
comment on column MBT_PM_110_D .BATCH_NO is '批次号';
comment on column MBT_PM_110_D .ROW_NUM is '行号';
comment on column MBT_PM_110_D .IS_RPT is '是否报送';
comment on column MBT_PM_110_D .IS_VALID is '是否有效';
comment on column MBT_PM_110_D .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_D .OPT_FLAG is '操作标识';
comment on column MBT_PM_110_D .RPT_DATE is '报送日期';
comment on column MBT_PM_110_D .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_D .RPT_STATUS is '报送状态';
comment on column MBT_PM_110_D .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_D .RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_D .RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_D .REMARKS is '备注';
comment on column MBT_PM_110_D .CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_D .CHECK_DESC is '校验说明';
comment on column MBT_PM_110_D .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_D .NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_D .DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_D .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_D .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_D .DATA_FLAG is '数据标志';
comment on column MBT_PM_110_D .DATA_OP is '操作标志';
comment on column MBT_PM_110_D .DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_D .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_D .DATA_HASH is '数据HASH';
comment on column MBT_PM_110_D .DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_D .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_D .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_D .DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_D .DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_D .DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_D .DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_D .DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_D .DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_D .DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_D .DATA_APV_USER is '审核人';
comment on column MBT_PM_110_D .DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_D .DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_D .RSV1 is '备用字段';
comment on column MBT_PM_110_D .RSV2 is '备用字段';
comment on column MBT_PM_110_D .RSV3 is '备用字段';
comment on column MBT_PM_110_D .RSV4 is '备用字段';
comment on column MBT_PM_110_D .RSV5 is '备用字段';
create table MBT_PM_110_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_CELL_PHONE VARCHAR(12),
D_DOB VARCHAR(8),
D_EMAIL VARCHAR(120),
D_FCS_INFO_UP_DATE VARCHAR(8),
D_HH_DIST VARCHAR(6),
D_HOUSE_ADD VARCHAR(200),
D_NATION VARCHAR(3),
D_SEX VARCHAR(1),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_D is '个人基本信息-基本概况段';
comment on column MBT_PM_110_D.DATA_ID is '数据ID';
comment on column MBT_PM_110_D.DATA_DATE is '数据日期';
comment on column MBT_PM_110_D.CORP_ID is '法人ID';
comment on column MBT_PM_110_D.ORG_ID is '机构ID';
comment on column MBT_PM_110_D.GROUP_ID is '数据分组';
comment on column MBT_PM_110_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_D.D_CELL_PHONE is '手机号码';
comment on column MBT_PM_110_D.D_DOB is '出生日期';
comment on column MBT_PM_110_D.D_EMAIL is '电子邮箱';
comment on column MBT_PM_110_D.D_FCS_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_110_D.D_HH_DIST is '户籍所在地行政区划';
comment on column MBT_PM_110_D.D_HOUSE_ADD is '户籍地址';
comment on column MBT_PM_110_D.D_NATION is '国籍';
comment on column MBT_PM_110_D.D_SEX is '性别';
comment on column MBT_PM_110_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_D.B_ID_NUM is '证件号码';
comment on column MBT_PM_110_D.B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_D.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_D.CUST_NO is '客户号';
comment on column MBT_PM_110_D.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_D.PART_TYPE is '段标识';
comment on column MBT_PM_110_D.PART_NAME is '段名称';
comment on column MBT_PM_110_D.START_DATE is '起始日期';
comment on column MBT_PM_110_D.END_DATE is '结束日期';
comment on column MBT_PM_110_D.BATCH_NO is '批次号';
comment on column MBT_PM_110_D.ROW_NUM is '行号';
comment on column MBT_PM_110_D.IS_RPT is '是否报送';
comment on column MBT_PM_110_D.IS_VALID is '是否有效';
comment on column MBT_PM_110_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_D.OPT_FLAG is '操作标识';
comment on column MBT_PM_110_D.RPT_DATE is '报送日期';
comment on column MBT_PM_110_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_D.RPT_STATUS is '报送状态';
comment on column MBT_PM_110_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_D.REMARKS is '备注';
comment on column MBT_PM_110_D.CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_D.CHECK_DESC is '校验说明';
comment on column MBT_PM_110_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_D.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_D.DATA_FLAG is '数据标志';
comment on column MBT_PM_110_D.DATA_OP is '操作标志';
comment on column MBT_PM_110_D.DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_D.DATA_HASH is '数据HASH';
comment on column MBT_PM_110_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_D.DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_D.DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_D.DATA_APV_USER is '审核人';
comment on column MBT_PM_110_D.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_D.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_D.RSV1 is '备用字段';
comment on column MBT_PM_110_D.RSV2 is '备用字段';
comment on column MBT_PM_110_D.RSV3 is '备用字段';
comment on column MBT_PM_110_D.RSV4 is '备用字段';
comment on column MBT_PM_110_D.RSV5 is '备用字段';
create table MBT_PM_110_E  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
E_MARI_STATUS VARCHAR(2),
E_SPO_ID_NUM VARCHAR(40),
E_SPO_ID_TYPE VARCHAR(2),
E_SPO_NAME VARCHAR(60),
E_SPO_TEL VARCHAR(50),
E_SPS_CMPY_NM VARCHAR(160),
E_SPS_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_E  is '个人基本信息-婚姻信息段';
comment on column MBT_PM_110_E .DATA_ID is '数据ID';
comment on column MBT_PM_110_E .DATA_DATE is '数据日期';
comment on column MBT_PM_110_E .CORP_ID is '法人ID';
comment on column MBT_PM_110_E .ORG_ID is '机构ID';
comment on column MBT_PM_110_E .GROUP_ID is '数据分组';
comment on column MBT_PM_110_E .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_E .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_E .E_MARI_STATUS is '婚姻状况';
comment on column MBT_PM_110_E .E_SPO_ID_NUM is '配偶证件号码';
comment on column MBT_PM_110_E .E_SPO_ID_TYPE is '配偶证件类型';
comment on column MBT_PM_110_E .E_SPO_NAME is '配偶姓名';
comment on column MBT_PM_110_E .E_SPO_TEL is '配偶联系电话';
comment on column MBT_PM_110_E .E_SPS_CMPY_NM is '配偶工作单位';
comment on column MBT_PM_110_E .E_SPS_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_110_E .B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_E .B_ID_NUM is '证件号码';
comment on column MBT_PM_110_E .B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_E .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_E .CUST_NO is '客户号';
comment on column MBT_PM_110_E .UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_E .PART_TYPE is '段标识';
comment on column MBT_PM_110_E .PART_NAME is '段名称';
comment on column MBT_PM_110_E .START_DATE is '起始日期';
comment on column MBT_PM_110_E .END_DATE is '结束日期';
comment on column MBT_PM_110_E .BATCH_NO is '批次号';
comment on column MBT_PM_110_E .ROW_NUM is '行号';
comment on column MBT_PM_110_E .IS_RPT is '是否报送';
comment on column MBT_PM_110_E .IS_VALID is '是否有效';
comment on column MBT_PM_110_E .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_E .OPT_FLAG is '操作标识';
comment on column MBT_PM_110_E .RPT_DATE is '报送日期';
comment on column MBT_PM_110_E .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_E .RPT_STATUS is '报送状态';
comment on column MBT_PM_110_E .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_E .RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_E .RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_E .REMARKS is '备注';
comment on column MBT_PM_110_E .CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_E .CHECK_DESC is '校验说明';
comment on column MBT_PM_110_E .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_E .NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_E .DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_E .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_E .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_E .DATA_FLAG is '数据标志';
comment on column MBT_PM_110_E .DATA_OP is '操作标志';
comment on column MBT_PM_110_E .DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_E .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_E .DATA_HASH is '数据HASH';
comment on column MBT_PM_110_E .DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_E .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_E .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_E .DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_E .DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_E .DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_E .DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_E .DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_E .DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_E .DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_E .DATA_APV_USER is '审核人';
comment on column MBT_PM_110_E .DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_E .DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_E .RSV1 is '备用字段';
comment on column MBT_PM_110_E .RSV2 is '备用字段';
comment on column MBT_PM_110_E .RSV3 is '备用字段';
comment on column MBT_PM_110_E .RSV4 is '备用字段';
comment on column MBT_PM_110_E .RSV5 is '备用字段';
create table MBT_PM_110_E (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
E_MARI_STATUS VARCHAR(2),
E_SPO_ID_NUM VARCHAR(40),
E_SPO_ID_TYPE VARCHAR(2),
E_SPO_NAME VARCHAR(60),
E_SPO_TEL VARCHAR(50),
E_SPS_CMPY_NM VARCHAR(160),
E_SPS_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_E is '个人基本信息-婚姻信息段';
comment on column MBT_PM_110_E.DATA_ID is '数据ID';
comment on column MBT_PM_110_E.DATA_DATE is '数据日期';
comment on column MBT_PM_110_E.CORP_ID is '法人ID';
comment on column MBT_PM_110_E.ORG_ID is '机构ID';
comment on column MBT_PM_110_E.GROUP_ID is '数据分组';
comment on column MBT_PM_110_E.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_E.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_E.E_MARI_STATUS is '婚姻状况';
comment on column MBT_PM_110_E.E_SPO_ID_NUM is '配偶证件号码';
comment on column MBT_PM_110_E.E_SPO_ID_TYPE is '配偶证件类型';
comment on column MBT_PM_110_E.E_SPO_NAME is '配偶姓名';
comment on column MBT_PM_110_E.E_SPO_TEL is '配偶联系电话';
comment on column MBT_PM_110_E.E_SPS_CMPY_NM is '配偶工作单位';
comment on column MBT_PM_110_E.E_SPS_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_110_E.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_E.B_ID_NUM is '证件号码';
comment on column MBT_PM_110_E.B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_E.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_E.CUST_NO is '客户号';
comment on column MBT_PM_110_E.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_E.PART_TYPE is '段标识';
comment on column MBT_PM_110_E.PART_NAME is '段名称';
comment on column MBT_PM_110_E.START_DATE is '起始日期';
comment on column MBT_PM_110_E.END_DATE is '结束日期';
comment on column MBT_PM_110_E.BATCH_NO is '批次号';
comment on column MBT_PM_110_E.ROW_NUM is '行号';
comment on column MBT_PM_110_E.IS_RPT is '是否报送';
comment on column MBT_PM_110_E.IS_VALID is '是否有效';
comment on column MBT_PM_110_E.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_E.OPT_FLAG is '操作标识';
comment on column MBT_PM_110_E.RPT_DATE is '报送日期';
comment on column MBT_PM_110_E.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_E.RPT_STATUS is '报送状态';
comment on column MBT_PM_110_E.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_E.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_E.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_E.REMARKS is '备注';
comment on column MBT_PM_110_E.CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_E.CHECK_DESC is '校验说明';
comment on column MBT_PM_110_E.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_E.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_E.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_E.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_E.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_E.DATA_FLAG is '数据标志';
comment on column MBT_PM_110_E.DATA_OP is '操作标志';
comment on column MBT_PM_110_E.DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_E.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_E.DATA_HASH is '数据HASH';
comment on column MBT_PM_110_E.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_E.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_E.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_E.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_E.DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_E.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_E.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_E.DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_E.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_E.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_E.DATA_APV_USER is '审核人';
comment on column MBT_PM_110_E.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_E.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_E.RSV1 is '备用字段';
comment on column MBT_PM_110_E.RSV2 is '备用字段';
comment on column MBT_PM_110_E.RSV3 is '备用字段';
comment on column MBT_PM_110_E.RSV4 is '备用字段';
comment on column MBT_PM_110_E.RSV5 is '备用字段';
create table MBT_PM_110_F  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
F_ACA_DEGREE VARCHAR(1),
F_EDU_INFO_UP_DATE VARCHAR(8),
F_EDU_LEVEL VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_F  is '个人基本信息-教育信息段';
comment on column MBT_PM_110_F .DATA_ID is '数据ID';
comment on column MBT_PM_110_F .DATA_DATE is '数据日期';
comment on column MBT_PM_110_F .CORP_ID is '法人ID';
comment on column MBT_PM_110_F .ORG_ID is '机构ID';
comment on column MBT_PM_110_F .GROUP_ID is '数据分组';
comment on column MBT_PM_110_F .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_F .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_F .F_ACA_DEGREE is '学位';
comment on column MBT_PM_110_F .F_EDU_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_110_F .F_EDU_LEVEL is '学历';
comment on column MBT_PM_110_F .B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_F .B_ID_NUM is '证件号码';
comment on column MBT_PM_110_F .B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_F .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_F .CUST_NO is '客户号';
comment on column MBT_PM_110_F .UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_F .PART_TYPE is '段标识';
comment on column MBT_PM_110_F .PART_NAME is '段名称';
comment on column MBT_PM_110_F .START_DATE is '起始日期';
comment on column MBT_PM_110_F .END_DATE is '结束日期';
comment on column MBT_PM_110_F .BATCH_NO is '批次号';
comment on column MBT_PM_110_F .ROW_NUM is '行号';
comment on column MBT_PM_110_F .IS_RPT is '是否报送';
comment on column MBT_PM_110_F .IS_VALID is '是否有效';
comment on column MBT_PM_110_F .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_F .OPT_FLAG is '操作标识';
comment on column MBT_PM_110_F .RPT_DATE is '报送日期';
comment on column MBT_PM_110_F .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_F .RPT_STATUS is '报送状态';
comment on column MBT_PM_110_F .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_F .RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_F .RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_F .REMARKS is '备注';
comment on column MBT_PM_110_F .CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_F .CHECK_DESC is '校验说明';
comment on column MBT_PM_110_F .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_F .NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_F .DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_F .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_F .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_F .DATA_FLAG is '数据标志';
comment on column MBT_PM_110_F .DATA_OP is '操作标志';
comment on column MBT_PM_110_F .DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_F .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_F .DATA_HASH is '数据HASH';
comment on column MBT_PM_110_F .DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_F .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_F .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_F .DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_F .DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_F .DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_F .DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_F .DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_F .DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_F .DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_F .DATA_APV_USER is '审核人';
comment on column MBT_PM_110_F .DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_F .DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_F .RSV1 is '备用字段';
comment on column MBT_PM_110_F .RSV2 is '备用字段';
comment on column MBT_PM_110_F .RSV3 is '备用字段';
comment on column MBT_PM_110_F .RSV4 is '备用字段';
comment on column MBT_PM_110_F .RSV5 is '备用字段';
create table MBT_PM_110_F (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
F_ACA_DEGREE VARCHAR(1),
F_EDU_INFO_UP_DATE VARCHAR(8),
F_EDU_LEVEL VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_F is '个人基本信息-教育信息段';
comment on column MBT_PM_110_F.DATA_ID is '数据ID';
comment on column MBT_PM_110_F.DATA_DATE is '数据日期';
comment on column MBT_PM_110_F.CORP_ID is '法人ID';
comment on column MBT_PM_110_F.ORG_ID is '机构ID';
comment on column MBT_PM_110_F.GROUP_ID is '数据分组';
comment on column MBT_PM_110_F.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_F.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_F.F_ACA_DEGREE is '学位';
comment on column MBT_PM_110_F.F_EDU_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_110_F.F_EDU_LEVEL is '学历';
comment on column MBT_PM_110_F.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_F.B_ID_NUM is '证件号码';
comment on column MBT_PM_110_F.B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_F.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_F.CUST_NO is '客户号';
comment on column MBT_PM_110_F.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_F.PART_TYPE is '段标识';
comment on column MBT_PM_110_F.PART_NAME is '段名称';
comment on column MBT_PM_110_F.START_DATE is '起始日期';
comment on column MBT_PM_110_F.END_DATE is '结束日期';
comment on column MBT_PM_110_F.BATCH_NO is '批次号';
comment on column MBT_PM_110_F.ROW_NUM is '行号';
comment on column MBT_PM_110_F.IS_RPT is '是否报送';
comment on column MBT_PM_110_F.IS_VALID is '是否有效';
comment on column MBT_PM_110_F.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_F.OPT_FLAG is '操作标识';
comment on column MBT_PM_110_F.RPT_DATE is '报送日期';
comment on column MBT_PM_110_F.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_F.RPT_STATUS is '报送状态';
comment on column MBT_PM_110_F.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_F.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_F.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_F.REMARKS is '备注';
comment on column MBT_PM_110_F.CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_F.CHECK_DESC is '校验说明';
comment on column MBT_PM_110_F.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_F.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_F.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_F.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_F.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_F.DATA_FLAG is '数据标志';
comment on column MBT_PM_110_F.DATA_OP is '操作标志';
comment on column MBT_PM_110_F.DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_F.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_F.DATA_HASH is '数据HASH';
comment on column MBT_PM_110_F.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_F.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_F.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_F.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_F.DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_F.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_F.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_F.DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_F.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_F.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_F.DATA_APV_USER is '审核人';
comment on column MBT_PM_110_F.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_F.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_F.RSV1 is '备用字段';
comment on column MBT_PM_110_F.RSV2 is '备用字段';
comment on column MBT_PM_110_F.RSV3 is '备用字段';
comment on column MBT_PM_110_F.RSV4 is '备用字段';
comment on column MBT_PM_110_F.RSV5 is '备用字段';
create table MBT_PM_110_G  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_CPN_ADDR VARCHAR(200),
G_CPN_DIST VARCHAR(6),
G_CPN_NAME VARCHAR(160),
G_CPN_PC VARCHAR(6),
G_CPN_TEL VARCHAR(50),
G_CPN_TYPE VARCHAR(2),
G_EMP_STATUS VARCHAR(2),
G_INDUSTRY VARCHAR(1),
G_OCCUPATION VARCHAR(1),
G_OCTPN_INFO_UP_DATE VARCHAR(8),
G_TECH_TITLE VARCHAR(1),
G_TITLE VARCHAR(1),
G_WORK_START_DATE VARCHAR(4),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_G  is '个人基本信息-职业信息段';
comment on column MBT_PM_110_G .DATA_ID is '数据ID';
comment on column MBT_PM_110_G .DATA_DATE is '数据日期';
comment on column MBT_PM_110_G .CORP_ID is '法人ID';
comment on column MBT_PM_110_G .ORG_ID is '机构ID';
comment on column MBT_PM_110_G .GROUP_ID is '数据分组';
comment on column MBT_PM_110_G .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_G .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_G .G_CPN_ADDR is '单位详细地址';
comment on column MBT_PM_110_G .G_CPN_DIST is '单位所在地行政区划';
comment on column MBT_PM_110_G .G_CPN_NAME is '单位名称';
comment on column MBT_PM_110_G .G_CPN_PC is '单位所在地邮编';
comment on column MBT_PM_110_G .G_CPN_TEL is '单位电话';
comment on column MBT_PM_110_G .G_CPN_TYPE is '单位性质';
comment on column MBT_PM_110_G .G_EMP_STATUS is '就业状况';
comment on column MBT_PM_110_G .G_INDUSTRY is '单位所属行业';
comment on column MBT_PM_110_G .G_OCCUPATION is '职业';
comment on column MBT_PM_110_G .G_OCTPN_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_110_G .G_TECH_TITLE is '职称';
comment on column MBT_PM_110_G .G_TITLE is '职务';
comment on column MBT_PM_110_G .G_WORK_START_DATE is '本单位工作起始年份';
comment on column MBT_PM_110_G .B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_G .B_ID_NUM is '证件号码';
comment on column MBT_PM_110_G .B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_G .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_G .CUST_NO is '客户号';
comment on column MBT_PM_110_G .UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_G .PART_TYPE is '段标识';
comment on column MBT_PM_110_G .PART_NAME is '段名称';
comment on column MBT_PM_110_G .START_DATE is '起始日期';
comment on column MBT_PM_110_G .END_DATE is '结束日期';
comment on column MBT_PM_110_G .BATCH_NO is '批次号';
comment on column MBT_PM_110_G .ROW_NUM is '行号';
comment on column MBT_PM_110_G .IS_RPT is '是否报送';
comment on column MBT_PM_110_G .IS_VALID is '是否有效';
comment on column MBT_PM_110_G .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_G .OPT_FLAG is '操作标识';
comment on column MBT_PM_110_G .RPT_DATE is '报送日期';
comment on column MBT_PM_110_G .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_G .RPT_STATUS is '报送状态';
comment on column MBT_PM_110_G .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_G .RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_G .RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_G .REMARKS is '备注';
comment on column MBT_PM_110_G .CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_G .CHECK_DESC is '校验说明';
comment on column MBT_PM_110_G .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_G .NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_G .DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_G .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_G .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_G .DATA_FLAG is '数据标志';
comment on column MBT_PM_110_G .DATA_OP is '操作标志';
comment on column MBT_PM_110_G .DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_G .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_G .DATA_HASH is '数据HASH';
comment on column MBT_PM_110_G .DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_G .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_G .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_G .DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_G .DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_G .DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_G .DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_G .DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_G .DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_G .DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_G .DATA_APV_USER is '审核人';
comment on column MBT_PM_110_G .DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_G .DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_G .RSV1 is '备用字段';
comment on column MBT_PM_110_G .RSV2 is '备用字段';
comment on column MBT_PM_110_G .RSV3 is '备用字段';
comment on column MBT_PM_110_G .RSV4 is '备用字段';
comment on column MBT_PM_110_G .RSV5 is '备用字段';
create table MBT_PM_110_G (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_CPN_ADDR VARCHAR(200),
G_CPN_DIST VARCHAR(6),
G_CPN_NAME VARCHAR(160),
G_CPN_PC VARCHAR(6),
G_CPN_TEL VARCHAR(50),
G_CPN_TYPE VARCHAR(2),
G_EMP_STATUS VARCHAR(2),
G_INDUSTRY VARCHAR(1),
G_OCCUPATION VARCHAR(1),
G_OCTPN_INFO_UP_DATE VARCHAR(8),
G_TECH_TITLE VARCHAR(1),
G_TITLE VARCHAR(1),
G_WORK_START_DATE VARCHAR(4),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_G is '个人基本信息-职业信息段';
comment on column MBT_PM_110_G.DATA_ID is '数据ID';
comment on column MBT_PM_110_G.DATA_DATE is '数据日期';
comment on column MBT_PM_110_G.CORP_ID is '法人ID';
comment on column MBT_PM_110_G.ORG_ID is '机构ID';
comment on column MBT_PM_110_G.GROUP_ID is '数据分组';
comment on column MBT_PM_110_G.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_G.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_G.G_CPN_ADDR is '单位详细地址';
comment on column MBT_PM_110_G.G_CPN_DIST is '单位所在地行政区划';
comment on column MBT_PM_110_G.G_CPN_NAME is '单位名称';
comment on column MBT_PM_110_G.G_CPN_PC is '单位所在地邮编';
comment on column MBT_PM_110_G.G_CPN_TEL is '单位电话';
comment on column MBT_PM_110_G.G_CPN_TYPE is '单位性质';
comment on column MBT_PM_110_G.G_EMP_STATUS is '就业状况';
comment on column MBT_PM_110_G.G_INDUSTRY is '单位所属行业';
comment on column MBT_PM_110_G.G_OCCUPATION is '职业';
comment on column MBT_PM_110_G.G_OCTPN_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_110_G.G_TECH_TITLE is '职称';
comment on column MBT_PM_110_G.G_TITLE is '职务';
comment on column MBT_PM_110_G.G_WORK_START_DATE is '本单位工作起始年份';
comment on column MBT_PM_110_G.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_G.B_ID_NUM is '证件号码';
comment on column MBT_PM_110_G.B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_G.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_G.CUST_NO is '客户号';
comment on column MBT_PM_110_G.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_G.PART_TYPE is '段标识';
comment on column MBT_PM_110_G.PART_NAME is '段名称';
comment on column MBT_PM_110_G.START_DATE is '起始日期';
comment on column MBT_PM_110_G.END_DATE is '结束日期';
comment on column MBT_PM_110_G.BATCH_NO is '批次号';
comment on column MBT_PM_110_G.ROW_NUM is '行号';
comment on column MBT_PM_110_G.IS_RPT is '是否报送';
comment on column MBT_PM_110_G.IS_VALID is '是否有效';
comment on column MBT_PM_110_G.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_G.OPT_FLAG is '操作标识';
comment on column MBT_PM_110_G.RPT_DATE is '报送日期';
comment on column MBT_PM_110_G.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_G.RPT_STATUS is '报送状态';
comment on column MBT_PM_110_G.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_G.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_G.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_G.REMARKS is '备注';
comment on column MBT_PM_110_G.CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_G.CHECK_DESC is '校验说明';
comment on column MBT_PM_110_G.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_G.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_G.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_G.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_G.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_G.DATA_FLAG is '数据标志';
comment on column MBT_PM_110_G.DATA_OP is '操作标志';
comment on column MBT_PM_110_G.DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_G.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_G.DATA_HASH is '数据HASH';
comment on column MBT_PM_110_G.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_G.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_G.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_G.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_G.DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_G.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_G.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_G.DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_G.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_G.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_G.DATA_APV_USER is '审核人';
comment on column MBT_PM_110_G.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_G.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_G.RSV1 is '备用字段';
comment on column MBT_PM_110_G.RSV2 is '备用字段';
comment on column MBT_PM_110_G.RSV3 is '备用字段';
comment on column MBT_PM_110_G.RSV4 is '备用字段';
comment on column MBT_PM_110_G.RSV5 is '备用字段';
create table MBT_PM_110_H  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
H_HOME_TEL VARCHAR(50),
H_RESI_ADDR VARCHAR(200),
H_RESI_DIST VARCHAR(6),
H_RESI_INFO_UP_DATE VARCHAR(8),
H_RESI_PC VARCHAR(6),
H_RESI_STATUS VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_H  is '个人基本信息-居住地址段';
comment on column MBT_PM_110_H .DATA_ID is '数据ID';
comment on column MBT_PM_110_H .DATA_DATE is '数据日期';
comment on column MBT_PM_110_H .CORP_ID is '法人ID';
comment on column MBT_PM_110_H .ORG_ID is '机构ID';
comment on column MBT_PM_110_H .GROUP_ID is '数据分组';
comment on column MBT_PM_110_H .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_H .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_H .H_HOME_TEL is '住宅电话';
comment on column MBT_PM_110_H .H_RESI_ADDR is '居住地详细地址';
comment on column MBT_PM_110_H .H_RESI_DIST is '居住地行政区划';
comment on column MBT_PM_110_H .H_RESI_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_110_H .H_RESI_PC is '居住地邮编';
comment on column MBT_PM_110_H .H_RESI_STATUS is '居住状况';
comment on column MBT_PM_110_H .B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_H .B_ID_NUM is '证件号码';
comment on column MBT_PM_110_H .B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_H .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_H .CUST_NO is '客户号';
comment on column MBT_PM_110_H .UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_H .PART_TYPE is '段标识';
comment on column MBT_PM_110_H .PART_NAME is '段名称';
comment on column MBT_PM_110_H .START_DATE is '起始日期';
comment on column MBT_PM_110_H .END_DATE is '结束日期';
comment on column MBT_PM_110_H .BATCH_NO is '批次号';
comment on column MBT_PM_110_H .ROW_NUM is '行号';
comment on column MBT_PM_110_H .IS_RPT is '是否报送';
comment on column MBT_PM_110_H .IS_VALID is '是否有效';
comment on column MBT_PM_110_H .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_H .OPT_FLAG is '操作标识';
comment on column MBT_PM_110_H .RPT_DATE is '报送日期';
comment on column MBT_PM_110_H .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_H .RPT_STATUS is '报送状态';
comment on column MBT_PM_110_H .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_H .RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_H .RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_H .REMARKS is '备注';
comment on column MBT_PM_110_H .CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_H .CHECK_DESC is '校验说明';
comment on column MBT_PM_110_H .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_H .NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_H .DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_H .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_H .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_H .DATA_FLAG is '数据标志';
comment on column MBT_PM_110_H .DATA_OP is '操作标志';
comment on column MBT_PM_110_H .DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_H .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_H .DATA_HASH is '数据HASH';
comment on column MBT_PM_110_H .DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_H .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_H .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_H .DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_H .DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_H .DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_H .DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_H .DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_H .DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_H .DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_H .DATA_APV_USER is '审核人';
comment on column MBT_PM_110_H .DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_H .DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_H .RSV1 is '备用字段';
comment on column MBT_PM_110_H .RSV2 is '备用字段';
comment on column MBT_PM_110_H .RSV3 is '备用字段';
comment on column MBT_PM_110_H .RSV4 is '备用字段';
comment on column MBT_PM_110_H .RSV5 is '备用字段';
create table MBT_PM_110_H (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
H_HOME_TEL VARCHAR(50),
H_RESI_ADDR VARCHAR(200),
H_RESI_DIST VARCHAR(6),
H_RESI_INFO_UP_DATE VARCHAR(8),
H_RESI_PC VARCHAR(6),
H_RESI_STATUS VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_H is '个人基本信息-居住地址段';
comment on column MBT_PM_110_H.DATA_ID is '数据ID';
comment on column MBT_PM_110_H.DATA_DATE is '数据日期';
comment on column MBT_PM_110_H.CORP_ID is '法人ID';
comment on column MBT_PM_110_H.ORG_ID is '机构ID';
comment on column MBT_PM_110_H.GROUP_ID is '数据分组';
comment on column MBT_PM_110_H.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_H.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_H.H_HOME_TEL is '住宅电话';
comment on column MBT_PM_110_H.H_RESI_ADDR is '居住地详细地址';
comment on column MBT_PM_110_H.H_RESI_DIST is '居住地行政区划';
comment on column MBT_PM_110_H.H_RESI_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_110_H.H_RESI_PC is '居住地邮编';
comment on column MBT_PM_110_H.H_RESI_STATUS is '居住状况';
comment on column MBT_PM_110_H.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_H.B_ID_NUM is '证件号码';
comment on column MBT_PM_110_H.B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_H.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_H.CUST_NO is '客户号';
comment on column MBT_PM_110_H.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_H.PART_TYPE is '段标识';
comment on column MBT_PM_110_H.PART_NAME is '段名称';
comment on column MBT_PM_110_H.START_DATE is '起始日期';
comment on column MBT_PM_110_H.END_DATE is '结束日期';
comment on column MBT_PM_110_H.BATCH_NO is '批次号';
comment on column MBT_PM_110_H.ROW_NUM is '行号';
comment on column MBT_PM_110_H.IS_RPT is '是否报送';
comment on column MBT_PM_110_H.IS_VALID is '是否有效';
comment on column MBT_PM_110_H.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_H.OPT_FLAG is '操作标识';
comment on column MBT_PM_110_H.RPT_DATE is '报送日期';
comment on column MBT_PM_110_H.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_H.RPT_STATUS is '报送状态';
comment on column MBT_PM_110_H.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_H.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_H.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_H.REMARKS is '备注';
comment on column MBT_PM_110_H.CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_H.CHECK_DESC is '校验说明';
comment on column MBT_PM_110_H.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_H.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_H.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_H.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_H.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_H.DATA_FLAG is '数据标志';
comment on column MBT_PM_110_H.DATA_OP is '操作标志';
comment on column MBT_PM_110_H.DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_H.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_H.DATA_HASH is '数据HASH';
comment on column MBT_PM_110_H.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_H.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_H.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_H.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_H.DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_H.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_H.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_H.DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_H.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_H.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_H.DATA_APV_USER is '审核人';
comment on column MBT_PM_110_H.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_H.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_H.RSV1 is '备用字段';
comment on column MBT_PM_110_H.RSV2 is '备用字段';
comment on column MBT_PM_110_H.RSV3 is '备用字段';
comment on column MBT_PM_110_H.RSV4 is '备用字段';
comment on column MBT_PM_110_H.RSV5 is '备用字段';
create table MBT_PM_110_I  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
I_MAIL_ADDR VARCHAR(200),
I_MAIL_DIST VARCHAR(6),
I_MAIL_PC VARCHAR(6),
I_MLG_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_I  is '个人基本信息-通讯地址段';
comment on column MBT_PM_110_I .DATA_ID is '数据ID';
comment on column MBT_PM_110_I .DATA_DATE is '数据日期';
comment on column MBT_PM_110_I .CORP_ID is '法人ID';
comment on column MBT_PM_110_I .ORG_ID is '机构ID';
comment on column MBT_PM_110_I .GROUP_ID is '数据分组';
comment on column MBT_PM_110_I .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_I .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_I .I_MAIL_ADDR is '通讯地址';
comment on column MBT_PM_110_I .I_MAIL_DIST is '通讯地行政区划';
comment on column MBT_PM_110_I .I_MAIL_PC is '通讯地邮编';
comment on column MBT_PM_110_I .I_MLG_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_110_I .B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_I .B_ID_NUM is '证件号码';
comment on column MBT_PM_110_I .B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_I .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_I .CUST_NO is '客户号';
comment on column MBT_PM_110_I .UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_I .PART_TYPE is '段标识';
comment on column MBT_PM_110_I .PART_NAME is '段名称';
comment on column MBT_PM_110_I .START_DATE is '起始日期';
comment on column MBT_PM_110_I .END_DATE is '结束日期';
comment on column MBT_PM_110_I .BATCH_NO is '批次号';
comment on column MBT_PM_110_I .ROW_NUM is '行号';
comment on column MBT_PM_110_I .IS_RPT is '是否报送';
comment on column MBT_PM_110_I .IS_VALID is '是否有效';
comment on column MBT_PM_110_I .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_I .OPT_FLAG is '操作标识';
comment on column MBT_PM_110_I .RPT_DATE is '报送日期';
comment on column MBT_PM_110_I .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_I .RPT_STATUS is '报送状态';
comment on column MBT_PM_110_I .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_I .RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_I .RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_I .REMARKS is '备注';
comment on column MBT_PM_110_I .CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_I .CHECK_DESC is '校验说明';
comment on column MBT_PM_110_I .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_I .NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_I .DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_I .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_I .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_I .DATA_FLAG is '数据标志';
comment on column MBT_PM_110_I .DATA_OP is '操作标志';
comment on column MBT_PM_110_I .DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_I .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_I .DATA_HASH is '数据HASH';
comment on column MBT_PM_110_I .DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_I .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_I .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_I .DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_I .DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_I .DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_I .DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_I .DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_I .DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_I .DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_I .DATA_APV_USER is '审核人';
comment on column MBT_PM_110_I .DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_I .DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_I .RSV1 is '备用字段';
comment on column MBT_PM_110_I .RSV2 is '备用字段';
comment on column MBT_PM_110_I .RSV3 is '备用字段';
comment on column MBT_PM_110_I .RSV4 is '备用字段';
comment on column MBT_PM_110_I .RSV5 is '备用字段';
create table MBT_PM_110_I (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
I_MAIL_ADDR VARCHAR(200),
I_MAIL_DIST VARCHAR(6),
I_MAIL_PC VARCHAR(6),
I_MLG_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_I is '个人基本信息-通讯地址段';
comment on column MBT_PM_110_I.DATA_ID is '数据ID';
comment on column MBT_PM_110_I.DATA_DATE is '数据日期';
comment on column MBT_PM_110_I.CORP_ID is '法人ID';
comment on column MBT_PM_110_I.ORG_ID is '机构ID';
comment on column MBT_PM_110_I.GROUP_ID is '数据分组';
comment on column MBT_PM_110_I.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_I.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_I.I_MAIL_ADDR is '通讯地址';
comment on column MBT_PM_110_I.I_MAIL_DIST is '通讯地行政区划';
comment on column MBT_PM_110_I.I_MAIL_PC is '通讯地邮编';
comment on column MBT_PM_110_I.I_MLG_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_110_I.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_I.B_ID_NUM is '证件号码';
comment on column MBT_PM_110_I.B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_I.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_I.CUST_NO is '客户号';
comment on column MBT_PM_110_I.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_I.PART_TYPE is '段标识';
comment on column MBT_PM_110_I.PART_NAME is '段名称';
comment on column MBT_PM_110_I.START_DATE is '起始日期';
comment on column MBT_PM_110_I.END_DATE is '结束日期';
comment on column MBT_PM_110_I.BATCH_NO is '批次号';
comment on column MBT_PM_110_I.ROW_NUM is '行号';
comment on column MBT_PM_110_I.IS_RPT is '是否报送';
comment on column MBT_PM_110_I.IS_VALID is '是否有效';
comment on column MBT_PM_110_I.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_I.OPT_FLAG is '操作标识';
comment on column MBT_PM_110_I.RPT_DATE is '报送日期';
comment on column MBT_PM_110_I.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_I.RPT_STATUS is '报送状态';
comment on column MBT_PM_110_I.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_I.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_I.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_I.REMARKS is '备注';
comment on column MBT_PM_110_I.CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_I.CHECK_DESC is '校验说明';
comment on column MBT_PM_110_I.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_I.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_I.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_I.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_I.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_I.DATA_FLAG is '数据标志';
comment on column MBT_PM_110_I.DATA_OP is '操作标志';
comment on column MBT_PM_110_I.DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_I.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_I.DATA_HASH is '数据HASH';
comment on column MBT_PM_110_I.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_I.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_I.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_I.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_I.DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_I.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_I.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_I.DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_I.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_I.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_I.DATA_APV_USER is '审核人';
comment on column MBT_PM_110_I.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_I.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_I.RSV1 is '备用字段';
comment on column MBT_PM_110_I.RSV2 is '备用字段';
comment on column MBT_PM_110_I.RSV3 is '备用字段';
comment on column MBT_PM_110_I.RSV4 is '备用字段';
comment on column MBT_PM_110_I.RSV5 is '备用字段';
create table MBT_PM_110_J (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
J_ANNL_INC NUMBER(15),
J_ANNL_INC_LCY NUMBER(15),
J_ANNL_INC_ORG NUMBER(15),
J_INC_INFO_UP_DATE VARCHAR(8),
J_TAX_INCOME NUMBER(15),
J_TAX_INCOME_LCY NUMBER(15),
J_TAX_INCOME_ORG NUMBER(15),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_110_J is '个人基本信息-收入信息段';
comment on column MBT_PM_110_J.DATA_ID is '数据ID';
comment on column MBT_PM_110_J.DATA_DATE is '数据日期';
comment on column MBT_PM_110_J.CORP_ID is '法人ID';
comment on column MBT_PM_110_J.ORG_ID is '机构ID';
comment on column MBT_PM_110_J.GROUP_ID is '数据分组';
comment on column MBT_PM_110_J.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_110_J.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_110_J.J_ANNL_INC is '自报年收入';
comment on column MBT_PM_110_J.J_ANNL_INC_LCY is '自报年收入人民币金额';
comment on column MBT_PM_110_J.J_ANNL_INC_ORG is '自报年收入_原始数据金额';
comment on column MBT_PM_110_J.J_INC_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_110_J.J_TAX_INCOME is '纳税年收入';
comment on column MBT_PM_110_J.J_TAX_INCOME_LCY is '纳税年收入人民币金额';
comment on column MBT_PM_110_J.J_TAX_INCOME_ORG is '纳税年收入_原始数据金额';
comment on column MBT_PM_110_J.C_CY is '币种';
comment on column MBT_PM_110_J.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_110_J.B_ID_NUM is '证件号码';
comment on column MBT_PM_110_J.B_ID_TYPE is '证件类型';
comment on column MBT_PM_110_J.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_110_J.CUST_NO is '客户号';
comment on column MBT_PM_110_J.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_110_J.PART_TYPE is '段标识';
comment on column MBT_PM_110_J.PART_NAME is '段名称';
comment on column MBT_PM_110_J.START_DATE is '起始日期';
comment on column MBT_PM_110_J.END_DATE is '结束日期';
comment on column MBT_PM_110_J.BATCH_NO is '批次号';
comment on column MBT_PM_110_J.ROW_NUM is '行号';
comment on column MBT_PM_110_J.IS_RPT is '是否报送';
comment on column MBT_PM_110_J.IS_VALID is '是否有效';
comment on column MBT_PM_110_J.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_110_J.OPT_FLAG is '操作标识';
comment on column MBT_PM_110_J.RPT_DATE is '报送日期';
comment on column MBT_PM_110_J.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_110_J.RPT_STATUS is '报送状态';
comment on column MBT_PM_110_J.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_110_J.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_110_J.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_110_J.REMARKS is '备注';
comment on column MBT_PM_110_J.CHECK_FLAG is '校验标志';
comment on column MBT_PM_110_J.CHECK_DESC is '校验说明';
comment on column MBT_PM_110_J.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_110_J.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_110_J.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_110_J.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_110_J.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_110_J.DATA_FLAG is '数据标志';
comment on column MBT_PM_110_J.DATA_OP is '操作标志';
comment on column MBT_PM_110_J.DATA_SOURCE is '数据来源';
comment on column MBT_PM_110_J.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_110_J.DATA_HASH is '数据HASH';
comment on column MBT_PM_110_J.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_J.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_110_J.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_110_J.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_110_J.DATA_CRT_USER is '创建人';
comment on column MBT_PM_110_J.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_110_J.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_110_J.DATA_CHG_USER is '修改人';
comment on column MBT_PM_110_J.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_110_J.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_110_J.DATA_APV_USER is '审核人';
comment on column MBT_PM_110_J.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_110_J.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_110_J.RSV1 is '备用字段';
comment on column MBT_PM_110_J.RSV2 is '备用字段';
comment on column MBT_PM_110_J.RSV3 is '备用字段';
comment on column MBT_PM_110_J.RSV4 is '备用字段';
comment on column MBT_PM_110_J.RSV5 is '备用字段';
create table MBT_RPT_110 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110 is '个人基本信息';
comment on column MBT_RPT_110.DATA_ID is '数据ID';
comment on column MBT_RPT_110.DATA_DATE is '数据日期';
comment on column MBT_RPT_110.CORP_ID is '法人ID';
comment on column MBT_RPT_110.ORG_ID is '机构ID';
comment on column MBT_RPT_110.GROUP_ID is '数据分组';
comment on column MBT_RPT_110.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110.B_ID_NUM is '证件号码';
comment on column MBT_RPT_110.B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110.SECTION_CHG_CNT is '段变更';
comment on column MBT_RPT_110.SECTION_DEL_CNT is '段删除';
comment on column MBT_RPT_110.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_RPT_110.IDN_CHG_CNT is '标识项变更';
comment on column MBT_RPT_110.CUST_NO is '客户号';
comment on column MBT_RPT_110.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110.PART_TYPE is '段标识';
comment on column MBT_RPT_110.PART_NAME is '段名称';
comment on column MBT_RPT_110.START_DATE is '起始日期';
comment on column MBT_RPT_110.END_DATE is '结束日期';
comment on column MBT_RPT_110.BATCH_NO is '批次号';
comment on column MBT_RPT_110.ROW_NUM is '行号';
comment on column MBT_RPT_110.IS_RPT is '是否报送';
comment on column MBT_RPT_110.IS_VALID is '是否有效';
comment on column MBT_RPT_110.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110.OPT_FLAG is '操作标识';
comment on column MBT_RPT_110.RPT_DATE is '报送日期';
comment on column MBT_RPT_110.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110.RPT_STATUS is '报送状态';
comment on column MBT_RPT_110.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110.REMARKS is '备注';
comment on column MBT_RPT_110.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110.CHECK_DESC is '校验说明';
comment on column MBT_RPT_110.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110.DATA_FLAG is '数据标志';
comment on column MBT_RPT_110.DATA_OP is '操作标志';
comment on column MBT_RPT_110.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110.DATA_HASH is '数据HASH';
comment on column MBT_RPT_110.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110.DATA_APV_USER is '审核人';
comment on column MBT_RPT_110.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110.RSV1 is '备用字段';
comment on column MBT_RPT_110.RSV2 is '备用字段';
comment on column MBT_RPT_110.RSV3 is '备用字段';
comment on column MBT_RPT_110.RSV4 is '备用字段';
comment on column MBT_RPT_110.RSV5 is '备用字段';
create table MBT_RPT_110_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_CIMOC VARCHAR(14),
B_CUSTOMER_TYPE VARCHAR(2),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
B_INF_REC_TYPE VARCHAR(3),
B_NAME VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_B is '个人基本信息-基础段';
comment on column MBT_RPT_110_B.DATA_ID is '数据ID';
comment on column MBT_RPT_110_B.DATA_DATE is '数据日期';
comment on column MBT_RPT_110_B.CORP_ID is '法人ID';
comment on column MBT_RPT_110_B.ORG_ID is '机构ID';
comment on column MBT_RPT_110_B.GROUP_ID is '数据分组';
comment on column MBT_RPT_110_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_RPT_110_B.B_CUSTOMER_TYPE is '客户资料类型';
comment on column MBT_RPT_110_B.B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_B.B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_RPT_110_B.B_NAME is '姓名';
comment on column MBT_RPT_110_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_RPT_110_B.CUST_NO is '客户号';
comment on column MBT_RPT_110_B.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_B.PART_TYPE is '段标识';
comment on column MBT_RPT_110_B.PART_NAME is '段名称';
comment on column MBT_RPT_110_B.START_DATE is '起始日期';
comment on column MBT_RPT_110_B.END_DATE is '结束日期';
comment on column MBT_RPT_110_B.BATCH_NO is '批次号';
comment on column MBT_RPT_110_B.ROW_NUM is '行号';
comment on column MBT_RPT_110_B.IS_RPT is '是否报送';
comment on column MBT_RPT_110_B.IS_VALID is '是否有效';
comment on column MBT_RPT_110_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_B.OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_B.RPT_DATE is '报送日期';
comment on column MBT_RPT_110_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_B.RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_B.REMARKS is '备注';
comment on column MBT_RPT_110_B.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_B.CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_B.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_B.DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_B.DATA_OP is '操作标志';
comment on column MBT_RPT_110_B.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_B.DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_B.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_B.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_B.DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_B.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_B.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_B.RSV1 is '备用字段';
comment on column MBT_RPT_110_B.RSV2 is '备用字段';
comment on column MBT_RPT_110_B.RSV3 is '备用字段';
comment on column MBT_RPT_110_B.RSV4 is '备用字段';
comment on column MBT_RPT_110_B.RSV5 is '备用字段';
create table MBT_RPT_110_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
OTH_ID_NUM VARCHAR(40),
OTH_ID_TYPE VARCHAR(2),
ALIAS VARCHAR(60),
ID_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_C is '个人基本信息-其他标识段';
comment on column MBT_RPT_110_C.DATA_ID is '数据ID';
comment on column MBT_RPT_110_C.DATA_DATE is '数据日期';
comment on column MBT_RPT_110_C.CORP_ID is '法人ID';
comment on column MBT_RPT_110_C.ORG_ID is '机构ID';
comment on column MBT_RPT_110_C.GROUP_ID is '数据分组';
comment on column MBT_RPT_110_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_C.OTH_ID_NUM is '证件号码';
comment on column MBT_RPT_110_C.OTH_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_C.ALIAS is '姓名';
comment on column MBT_RPT_110_C.ID_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_110_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_C.B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_C.B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_C.CUST_NO is '客户号';
comment on column MBT_RPT_110_C.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_C.PART_TYPE is '段标识';
comment on column MBT_RPT_110_C.PART_NAME is '段名称';
comment on column MBT_RPT_110_C.START_DATE is '起始日期';
comment on column MBT_RPT_110_C.END_DATE is '结束日期';
comment on column MBT_RPT_110_C.BATCH_NO is '批次号';
comment on column MBT_RPT_110_C.ROW_NUM is '行号';
comment on column MBT_RPT_110_C.IS_RPT is '是否报送';
comment on column MBT_RPT_110_C.IS_VALID is '是否有效';
comment on column MBT_RPT_110_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_C.OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_C.RPT_DATE is '报送日期';
comment on column MBT_RPT_110_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_C.RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_C.REMARKS is '备注';
comment on column MBT_RPT_110_C.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_C.CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_C.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_C.DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_C.DATA_OP is '操作标志';
comment on column MBT_RPT_110_C.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_C.DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_C.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_C.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_C.DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_C.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_C.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_C.RSV1 is '备用字段';
comment on column MBT_RPT_110_C.RSV2 is '备用字段';
comment on column MBT_RPT_110_C.RSV3 is '备用字段';
comment on column MBT_RPT_110_C.RSV4 is '备用字段';
comment on column MBT_RPT_110_C.RSV5 is '备用字段';
create table MBT_RPT_110_D  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_CELL_PHONE VARCHAR(11),
D_DOB VARCHAR(8),
D_EMAIL VARCHAR(120),
D_FCS_INFO_UP_DATE VARCHAR(8),
D_HH_DIST VARCHAR(6),
D_HOUSE_ADD VARCHAR(200),
D_NATION VARCHAR(3),
D_SEX VARCHAR(1),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_D  is '个人基本信息-基本概况段';
comment on column MBT_RPT_110_D .DATA_ID is '数据ID';
comment on column MBT_RPT_110_D .DATA_DATE is '数据日期';
comment on column MBT_RPT_110_D .CORP_ID is '法人ID';
comment on column MBT_RPT_110_D .ORG_ID is '机构ID';
comment on column MBT_RPT_110_D .GROUP_ID is '数据分组';
comment on column MBT_RPT_110_D .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_D .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_D .D_CELL_PHONE is '手机号码';
comment on column MBT_RPT_110_D .D_DOB is '出生日期';
comment on column MBT_RPT_110_D .D_EMAIL is '电子邮箱';
comment on column MBT_RPT_110_D .D_FCS_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_110_D .D_HH_DIST is '户籍所在地行政区划';
comment on column MBT_RPT_110_D .D_HOUSE_ADD is '户籍地址';
comment on column MBT_RPT_110_D .D_NATION is '国籍';
comment on column MBT_RPT_110_D .D_SEX is '性别';
comment on column MBT_RPT_110_D .B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_D .B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_D .B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_D .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_D .CUST_NO is '客户号';
comment on column MBT_RPT_110_D .UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_D .PART_TYPE is '段标识';
comment on column MBT_RPT_110_D .PART_NAME is '段名称';
comment on column MBT_RPT_110_D .START_DATE is '起始日期';
comment on column MBT_RPT_110_D .END_DATE is '结束日期';
comment on column MBT_RPT_110_D .BATCH_NO is '批次号';
comment on column MBT_RPT_110_D .ROW_NUM is '行号';
comment on column MBT_RPT_110_D .IS_RPT is '是否报送';
comment on column MBT_RPT_110_D .IS_VALID is '是否有效';
comment on column MBT_RPT_110_D .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_D .OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_D .RPT_DATE is '报送日期';
comment on column MBT_RPT_110_D .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_D .RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_D .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_D .RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_D .RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_D .REMARKS is '备注';
comment on column MBT_RPT_110_D .CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_D .CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_D .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_D .NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_D .DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_D .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_D .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_D .DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_D .DATA_OP is '操作标志';
comment on column MBT_RPT_110_D .DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_D .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_D .DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_D .DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_D .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_D .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_D .DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_D .DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_D .DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_D .DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_D .DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_D .DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_D .DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_D .DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_D .DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_D .DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_D .RSV1 is '备用字段';
comment on column MBT_RPT_110_D .RSV2 is '备用字段';
comment on column MBT_RPT_110_D .RSV3 is '备用字段';
comment on column MBT_RPT_110_D .RSV4 is '备用字段';
comment on column MBT_RPT_110_D .RSV5 is '备用字段';
create table MBT_RPT_110_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_CELL_PHONE VARCHAR(12),
D_DOB VARCHAR(8),
D_EMAIL VARCHAR(120),
D_FCS_INFO_UP_DATE VARCHAR(8),
D_HH_DIST VARCHAR(6),
D_HOUSE_ADD VARCHAR(200),
D_NATION VARCHAR(3),
D_SEX VARCHAR(1),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_D is '个人基本信息-基本概况段';
comment on column MBT_RPT_110_D.DATA_ID is '数据ID';
comment on column MBT_RPT_110_D.DATA_DATE is '数据日期';
comment on column MBT_RPT_110_D.CORP_ID is '法人ID';
comment on column MBT_RPT_110_D.ORG_ID is '机构ID';
comment on column MBT_RPT_110_D.GROUP_ID is '数据分组';
comment on column MBT_RPT_110_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_D.D_CELL_PHONE is '手机号码';
comment on column MBT_RPT_110_D.D_DOB is '出生日期';
comment on column MBT_RPT_110_D.D_EMAIL is '电子邮箱';
comment on column MBT_RPT_110_D.D_FCS_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_110_D.D_HH_DIST is '户籍所在地行政区划';
comment on column MBT_RPT_110_D.D_HOUSE_ADD is '户籍地址';
comment on column MBT_RPT_110_D.D_NATION is '国籍';
comment on column MBT_RPT_110_D.D_SEX is '性别';
comment on column MBT_RPT_110_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_D.B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_D.B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_D.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_D.CUST_NO is '客户号';
comment on column MBT_RPT_110_D.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_D.PART_TYPE is '段标识';
comment on column MBT_RPT_110_D.PART_NAME is '段名称';
comment on column MBT_RPT_110_D.START_DATE is '起始日期';
comment on column MBT_RPT_110_D.END_DATE is '结束日期';
comment on column MBT_RPT_110_D.BATCH_NO is '批次号';
comment on column MBT_RPT_110_D.ROW_NUM is '行号';
comment on column MBT_RPT_110_D.IS_RPT is '是否报送';
comment on column MBT_RPT_110_D.IS_VALID is '是否有效';
comment on column MBT_RPT_110_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_D.OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_D.RPT_DATE is '报送日期';
comment on column MBT_RPT_110_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_D.RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_D.REMARKS is '备注';
comment on column MBT_RPT_110_D.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_D.CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_D.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_D.DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_D.DATA_OP is '操作标志';
comment on column MBT_RPT_110_D.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_D.DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_D.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_D.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_D.DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_D.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_D.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_D.RSV1 is '备用字段';
comment on column MBT_RPT_110_D.RSV2 is '备用字段';
comment on column MBT_RPT_110_D.RSV3 is '备用字段';
comment on column MBT_RPT_110_D.RSV4 is '备用字段';
comment on column MBT_RPT_110_D.RSV5 is '备用字段';
create table MBT_RPT_110_E  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
E_MARI_STATUS VARCHAR(2),
E_SPO_ID_NUM VARCHAR(40),
E_SPO_ID_TYPE VARCHAR(2),
E_SPO_NAME VARCHAR(60),
E_SPO_TEL VARCHAR(50),
E_SPS_CMPY_NM VARCHAR(160),
E_SPS_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_E  is '个人基本信息-婚姻信息段';
comment on column MBT_RPT_110_E .DATA_ID is '数据ID';
comment on column MBT_RPT_110_E .DATA_DATE is '数据日期';
comment on column MBT_RPT_110_E .CORP_ID is '法人ID';
comment on column MBT_RPT_110_E .ORG_ID is '机构ID';
comment on column MBT_RPT_110_E .GROUP_ID is '数据分组';
comment on column MBT_RPT_110_E .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_E .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_E .E_MARI_STATUS is '婚姻状况';
comment on column MBT_RPT_110_E .E_SPO_ID_NUM is '配偶证件号码';
comment on column MBT_RPT_110_E .E_SPO_ID_TYPE is '配偶证件类型';
comment on column MBT_RPT_110_E .E_SPO_NAME is '配偶姓名';
comment on column MBT_RPT_110_E .E_SPO_TEL is '配偶联系电话';
comment on column MBT_RPT_110_E .E_SPS_CMPY_NM is '配偶工作单位';
comment on column MBT_RPT_110_E .E_SPS_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_110_E .B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_E .B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_E .B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_E .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_E .CUST_NO is '客户号';
comment on column MBT_RPT_110_E .UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_E .PART_TYPE is '段标识';
comment on column MBT_RPT_110_E .PART_NAME is '段名称';
comment on column MBT_RPT_110_E .START_DATE is '起始日期';
comment on column MBT_RPT_110_E .END_DATE is '结束日期';
comment on column MBT_RPT_110_E .BATCH_NO is '批次号';
comment on column MBT_RPT_110_E .ROW_NUM is '行号';
comment on column MBT_RPT_110_E .IS_RPT is '是否报送';
comment on column MBT_RPT_110_E .IS_VALID is '是否有效';
comment on column MBT_RPT_110_E .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_E .OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_E .RPT_DATE is '报送日期';
comment on column MBT_RPT_110_E .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_E .RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_E .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_E .RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_E .RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_E .REMARKS is '备注';
comment on column MBT_RPT_110_E .CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_E .CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_E .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_E .NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_E .DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_E .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_E .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_E .DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_E .DATA_OP is '操作标志';
comment on column MBT_RPT_110_E .DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_E .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_E .DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_E .DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_E .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_E .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_E .DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_E .DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_E .DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_E .DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_E .DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_E .DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_E .DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_E .DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_E .DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_E .DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_E .RSV1 is '备用字段';
comment on column MBT_RPT_110_E .RSV2 is '备用字段';
comment on column MBT_RPT_110_E .RSV3 is '备用字段';
comment on column MBT_RPT_110_E .RSV4 is '备用字段';
comment on column MBT_RPT_110_E .RSV5 is '备用字段';
create table MBT_RPT_110_E (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
E_MARI_STATUS VARCHAR(2),
E_SPO_ID_NUM VARCHAR(40),
E_SPO_ID_TYPE VARCHAR(2),
E_SPO_NAME VARCHAR(60),
E_SPO_TEL VARCHAR(50),
E_SPS_CMPY_NM VARCHAR(160),
E_SPS_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_E is '个人基本信息-婚姻信息段';
comment on column MBT_RPT_110_E.DATA_ID is '数据ID';
comment on column MBT_RPT_110_E.DATA_DATE is '数据日期';
comment on column MBT_RPT_110_E.CORP_ID is '法人ID';
comment on column MBT_RPT_110_E.ORG_ID is '机构ID';
comment on column MBT_RPT_110_E.GROUP_ID is '数据分组';
comment on column MBT_RPT_110_E.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_E.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_E.E_MARI_STATUS is '婚姻状况';
comment on column MBT_RPT_110_E.E_SPO_ID_NUM is '配偶证件号码';
comment on column MBT_RPT_110_E.E_SPO_ID_TYPE is '配偶证件类型';
comment on column MBT_RPT_110_E.E_SPO_NAME is '配偶姓名';
comment on column MBT_RPT_110_E.E_SPO_TEL is '配偶联系电话';
comment on column MBT_RPT_110_E.E_SPS_CMPY_NM is '配偶工作单位';
comment on column MBT_RPT_110_E.E_SPS_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_110_E.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_E.B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_E.B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_E.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_E.CUST_NO is '客户号';
comment on column MBT_RPT_110_E.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_E.PART_TYPE is '段标识';
comment on column MBT_RPT_110_E.PART_NAME is '段名称';
comment on column MBT_RPT_110_E.START_DATE is '起始日期';
comment on column MBT_RPT_110_E.END_DATE is '结束日期';
comment on column MBT_RPT_110_E.BATCH_NO is '批次号';
comment on column MBT_RPT_110_E.ROW_NUM is '行号';
comment on column MBT_RPT_110_E.IS_RPT is '是否报送';
comment on column MBT_RPT_110_E.IS_VALID is '是否有效';
comment on column MBT_RPT_110_E.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_E.OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_E.RPT_DATE is '报送日期';
comment on column MBT_RPT_110_E.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_E.RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_E.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_E.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_E.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_E.REMARKS is '备注';
comment on column MBT_RPT_110_E.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_E.CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_E.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_E.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_E.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_E.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_E.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_E.DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_E.DATA_OP is '操作标志';
comment on column MBT_RPT_110_E.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_E.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_E.DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_E.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_E.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_E.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_E.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_E.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_E.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_E.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_E.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_E.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_E.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_E.DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_E.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_E.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_E.RSV1 is '备用字段';
comment on column MBT_RPT_110_E.RSV2 is '备用字段';
comment on column MBT_RPT_110_E.RSV3 is '备用字段';
comment on column MBT_RPT_110_E.RSV4 is '备用字段';
comment on column MBT_RPT_110_E.RSV5 is '备用字段';
create table MBT_RPT_110_F  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
F_ACA_DEGREE VARCHAR(1),
F_EDU_INFO_UP_DATE VARCHAR(8),
F_EDU_LEVEL VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_F  is '个人基本信息-教育信息段';
comment on column MBT_RPT_110_F .DATA_ID is '数据ID';
comment on column MBT_RPT_110_F .DATA_DATE is '数据日期';
comment on column MBT_RPT_110_F .CORP_ID is '法人ID';
comment on column MBT_RPT_110_F .ORG_ID is '机构ID';
comment on column MBT_RPT_110_F .GROUP_ID is '数据分组';
comment on column MBT_RPT_110_F .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_F .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_F .F_ACA_DEGREE is '学位';
comment on column MBT_RPT_110_F .F_EDU_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_110_F .F_EDU_LEVEL is '学历';
comment on column MBT_RPT_110_F .B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_F .B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_F .B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_F .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_F .CUST_NO is '客户号';
comment on column MBT_RPT_110_F .UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_F .PART_TYPE is '段标识';
comment on column MBT_RPT_110_F .PART_NAME is '段名称';
comment on column MBT_RPT_110_F .START_DATE is '起始日期';
comment on column MBT_RPT_110_F .END_DATE is '结束日期';
comment on column MBT_RPT_110_F .BATCH_NO is '批次号';
comment on column MBT_RPT_110_F .ROW_NUM is '行号';
comment on column MBT_RPT_110_F .IS_RPT is '是否报送';
comment on column MBT_RPT_110_F .IS_VALID is '是否有效';
comment on column MBT_RPT_110_F .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_F .OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_F .RPT_DATE is '报送日期';
comment on column MBT_RPT_110_F .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_F .RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_F .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_F .RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_F .RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_F .REMARKS is '备注';
comment on column MBT_RPT_110_F .CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_F .CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_F .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_F .NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_F .DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_F .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_F .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_F .DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_F .DATA_OP is '操作标志';
comment on column MBT_RPT_110_F .DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_F .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_F .DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_F .DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_F .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_F .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_F .DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_F .DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_F .DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_F .DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_F .DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_F .DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_F .DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_F .DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_F .DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_F .DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_F .RSV1 is '备用字段';
comment on column MBT_RPT_110_F .RSV2 is '备用字段';
comment on column MBT_RPT_110_F .RSV3 is '备用字段';
comment on column MBT_RPT_110_F .RSV4 is '备用字段';
comment on column MBT_RPT_110_F .RSV5 is '备用字段';
create table MBT_RPT_110_F (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
F_ACA_DEGREE VARCHAR(1),
F_EDU_INFO_UP_DATE VARCHAR(8),
F_EDU_LEVEL VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_F is '个人基本信息-教育信息段';
comment on column MBT_RPT_110_F.DATA_ID is '数据ID';
comment on column MBT_RPT_110_F.DATA_DATE is '数据日期';
comment on column MBT_RPT_110_F.CORP_ID is '法人ID';
comment on column MBT_RPT_110_F.ORG_ID is '机构ID';
comment on column MBT_RPT_110_F.GROUP_ID is '数据分组';
comment on column MBT_RPT_110_F.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_F.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_F.F_ACA_DEGREE is '学位';
comment on column MBT_RPT_110_F.F_EDU_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_110_F.F_EDU_LEVEL is '学历';
comment on column MBT_RPT_110_F.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_F.B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_F.B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_F.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_F.CUST_NO is '客户号';
comment on column MBT_RPT_110_F.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_F.PART_TYPE is '段标识';
comment on column MBT_RPT_110_F.PART_NAME is '段名称';
comment on column MBT_RPT_110_F.START_DATE is '起始日期';
comment on column MBT_RPT_110_F.END_DATE is '结束日期';
comment on column MBT_RPT_110_F.BATCH_NO is '批次号';
comment on column MBT_RPT_110_F.ROW_NUM is '行号';
comment on column MBT_RPT_110_F.IS_RPT is '是否报送';
comment on column MBT_RPT_110_F.IS_VALID is '是否有效';
comment on column MBT_RPT_110_F.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_F.OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_F.RPT_DATE is '报送日期';
comment on column MBT_RPT_110_F.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_F.RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_F.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_F.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_F.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_F.REMARKS is '备注';
comment on column MBT_RPT_110_F.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_F.CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_F.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_F.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_F.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_F.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_F.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_F.DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_F.DATA_OP is '操作标志';
comment on column MBT_RPT_110_F.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_F.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_F.DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_F.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_F.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_F.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_F.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_F.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_F.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_F.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_F.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_F.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_F.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_F.DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_F.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_F.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_F.RSV1 is '备用字段';
comment on column MBT_RPT_110_F.RSV2 is '备用字段';
comment on column MBT_RPT_110_F.RSV3 is '备用字段';
comment on column MBT_RPT_110_F.RSV4 is '备用字段';
comment on column MBT_RPT_110_F.RSV5 is '备用字段';
create table MBT_RPT_110_G  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_CPN_ADDR VARCHAR(200),
G_CPN_DIST VARCHAR(6),
G_CPN_NAME VARCHAR(160),
G_CPN_PC VARCHAR(6),
G_CPN_TEL VARCHAR(50),
G_CPN_TYPE VARCHAR(2),
G_EMP_STATUS VARCHAR(2),
G_INDUSTRY VARCHAR(1),
G_OCCUPATION VARCHAR(1),
G_OCTPN_INFO_UP_DATE VARCHAR(8),
G_TECH_TITLE VARCHAR(1),
G_TITLE VARCHAR(1),
G_WORK_START_DATE VARCHAR(4),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_G  is '个人基本信息-职业信息段';
comment on column MBT_RPT_110_G .DATA_ID is '数据ID';
comment on column MBT_RPT_110_G .DATA_DATE is '数据日期';
comment on column MBT_RPT_110_G .CORP_ID is '法人ID';
comment on column MBT_RPT_110_G .ORG_ID is '机构ID';
comment on column MBT_RPT_110_G .GROUP_ID is '数据分组';
comment on column MBT_RPT_110_G .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_G .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_G .G_CPN_ADDR is '单位详细地址';
comment on column MBT_RPT_110_G .G_CPN_DIST is '单位所在地行政区划';
comment on column MBT_RPT_110_G .G_CPN_NAME is '单位名称';
comment on column MBT_RPT_110_G .G_CPN_PC is '单位所在地邮编';
comment on column MBT_RPT_110_G .G_CPN_TEL is '单位电话';
comment on column MBT_RPT_110_G .G_CPN_TYPE is '单位性质';
comment on column MBT_RPT_110_G .G_EMP_STATUS is '就业状况';
comment on column MBT_RPT_110_G .G_INDUSTRY is '单位所属行业';
comment on column MBT_RPT_110_G .G_OCCUPATION is '职业';
comment on column MBT_RPT_110_G .G_OCTPN_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_110_G .G_TECH_TITLE is '职称';
comment on column MBT_RPT_110_G .G_TITLE is '职务';
comment on column MBT_RPT_110_G .G_WORK_START_DATE is '本单位工作起始年份';
comment on column MBT_RPT_110_G .B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_G .B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_G .B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_G .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_G .CUST_NO is '客户号';
comment on column MBT_RPT_110_G .UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_G .PART_TYPE is '段标识';
comment on column MBT_RPT_110_G .PART_NAME is '段名称';
comment on column MBT_RPT_110_G .START_DATE is '起始日期';
comment on column MBT_RPT_110_G .END_DATE is '结束日期';
comment on column MBT_RPT_110_G .BATCH_NO is '批次号';
comment on column MBT_RPT_110_G .ROW_NUM is '行号';
comment on column MBT_RPT_110_G .IS_RPT is '是否报送';
comment on column MBT_RPT_110_G .IS_VALID is '是否有效';
comment on column MBT_RPT_110_G .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_G .OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_G .RPT_DATE is '报送日期';
comment on column MBT_RPT_110_G .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_G .RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_G .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_G .RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_G .RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_G .REMARKS is '备注';
comment on column MBT_RPT_110_G .CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_G .CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_G .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_G .NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_G .DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_G .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_G .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_G .DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_G .DATA_OP is '操作标志';
comment on column MBT_RPT_110_G .DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_G .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_G .DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_G .DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_G .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_G .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_G .DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_G .DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_G .DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_G .DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_G .DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_G .DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_G .DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_G .DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_G .DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_G .DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_G .RSV1 is '备用字段';
comment on column MBT_RPT_110_G .RSV2 is '备用字段';
comment on column MBT_RPT_110_G .RSV3 is '备用字段';
comment on column MBT_RPT_110_G .RSV4 is '备用字段';
comment on column MBT_RPT_110_G .RSV5 is '备用字段';
create table MBT_RPT_110_G (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_CPN_ADDR VARCHAR(200),
G_CPN_DIST VARCHAR(6),
G_CPN_NAME VARCHAR(160),
G_CPN_PC VARCHAR(6),
G_CPN_TEL VARCHAR(50),
G_CPN_TYPE VARCHAR(2),
G_EMP_STATUS VARCHAR(2),
G_INDUSTRY VARCHAR(1),
G_OCCUPATION VARCHAR(1),
G_OCTPN_INFO_UP_DATE VARCHAR(8),
G_TECH_TITLE VARCHAR(1),
G_TITLE VARCHAR(1),
G_WORK_START_DATE VARCHAR(4),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_G is '个人基本信息-职业信息段';
comment on column MBT_RPT_110_G.DATA_ID is '数据ID';
comment on column MBT_RPT_110_G.DATA_DATE is '数据日期';
comment on column MBT_RPT_110_G.CORP_ID is '法人ID';
comment on column MBT_RPT_110_G.ORG_ID is '机构ID';
comment on column MBT_RPT_110_G.GROUP_ID is '数据分组';
comment on column MBT_RPT_110_G.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_G.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_G.G_CPN_ADDR is '单位详细地址';
comment on column MBT_RPT_110_G.G_CPN_DIST is '单位所在地行政区划';
comment on column MBT_RPT_110_G.G_CPN_NAME is '单位名称';
comment on column MBT_RPT_110_G.G_CPN_PC is '单位所在地邮编';
comment on column MBT_RPT_110_G.G_CPN_TEL is '单位电话';
comment on column MBT_RPT_110_G.G_CPN_TYPE is '单位性质';
comment on column MBT_RPT_110_G.G_EMP_STATUS is '就业状况';
comment on column MBT_RPT_110_G.G_INDUSTRY is '单位所属行业';
comment on column MBT_RPT_110_G.G_OCCUPATION is '职业';
comment on column MBT_RPT_110_G.G_OCTPN_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_110_G.G_TECH_TITLE is '职称';
comment on column MBT_RPT_110_G.G_TITLE is '职务';
comment on column MBT_RPT_110_G.G_WORK_START_DATE is '本单位工作起始年份';
comment on column MBT_RPT_110_G.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_G.B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_G.B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_G.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_G.CUST_NO is '客户号';
comment on column MBT_RPT_110_G.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_G.PART_TYPE is '段标识';
comment on column MBT_RPT_110_G.PART_NAME is '段名称';
comment on column MBT_RPT_110_G.START_DATE is '起始日期';
comment on column MBT_RPT_110_G.END_DATE is '结束日期';
comment on column MBT_RPT_110_G.BATCH_NO is '批次号';
comment on column MBT_RPT_110_G.ROW_NUM is '行号';
comment on column MBT_RPT_110_G.IS_RPT is '是否报送';
comment on column MBT_RPT_110_G.IS_VALID is '是否有效';
comment on column MBT_RPT_110_G.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_G.OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_G.RPT_DATE is '报送日期';
comment on column MBT_RPT_110_G.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_G.RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_G.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_G.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_G.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_G.REMARKS is '备注';
comment on column MBT_RPT_110_G.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_G.CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_G.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_G.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_G.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_G.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_G.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_G.DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_G.DATA_OP is '操作标志';
comment on column MBT_RPT_110_G.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_G.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_G.DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_G.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_G.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_G.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_G.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_G.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_G.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_G.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_G.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_G.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_G.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_G.DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_G.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_G.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_G.RSV1 is '备用字段';
comment on column MBT_RPT_110_G.RSV2 is '备用字段';
comment on column MBT_RPT_110_G.RSV3 is '备用字段';
comment on column MBT_RPT_110_G.RSV4 is '备用字段';
comment on column MBT_RPT_110_G.RSV5 is '备用字段';
create table MBT_RPT_110_H  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
H_HOME_TEL VARCHAR(50),
H_RESI_ADDR VARCHAR(200),
H_RESI_DIST VARCHAR(6),
H_RESI_INFO_UP_DATE VARCHAR(8),
H_RESI_PC VARCHAR(6),
H_RESI_STATUS VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_H  is '个人基本信息-居住地址段';
comment on column MBT_RPT_110_H .DATA_ID is '数据ID';
comment on column MBT_RPT_110_H .DATA_DATE is '数据日期';
comment on column MBT_RPT_110_H .CORP_ID is '法人ID';
comment on column MBT_RPT_110_H .ORG_ID is '机构ID';
comment on column MBT_RPT_110_H .GROUP_ID is '数据分组';
comment on column MBT_RPT_110_H .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_H .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_H .H_HOME_TEL is '住宅电话';
comment on column MBT_RPT_110_H .H_RESI_ADDR is '居住地详细地址';
comment on column MBT_RPT_110_H .H_RESI_DIST is '居住地行政区划';
comment on column MBT_RPT_110_H .H_RESI_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_110_H .H_RESI_PC is '居住地邮编';
comment on column MBT_RPT_110_H .H_RESI_STATUS is '居住状况';
comment on column MBT_RPT_110_H .B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_H .B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_H .B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_H .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_H .CUST_NO is '客户号';
comment on column MBT_RPT_110_H .UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_H .PART_TYPE is '段标识';
comment on column MBT_RPT_110_H .PART_NAME is '段名称';
comment on column MBT_RPT_110_H .START_DATE is '起始日期';
comment on column MBT_RPT_110_H .END_DATE is '结束日期';
comment on column MBT_RPT_110_H .BATCH_NO is '批次号';
comment on column MBT_RPT_110_H .ROW_NUM is '行号';
comment on column MBT_RPT_110_H .IS_RPT is '是否报送';
comment on column MBT_RPT_110_H .IS_VALID is '是否有效';
comment on column MBT_RPT_110_H .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_H .OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_H .RPT_DATE is '报送日期';
comment on column MBT_RPT_110_H .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_H .RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_H .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_H .RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_H .RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_H .REMARKS is '备注';
comment on column MBT_RPT_110_H .CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_H .CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_H .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_H .NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_H .DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_H .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_H .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_H .DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_H .DATA_OP is '操作标志';
comment on column MBT_RPT_110_H .DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_H .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_H .DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_H .DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_H .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_H .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_H .DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_H .DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_H .DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_H .DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_H .DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_H .DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_H .DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_H .DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_H .DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_H .DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_H .RSV1 is '备用字段';
comment on column MBT_RPT_110_H .RSV2 is '备用字段';
comment on column MBT_RPT_110_H .RSV3 is '备用字段';
comment on column MBT_RPT_110_H .RSV4 is '备用字段';
comment on column MBT_RPT_110_H .RSV5 is '备用字段';
create table MBT_RPT_110_H (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
H_HOME_TEL VARCHAR(50),
H_RESI_ADDR VARCHAR(200),
H_RESI_DIST VARCHAR(6),
H_RESI_INFO_UP_DATE VARCHAR(8),
H_RESI_PC VARCHAR(6),
H_RESI_STATUS VARCHAR(2),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_H is '个人基本信息-居住地址段';
comment on column MBT_RPT_110_H.DATA_ID is '数据ID';
comment on column MBT_RPT_110_H.DATA_DATE is '数据日期';
comment on column MBT_RPT_110_H.CORP_ID is '法人ID';
comment on column MBT_RPT_110_H.ORG_ID is '机构ID';
comment on column MBT_RPT_110_H.GROUP_ID is '数据分组';
comment on column MBT_RPT_110_H.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_H.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_H.H_HOME_TEL is '住宅电话';
comment on column MBT_RPT_110_H.H_RESI_ADDR is '居住地详细地址';
comment on column MBT_RPT_110_H.H_RESI_DIST is '居住地行政区划';
comment on column MBT_RPT_110_H.H_RESI_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_110_H.H_RESI_PC is '居住地邮编';
comment on column MBT_RPT_110_H.H_RESI_STATUS is '居住状况';
comment on column MBT_RPT_110_H.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_H.B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_H.B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_H.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_H.CUST_NO is '客户号';
comment on column MBT_RPT_110_H.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_H.PART_TYPE is '段标识';
comment on column MBT_RPT_110_H.PART_NAME is '段名称';
comment on column MBT_RPT_110_H.START_DATE is '起始日期';
comment on column MBT_RPT_110_H.END_DATE is '结束日期';
comment on column MBT_RPT_110_H.BATCH_NO is '批次号';
comment on column MBT_RPT_110_H.ROW_NUM is '行号';
comment on column MBT_RPT_110_H.IS_RPT is '是否报送';
comment on column MBT_RPT_110_H.IS_VALID is '是否有效';
comment on column MBT_RPT_110_H.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_H.OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_H.RPT_DATE is '报送日期';
comment on column MBT_RPT_110_H.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_H.RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_H.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_H.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_H.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_H.REMARKS is '备注';
comment on column MBT_RPT_110_H.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_H.CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_H.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_H.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_H.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_H.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_H.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_H.DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_H.DATA_OP is '操作标志';
comment on column MBT_RPT_110_H.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_H.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_H.DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_H.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_H.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_H.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_H.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_H.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_H.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_H.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_H.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_H.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_H.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_H.DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_H.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_H.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_H.RSV1 is '备用字段';
comment on column MBT_RPT_110_H.RSV2 is '备用字段';
comment on column MBT_RPT_110_H.RSV3 is '备用字段';
comment on column MBT_RPT_110_H.RSV4 is '备用字段';
comment on column MBT_RPT_110_H.RSV5 is '备用字段';
create table MBT_RPT_110_I  (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
I_MAIL_ADDR VARCHAR(200),
I_MAIL_DIST VARCHAR(6),
I_MAIL_PC VARCHAR(6),
I_MLG_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_I  is '个人基本信息-通讯地址段';
comment on column MBT_RPT_110_I .DATA_ID is '数据ID';
comment on column MBT_RPT_110_I .DATA_DATE is '数据日期';
comment on column MBT_RPT_110_I .CORP_ID is '法人ID';
comment on column MBT_RPT_110_I .ORG_ID is '机构ID';
comment on column MBT_RPT_110_I .GROUP_ID is '数据分组';
comment on column MBT_RPT_110_I .INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_I .INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_I .I_MAIL_ADDR is '通讯地址';
comment on column MBT_RPT_110_I .I_MAIL_DIST is '通讯地行政区划';
comment on column MBT_RPT_110_I .I_MAIL_PC is '通讯地邮编';
comment on column MBT_RPT_110_I .I_MLG_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_110_I .B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_I .B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_I .B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_I .B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_I .CUST_NO is '客户号';
comment on column MBT_RPT_110_I .UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_I .PART_TYPE is '段标识';
comment on column MBT_RPT_110_I .PART_NAME is '段名称';
comment on column MBT_RPT_110_I .START_DATE is '起始日期';
comment on column MBT_RPT_110_I .END_DATE is '结束日期';
comment on column MBT_RPT_110_I .BATCH_NO is '批次号';
comment on column MBT_RPT_110_I .ROW_NUM is '行号';
comment on column MBT_RPT_110_I .IS_RPT is '是否报送';
comment on column MBT_RPT_110_I .IS_VALID is '是否有效';
comment on column MBT_RPT_110_I .IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_I .OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_I .RPT_DATE is '报送日期';
comment on column MBT_RPT_110_I .LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_I .RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_I .CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_I .RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_I .RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_I .REMARKS is '备注';
comment on column MBT_RPT_110_I .CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_I .CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_I .CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_I .NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_I .DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_I .CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_I .RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_I .DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_I .DATA_OP is '操作标志';
comment on column MBT_RPT_110_I .DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_I .DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_I .DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_I .DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_I .P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_I .DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_I .DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_I .DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_I .DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_I .DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_I .DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_I .DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_I .DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_I .DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_I .DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_I .DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_I .RSV1 is '备用字段';
comment on column MBT_RPT_110_I .RSV2 is '备用字段';
comment on column MBT_RPT_110_I .RSV3 is '备用字段';
comment on column MBT_RPT_110_I .RSV4 is '备用字段';
comment on column MBT_RPT_110_I .RSV5 is '备用字段';
create table MBT_RPT_110_I (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
I_MAIL_ADDR VARCHAR(200),
I_MAIL_DIST VARCHAR(6),
I_MAIL_PC VARCHAR(6),
I_MLG_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_I is '个人基本信息-通讯地址段';
comment on column MBT_RPT_110_I.DATA_ID is '数据ID';
comment on column MBT_RPT_110_I.DATA_DATE is '数据日期';
comment on column MBT_RPT_110_I.CORP_ID is '法人ID';
comment on column MBT_RPT_110_I.ORG_ID is '机构ID';
comment on column MBT_RPT_110_I.GROUP_ID is '数据分组';
comment on column MBT_RPT_110_I.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_I.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_I.I_MAIL_ADDR is '通讯地址';
comment on column MBT_RPT_110_I.I_MAIL_DIST is '通讯地行政区划';
comment on column MBT_RPT_110_I.I_MAIL_PC is '通讯地邮编';
comment on column MBT_RPT_110_I.I_MLG_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_110_I.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_I.B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_I.B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_I.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_I.CUST_NO is '客户号';
comment on column MBT_RPT_110_I.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_I.PART_TYPE is '段标识';
comment on column MBT_RPT_110_I.PART_NAME is '段名称';
comment on column MBT_RPT_110_I.START_DATE is '起始日期';
comment on column MBT_RPT_110_I.END_DATE is '结束日期';
comment on column MBT_RPT_110_I.BATCH_NO is '批次号';
comment on column MBT_RPT_110_I.ROW_NUM is '行号';
comment on column MBT_RPT_110_I.IS_RPT is '是否报送';
comment on column MBT_RPT_110_I.IS_VALID is '是否有效';
comment on column MBT_RPT_110_I.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_I.OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_I.RPT_DATE is '报送日期';
comment on column MBT_RPT_110_I.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_I.RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_I.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_I.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_I.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_I.REMARKS is '备注';
comment on column MBT_RPT_110_I.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_I.CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_I.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_I.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_I.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_I.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_I.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_I.DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_I.DATA_OP is '操作标志';
comment on column MBT_RPT_110_I.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_I.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_I.DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_I.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_I.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_I.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_I.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_I.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_I.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_I.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_I.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_I.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_I.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_I.DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_I.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_I.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_I.RSV1 is '备用字段';
comment on column MBT_RPT_110_I.RSV2 is '备用字段';
comment on column MBT_RPT_110_I.RSV3 is '备用字段';
comment on column MBT_RPT_110_I.RSV4 is '备用字段';
comment on column MBT_RPT_110_I.RSV5 is '备用字段';
create table MBT_RPT_110_J (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
J_ANNL_INC NUMBER(15),
J_ANNL_INC_LCY NUMBER(15),
J_ANNL_INC_ORG NUMBER(15),
J_INC_INFO_UP_DATE VARCHAR(8),
J_TAX_INCOME NUMBER(15),
J_TAX_INCOME_LCY NUMBER(15),
J_TAX_INCOME_ORG NUMBER(15),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_SURC_CODE VARCHAR(20),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_110_J is '个人基本信息-收入信息段';
comment on column MBT_RPT_110_J.DATA_ID is '数据ID';
comment on column MBT_RPT_110_J.DATA_DATE is '数据日期';
comment on column MBT_RPT_110_J.CORP_ID is '法人ID';
comment on column MBT_RPT_110_J.ORG_ID is '机构ID';
comment on column MBT_RPT_110_J.GROUP_ID is '数据分组';
comment on column MBT_RPT_110_J.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_110_J.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_110_J.J_ANNL_INC is '自报年收入';
comment on column MBT_RPT_110_J.J_ANNL_INC_LCY is '自报年收入人民币金额';
comment on column MBT_RPT_110_J.J_ANNL_INC_ORG is '自报年收入_原始数据金额';
comment on column MBT_RPT_110_J.J_INC_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_110_J.J_TAX_INCOME is '纳税年收入';
comment on column MBT_RPT_110_J.J_TAX_INCOME_LCY is '纳税年收入人民币金额';
comment on column MBT_RPT_110_J.J_TAX_INCOME_ORG is '纳税年收入_原始数据金额';
comment on column MBT_RPT_110_J.C_CY is '币种';
comment on column MBT_RPT_110_J.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_110_J.B_ID_NUM is '证件号码';
comment on column MBT_RPT_110_J.B_ID_TYPE is '证件类型';
comment on column MBT_RPT_110_J.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_110_J.CUST_NO is '客户号';
comment on column MBT_RPT_110_J.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_110_J.PART_TYPE is '段标识';
comment on column MBT_RPT_110_J.PART_NAME is '段名称';
comment on column MBT_RPT_110_J.START_DATE is '起始日期';
comment on column MBT_RPT_110_J.END_DATE is '结束日期';
comment on column MBT_RPT_110_J.BATCH_NO is '批次号';
comment on column MBT_RPT_110_J.ROW_NUM is '行号';
comment on column MBT_RPT_110_J.IS_RPT is '是否报送';
comment on column MBT_RPT_110_J.IS_VALID is '是否有效';
comment on column MBT_RPT_110_J.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_110_J.OPT_FLAG is '操作标识';
comment on column MBT_RPT_110_J.RPT_DATE is '报送日期';
comment on column MBT_RPT_110_J.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_110_J.RPT_STATUS is '报送状态';
comment on column MBT_RPT_110_J.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_110_J.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_110_J.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_110_J.REMARKS is '备注';
comment on column MBT_RPT_110_J.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_110_J.CHECK_DESC is '校验说明';
comment on column MBT_RPT_110_J.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_110_J.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_110_J.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_110_J.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_110_J.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_110_J.DATA_FLAG is '数据标志';
comment on column MBT_RPT_110_J.DATA_OP is '操作标志';
comment on column MBT_RPT_110_J.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_110_J.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_110_J.DATA_HASH is '数据HASH';
comment on column MBT_RPT_110_J.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_J.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_110_J.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_110_J.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_110_J.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_110_J.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_110_J.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_110_J.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_110_J.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_110_J.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_110_J.DATA_APV_USER is '审核人';
comment on column MBT_RPT_110_J.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_110_J.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_110_J.RSV1 is '备用字段';
comment on column MBT_RPT_110_J.RSV2 is '备用字段';
comment on column MBT_RPT_110_J.RSV3 is '备用字段';
comment on column MBT_RPT_110_J.RSV4 is '备用字段';
comment on column MBT_RPT_110_J.RSV5 is '备用字段';
