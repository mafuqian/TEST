create table MBT_DM_640 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_640 is '事业单位资产负债表信息';
comment on column MBT_DM_640.DATA_ID is '数据ID';
comment on column MBT_DM_640.DATA_DATE is '数据日期';
comment on column MBT_DM_640.CORP_ID is '法人ID';
comment on column MBT_DM_640.ORG_ID is '机构ID';
comment on column MBT_DM_640.GROUP_ID is '数据分组';
comment on column MBT_DM_640.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_640.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_640.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_640.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_640.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_640.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_640.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_640.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_640.B_ENT_NAME is '企业名称';
comment on column MBT_DM_640.SECTION_CHG_CNT is '段变更';
comment on column MBT_DM_640.SECTION_DEL_CNT is '段删除';
comment on column MBT_DM_640.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_DM_640.IDN_CHG_CNT is '标识项变更';
comment on column MBT_DM_640.CUST_NO is '客户号';
comment on column MBT_DM_640.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_640.PART_TYPE is '段标识';
comment on column MBT_DM_640.PART_NAME is '段名称';
comment on column MBT_DM_640.START_DATE is '起始日期';
comment on column MBT_DM_640.END_DATE is '结束日期';
comment on column MBT_DM_640.BATCH_NO is '批次号';
comment on column MBT_DM_640.ROW_NUM is '行号';
comment on column MBT_DM_640.IS_RPT is '是否报送';
comment on column MBT_DM_640.IS_VALID is '是否有效';
comment on column MBT_DM_640.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_640.OPT_FLAG is '操作标识';
comment on column MBT_DM_640.RPT_DATE is '报送日期';
comment on column MBT_DM_640.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_640.RPT_STATUS is '报送状态';
comment on column MBT_DM_640.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_640.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_640.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_640.REMARKS is '备注';
comment on column MBT_DM_640.CHECK_FLAG is '校验标志';
comment on column MBT_DM_640.CHECK_DESC is '校验说明';
comment on column MBT_DM_640.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_640.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_640.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_640.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_640.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_640.DATA_FLAG is '数据标志';
comment on column MBT_DM_640.DATA_OP is '操作标志';
comment on column MBT_DM_640.DATA_SOURCE is '数据来源';
comment on column MBT_DM_640.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_640.DATA_HASH is '数据HASH';
comment on column MBT_DM_640.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_640.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_640.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_640.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_640.DATA_CRT_USER is '创建人';
comment on column MBT_DM_640.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_640.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_640.DATA_CHG_USER is '修改人';
comment on column MBT_DM_640.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_640.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_640.DATA_APV_USER is '审核人';
comment on column MBT_DM_640.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_640.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_640.RSV1 is '备用字段';
comment on column MBT_DM_640.RSV2 is '备用字段';
comment on column MBT_DM_640.RSV3 is '备用字段';
comment on column MBT_DM_640.RSV4 is '备用字段';
comment on column MBT_DM_640.RSV5 is '备用字段';
create table MBT_DM_640_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_640_B is '事业单位资产负债表信息-基础段';
comment on column MBT_DM_640_B.DATA_ID is '数据ID';
comment on column MBT_DM_640_B.DATA_DATE is '数据日期';
comment on column MBT_DM_640_B.CORP_ID is '法人ID';
comment on column MBT_DM_640_B.ORG_ID is '机构ID';
comment on column MBT_DM_640_B.GROUP_ID is '数据分组';
comment on column MBT_DM_640_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_640_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_640_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_640_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_640_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_640_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_640_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_640_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_640_B.B_ENT_NAME is '企业名称';
comment on column MBT_DM_640_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_DM_640_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_DM_640_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_DM_640_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_DM_640_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_DM_640_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_640_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_DM_640_B.CUST_NO is '客户号';
comment on column MBT_DM_640_B.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_640_B.PART_TYPE is '段标识';
comment on column MBT_DM_640_B.PART_NAME is '段名称';
comment on column MBT_DM_640_B.START_DATE is '起始日期';
comment on column MBT_DM_640_B.END_DATE is '结束日期';
comment on column MBT_DM_640_B.BATCH_NO is '批次号';
comment on column MBT_DM_640_B.ROW_NUM is '行号';
comment on column MBT_DM_640_B.IS_RPT is '是否报送';
comment on column MBT_DM_640_B.IS_VALID is '是否有效';
comment on column MBT_DM_640_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_640_B.OPT_FLAG is '操作标识';
comment on column MBT_DM_640_B.RPT_DATE is '报送日期';
comment on column MBT_DM_640_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_640_B.RPT_STATUS is '报送状态';
comment on column MBT_DM_640_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_640_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_640_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_640_B.REMARKS is '备注';
comment on column MBT_DM_640_B.CHECK_FLAG is '校验标志';
comment on column MBT_DM_640_B.CHECK_DESC is '校验说明';
comment on column MBT_DM_640_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_640_B.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_640_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_640_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_640_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_640_B.DATA_FLAG is '数据标志';
comment on column MBT_DM_640_B.DATA_OP is '操作标志';
comment on column MBT_DM_640_B.DATA_SOURCE is '数据来源';
comment on column MBT_DM_640_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_640_B.DATA_HASH is '数据HASH';
comment on column MBT_DM_640_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_640_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_640_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_640_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_640_B.DATA_CRT_USER is '创建人';
comment on column MBT_DM_640_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_640_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_640_B.DATA_CHG_USER is '修改人';
comment on column MBT_DM_640_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_640_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_640_B.DATA_APV_USER is '审核人';
comment on column MBT_DM_640_B.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_640_B.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_640_B.RSV1 is '备用字段';
comment on column MBT_DM_640_B.RSV2 is '备用字段';
comment on column MBT_DM_640_B.RSV3 is '备用字段';
comment on column MBT_DM_640_B.RSV4 is '备用字段';
comment on column MBT_DM_640_B.RSV5 is '备用字段';
create table MBT_DM_640_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ACCOUNTS_PAYABLE NUMBER(17),
C_ACCOUNTS_RECEIVABLE NUMBER(17),
C_ACCUMULATED_AMORTIZATION NUMBER(17),
C_AMOUNT_OF_FINANCIAL_RETURN NUMBER(17),
C_ASSETS_PROCESSED_PENDING_PRO NUMBER(17),
C_CONSTRUCTION_IN_PROCESS NUMBER(17),
C_CURRENCY_FUNDS NUMBER(17),
C_EMPLOYEE_BENEFITS_PAYABLE NUMBER(17),
C_ENTERPRISE_FUND NUMBER(17),
C_FINANCIAL_AID_BALANCE NUMBER(17),
C_FINANCIAL_AID_CARRIED_OVER NUMBER(17),
C_FIXED_ASSETS NUMBER(17),
C_FIXED_ASSET_ACC_DEPRECIATION NUMBER(17),
C_INTANGIBLE_ASSETS NUMBER(17),
C_INVENTORIES NUMBER(17),
C_LONG_TERM_BORROWINGS NUMBER(17),
C_LONG_TERM_INVESTMENT NUMBER(17),
C_LONG_TERM_PAYABLES NUMBER(17),
C_NON_CURRENT_ASSETS_FUND NUMBER(17),
C_NON_FINANCIAL_AID_BALANCE NUMBER(17),
C_NON_FINANCIAL_AID_CARR_OVER NUMBER(17),
C_NOTES_PAYABLE NUMBER(17),
C_NOTES_RECEIVABLE NUMBER(17),
C_OPERATING_BALANCE NUMBER(17),
C_ORIGINAL_COST_FIXED_ASSET NUMBER(17),
C_ORIGINAL_PRICE_INTAN_ASSETS NUMBER(17),
C_OTHER_CURRENT_ASSETS NUMBER(17),
C_OTHER_CURRENT_LIABILITIES NUMBER(17),
C_OTHER_PAYABLES NUMBER(17),
C_OTHER_RECEIVABLES NUMBER(17),
C_PAYABLE_FINANCIAL_SPECIAL_AC NUMBER(17),
C_PREPAYMENTS NUMBER(17),
C_RECEIPTS_INADVANCE NUMBER(17),
C_SHORT_TERM_BORROWINGS NUMBER(17),
C_SHORT_TERM_INVESTMENTS NUMBER(17),
C_SPECIAL_PURPOSE_FUNDS NUMBER(17),
C_TAX_PAYABLE NUMBER(17),
C_TOTAL_ASSETS NUMBER(17),
C_TOTAL_CURRENT_ASSETS NUMBER(17),
C_TOTAL_CURRENT_LIABILITIES NUMBER(17),
C_TOTAL_LIABILITIES NUMBER(17),
C_TOTAL_LIABILITIES_NET_ASSETS NUMBER(17),
C_TOTAL_NET_ASSETS NUMBER(17),
C_TOTAL_NON_CURRENT_ASSETS NUMBER(17),
C_TOTAL_NON_CURRENT_LIABILITIE NUMBER(17),
C_TREASURY_PAYABLE NUMBER(17),
C_UNDERTAKINGS_BALANCE NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_640_C is '事业单位资产负债表信息-事业单位资产负债表段';
comment on column MBT_DM_640_C.DATA_ID is '数据ID';
comment on column MBT_DM_640_C.DATA_DATE is '数据日期';
comment on column MBT_DM_640_C.CORP_ID is '法人ID';
comment on column MBT_DM_640_C.ORG_ID is '机构ID';
comment on column MBT_DM_640_C.GROUP_ID is '数据分组';
comment on column MBT_DM_640_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_640_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_640_C.C_ACCOUNTS_PAYABLE is '应付账款';
comment on column MBT_DM_640_C.C_ACCOUNTS_RECEIVABLE is '应收账款';
comment on column MBT_DM_640_C.C_ACCUMULATED_AMORTIZATION is '累计摊销';
comment on column MBT_DM_640_C.C_AMOUNT_OF_FINANCIAL_RETURN is '财政应返还额度';
comment on column MBT_DM_640_C.C_ASSETS_PROCESSED_PENDING_PRO is '待处置资产损溢';
comment on column MBT_DM_640_C.C_CONSTRUCTION_IN_PROCESS is '在建工程';
comment on column MBT_DM_640_C.C_CURRENCY_FUNDS is '货币资金';
comment on column MBT_DM_640_C.C_EMPLOYEE_BENEFITS_PAYABLE is '应付职工薪酬';
comment on column MBT_DM_640_C.C_ENTERPRISE_FUND is '事业基金';
comment on column MBT_DM_640_C.C_FINANCIAL_AID_BALANCE is '财政补助结余';
comment on column MBT_DM_640_C.C_FINANCIAL_AID_CARRIED_OVER is '财政补助结转';
comment on column MBT_DM_640_C.C_FIXED_ASSETS is '固定资产';
comment on column MBT_DM_640_C.C_FIXED_ASSET_ACC_DEPRECIATION is '累计折旧';
comment on column MBT_DM_640_C.C_INTANGIBLE_ASSETS is '无形资产';
comment on column MBT_DM_640_C.C_INVENTORIES is '存货';
comment on column MBT_DM_640_C.C_LONG_TERM_BORROWINGS is '长期借款';
comment on column MBT_DM_640_C.C_LONG_TERM_INVESTMENT is '长期投资';
comment on column MBT_DM_640_C.C_LONG_TERM_PAYABLES is '长期应付款';
comment on column MBT_DM_640_C.C_NON_CURRENT_ASSETS_FUND is '非流动资产基金';
comment on column MBT_DM_640_C.C_NON_FINANCIAL_AID_BALANCE is '非财政补助结余';
comment on column MBT_DM_640_C.C_NON_FINANCIAL_AID_CARR_OVER is '非财政补助结转';
comment on column MBT_DM_640_C.C_NOTES_PAYABLE is '应付票据';
comment on column MBT_DM_640_C.C_NOTES_RECEIVABLE is '应收票据';
comment on column MBT_DM_640_C.C_OPERATING_BALANCE is '经营结余';
comment on column MBT_DM_640_C.C_ORIGINAL_COST_FIXED_ASSET is '固定资产原价';
comment on column MBT_DM_640_C.C_ORIGINAL_PRICE_INTAN_ASSETS is '无形资产原价';
comment on column MBT_DM_640_C.C_OTHER_CURRENT_ASSETS is '其他流动资产';
comment on column MBT_DM_640_C.C_OTHER_CURRENT_LIABILITIES is '其他流动负债';
comment on column MBT_DM_640_C.C_OTHER_PAYABLES is '其他应付款';
comment on column MBT_DM_640_C.C_OTHER_RECEIVABLES is '其他应收款';
comment on column MBT_DM_640_C.C_PAYABLE_FINANCIAL_SPECIAL_AC is '应缴财政专户款';
comment on column MBT_DM_640_C.C_PREPAYMENTS is '预付账款';
comment on column MBT_DM_640_C.C_RECEIPTS_INADVANCE is '预收账款';
comment on column MBT_DM_640_C.C_SHORT_TERM_BORROWINGS is '短期借款';
comment on column MBT_DM_640_C.C_SHORT_TERM_INVESTMENTS is '短期投资';
comment on column MBT_DM_640_C.C_SPECIAL_PURPOSE_FUNDS is '专用基金';
comment on column MBT_DM_640_C.C_TAX_PAYABLE is '应缴税费';
comment on column MBT_DM_640_C.C_TOTAL_ASSETS is '资产总计';
comment on column MBT_DM_640_C.C_TOTAL_CURRENT_ASSETS is '流动资产合计';
comment on column MBT_DM_640_C.C_TOTAL_CURRENT_LIABILITIES is '流动负债合计';
comment on column MBT_DM_640_C.C_TOTAL_LIABILITIES is '负债合计';
comment on column MBT_DM_640_C.C_TOTAL_LIABILITIES_NET_ASSETS is '负债和净资产总计';
comment on column MBT_DM_640_C.C_TOTAL_NET_ASSETS is '净资产合计';
comment on column MBT_DM_640_C.C_TOTAL_NON_CURRENT_ASSETS is '非流动资产合计';
comment on column MBT_DM_640_C.C_TOTAL_NON_CURRENT_LIABILITIE is '非流动负债合计';
comment on column MBT_DM_640_C.C_TREASURY_PAYABLE is '应缴国库款';
comment on column MBT_DM_640_C.C_UNDERTAKINGS_BALANCE is '事业结余';
comment on column MBT_DM_640_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_640_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_640_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_640_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_640_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_640_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_640_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_640_C.CUST_NO is '客户号';
comment on column MBT_DM_640_C.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_640_C.PART_TYPE is '段标识';
comment on column MBT_DM_640_C.PART_NAME is '段名称';
comment on column MBT_DM_640_C.START_DATE is '起始日期';
comment on column MBT_DM_640_C.END_DATE is '结束日期';
comment on column MBT_DM_640_C.BATCH_NO is '批次号';
comment on column MBT_DM_640_C.ROW_NUM is '行号';
comment on column MBT_DM_640_C.IS_RPT is '是否报送';
comment on column MBT_DM_640_C.IS_VALID is '是否有效';
comment on column MBT_DM_640_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_640_C.OPT_FLAG is '操作标识';
comment on column MBT_DM_640_C.RPT_DATE is '报送日期';
comment on column MBT_DM_640_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_640_C.RPT_STATUS is '报送状态';
comment on column MBT_DM_640_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_640_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_640_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_640_C.REMARKS is '备注';
comment on column MBT_DM_640_C.CHECK_FLAG is '校验标志';
comment on column MBT_DM_640_C.CHECK_DESC is '校验说明';
comment on column MBT_DM_640_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_640_C.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_640_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_640_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_640_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_640_C.DATA_FLAG is '数据标志';
comment on column MBT_DM_640_C.DATA_OP is '操作标志';
comment on column MBT_DM_640_C.DATA_SOURCE is '数据来源';
comment on column MBT_DM_640_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_640_C.DATA_HASH is '数据HASH';
comment on column MBT_DM_640_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_640_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_640_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_640_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_640_C.DATA_CRT_USER is '创建人';
comment on column MBT_DM_640_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_640_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_640_C.DATA_CHG_USER is '修改人';
comment on column MBT_DM_640_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_640_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_640_C.DATA_APV_USER is '审核人';
comment on column MBT_DM_640_C.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_640_C.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_640_C.RSV1 is '备用字段';
comment on column MBT_DM_640_C.RSV2 is '备用字段';
comment on column MBT_DM_640_C.RSV3 is '备用字段';
comment on column MBT_DM_640_C.RSV4 is '备用字段';
comment on column MBT_DM_640_C.RSV5 is '备用字段';
create table MBT_PM_640 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_640 is '事业单位资产负债表信息';
comment on column MBT_PM_640.DATA_ID is '数据ID';
comment on column MBT_PM_640.DATA_DATE is '数据日期';
comment on column MBT_PM_640.CORP_ID is '法人ID';
comment on column MBT_PM_640.ORG_ID is '机构ID';
comment on column MBT_PM_640.GROUP_ID is '数据分组';
comment on column MBT_PM_640.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_640.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_640.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_640.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_640.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_640.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_640.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_640.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_640.B_ENT_NAME is '企业名称';
comment on column MBT_PM_640.SECTION_CHG_CNT is '段变更';
comment on column MBT_PM_640.SECTION_DEL_CNT is '段删除';
comment on column MBT_PM_640.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_PM_640.IDN_CHG_CNT is '标识项变更';
comment on column MBT_PM_640.CUST_NO is '客户号';
comment on column MBT_PM_640.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_640.PART_TYPE is '段标识';
comment on column MBT_PM_640.PART_NAME is '段名称';
comment on column MBT_PM_640.START_DATE is '起始日期';
comment on column MBT_PM_640.END_DATE is '结束日期';
comment on column MBT_PM_640.BATCH_NO is '批次号';
comment on column MBT_PM_640.ROW_NUM is '行号';
comment on column MBT_PM_640.IS_RPT is '是否报送';
comment on column MBT_PM_640.IS_VALID is '是否有效';
comment on column MBT_PM_640.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_640.OPT_FLAG is '操作标识';
comment on column MBT_PM_640.RPT_DATE is '报送日期';
comment on column MBT_PM_640.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_640.RPT_STATUS is '报送状态';
comment on column MBT_PM_640.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_640.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_640.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_640.REMARKS is '备注';
comment on column MBT_PM_640.CHECK_FLAG is '校验标志';
comment on column MBT_PM_640.CHECK_DESC is '校验说明';
comment on column MBT_PM_640.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_640.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_640.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_640.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_640.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_640.DATA_FLAG is '数据标志';
comment on column MBT_PM_640.DATA_OP is '操作标志';
comment on column MBT_PM_640.DATA_SOURCE is '数据来源';
comment on column MBT_PM_640.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_640.DATA_HASH is '数据HASH';
comment on column MBT_PM_640.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_640.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_640.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_640.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_640.DATA_CRT_USER is '创建人';
comment on column MBT_PM_640.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_640.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_640.DATA_CHG_USER is '修改人';
comment on column MBT_PM_640.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_640.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_640.DATA_APV_USER is '审核人';
comment on column MBT_PM_640.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_640.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_640.RSV1 is '备用字段';
comment on column MBT_PM_640.RSV2 is '备用字段';
comment on column MBT_PM_640.RSV3 is '备用字段';
comment on column MBT_PM_640.RSV4 is '备用字段';
comment on column MBT_PM_640.RSV5 is '备用字段';
create table MBT_PM_640_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_640_B is '事业单位资产负债表信息-基础段';
comment on column MBT_PM_640_B.DATA_ID is '数据ID';
comment on column MBT_PM_640_B.DATA_DATE is '数据日期';
comment on column MBT_PM_640_B.CORP_ID is '法人ID';
comment on column MBT_PM_640_B.ORG_ID is '机构ID';
comment on column MBT_PM_640_B.GROUP_ID is '数据分组';
comment on column MBT_PM_640_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_640_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_640_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_640_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_640_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_640_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_640_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_640_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_640_B.B_ENT_NAME is '企业名称';
comment on column MBT_PM_640_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_PM_640_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_PM_640_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_PM_640_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_PM_640_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_PM_640_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_640_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_PM_640_B.CUST_NO is '客户号';
comment on column MBT_PM_640_B.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_640_B.PART_TYPE is '段标识';
comment on column MBT_PM_640_B.PART_NAME is '段名称';
comment on column MBT_PM_640_B.START_DATE is '起始日期';
comment on column MBT_PM_640_B.END_DATE is '结束日期';
comment on column MBT_PM_640_B.BATCH_NO is '批次号';
comment on column MBT_PM_640_B.ROW_NUM is '行号';
comment on column MBT_PM_640_B.IS_RPT is '是否报送';
comment on column MBT_PM_640_B.IS_VALID is '是否有效';
comment on column MBT_PM_640_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_640_B.OPT_FLAG is '操作标识';
comment on column MBT_PM_640_B.RPT_DATE is '报送日期';
comment on column MBT_PM_640_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_640_B.RPT_STATUS is '报送状态';
comment on column MBT_PM_640_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_640_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_640_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_640_B.REMARKS is '备注';
comment on column MBT_PM_640_B.CHECK_FLAG is '校验标志';
comment on column MBT_PM_640_B.CHECK_DESC is '校验说明';
comment on column MBT_PM_640_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_640_B.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_640_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_640_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_640_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_640_B.DATA_FLAG is '数据标志';
comment on column MBT_PM_640_B.DATA_OP is '操作标志';
comment on column MBT_PM_640_B.DATA_SOURCE is '数据来源';
comment on column MBT_PM_640_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_640_B.DATA_HASH is '数据HASH';
comment on column MBT_PM_640_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_640_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_640_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_640_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_640_B.DATA_CRT_USER is '创建人';
comment on column MBT_PM_640_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_640_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_640_B.DATA_CHG_USER is '修改人';
comment on column MBT_PM_640_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_640_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_640_B.DATA_APV_USER is '审核人';
comment on column MBT_PM_640_B.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_640_B.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_640_B.RSV1 is '备用字段';
comment on column MBT_PM_640_B.RSV2 is '备用字段';
comment on column MBT_PM_640_B.RSV3 is '备用字段';
comment on column MBT_PM_640_B.RSV4 is '备用字段';
comment on column MBT_PM_640_B.RSV5 is '备用字段';
create table MBT_PM_640_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ACCOUNTS_PAYABLE NUMBER(17),
C_ACCOUNTS_RECEIVABLE NUMBER(17),
C_ACCUMULATED_AMORTIZATION NUMBER(17),
C_AMOUNT_OF_FINANCIAL_RETURN NUMBER(17),
C_ASSETS_PROCESSED_PENDING_PRO NUMBER(17),
C_CONSTRUCTION_IN_PROCESS NUMBER(17),
C_CURRENCY_FUNDS NUMBER(17),
C_EMPLOYEE_BENEFITS_PAYABLE NUMBER(17),
C_ENTERPRISE_FUND NUMBER(17),
C_FINANCIAL_AID_BALANCE NUMBER(17),
C_FINANCIAL_AID_CARRIED_OVER NUMBER(17),
C_FIXED_ASSETS NUMBER(17),
C_FIXED_ASSET_ACC_DEPRECIATION NUMBER(17),
C_INTANGIBLE_ASSETS NUMBER(17),
C_INVENTORIES NUMBER(17),
C_LONG_TERM_BORROWINGS NUMBER(17),
C_LONG_TERM_INVESTMENT NUMBER(17),
C_LONG_TERM_PAYABLES NUMBER(17),
C_NON_CURRENT_ASSETS_FUND NUMBER(17),
C_NON_FINANCIAL_AID_BALANCE NUMBER(17),
C_NON_FINANCIAL_AID_CARR_OVER NUMBER(17),
C_NOTES_PAYABLE NUMBER(17),
C_NOTES_RECEIVABLE NUMBER(17),
C_OPERATING_BALANCE NUMBER(17),
C_ORIGINAL_COST_FIXED_ASSET NUMBER(17),
C_ORIGINAL_PRICE_INTAN_ASSETS NUMBER(17),
C_OTHER_CURRENT_ASSETS NUMBER(17),
C_OTHER_CURRENT_LIABILITIES NUMBER(17),
C_OTHER_PAYABLES NUMBER(17),
C_OTHER_RECEIVABLES NUMBER(17),
C_PAYABLE_FINANCIAL_SPECIAL_AC NUMBER(17),
C_PREPAYMENTS NUMBER(17),
C_RECEIPTS_INADVANCE NUMBER(17),
C_SHORT_TERM_BORROWINGS NUMBER(17),
C_SHORT_TERM_INVESTMENTS NUMBER(17),
C_SPECIAL_PURPOSE_FUNDS NUMBER(17),
C_TAX_PAYABLE NUMBER(17),
C_TOTAL_ASSETS NUMBER(17),
C_TOTAL_CURRENT_ASSETS NUMBER(17),
C_TOTAL_CURRENT_LIABILITIES NUMBER(17),
C_TOTAL_LIABILITIES NUMBER(17),
C_TOTAL_LIABILITIES_NET_ASSETS NUMBER(17),
C_TOTAL_NET_ASSETS NUMBER(17),
C_TOTAL_NON_CURRENT_ASSETS NUMBER(17),
C_TOTAL_NON_CURRENT_LIABILITIE NUMBER(17),
C_TREASURY_PAYABLE NUMBER(17),
C_UNDERTAKINGS_BALANCE NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_640_C is '事业单位资产负债表信息-事业单位资产负债表段';
comment on column MBT_PM_640_C.DATA_ID is '数据ID';
comment on column MBT_PM_640_C.DATA_DATE is '数据日期';
comment on column MBT_PM_640_C.CORP_ID is '法人ID';
comment on column MBT_PM_640_C.ORG_ID is '机构ID';
comment on column MBT_PM_640_C.GROUP_ID is '数据分组';
comment on column MBT_PM_640_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_640_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_640_C.C_ACCOUNTS_PAYABLE is '应付账款';
comment on column MBT_PM_640_C.C_ACCOUNTS_RECEIVABLE is '应收账款';
comment on column MBT_PM_640_C.C_ACCUMULATED_AMORTIZATION is '累计摊销';
comment on column MBT_PM_640_C.C_AMOUNT_OF_FINANCIAL_RETURN is '财政应返还额度';
comment on column MBT_PM_640_C.C_ASSETS_PROCESSED_PENDING_PRO is '待处置资产损溢';
comment on column MBT_PM_640_C.C_CONSTRUCTION_IN_PROCESS is '在建工程';
comment on column MBT_PM_640_C.C_CURRENCY_FUNDS is '货币资金';
comment on column MBT_PM_640_C.C_EMPLOYEE_BENEFITS_PAYABLE is '应付职工薪酬';
comment on column MBT_PM_640_C.C_ENTERPRISE_FUND is '事业基金';
comment on column MBT_PM_640_C.C_FINANCIAL_AID_BALANCE is '财政补助结余';
comment on column MBT_PM_640_C.C_FINANCIAL_AID_CARRIED_OVER is '财政补助结转';
comment on column MBT_PM_640_C.C_FIXED_ASSETS is '固定资产';
comment on column MBT_PM_640_C.C_FIXED_ASSET_ACC_DEPRECIATION is '累计折旧';
comment on column MBT_PM_640_C.C_INTANGIBLE_ASSETS is '无形资产';
comment on column MBT_PM_640_C.C_INVENTORIES is '存货';
comment on column MBT_PM_640_C.C_LONG_TERM_BORROWINGS is '长期借款';
comment on column MBT_PM_640_C.C_LONG_TERM_INVESTMENT is '长期投资';
comment on column MBT_PM_640_C.C_LONG_TERM_PAYABLES is '长期应付款';
comment on column MBT_PM_640_C.C_NON_CURRENT_ASSETS_FUND is '非流动资产基金';
comment on column MBT_PM_640_C.C_NON_FINANCIAL_AID_BALANCE is '非财政补助结余';
comment on column MBT_PM_640_C.C_NON_FINANCIAL_AID_CARR_OVER is '非财政补助结转';
comment on column MBT_PM_640_C.C_NOTES_PAYABLE is '应付票据';
comment on column MBT_PM_640_C.C_NOTES_RECEIVABLE is '应收票据';
comment on column MBT_PM_640_C.C_OPERATING_BALANCE is '经营结余';
comment on column MBT_PM_640_C.C_ORIGINAL_COST_FIXED_ASSET is '固定资产原价';
comment on column MBT_PM_640_C.C_ORIGINAL_PRICE_INTAN_ASSETS is '无形资产原价';
comment on column MBT_PM_640_C.C_OTHER_CURRENT_ASSETS is '其他流动资产';
comment on column MBT_PM_640_C.C_OTHER_CURRENT_LIABILITIES is '其他流动负债';
comment on column MBT_PM_640_C.C_OTHER_PAYABLES is '其他应付款';
comment on column MBT_PM_640_C.C_OTHER_RECEIVABLES is '其他应收款';
comment on column MBT_PM_640_C.C_PAYABLE_FINANCIAL_SPECIAL_AC is '应缴财政专户款';
comment on column MBT_PM_640_C.C_PREPAYMENTS is '预付账款';
comment on column MBT_PM_640_C.C_RECEIPTS_INADVANCE is '预收账款';
comment on column MBT_PM_640_C.C_SHORT_TERM_BORROWINGS is '短期借款';
comment on column MBT_PM_640_C.C_SHORT_TERM_INVESTMENTS is '短期投资';
comment on column MBT_PM_640_C.C_SPECIAL_PURPOSE_FUNDS is '专用基金';
comment on column MBT_PM_640_C.C_TAX_PAYABLE is '应缴税费';
comment on column MBT_PM_640_C.C_TOTAL_ASSETS is '资产总计';
comment on column MBT_PM_640_C.C_TOTAL_CURRENT_ASSETS is '流动资产合计';
comment on column MBT_PM_640_C.C_TOTAL_CURRENT_LIABILITIES is '流动负债合计';
comment on column MBT_PM_640_C.C_TOTAL_LIABILITIES is '负债合计';
comment on column MBT_PM_640_C.C_TOTAL_LIABILITIES_NET_ASSETS is '负债和净资产总计';
comment on column MBT_PM_640_C.C_TOTAL_NET_ASSETS is '净资产合计';
comment on column MBT_PM_640_C.C_TOTAL_NON_CURRENT_ASSETS is '非流动资产合计';
comment on column MBT_PM_640_C.C_TOTAL_NON_CURRENT_LIABILITIE is '非流动负债合计';
comment on column MBT_PM_640_C.C_TREASURY_PAYABLE is '应缴国库款';
comment on column MBT_PM_640_C.C_UNDERTAKINGS_BALANCE is '事业结余';
comment on column MBT_PM_640_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_640_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_640_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_640_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_640_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_640_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_640_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_640_C.CUST_NO is '客户号';
comment on column MBT_PM_640_C.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_640_C.PART_TYPE is '段标识';
comment on column MBT_PM_640_C.PART_NAME is '段名称';
comment on column MBT_PM_640_C.START_DATE is '起始日期';
comment on column MBT_PM_640_C.END_DATE is '结束日期';
comment on column MBT_PM_640_C.BATCH_NO is '批次号';
comment on column MBT_PM_640_C.ROW_NUM is '行号';
comment on column MBT_PM_640_C.IS_RPT is '是否报送';
comment on column MBT_PM_640_C.IS_VALID is '是否有效';
comment on column MBT_PM_640_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_640_C.OPT_FLAG is '操作标识';
comment on column MBT_PM_640_C.RPT_DATE is '报送日期';
comment on column MBT_PM_640_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_640_C.RPT_STATUS is '报送状态';
comment on column MBT_PM_640_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_640_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_640_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_640_C.REMARKS is '备注';
comment on column MBT_PM_640_C.CHECK_FLAG is '校验标志';
comment on column MBT_PM_640_C.CHECK_DESC is '校验说明';
comment on column MBT_PM_640_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_640_C.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_640_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_640_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_640_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_640_C.DATA_FLAG is '数据标志';
comment on column MBT_PM_640_C.DATA_OP is '操作标志';
comment on column MBT_PM_640_C.DATA_SOURCE is '数据来源';
comment on column MBT_PM_640_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_640_C.DATA_HASH is '数据HASH';
comment on column MBT_PM_640_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_640_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_640_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_640_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_640_C.DATA_CRT_USER is '创建人';
comment on column MBT_PM_640_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_640_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_640_C.DATA_CHG_USER is '修改人';
comment on column MBT_PM_640_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_640_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_640_C.DATA_APV_USER is '审核人';
comment on column MBT_PM_640_C.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_640_C.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_640_C.RSV1 is '备用字段';
comment on column MBT_PM_640_C.RSV2 is '备用字段';
comment on column MBT_PM_640_C.RSV3 is '备用字段';
comment on column MBT_PM_640_C.RSV4 is '备用字段';
comment on column MBT_PM_640_C.RSV5 is '备用字段';
create table MBT_RPT_640 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_640 is '事业单位资产负债表信息';
comment on column MBT_RPT_640.DATA_ID is '数据ID';
comment on column MBT_RPT_640.DATA_DATE is '数据日期';
comment on column MBT_RPT_640.CORP_ID is '法人ID';
comment on column MBT_RPT_640.ORG_ID is '机构ID';
comment on column MBT_RPT_640.GROUP_ID is '数据分组';
comment on column MBT_RPT_640.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_640.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_640.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_640.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_640.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_640.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_640.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_640.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_640.B_ENT_NAME is '企业名称';
comment on column MBT_RPT_640.SECTION_CHG_CNT is '段变更';
comment on column MBT_RPT_640.SECTION_DEL_CNT is '段删除';
comment on column MBT_RPT_640.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_RPT_640.IDN_CHG_CNT is '标识项变更';
comment on column MBT_RPT_640.CUST_NO is '客户号';
comment on column MBT_RPT_640.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_640.PART_TYPE is '段标识';
comment on column MBT_RPT_640.PART_NAME is '段名称';
comment on column MBT_RPT_640.START_DATE is '起始日期';
comment on column MBT_RPT_640.END_DATE is '结束日期';
comment on column MBT_RPT_640.BATCH_NO is '批次号';
comment on column MBT_RPT_640.ROW_NUM is '行号';
comment on column MBT_RPT_640.IS_RPT is '是否报送';
comment on column MBT_RPT_640.IS_VALID is '是否有效';
comment on column MBT_RPT_640.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_640.OPT_FLAG is '操作标识';
comment on column MBT_RPT_640.RPT_DATE is '报送日期';
comment on column MBT_RPT_640.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_640.RPT_STATUS is '报送状态';
comment on column MBT_RPT_640.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_640.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_640.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_640.REMARKS is '备注';
comment on column MBT_RPT_640.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_640.CHECK_DESC is '校验说明';
comment on column MBT_RPT_640.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_640.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_640.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_640.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_640.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_640.DATA_FLAG is '数据标志';
comment on column MBT_RPT_640.DATA_OP is '操作标志';
comment on column MBT_RPT_640.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_640.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_640.DATA_HASH is '数据HASH';
comment on column MBT_RPT_640.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_640.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_640.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_640.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_640.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_640.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_640.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_640.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_640.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_640.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_640.DATA_APV_USER is '审核人';
comment on column MBT_RPT_640.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_640.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_640.RSV1 is '备用字段';
comment on column MBT_RPT_640.RSV2 is '备用字段';
comment on column MBT_RPT_640.RSV3 is '备用字段';
comment on column MBT_RPT_640.RSV4 is '备用字段';
comment on column MBT_RPT_640.RSV5 is '备用字段';
create table MBT_RPT_640_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_640_B is '事业单位资产负债表信息-基础段';
comment on column MBT_RPT_640_B.DATA_ID is '数据ID';
comment on column MBT_RPT_640_B.DATA_DATE is '数据日期';
comment on column MBT_RPT_640_B.CORP_ID is '法人ID';
comment on column MBT_RPT_640_B.ORG_ID is '机构ID';
comment on column MBT_RPT_640_B.GROUP_ID is '数据分组';
comment on column MBT_RPT_640_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_640_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_640_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_640_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_640_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_640_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_640_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_640_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_640_B.B_ENT_NAME is '企业名称';
comment on column MBT_RPT_640_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_RPT_640_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_RPT_640_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_RPT_640_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_RPT_640_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_RPT_640_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_640_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_RPT_640_B.CUST_NO is '客户号';
comment on column MBT_RPT_640_B.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_640_B.PART_TYPE is '段标识';
comment on column MBT_RPT_640_B.PART_NAME is '段名称';
comment on column MBT_RPT_640_B.START_DATE is '起始日期';
comment on column MBT_RPT_640_B.END_DATE is '结束日期';
comment on column MBT_RPT_640_B.BATCH_NO is '批次号';
comment on column MBT_RPT_640_B.ROW_NUM is '行号';
comment on column MBT_RPT_640_B.IS_RPT is '是否报送';
comment on column MBT_RPT_640_B.IS_VALID is '是否有效';
comment on column MBT_RPT_640_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_640_B.OPT_FLAG is '操作标识';
comment on column MBT_RPT_640_B.RPT_DATE is '报送日期';
comment on column MBT_RPT_640_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_640_B.RPT_STATUS is '报送状态';
comment on column MBT_RPT_640_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_640_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_640_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_640_B.REMARKS is '备注';
comment on column MBT_RPT_640_B.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_640_B.CHECK_DESC is '校验说明';
comment on column MBT_RPT_640_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_640_B.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_640_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_640_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_640_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_640_B.DATA_FLAG is '数据标志';
comment on column MBT_RPT_640_B.DATA_OP is '操作标志';
comment on column MBT_RPT_640_B.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_640_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_640_B.DATA_HASH is '数据HASH';
comment on column MBT_RPT_640_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_640_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_640_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_640_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_640_B.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_640_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_640_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_640_B.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_640_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_640_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_640_B.DATA_APV_USER is '审核人';
comment on column MBT_RPT_640_B.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_640_B.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_640_B.RSV1 is '备用字段';
comment on column MBT_RPT_640_B.RSV2 is '备用字段';
comment on column MBT_RPT_640_B.RSV3 is '备用字段';
comment on column MBT_RPT_640_B.RSV4 is '备用字段';
comment on column MBT_RPT_640_B.RSV5 is '备用字段';
create table MBT_RPT_640_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ACCOUNTS_PAYABLE NUMBER(17),
C_ACCOUNTS_RECEIVABLE NUMBER(17),
C_ACCUMULATED_AMORTIZATION NUMBER(17),
C_AMOUNT_OF_FINANCIAL_RETURN NUMBER(17),
C_ASSETS_PROCESSED_PENDING_PRO NUMBER(17),
C_CONSTRUCTION_IN_PROCESS NUMBER(17),
C_CURRENCY_FUNDS NUMBER(17),
C_EMPLOYEE_BENEFITS_PAYABLE NUMBER(17),
C_ENTERPRISE_FUND NUMBER(17),
C_FINANCIAL_AID_BALANCE NUMBER(17),
C_FINANCIAL_AID_CARRIED_OVER NUMBER(17),
C_FIXED_ASSETS NUMBER(17),
C_FIXED_ASSET_ACC_DEPRECIATION NUMBER(17),
C_INTANGIBLE_ASSETS NUMBER(17),
C_INVENTORIES NUMBER(17),
C_LONG_TERM_BORROWINGS NUMBER(17),
C_LONG_TERM_INVESTMENT NUMBER(17),
C_LONG_TERM_PAYABLES NUMBER(17),
C_NON_CURRENT_ASSETS_FUND NUMBER(17),
C_NON_FINANCIAL_AID_BALANCE NUMBER(17),
C_NON_FINANCIAL_AID_CARR_OVER NUMBER(17),
C_NOTES_PAYABLE NUMBER(17),
C_NOTES_RECEIVABLE NUMBER(17),
C_OPERATING_BALANCE NUMBER(17),
C_ORIGINAL_COST_FIXED_ASSET NUMBER(17),
C_ORIGINAL_PRICE_INTAN_ASSETS NUMBER(17),
C_OTHER_CURRENT_ASSETS NUMBER(17),
C_OTHER_CURRENT_LIABILITIES NUMBER(17),
C_OTHER_PAYABLES NUMBER(17),
C_OTHER_RECEIVABLES NUMBER(17),
C_PAYABLE_FINANCIAL_SPECIAL_AC NUMBER(17),
C_PREPAYMENTS NUMBER(17),
C_RECEIPTS_INADVANCE NUMBER(17),
C_SHORT_TERM_BORROWINGS NUMBER(17),
C_SHORT_TERM_INVESTMENTS NUMBER(17),
C_SPECIAL_PURPOSE_FUNDS NUMBER(17),
C_TAX_PAYABLE NUMBER(17),
C_TOTAL_ASSETS NUMBER(17),
C_TOTAL_CURRENT_ASSETS NUMBER(17),
C_TOTAL_CURRENT_LIABILITIES NUMBER(17),
C_TOTAL_LIABILITIES NUMBER(17),
C_TOTAL_LIABILITIES_NET_ASSETS NUMBER(17),
C_TOTAL_NET_ASSETS NUMBER(17),
C_TOTAL_NON_CURRENT_ASSETS NUMBER(17),
C_TOTAL_NON_CURRENT_LIABILITIE NUMBER(17),
C_TREASURY_PAYABLE NUMBER(17),
C_UNDERTAKINGS_BALANCE NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_640_C is '事业单位资产负债表信息-事业单位资产负债表段';
comment on column MBT_RPT_640_C.DATA_ID is '数据ID';
comment on column MBT_RPT_640_C.DATA_DATE is '数据日期';
comment on column MBT_RPT_640_C.CORP_ID is '法人ID';
comment on column MBT_RPT_640_C.ORG_ID is '机构ID';
comment on column MBT_RPT_640_C.GROUP_ID is '数据分组';
comment on column MBT_RPT_640_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_640_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_640_C.C_ACCOUNTS_PAYABLE is '应付账款';
comment on column MBT_RPT_640_C.C_ACCOUNTS_RECEIVABLE is '应收账款';
comment on column MBT_RPT_640_C.C_ACCUMULATED_AMORTIZATION is '累计摊销';
comment on column MBT_RPT_640_C.C_AMOUNT_OF_FINANCIAL_RETURN is '财政应返还额度';
comment on column MBT_RPT_640_C.C_ASSETS_PROCESSED_PENDING_PRO is '待处置资产损溢';
comment on column MBT_RPT_640_C.C_CONSTRUCTION_IN_PROCESS is '在建工程';
comment on column MBT_RPT_640_C.C_CURRENCY_FUNDS is '货币资金';
comment on column MBT_RPT_640_C.C_EMPLOYEE_BENEFITS_PAYABLE is '应付职工薪酬';
comment on column MBT_RPT_640_C.C_ENTERPRISE_FUND is '事业基金';
comment on column MBT_RPT_640_C.C_FINANCIAL_AID_BALANCE is '财政补助结余';
comment on column MBT_RPT_640_C.C_FINANCIAL_AID_CARRIED_OVER is '财政补助结转';
comment on column MBT_RPT_640_C.C_FIXED_ASSETS is '固定资产';
comment on column MBT_RPT_640_C.C_FIXED_ASSET_ACC_DEPRECIATION is '累计折旧';
comment on column MBT_RPT_640_C.C_INTANGIBLE_ASSETS is '无形资产';
comment on column MBT_RPT_640_C.C_INVENTORIES is '存货';
comment on column MBT_RPT_640_C.C_LONG_TERM_BORROWINGS is '长期借款';
comment on column MBT_RPT_640_C.C_LONG_TERM_INVESTMENT is '长期投资';
comment on column MBT_RPT_640_C.C_LONG_TERM_PAYABLES is '长期应付款';
comment on column MBT_RPT_640_C.C_NON_CURRENT_ASSETS_FUND is '非流动资产基金';
comment on column MBT_RPT_640_C.C_NON_FINANCIAL_AID_BALANCE is '非财政补助结余';
comment on column MBT_RPT_640_C.C_NON_FINANCIAL_AID_CARR_OVER is '非财政补助结转';
comment on column MBT_RPT_640_C.C_NOTES_PAYABLE is '应付票据';
comment on column MBT_RPT_640_C.C_NOTES_RECEIVABLE is '应收票据';
comment on column MBT_RPT_640_C.C_OPERATING_BALANCE is '经营结余';
comment on column MBT_RPT_640_C.C_ORIGINAL_COST_FIXED_ASSET is '固定资产原价';
comment on column MBT_RPT_640_C.C_ORIGINAL_PRICE_INTAN_ASSETS is '无形资产原价';
comment on column MBT_RPT_640_C.C_OTHER_CURRENT_ASSETS is '其他流动资产';
comment on column MBT_RPT_640_C.C_OTHER_CURRENT_LIABILITIES is '其他流动负债';
comment on column MBT_RPT_640_C.C_OTHER_PAYABLES is '其他应付款';
comment on column MBT_RPT_640_C.C_OTHER_RECEIVABLES is '其他应收款';
comment on column MBT_RPT_640_C.C_PAYABLE_FINANCIAL_SPECIAL_AC is '应缴财政专户款';
comment on column MBT_RPT_640_C.C_PREPAYMENTS is '预付账款';
comment on column MBT_RPT_640_C.C_RECEIPTS_INADVANCE is '预收账款';
comment on column MBT_RPT_640_C.C_SHORT_TERM_BORROWINGS is '短期借款';
comment on column MBT_RPT_640_C.C_SHORT_TERM_INVESTMENTS is '短期投资';
comment on column MBT_RPT_640_C.C_SPECIAL_PURPOSE_FUNDS is '专用基金';
comment on column MBT_RPT_640_C.C_TAX_PAYABLE is '应缴税费';
comment on column MBT_RPT_640_C.C_TOTAL_ASSETS is '资产总计';
comment on column MBT_RPT_640_C.C_TOTAL_CURRENT_ASSETS is '流动资产合计';
comment on column MBT_RPT_640_C.C_TOTAL_CURRENT_LIABILITIES is '流动负债合计';
comment on column MBT_RPT_640_C.C_TOTAL_LIABILITIES is '负债合计';
comment on column MBT_RPT_640_C.C_TOTAL_LIABILITIES_NET_ASSETS is '负债和净资产总计';
comment on column MBT_RPT_640_C.C_TOTAL_NET_ASSETS is '净资产合计';
comment on column MBT_RPT_640_C.C_TOTAL_NON_CURRENT_ASSETS is '非流动资产合计';
comment on column MBT_RPT_640_C.C_TOTAL_NON_CURRENT_LIABILITIE is '非流动负债合计';
comment on column MBT_RPT_640_C.C_TREASURY_PAYABLE is '应缴国库款';
comment on column MBT_RPT_640_C.C_UNDERTAKINGS_BALANCE is '事业结余';
comment on column MBT_RPT_640_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_640_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_640_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_640_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_640_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_640_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_640_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_640_C.CUST_NO is '客户号';
comment on column MBT_RPT_640_C.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_640_C.PART_TYPE is '段标识';
comment on column MBT_RPT_640_C.PART_NAME is '段名称';
comment on column MBT_RPT_640_C.START_DATE is '起始日期';
comment on column MBT_RPT_640_C.END_DATE is '结束日期';
comment on column MBT_RPT_640_C.BATCH_NO is '批次号';
comment on column MBT_RPT_640_C.ROW_NUM is '行号';
comment on column MBT_RPT_640_C.IS_RPT is '是否报送';
comment on column MBT_RPT_640_C.IS_VALID is '是否有效';
comment on column MBT_RPT_640_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_640_C.OPT_FLAG is '操作标识';
comment on column MBT_RPT_640_C.RPT_DATE is '报送日期';
comment on column MBT_RPT_640_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_640_C.RPT_STATUS is '报送状态';
comment on column MBT_RPT_640_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_640_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_640_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_640_C.REMARKS is '备注';
comment on column MBT_RPT_640_C.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_640_C.CHECK_DESC is '校验说明';
comment on column MBT_RPT_640_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_640_C.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_640_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_640_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_640_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_640_C.DATA_FLAG is '数据标志';
comment on column MBT_RPT_640_C.DATA_OP is '操作标志';
comment on column MBT_RPT_640_C.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_640_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_640_C.DATA_HASH is '数据HASH';
comment on column MBT_RPT_640_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_640_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_640_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_640_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_640_C.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_640_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_640_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_640_C.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_640_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_640_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_640_C.DATA_APV_USER is '审核人';
comment on column MBT_RPT_640_C.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_640_C.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_640_C.RSV1 is '备用字段';
comment on column MBT_RPT_640_C.RSV2 is '备用字段';
comment on column MBT_RPT_640_C.RSV3 is '备用字段';
comment on column MBT_RPT_640_C.RSV4 is '备用字段';
comment on column MBT_RPT_640_C.RSV5 is '备用字段';
