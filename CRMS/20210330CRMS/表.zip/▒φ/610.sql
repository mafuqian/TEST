create table MBT_DM_610 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_610 is '企业资产负债表信息';
comment on column MBT_DM_610.DATA_ID is '数据ID';
comment on column MBT_DM_610.DATA_DATE is '数据日期';
comment on column MBT_DM_610.CORP_ID is '法人ID';
comment on column MBT_DM_610.ORG_ID is '机构ID';
comment on column MBT_DM_610.GROUP_ID is '数据分组';
comment on column MBT_DM_610.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_610.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_610.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_610.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_610.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_610.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_610.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_610.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_610.B_ENT_NAME is '企业名称';
comment on column MBT_DM_610.SECTION_CHG_CNT is '段变更';
comment on column MBT_DM_610.SECTION_DEL_CNT is '段删除';
comment on column MBT_DM_610.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_DM_610.IDN_CHG_CNT is '标识项变更';
comment on column MBT_DM_610.CUST_NO is '客户号';
comment on column MBT_DM_610.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_610.PART_TYPE is '段标识';
comment on column MBT_DM_610.PART_NAME is '段名称';
comment on column MBT_DM_610.START_DATE is '起始日期';
comment on column MBT_DM_610.END_DATE is '结束日期';
comment on column MBT_DM_610.BATCH_NO is '批次号';
comment on column MBT_DM_610.ROW_NUM is '行号';
comment on column MBT_DM_610.IS_RPT is '是否报送';
comment on column MBT_DM_610.IS_VALID is '是否有效';
comment on column MBT_DM_610.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_610.OPT_FLAG is '操作标识';
comment on column MBT_DM_610.RPT_DATE is '报送日期';
comment on column MBT_DM_610.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_610.RPT_STATUS is '报送状态';
comment on column MBT_DM_610.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_610.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_610.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_610.REMARKS is '备注';
comment on column MBT_DM_610.CHECK_FLAG is '校验标志';
comment on column MBT_DM_610.CHECK_DESC is '校验说明';
comment on column MBT_DM_610.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_610.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_610.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_610.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_610.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_610.DATA_FLAG is '数据标志';
comment on column MBT_DM_610.DATA_OP is '操作标志';
comment on column MBT_DM_610.DATA_SOURCE is '数据来源';
comment on column MBT_DM_610.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_610.DATA_HASH is '数据HASH';
comment on column MBT_DM_610.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_610.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_610.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_610.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_610.DATA_CRT_USER is '创建人';
comment on column MBT_DM_610.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_610.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_610.DATA_CHG_USER is '修改人';
comment on column MBT_DM_610.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_610.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_610.DATA_APV_USER is '审核人';
comment on column MBT_DM_610.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_610.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_610.RSV1 is '备用字段';
comment on column MBT_DM_610.RSV2 is '备用字段';
comment on column MBT_DM_610.RSV3 is '备用字段';
comment on column MBT_DM_610.RSV4 is '备用字段';
comment on column MBT_DM_610.RSV5 is '备用字段';
create table MBT_DM_610_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_610_B is '企业资产负债表信息-基础段';
comment on column MBT_DM_610_B.DATA_ID is '数据ID';
comment on column MBT_DM_610_B.DATA_DATE is '数据日期';
comment on column MBT_DM_610_B.CORP_ID is '法人ID';
comment on column MBT_DM_610_B.ORG_ID is '机构ID';
comment on column MBT_DM_610_B.GROUP_ID is '数据分组';
comment on column MBT_DM_610_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_610_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_610_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_610_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_610_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_610_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_610_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_610_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_610_B.B_ENT_NAME is '企业名称';
comment on column MBT_DM_610_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_DM_610_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_DM_610_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_DM_610_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_DM_610_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_DM_610_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_610_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_DM_610_B.CUST_NO is '客户号';
comment on column MBT_DM_610_B.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_610_B.PART_TYPE is '段标识';
comment on column MBT_DM_610_B.PART_NAME is '段名称';
comment on column MBT_DM_610_B.START_DATE is '起始日期';
comment on column MBT_DM_610_B.END_DATE is '结束日期';
comment on column MBT_DM_610_B.BATCH_NO is '批次号';
comment on column MBT_DM_610_B.ROW_NUM is '行号';
comment on column MBT_DM_610_B.IS_RPT is '是否报送';
comment on column MBT_DM_610_B.IS_VALID is '是否有效';
comment on column MBT_DM_610_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_610_B.OPT_FLAG is '操作标识';
comment on column MBT_DM_610_B.RPT_DATE is '报送日期';
comment on column MBT_DM_610_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_610_B.RPT_STATUS is '报送状态';
comment on column MBT_DM_610_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_610_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_610_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_610_B.REMARKS is '备注';
comment on column MBT_DM_610_B.CHECK_FLAG is '校验标志';
comment on column MBT_DM_610_B.CHECK_DESC is '校验说明';
comment on column MBT_DM_610_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_610_B.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_610_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_610_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_610_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_610_B.DATA_FLAG is '数据标志';
comment on column MBT_DM_610_B.DATA_OP is '操作标志';
comment on column MBT_DM_610_B.DATA_SOURCE is '数据来源';
comment on column MBT_DM_610_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_610_B.DATA_HASH is '数据HASH';
comment on column MBT_DM_610_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_610_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_610_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_610_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_610_B.DATA_CRT_USER is '创建人';
comment on column MBT_DM_610_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_610_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_610_B.DATA_CHG_USER is '修改人';
comment on column MBT_DM_610_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_610_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_610_B.DATA_APV_USER is '审核人';
comment on column MBT_DM_610_B.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_610_B.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_610_B.RSV1 is '备用字段';
comment on column MBT_DM_610_B.RSV2 is '备用字段';
comment on column MBT_DM_610_B.RSV3 is '备用字段';
comment on column MBT_DM_610_B.RSV4 is '备用字段';
comment on column MBT_DM_610_B.RSV5 is '备用字段';
create table MBT_DM_610_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ACCOUNTS_PAYABLE NUMBER(17),
C_ACCOUNTS_RECEIVABLE NUMBER(17),
C_ALLOWANCE_RECEIVABLE NUMBER(17),
C_AMONG_IT_SPE_APPR_RES_MAT NUMBER(17),
C_BONDS_PAYABLE NUMBER(17),
C_CAPITALR_RSERVE NUMBER(17),
C_COLLECTIVE_CAPITAL NUMBER(17),
C_COLLECTIVE_LP_CAPITAL NUMBER(17),
C_CONSTRUCTION_IN_PROGRESS NUMBER(17),
C_CONSTRUCTION_MATERIALS NUMBER(17),
C_CURRENCY_FUNDS NUMBER(17),
C_DEFERRED_ASSETS NUMBER(17),
C_DEFERRED_ASSETS_DEBITS NUMBER(17),
C_DEFERRED_EXPENSES NUMBER(17),
C_DEFERRED_TAXATION_CREDIT NUMBER(17),
C_DIVIDENDS_RECEIVABLE NUMBER(17),
C_DT_FC_FINANCIAL_STA NUMBER(17),
C_EMPLOYEE_BENEFITS NUMBER(17),
C_EXPORT_DRAWBACK_RECEIVABLE NUMBER(17),
C_FA_ACC_DEPRECIATION NUMBER(17),
C_FA_NET_VALUE NUMBER(17),
C_FA_PENDING_DISPOSAL NUMBER(17),
C_FINISHED_PRODUCTS NUMBER(17),
C_FOREIGN_BUS_CAPITAL NUMBER(17),
C_FUTURE_GUARANTEE NUMBER(17),
C_GRANTS_PAYABLE NUMBER(17),
C_IMPROVEMENT_EXPENDITURE_FA NUMBER(17),
C_INCLUDING_FA_REPAIR NUMBER(17),
C_INCOME_PAYABLE NUMBER(17),
C_INC_PRICE_DIFFERENCE NUMBER(17),
C_INTANGIBLE_ASSETS NUMBER(17),
C_INTEREST_RECEIVABLE NUMBER(17),
C_INVENTORIES NUMBER(17),
C_LAND_USE_RIGHTS NUMBER(17),
C_LEGAL_PERSONS_CAPITAL NUMBER(17),
C_LONG_TERM_PAYABLES NUMBER(17),
C_LT_BORROWINGS NUMBER(17),
C_LT_DI_FALLINGDUEINAYEAR NUMBER(17),
C_LT_EQUITYINVESTMENT NUMBER(17),
C_LT_INVESTMENT NUMBER(17),
C_LT_LIABILITIES_DUE_ONEYEAR NUMBER(17),
C_LT_SECURITIES_INVESTMENT NUMBER(17),
C_MINORITY_INTEREST NUMBER(17),
C_NATIONAL_CAPITAL NUMBER(17),
C_NET_VALUE_FA NUMBER(17),
C_NOTES_PAYABLE NUMBER(17),
C_NOTES_RECEIVABLE NUMBER(17),
C_ORIGINAL_COST_FA NUMBER(17),
C_OTHER_CURRENT_ASSETS NUMBER(17),
C_OTHER_CURRENT_LIABILITIES NUMBER(17),
C_OTHER_LONG_TERM_ASSETS NUMBER(17),
C_OTHER_LT_LIABILITIES NUMBER(17),
C_OTHER_PAYABLE NUMBER(17),
C_OTHER_PAYABLE_GOVERNMENT NUMBER(17),
C_OTHER_RECEIVABLES NUMBER(17),
C_PAID_IN_CAPITAL NUMBER(17),
C_PERSONAL_CAPITAL NUMBER(17),
C_PREPAYMENTS NUMBER(17),
C_PROVISIONS NUMBER(17),
C_PROVISION_FOR_EXPENSES NUMBER(17),
C_PROVISION_IMPAIRMENT_FA NUMBER(17),
C_PUBLIC_WELFARE_FUND NUMBER(17),
C_RAW_MATERIALS NUMBER(17),
C_RECEIPTS_IN_ADVANCE NUMBER(17),
C_SHORT_TERM_BORROWINGS NUMBER(17),
C_SHORT_TERM_INVESTMENTS NUMBER(17),
C_SPECIAL_RESERVE_FUND NUMBER(17),
C_STATE_OWNED_LP_CAPITAL NUMBER(17),
C_STATUTORY_SURPLUS_RESERVE NUMBER(17),
C_SUPPLER_CURRENT_CAPITAL NUMBER(17),
C_SURPLUS_RESERVE NUMBER(17),
C_TAXES_PAYABLE NUMBER(17),
C_TOTAL_ASSETS NUMBER(17),
C_TOTAL_CURRENT_ASSETS NUMBER(17),
C_TOTAL_CURRENT_LIABILITIES NUMBER(17),
C_TOTAL_EQUITY NUMBER(17),
C_TOTAL_EQUITY_LIABILITIES NUMBER(17),
C_TOTAL_FIXED_ASSETS NUMBER(17),
C_TOTAL_INTANGIBLE_OTHER_ASS NUMBER(17),
C_TOTAL_LIABILITIES NUMBER(17),
C_TOTAL_LT_INVESTMENT NUMBER(17),
C_TOTAL_LT_LIABILITIES NUMBER(17),
C_UNAFFIRMED_INVESTMENT_LOSS NUMBER(17),
C_UNAPPROPRIATED_PROFIT NUMBER(17),
C_UNSETTLED_GL_CURRENT_ASSETS NUMBER(17),
C_UNSETTLED_GL_ON_FA NUMBER(17),
C_WAGES_SALARIES_PAYABLES NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_610_C is '企业资产负债表信息-2002版资产负债表段';
comment on column MBT_DM_610_C.DATA_ID is '数据ID';
comment on column MBT_DM_610_C.DATA_DATE is '数据日期';
comment on column MBT_DM_610_C.CORP_ID is '法人ID';
comment on column MBT_DM_610_C.ORG_ID is '机构ID';
comment on column MBT_DM_610_C.GROUP_ID is '数据分组';
comment on column MBT_DM_610_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_610_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_610_C.C_ACCOUNTS_PAYABLE is '应付账款';
comment on column MBT_DM_610_C.C_ACCOUNTS_RECEIVABLE is '应收账款';
comment on column MBT_DM_610_C.C_ALLOWANCE_RECEIVABLE is '应收补贴款';
comment on column MBT_DM_610_C.C_AMONG_IT_SPE_APPR_RES_MAT is '（其他长期资产科目下）特准储备物资';
comment on column MBT_DM_610_C.C_BONDS_PAYABLE is '应付债券';
comment on column MBT_DM_610_C.C_CAPITALR_RSERVE is '资本公积';
comment on column MBT_DM_610_C.C_COLLECTIVE_CAPITAL is '集体资本';
comment on column MBT_DM_610_C.C_COLLECTIVE_LP_CAPITAL is '（法人资本科目下）集体法人资本';
comment on column MBT_DM_610_C.C_CONSTRUCTION_IN_PROGRESS is '在建工程';
comment on column MBT_DM_610_C.C_CONSTRUCTION_MATERIALS is '工程物资';
comment on column MBT_DM_610_C.C_CURRENCY_FUNDS is '货币资金';
comment on column MBT_DM_610_C.C_DEFERRED_ASSETS is '递延资产';
comment on column MBT_DM_610_C.C_DEFERRED_ASSETS_DEBITS is '递延税款借项';
comment on column MBT_DM_610_C.C_DEFERRED_EXPENSES is '待摊费用';
comment on column MBT_DM_610_C.C_DEFERRED_TAXATION_CREDIT is '递延税款贷项';
comment on column MBT_DM_610_C.C_DIVIDENDS_RECEIVABLE is '应收股利';
comment on column MBT_DM_610_C.C_DT_FC_FINANCIAL_STA is '外币报表折算差额';
comment on column MBT_DM_610_C.C_EMPLOYEE_BENEFITS is '应付福利费';
comment on column MBT_DM_610_C.C_EXPORT_DRAWBACK_RECEIVABLE is '应收出口退税';
comment on column MBT_DM_610_C.C_FA_ACC_DEPRECIATION is '累计折旧';
comment on column MBT_DM_610_C.C_FA_NET_VALUE is '固定资产净值';
comment on column MBT_DM_610_C.C_FA_PENDING_DISPOSAL is '固定资产清理';
comment on column MBT_DM_610_C.C_FINISHED_PRODUCTS is '存货产成品';
comment on column MBT_DM_610_C.C_FOREIGN_BUS_CAPITAL is '外商资本';
comment on column MBT_DM_610_C.C_FUTURE_GUARANTEE is '期货保证金';
comment on column MBT_DM_610_C.C_GRANTS_PAYABLE is '专项应付款';
comment on column MBT_DM_610_C.C_IMPROVEMENT_EXPENDITURE_FA is '（递延资产科目下）固定资产改良支出';
comment on column MBT_DM_610_C.C_INCLUDING_FA_REPAIR is '（递延资产科目下）固定资产修理';
comment on column MBT_DM_610_C.C_INCOME_PAYABLE is '应付利润';
comment on column MBT_DM_610_C.C_INC_PRICE_DIFFERENCE is '合并价差';
comment on column MBT_DM_610_C.C_INTANGIBLE_ASSETS is '无形资产';
comment on column MBT_DM_610_C.C_INTEREST_RECEIVABLE is '应收利息';
comment on column MBT_DM_610_C.C_INVENTORIES is '存货';
comment on column MBT_DM_610_C.C_LAND_USE_RIGHTS is '（无形资产科目下）土地使用权';
comment on column MBT_DM_610_C.C_LEGAL_PERSONS_CAPITAL is '法人资本';
comment on column MBT_DM_610_C.C_LONG_TERM_PAYABLES is '长期应付款';
comment on column MBT_DM_610_C.C_LT_BORROWINGS is '长期借款';
comment on column MBT_DM_610_C.C_LT_DI_FALLINGDUEINAYEAR is '一年内到期的长期债权投资';
comment on column MBT_DM_610_C.C_LT_EQUITYINVESTMENT is '长期股权投资';
comment on column MBT_DM_610_C.C_LT_INVESTMENT is '长期投资';
comment on column MBT_DM_610_C.C_LT_LIABILITIES_DUE_ONEYEAR is '一年内到期的长期负债';
comment on column MBT_DM_610_C.C_LT_SECURITIES_INVESTMENT is '长期债权投资';
comment on column MBT_DM_610_C.C_MINORITY_INTEREST is '少数股东权益';
comment on column MBT_DM_610_C.C_NATIONAL_CAPITAL is '国家资本';
comment on column MBT_DM_610_C.C_NET_VALUE_FA is '固定资产净额';
comment on column MBT_DM_610_C.C_NOTES_PAYABLE is '应付票据';
comment on column MBT_DM_610_C.C_NOTES_RECEIVABLE is '应收票据';
comment on column MBT_DM_610_C.C_ORIGINAL_COST_FA is '固定资产原价';
comment on column MBT_DM_610_C.C_OTHER_CURRENT_ASSETS is '其他流动资产';
comment on column MBT_DM_610_C.C_OTHER_CURRENT_LIABILITIES is '其他流动负债';
comment on column MBT_DM_610_C.C_OTHER_LONG_TERM_ASSETS is '其他长期资产';
comment on column MBT_DM_610_C.C_OTHER_LT_LIABILITIES is '其他长期负债';
comment on column MBT_DM_610_C.C_OTHER_PAYABLE is '其他应付款';
comment on column MBT_DM_610_C.C_OTHER_PAYABLE_GOVERNMENT is '其他应交款';
comment on column MBT_DM_610_C.C_OTHER_RECEIVABLES is '其他应收款';
comment on column MBT_DM_610_C.C_PAID_IN_CAPITAL is '实收资本';
comment on column MBT_DM_610_C.C_PERSONAL_CAPITAL is '个人资本';
comment on column MBT_DM_610_C.C_PREPAYMENTS is '预付账款';
comment on column MBT_DM_610_C.C_PROVISIONS is '预计负债';
comment on column MBT_DM_610_C.C_PROVISION_FOR_EXPENSES is '预提费用';
comment on column MBT_DM_610_C.C_PROVISION_IMPAIRMENT_FA is '固定资产值减值准备';
comment on column MBT_DM_610_C.C_PUBLIC_WELFARE_FUND is '（盈余公积科目下）公益金';
comment on column MBT_DM_610_C.C_RAW_MATERIALS is '存货原材料';
comment on column MBT_DM_610_C.C_RECEIPTS_IN_ADVANCE is '预收账款';
comment on column MBT_DM_610_C.C_SHORT_TERM_BORROWINGS is '短期借款';
comment on column MBT_DM_610_C.C_SHORT_TERM_INVESTMENTS is '短期投资';
comment on column MBT_DM_610_C.C_SPECIAL_RESERVE_FUND is '（其他长期负债科目下）特准储备基金';
comment on column MBT_DM_610_C.C_STATE_OWNED_LP_CAPITAL is '（法人资本科目下）国有法人资本';
comment on column MBT_DM_610_C.C_STATUTORY_SURPLUS_RESERVE is '（盈余公积科目下）法定盈余公积';
comment on column MBT_DM_610_C.C_SUPPLER_CURRENT_CAPITAL is '（盈余公积科目下）补充流动资本';
comment on column MBT_DM_610_C.C_SURPLUS_RESERVE is '盈余公积';
comment on column MBT_DM_610_C.C_TAXES_PAYABLE is '应交税金';
comment on column MBT_DM_610_C.C_TOTAL_ASSETS is '资产总计';
comment on column MBT_DM_610_C.C_TOTAL_CURRENT_ASSETS is '流动资产合计';
comment on column MBT_DM_610_C.C_TOTAL_CURRENT_LIABILITIES is '流动负债合计';
comment on column MBT_DM_610_C.C_TOTAL_EQUITY is '所有者权益合计';
comment on column MBT_DM_610_C.C_TOTAL_EQUITY_LIABILITIES is '负债和所有者权益总计';
comment on column MBT_DM_610_C.C_TOTAL_FIXED_ASSETS is '固定资产合计';
comment on column MBT_DM_610_C.C_TOTAL_INTANGIBLE_OTHER_ASS is '无形及其他资产合计';
comment on column MBT_DM_610_C.C_TOTAL_LIABILITIES is '负债合计';
comment on column MBT_DM_610_C.C_TOTAL_LT_INVESTMENT is '长期投资合计';
comment on column MBT_DM_610_C.C_TOTAL_LT_LIABILITIES is '长期负债合计';
comment on column MBT_DM_610_C.C_UNAFFIRMED_INVESTMENT_LOSS is '未确认的投资损失';
comment on column MBT_DM_610_C.C_UNAPPROPRIATED_PROFIT is '未分配利润';
comment on column MBT_DM_610_C.C_UNSETTLED_GL_CURRENT_ASSETS is '待处理流动资产净损失';
comment on column MBT_DM_610_C.C_UNSETTLED_GL_ON_FA is '待处理固定资产净损失';
comment on column MBT_DM_610_C.C_WAGES_SALARIES_PAYABLES is '应付工资';
comment on column MBT_DM_610_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_610_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_610_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_610_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_610_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_610_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_610_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_610_C.CUST_NO is '客户号';
comment on column MBT_DM_610_C.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_610_C.PART_TYPE is '段标识';
comment on column MBT_DM_610_C.PART_NAME is '段名称';
comment on column MBT_DM_610_C.START_DATE is '起始日期';
comment on column MBT_DM_610_C.END_DATE is '结束日期';
comment on column MBT_DM_610_C.BATCH_NO is '批次号';
comment on column MBT_DM_610_C.ROW_NUM is '行号';
comment on column MBT_DM_610_C.IS_RPT is '是否报送';
comment on column MBT_DM_610_C.IS_VALID is '是否有效';
comment on column MBT_DM_610_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_610_C.OPT_FLAG is '操作标识';
comment on column MBT_DM_610_C.RPT_DATE is '报送日期';
comment on column MBT_DM_610_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_610_C.RPT_STATUS is '报送状态';
comment on column MBT_DM_610_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_610_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_610_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_610_C.REMARKS is '备注';
comment on column MBT_DM_610_C.CHECK_FLAG is '校验标志';
comment on column MBT_DM_610_C.CHECK_DESC is '校验说明';
comment on column MBT_DM_610_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_610_C.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_610_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_610_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_610_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_610_C.DATA_FLAG is '数据标志';
comment on column MBT_DM_610_C.DATA_OP is '操作标志';
comment on column MBT_DM_610_C.DATA_SOURCE is '数据来源';
comment on column MBT_DM_610_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_610_C.DATA_HASH is '数据HASH';
comment on column MBT_DM_610_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_610_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_610_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_610_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_610_C.DATA_CRT_USER is '创建人';
comment on column MBT_DM_610_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_610_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_610_C.DATA_CHG_USER is '修改人';
comment on column MBT_DM_610_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_610_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_610_C.DATA_APV_USER is '审核人';
comment on column MBT_DM_610_C.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_610_C.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_610_C.RSV1 is '备用字段';
comment on column MBT_DM_610_C.RSV2 is '备用字段';
comment on column MBT_DM_610_C.RSV3 is '备用字段';
comment on column MBT_DM_610_C.RSV4 is '备用字段';
comment on column MBT_DM_610_C.RSV5 is '备用字段';
create table MBT_DM_610_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ACCOUNTS_PAYABLE NUMBER(17),
D_ACCOUNTS_RECEIVABLE NUMBER(17),
D_BONDS_PAYABLE NUMBER(17),
D_CAPITALR_RSERVE NUMBER(17),
D_CONSTRUCTION_IN_PROGRESS NUMBER(17),
D_CONSTRUCTION_MATERIALS NUMBER(17),
D_CURRENCY_FUNDS NUMBER(17),
D_CURRENT_PORTION_LIABILITIES NUMBER(17),
D_CURRENT_PORTION_NCA NUMBER(17),
D_DEFERRED_TAX_ASSETS NUMBER(17),
D_DEFERRED_TAX_LIABILITIES NUMBER(17),
D_DEVELOPMENT_DISBURSEMENTS NUMBER(17),
D_DIVIDENDS_PAYABLE NUMBER(17),
D_DIVIDENDS_RECEIVABLE NUMBER(17),
D_EMPLOYEE_BENEFITS_PAYABLE NUMBER(17),
D_FINANCIAL_ASS_AVAILABLE_SALE NUMBER(17),
D_FINANCIAL_ASS_HELD_TRADING NUMBER(17),
D_FINANCIAL_LIABILITIES_HFT NUMBER(17),
D_FIXED_ASSETS NUMBER(17),
D_FIXED_ASS_PENDING_DISPOSAL NUMBER(17),
D_GOODWILL NUMBER(17),
D_GRANTS_PAYABLE NUMBER(17),
D_HELD_MATURITY_INVESTMENTS NUMBER(17),
D_INTANGIBLE_ASSETS NUMBER(17),
D_INTEREST_PAYABLE NUMBER(17),
D_INTEREST_RECEIVABLE NUMBER(17),
D_INVENTORIES NUMBER(17),
D_INVESTMENT_PROPERTIES NUMBER(17),
D_LAND_USE_RIGHTS NUMBER(17),
D_LESS_TREASURY_STOCKS NUMBER(17),
D_LONG_TERM_BORROWINGSORROWING NUMBER(17),
D_LONG_TERM_DEFERRED_EXPENSES NUMBER(17),
D_LONG_TERM_EQUITY_INVESTMENT NUMBER(17),
D_LONG_TERM_PAYABLES NUMBER(17),
D_LONG_TERM_RECEIVABLES NUMBER(17),
D_NET_VALUE_OF_FIXE_ASSETS NUMBER(17),
D_NON_CURRENT_BIOLOGICAL_ASS NUMBER(17),
D_NOTES_PAYABLE NUMBER(17),
D_NOTES_RECEIVABLE NUMBER(17),
D_OIL_AND_GAS_ASSETS NUMBER(17),
D_OTHER_CURRENT_ASSETS NUMBER(17),
D_OTHER_CURRENT_LIABILITIES NUMBER(17),
D_OTHER_NON_CURRENT_ASSETS NUMBER(17),
D_OTHER_NON_CURRENT_LIABILITIE NUMBER(17),
D_OTHER_PAYABLE NUMBER(17),
D_OTHER_RECEIVABLES NUMBER(17),
D_PAID_IN_CAPITAL_SHARE_CAPITA NUMBER(17),
D_PREPAYMENTS NUMBER(17),
D_PROVISIONS NUMBER(17),
D_RECEIPTS_IN_ADVANCE NUMBER(17),
D_SHORT_TERM_BORROWINGS NUMBER(17),
D_SURPLUS_RESERVE NUMBER(17),
D_TAXES_PAYABLE NUMBER(17),
D_TOTAL_ASSETS NUMBER(17),
D_TOTAL_CURRENT_ASSETS NUMBER(17),
D_TOTAL_CURRENT_LIABILITIES NUMBER(17),
D_TOTAL_EQUITY NUMBER(17),
D_TOTAL_EQUITY_LIABILITIES NUMBER(17),
D_TOTAL_LIABILITIES NUMBER(17),
D_TOTAL_NON_CURRENT_ASSETS NUMBER(17),
D_TOTAL_NON_CURRENT_LIABILITIE NUMBER(17),
D_UNAPPROPRIATED_PROFIT NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_610_D is '企业资产负债表信息-2007版资产负债表段';
comment on column MBT_DM_610_D.DATA_ID is '数据ID';
comment on column MBT_DM_610_D.DATA_DATE is '数据日期';
comment on column MBT_DM_610_D.CORP_ID is '法人ID';
comment on column MBT_DM_610_D.ORG_ID is '机构ID';
comment on column MBT_DM_610_D.GROUP_ID is '数据分组';
comment on column MBT_DM_610_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_610_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_610_D.D_ACCOUNTS_PAYABLE is '应付账款';
comment on column MBT_DM_610_D.D_ACCOUNTS_RECEIVABLE is '应收账款';
comment on column MBT_DM_610_D.D_BONDS_PAYABLE is '应付债券';
comment on column MBT_DM_610_D.D_CAPITALR_RSERVE is '资本公积';
comment on column MBT_DM_610_D.D_CONSTRUCTION_IN_PROGRESS is '在建工程';
comment on column MBT_DM_610_D.D_CONSTRUCTION_MATERIALS is '工程物资';
comment on column MBT_DM_610_D.D_CURRENCY_FUNDS is '货币资金';
comment on column MBT_DM_610_D.D_CURRENT_PORTION_LIABILITIES is '一年内到期的非流动负债';
comment on column MBT_DM_610_D.D_CURRENT_PORTION_NCA is '一年内到期的非流动资产';
comment on column MBT_DM_610_D.D_DEFERRED_TAX_ASSETS is '递延所得税资产';
comment on column MBT_DM_610_D.D_DEFERRED_TAX_LIABILITIES is '递延所得税负债';
comment on column MBT_DM_610_D.D_DEVELOPMENT_DISBURSEMENTS is '开发支出';
comment on column MBT_DM_610_D.D_DIVIDENDS_PAYABLE is '应付股利';
comment on column MBT_DM_610_D.D_DIVIDENDS_RECEIVABLE is '应收股利';
comment on column MBT_DM_610_D.D_EMPLOYEE_BENEFITS_PAYABLE is '应付职工薪酬';
comment on column MBT_DM_610_D.D_FINANCIAL_ASS_AVAILABLE_SALE is '可供出售的金融资产';
comment on column MBT_DM_610_D.D_FINANCIAL_ASS_HELD_TRADING is '交易性金融资产';
comment on column MBT_DM_610_D.D_FINANCIAL_LIABILITIES_HFT is '交易性金融负债';
comment on column MBT_DM_610_D.D_FIXED_ASSETS is '固定资产';
comment on column MBT_DM_610_D.D_FIXED_ASS_PENDING_DISPOSAL is '固定资产清理';
comment on column MBT_DM_610_D.D_GOODWILL is '商誉';
comment on column MBT_DM_610_D.D_GRANTS_PAYABLE is '专项应付款';
comment on column MBT_DM_610_D.D_HELD_MATURITY_INVESTMENTS is '持有至到期投资';
comment on column MBT_DM_610_D.D_INTANGIBLE_ASSETS is '无形资产';
comment on column MBT_DM_610_D.D_INTEREST_PAYABLE is '应付利息';
comment on column MBT_DM_610_D.D_INTEREST_RECEIVABLE is '应收利息';
comment on column MBT_DM_610_D.D_INVENTORIES is '存货';
comment on column MBT_DM_610_D.D_INVESTMENT_PROPERTIES is '投资性房地产';
comment on column MBT_DM_610_D.D_LAND_USE_RIGHTS is '（无形资产科目下）土地使用权';
comment on column MBT_DM_610_D.D_LESS_TREASURY_STOCKS is '减：库存股';
comment on column MBT_DM_610_D.D_LONG_TERM_BORROWINGSORROWING is '长期借款';
comment on column MBT_DM_610_D.D_LONG_TERM_DEFERRED_EXPENSES is '长期待摊费用';
comment on column MBT_DM_610_D.D_LONG_TERM_EQUITY_INVESTMENT is '长期股权投资';
comment on column MBT_DM_610_D.D_LONG_TERM_PAYABLES is '长期应付款';
comment on column MBT_DM_610_D.D_LONG_TERM_RECEIVABLES is '长期应收款';
comment on column MBT_DM_610_D.D_NET_VALUE_OF_FIXE_ASSETS is '固定资产净额';
comment on column MBT_DM_610_D.D_NON_CURRENT_BIOLOGICAL_ASS is '生产性生物资产';
comment on column MBT_DM_610_D.D_NOTES_PAYABLE is '应付票据';
comment on column MBT_DM_610_D.D_NOTES_RECEIVABLE is '应收票据';
comment on column MBT_DM_610_D.D_OIL_AND_GAS_ASSETS is '油气资产';
comment on column MBT_DM_610_D.D_OTHER_CURRENT_ASSETS is '其他流动资产';
comment on column MBT_DM_610_D.D_OTHER_CURRENT_LIABILITIES is '其他流动负债';
comment on column MBT_DM_610_D.D_OTHER_NON_CURRENT_ASSETS is '其他非流动资产';
comment on column MBT_DM_610_D.D_OTHER_NON_CURRENT_LIABILITIE is '其他非流动负债';
comment on column MBT_DM_610_D.D_OTHER_PAYABLE is '其他应付款';
comment on column MBT_DM_610_D.D_OTHER_RECEIVABLES is '其他应收款';
comment on column MBT_DM_610_D.D_PAID_IN_CAPITAL_SHARE_CAPITA is '实收资本（或股本）';
comment on column MBT_DM_610_D.D_PREPAYMENTS is '预付账款';
comment on column MBT_DM_610_D.D_PROVISIONS is '预计负债';
comment on column MBT_DM_610_D.D_RECEIPTS_IN_ADVANCE is '预收账款';
comment on column MBT_DM_610_D.D_SHORT_TERM_BORROWINGS is '短期借款';
comment on column MBT_DM_610_D.D_SURPLUS_RESERVE is '盈余公积';
comment on column MBT_DM_610_D.D_TAXES_PAYABLE is '应交税费';
comment on column MBT_DM_610_D.D_TOTAL_ASSETS is '资产总计';
comment on column MBT_DM_610_D.D_TOTAL_CURRENT_ASSETS is '流动资产合计';
comment on column MBT_DM_610_D.D_TOTAL_CURRENT_LIABILITIES is '流动负债合计';
comment on column MBT_DM_610_D.D_TOTAL_EQUITY is '所有者权益合计';
comment on column MBT_DM_610_D.D_TOTAL_EQUITY_LIABILITIES is '负债和所有者权益合计';
comment on column MBT_DM_610_D.D_TOTAL_LIABILITIES is '负债合计';
comment on column MBT_DM_610_D.D_TOTAL_NON_CURRENT_ASSETS is '非流动资产合计';
comment on column MBT_DM_610_D.D_TOTAL_NON_CURRENT_LIABILITIE is '非流动负债合计';
comment on column MBT_DM_610_D.D_UNAPPROPRIATED_PROFIT is '未分配利润';
comment on column MBT_DM_610_D.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_DM_610_D.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_DM_610_D.B_SHEET_TYPE is '报表类型';
comment on column MBT_DM_610_D.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_DM_610_D.B_SHEET_YEAR is '报表年份';
comment on column MBT_DM_610_D.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_DM_610_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_610_D.CUST_NO is '客户号';
comment on column MBT_DM_610_D.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_610_D.PART_TYPE is '段标识';
comment on column MBT_DM_610_D.PART_NAME is '段名称';
comment on column MBT_DM_610_D.START_DATE is '起始日期';
comment on column MBT_DM_610_D.END_DATE is '结束日期';
comment on column MBT_DM_610_D.BATCH_NO is '批次号';
comment on column MBT_DM_610_D.ROW_NUM is '行号';
comment on column MBT_DM_610_D.IS_RPT is '是否报送';
comment on column MBT_DM_610_D.IS_VALID is '是否有效';
comment on column MBT_DM_610_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_610_D.OPT_FLAG is '操作标识';
comment on column MBT_DM_610_D.RPT_DATE is '报送日期';
comment on column MBT_DM_610_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_610_D.RPT_STATUS is '报送状态';
comment on column MBT_DM_610_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_610_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_610_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_610_D.REMARKS is '备注';
comment on column MBT_DM_610_D.CHECK_FLAG is '校验标志';
comment on column MBT_DM_610_D.CHECK_DESC is '校验说明';
comment on column MBT_DM_610_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_610_D.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_610_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_610_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_610_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_610_D.DATA_FLAG is '数据标志';
comment on column MBT_DM_610_D.DATA_OP is '操作标志';
comment on column MBT_DM_610_D.DATA_SOURCE is '数据来源';
comment on column MBT_DM_610_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_610_D.DATA_HASH is '数据HASH';
comment on column MBT_DM_610_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_610_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_610_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_610_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_610_D.DATA_CRT_USER is '创建人';
comment on column MBT_DM_610_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_610_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_610_D.DATA_CHG_USER is '修改人';
comment on column MBT_DM_610_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_610_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_610_D.DATA_APV_USER is '审核人';
comment on column MBT_DM_610_D.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_610_D.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_610_D.RSV1 is '备用字段';
comment on column MBT_DM_610_D.RSV2 is '备用字段';
comment on column MBT_DM_610_D.RSV3 is '备用字段';
comment on column MBT_DM_610_D.RSV4 is '备用字段';
comment on column MBT_DM_610_D.RSV5 is '备用字段';
create table MBT_PM_610 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_610 is '企业资产负债表信息';
comment on column MBT_PM_610.DATA_ID is '数据ID';
comment on column MBT_PM_610.DATA_DATE is '数据日期';
comment on column MBT_PM_610.CORP_ID is '法人ID';
comment on column MBT_PM_610.ORG_ID is '机构ID';
comment on column MBT_PM_610.GROUP_ID is '数据分组';
comment on column MBT_PM_610.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_610.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_610.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_610.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_610.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_610.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_610.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_610.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_610.B_ENT_NAME is '企业名称';
comment on column MBT_PM_610.SECTION_CHG_CNT is '段变更';
comment on column MBT_PM_610.SECTION_DEL_CNT is '段删除';
comment on column MBT_PM_610.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_PM_610.IDN_CHG_CNT is '标识项变更';
comment on column MBT_PM_610.CUST_NO is '客户号';
comment on column MBT_PM_610.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_610.PART_TYPE is '段标识';
comment on column MBT_PM_610.PART_NAME is '段名称';
comment on column MBT_PM_610.START_DATE is '起始日期';
comment on column MBT_PM_610.END_DATE is '结束日期';
comment on column MBT_PM_610.BATCH_NO is '批次号';
comment on column MBT_PM_610.ROW_NUM is '行号';
comment on column MBT_PM_610.IS_RPT is '是否报送';
comment on column MBT_PM_610.IS_VALID is '是否有效';
comment on column MBT_PM_610.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_610.OPT_FLAG is '操作标识';
comment on column MBT_PM_610.RPT_DATE is '报送日期';
comment on column MBT_PM_610.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_610.RPT_STATUS is '报送状态';
comment on column MBT_PM_610.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_610.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_610.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_610.REMARKS is '备注';
comment on column MBT_PM_610.CHECK_FLAG is '校验标志';
comment on column MBT_PM_610.CHECK_DESC is '校验说明';
comment on column MBT_PM_610.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_610.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_610.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_610.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_610.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_610.DATA_FLAG is '数据标志';
comment on column MBT_PM_610.DATA_OP is '操作标志';
comment on column MBT_PM_610.DATA_SOURCE is '数据来源';
comment on column MBT_PM_610.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_610.DATA_HASH is '数据HASH';
comment on column MBT_PM_610.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_610.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_610.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_610.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_610.DATA_CRT_USER is '创建人';
comment on column MBT_PM_610.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_610.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_610.DATA_CHG_USER is '修改人';
comment on column MBT_PM_610.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_610.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_610.DATA_APV_USER is '审核人';
comment on column MBT_PM_610.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_610.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_610.RSV1 is '备用字段';
comment on column MBT_PM_610.RSV2 is '备用字段';
comment on column MBT_PM_610.RSV3 is '备用字段';
comment on column MBT_PM_610.RSV4 is '备用字段';
comment on column MBT_PM_610.RSV5 is '备用字段';
create table MBT_PM_610_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_610_B is '企业资产负债表信息-基础段';
comment on column MBT_PM_610_B.DATA_ID is '数据ID';
comment on column MBT_PM_610_B.DATA_DATE is '数据日期';
comment on column MBT_PM_610_B.CORP_ID is '法人ID';
comment on column MBT_PM_610_B.ORG_ID is '机构ID';
comment on column MBT_PM_610_B.GROUP_ID is '数据分组';
comment on column MBT_PM_610_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_610_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_610_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_610_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_610_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_610_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_610_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_610_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_610_B.B_ENT_NAME is '企业名称';
comment on column MBT_PM_610_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_PM_610_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_PM_610_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_PM_610_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_PM_610_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_PM_610_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_610_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_PM_610_B.CUST_NO is '客户号';
comment on column MBT_PM_610_B.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_610_B.PART_TYPE is '段标识';
comment on column MBT_PM_610_B.PART_NAME is '段名称';
comment on column MBT_PM_610_B.START_DATE is '起始日期';
comment on column MBT_PM_610_B.END_DATE is '结束日期';
comment on column MBT_PM_610_B.BATCH_NO is '批次号';
comment on column MBT_PM_610_B.ROW_NUM is '行号';
comment on column MBT_PM_610_B.IS_RPT is '是否报送';
comment on column MBT_PM_610_B.IS_VALID is '是否有效';
comment on column MBT_PM_610_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_610_B.OPT_FLAG is '操作标识';
comment on column MBT_PM_610_B.RPT_DATE is '报送日期';
comment on column MBT_PM_610_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_610_B.RPT_STATUS is '报送状态';
comment on column MBT_PM_610_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_610_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_610_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_610_B.REMARKS is '备注';
comment on column MBT_PM_610_B.CHECK_FLAG is '校验标志';
comment on column MBT_PM_610_B.CHECK_DESC is '校验说明';
comment on column MBT_PM_610_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_610_B.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_610_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_610_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_610_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_610_B.DATA_FLAG is '数据标志';
comment on column MBT_PM_610_B.DATA_OP is '操作标志';
comment on column MBT_PM_610_B.DATA_SOURCE is '数据来源';
comment on column MBT_PM_610_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_610_B.DATA_HASH is '数据HASH';
comment on column MBT_PM_610_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_610_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_610_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_610_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_610_B.DATA_CRT_USER is '创建人';
comment on column MBT_PM_610_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_610_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_610_B.DATA_CHG_USER is '修改人';
comment on column MBT_PM_610_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_610_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_610_B.DATA_APV_USER is '审核人';
comment on column MBT_PM_610_B.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_610_B.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_610_B.RSV1 is '备用字段';
comment on column MBT_PM_610_B.RSV2 is '备用字段';
comment on column MBT_PM_610_B.RSV3 is '备用字段';
comment on column MBT_PM_610_B.RSV4 is '备用字段';
comment on column MBT_PM_610_B.RSV5 is '备用字段';
create table MBT_PM_610_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ACCOUNTS_PAYABLE NUMBER(17),
C_ACCOUNTS_RECEIVABLE NUMBER(17),
C_ALLOWANCE_RECEIVABLE NUMBER(17),
C_AMONG_IT_SPE_APPR_RES_MAT NUMBER(17),
C_BONDS_PAYABLE NUMBER(17),
C_CAPITALR_RSERVE NUMBER(17),
C_COLLECTIVE_CAPITAL NUMBER(17),
C_COLLECTIVE_LP_CAPITAL NUMBER(17),
C_CONSTRUCTION_IN_PROGRESS NUMBER(17),
C_CONSTRUCTION_MATERIALS NUMBER(17),
C_CURRENCY_FUNDS NUMBER(17),
C_DEFERRED_ASSETS NUMBER(17),
C_DEFERRED_ASSETS_DEBITS NUMBER(17),
C_DEFERRED_EXPENSES NUMBER(17),
C_DEFERRED_TAXATION_CREDIT NUMBER(17),
C_DIVIDENDS_RECEIVABLE NUMBER(17),
C_DT_FC_FINANCIAL_STA NUMBER(17),
C_EMPLOYEE_BENEFITS NUMBER(17),
C_EXPORT_DRAWBACK_RECEIVABLE NUMBER(17),
C_FA_ACC_DEPRECIATION NUMBER(17),
C_FA_NET_VALUE NUMBER(17),
C_FA_PENDING_DISPOSAL NUMBER(17),
C_FINISHED_PRODUCTS NUMBER(17),
C_FOREIGN_BUS_CAPITAL NUMBER(17),
C_FUTURE_GUARANTEE NUMBER(17),
C_GRANTS_PAYABLE NUMBER(17),
C_IMPROVEMENT_EXPENDITURE_FA NUMBER(17),
C_INCLUDING_FA_REPAIR NUMBER(17),
C_INCOME_PAYABLE NUMBER(17),
C_INC_PRICE_DIFFERENCE NUMBER(17),
C_INTANGIBLE_ASSETS NUMBER(17),
C_INTEREST_RECEIVABLE NUMBER(17),
C_INVENTORIES NUMBER(17),
C_LAND_USE_RIGHTS NUMBER(17),
C_LEGAL_PERSONS_CAPITAL NUMBER(17),
C_LONG_TERM_PAYABLES NUMBER(17),
C_LT_BORROWINGS NUMBER(17),
C_LT_DI_FALLINGDUEINAYEAR NUMBER(17),
C_LT_EQUITYINVESTMENT NUMBER(17),
C_LT_INVESTMENT NUMBER(17),
C_LT_LIABILITIES_DUE_ONEYEAR NUMBER(17),
C_LT_SECURITIES_INVESTMENT NUMBER(17),
C_MINORITY_INTEREST NUMBER(17),
C_NATIONAL_CAPITAL NUMBER(17),
C_NET_VALUE_FA NUMBER(17),
C_NOTES_PAYABLE NUMBER(17),
C_NOTES_RECEIVABLE NUMBER(17),
C_ORIGINAL_COST_FA NUMBER(17),
C_OTHER_CURRENT_ASSETS NUMBER(17),
C_OTHER_CURRENT_LIABILITIES NUMBER(17),
C_OTHER_LONG_TERM_ASSETS NUMBER(17),
C_OTHER_LT_LIABILITIES NUMBER(17),
C_OTHER_PAYABLE NUMBER(17),
C_OTHER_PAYABLE_GOVERNMENT NUMBER(17),
C_OTHER_RECEIVABLES NUMBER(17),
C_PAID_IN_CAPITAL NUMBER(17),
C_PERSONAL_CAPITAL NUMBER(17),
C_PREPAYMENTS NUMBER(17),
C_PROVISIONS NUMBER(17),
C_PROVISION_FOR_EXPENSES NUMBER(17),
C_PROVISION_IMPAIRMENT_FA NUMBER(17),
C_PUBLIC_WELFARE_FUND NUMBER(17),
C_RAW_MATERIALS NUMBER(17),
C_RECEIPTS_IN_ADVANCE NUMBER(17),
C_SHORT_TERM_BORROWINGS NUMBER(17),
C_SHORT_TERM_INVESTMENTS NUMBER(17),
C_SPECIAL_RESERVE_FUND NUMBER(17),
C_STATE_OWNED_LP_CAPITAL NUMBER(17),
C_STATUTORY_SURPLUS_RESERVE NUMBER(17),
C_SUPPLER_CURRENT_CAPITAL NUMBER(17),
C_SURPLUS_RESERVE NUMBER(17),
C_TAXES_PAYABLE NUMBER(17),
C_TOTAL_ASSETS NUMBER(17),
C_TOTAL_CURRENT_ASSETS NUMBER(17),
C_TOTAL_CURRENT_LIABILITIES NUMBER(17),
C_TOTAL_EQUITY NUMBER(17),
C_TOTAL_EQUITY_LIABILITIES NUMBER(17),
C_TOTAL_FIXED_ASSETS NUMBER(17),
C_TOTAL_INTANGIBLE_OTHER_ASS NUMBER(17),
C_TOTAL_LIABILITIES NUMBER(17),
C_TOTAL_LT_INVESTMENT NUMBER(17),
C_TOTAL_LT_LIABILITIES NUMBER(17),
C_UNAFFIRMED_INVESTMENT_LOSS NUMBER(17),
C_UNAPPROPRIATED_PROFIT NUMBER(17),
C_UNSETTLED_GL_CURRENT_ASSETS NUMBER(17),
C_UNSETTLED_GL_ON_FA NUMBER(17),
C_WAGES_SALARIES_PAYABLES NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_610_C is '企业资产负债表信息-2002版资产负债表段';
comment on column MBT_PM_610_C.DATA_ID is '数据ID';
comment on column MBT_PM_610_C.DATA_DATE is '数据日期';
comment on column MBT_PM_610_C.CORP_ID is '法人ID';
comment on column MBT_PM_610_C.ORG_ID is '机构ID';
comment on column MBT_PM_610_C.GROUP_ID is '数据分组';
comment on column MBT_PM_610_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_610_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_610_C.C_ACCOUNTS_PAYABLE is '应付账款';
comment on column MBT_PM_610_C.C_ACCOUNTS_RECEIVABLE is '应收账款';
comment on column MBT_PM_610_C.C_ALLOWANCE_RECEIVABLE is '应收补贴款';
comment on column MBT_PM_610_C.C_AMONG_IT_SPE_APPR_RES_MAT is '（其他长期资产科目下）特准储备物资';
comment on column MBT_PM_610_C.C_BONDS_PAYABLE is '应付债券';
comment on column MBT_PM_610_C.C_CAPITALR_RSERVE is '资本公积';
comment on column MBT_PM_610_C.C_COLLECTIVE_CAPITAL is '集体资本';
comment on column MBT_PM_610_C.C_COLLECTIVE_LP_CAPITAL is '（法人资本科目下）集体法人资本';
comment on column MBT_PM_610_C.C_CONSTRUCTION_IN_PROGRESS is '在建工程';
comment on column MBT_PM_610_C.C_CONSTRUCTION_MATERIALS is '工程物资';
comment on column MBT_PM_610_C.C_CURRENCY_FUNDS is '货币资金';
comment on column MBT_PM_610_C.C_DEFERRED_ASSETS is '递延资产';
comment on column MBT_PM_610_C.C_DEFERRED_ASSETS_DEBITS is '递延税款借项';
comment on column MBT_PM_610_C.C_DEFERRED_EXPENSES is '待摊费用';
comment on column MBT_PM_610_C.C_DEFERRED_TAXATION_CREDIT is '递延税款贷项';
comment on column MBT_PM_610_C.C_DIVIDENDS_RECEIVABLE is '应收股利';
comment on column MBT_PM_610_C.C_DT_FC_FINANCIAL_STA is '外币报表折算差额';
comment on column MBT_PM_610_C.C_EMPLOYEE_BENEFITS is '应付福利费';
comment on column MBT_PM_610_C.C_EXPORT_DRAWBACK_RECEIVABLE is '应收出口退税';
comment on column MBT_PM_610_C.C_FA_ACC_DEPRECIATION is '累计折旧';
comment on column MBT_PM_610_C.C_FA_NET_VALUE is '固定资产净值';
comment on column MBT_PM_610_C.C_FA_PENDING_DISPOSAL is '固定资产清理';
comment on column MBT_PM_610_C.C_FINISHED_PRODUCTS is '存货产成品';
comment on column MBT_PM_610_C.C_FOREIGN_BUS_CAPITAL is '外商资本';
comment on column MBT_PM_610_C.C_FUTURE_GUARANTEE is '期货保证金';
comment on column MBT_PM_610_C.C_GRANTS_PAYABLE is '专项应付款';
comment on column MBT_PM_610_C.C_IMPROVEMENT_EXPENDITURE_FA is '（递延资产科目下）固定资产改良支出';
comment on column MBT_PM_610_C.C_INCLUDING_FA_REPAIR is '（递延资产科目下）固定资产修理';
comment on column MBT_PM_610_C.C_INCOME_PAYABLE is '应付利润';
comment on column MBT_PM_610_C.C_INC_PRICE_DIFFERENCE is '合并价差';
comment on column MBT_PM_610_C.C_INTANGIBLE_ASSETS is '无形资产';
comment on column MBT_PM_610_C.C_INTEREST_RECEIVABLE is '应收利息';
comment on column MBT_PM_610_C.C_INVENTORIES is '存货';
comment on column MBT_PM_610_C.C_LAND_USE_RIGHTS is '（无形资产科目下）土地使用权';
comment on column MBT_PM_610_C.C_LEGAL_PERSONS_CAPITAL is '法人资本';
comment on column MBT_PM_610_C.C_LONG_TERM_PAYABLES is '长期应付款';
comment on column MBT_PM_610_C.C_LT_BORROWINGS is '长期借款';
comment on column MBT_PM_610_C.C_LT_DI_FALLINGDUEINAYEAR is '一年内到期的长期债权投资';
comment on column MBT_PM_610_C.C_LT_EQUITYINVESTMENT is '长期股权投资';
comment on column MBT_PM_610_C.C_LT_INVESTMENT is '长期投资';
comment on column MBT_PM_610_C.C_LT_LIABILITIES_DUE_ONEYEAR is '一年内到期的长期负债';
comment on column MBT_PM_610_C.C_LT_SECURITIES_INVESTMENT is '长期债权投资';
comment on column MBT_PM_610_C.C_MINORITY_INTEREST is '少数股东权益';
comment on column MBT_PM_610_C.C_NATIONAL_CAPITAL is '国家资本';
comment on column MBT_PM_610_C.C_NET_VALUE_FA is '固定资产净额';
comment on column MBT_PM_610_C.C_NOTES_PAYABLE is '应付票据';
comment on column MBT_PM_610_C.C_NOTES_RECEIVABLE is '应收票据';
comment on column MBT_PM_610_C.C_ORIGINAL_COST_FA is '固定资产原价';
comment on column MBT_PM_610_C.C_OTHER_CURRENT_ASSETS is '其他流动资产';
comment on column MBT_PM_610_C.C_OTHER_CURRENT_LIABILITIES is '其他流动负债';
comment on column MBT_PM_610_C.C_OTHER_LONG_TERM_ASSETS is '其他长期资产';
comment on column MBT_PM_610_C.C_OTHER_LT_LIABILITIES is '其他长期负债';
comment on column MBT_PM_610_C.C_OTHER_PAYABLE is '其他应付款';
comment on column MBT_PM_610_C.C_OTHER_PAYABLE_GOVERNMENT is '其他应交款';
comment on column MBT_PM_610_C.C_OTHER_RECEIVABLES is '其他应收款';
comment on column MBT_PM_610_C.C_PAID_IN_CAPITAL is '实收资本';
comment on column MBT_PM_610_C.C_PERSONAL_CAPITAL is '个人资本';
comment on column MBT_PM_610_C.C_PREPAYMENTS is '预付账款';
comment on column MBT_PM_610_C.C_PROVISIONS is '预计负债';
comment on column MBT_PM_610_C.C_PROVISION_FOR_EXPENSES is '预提费用';
comment on column MBT_PM_610_C.C_PROVISION_IMPAIRMENT_FA is '固定资产值减值准备';
comment on column MBT_PM_610_C.C_PUBLIC_WELFARE_FUND is '（盈余公积科目下）公益金';
comment on column MBT_PM_610_C.C_RAW_MATERIALS is '存货原材料';
comment on column MBT_PM_610_C.C_RECEIPTS_IN_ADVANCE is '预收账款';
comment on column MBT_PM_610_C.C_SHORT_TERM_BORROWINGS is '短期借款';
comment on column MBT_PM_610_C.C_SHORT_TERM_INVESTMENTS is '短期投资';
comment on column MBT_PM_610_C.C_SPECIAL_RESERVE_FUND is '（其他长期负债科目下）特准储备基金';
comment on column MBT_PM_610_C.C_STATE_OWNED_LP_CAPITAL is '（法人资本科目下）国有法人资本';
comment on column MBT_PM_610_C.C_STATUTORY_SURPLUS_RESERVE is '（盈余公积科目下）法定盈余公积';
comment on column MBT_PM_610_C.C_SUPPLER_CURRENT_CAPITAL is '（盈余公积科目下）补充流动资本';
comment on column MBT_PM_610_C.C_SURPLUS_RESERVE is '盈余公积';
comment on column MBT_PM_610_C.C_TAXES_PAYABLE is '应交税金';
comment on column MBT_PM_610_C.C_TOTAL_ASSETS is '资产总计';
comment on column MBT_PM_610_C.C_TOTAL_CURRENT_ASSETS is '流动资产合计';
comment on column MBT_PM_610_C.C_TOTAL_CURRENT_LIABILITIES is '流动负债合计';
comment on column MBT_PM_610_C.C_TOTAL_EQUITY is '所有者权益合计';
comment on column MBT_PM_610_C.C_TOTAL_EQUITY_LIABILITIES is '负债和所有者权益总计';
comment on column MBT_PM_610_C.C_TOTAL_FIXED_ASSETS is '固定资产合计';
comment on column MBT_PM_610_C.C_TOTAL_INTANGIBLE_OTHER_ASS is '无形及其他资产合计';
comment on column MBT_PM_610_C.C_TOTAL_LIABILITIES is '负债合计';
comment on column MBT_PM_610_C.C_TOTAL_LT_INVESTMENT is '长期投资合计';
comment on column MBT_PM_610_C.C_TOTAL_LT_LIABILITIES is '长期负债合计';
comment on column MBT_PM_610_C.C_UNAFFIRMED_INVESTMENT_LOSS is '未确认的投资损失';
comment on column MBT_PM_610_C.C_UNAPPROPRIATED_PROFIT is '未分配利润';
comment on column MBT_PM_610_C.C_UNSETTLED_GL_CURRENT_ASSETS is '待处理流动资产净损失';
comment on column MBT_PM_610_C.C_UNSETTLED_GL_ON_FA is '待处理固定资产净损失';
comment on column MBT_PM_610_C.C_WAGES_SALARIES_PAYABLES is '应付工资';
comment on column MBT_PM_610_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_610_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_610_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_610_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_610_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_610_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_610_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_610_C.CUST_NO is '客户号';
comment on column MBT_PM_610_C.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_610_C.PART_TYPE is '段标识';
comment on column MBT_PM_610_C.PART_NAME is '段名称';
comment on column MBT_PM_610_C.START_DATE is '起始日期';
comment on column MBT_PM_610_C.END_DATE is '结束日期';
comment on column MBT_PM_610_C.BATCH_NO is '批次号';
comment on column MBT_PM_610_C.ROW_NUM is '行号';
comment on column MBT_PM_610_C.IS_RPT is '是否报送';
comment on column MBT_PM_610_C.IS_VALID is '是否有效';
comment on column MBT_PM_610_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_610_C.OPT_FLAG is '操作标识';
comment on column MBT_PM_610_C.RPT_DATE is '报送日期';
comment on column MBT_PM_610_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_610_C.RPT_STATUS is '报送状态';
comment on column MBT_PM_610_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_610_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_610_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_610_C.REMARKS is '备注';
comment on column MBT_PM_610_C.CHECK_FLAG is '校验标志';
comment on column MBT_PM_610_C.CHECK_DESC is '校验说明';
comment on column MBT_PM_610_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_610_C.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_610_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_610_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_610_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_610_C.DATA_FLAG is '数据标志';
comment on column MBT_PM_610_C.DATA_OP is '操作标志';
comment on column MBT_PM_610_C.DATA_SOURCE is '数据来源';
comment on column MBT_PM_610_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_610_C.DATA_HASH is '数据HASH';
comment on column MBT_PM_610_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_610_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_610_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_610_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_610_C.DATA_CRT_USER is '创建人';
comment on column MBT_PM_610_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_610_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_610_C.DATA_CHG_USER is '修改人';
comment on column MBT_PM_610_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_610_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_610_C.DATA_APV_USER is '审核人';
comment on column MBT_PM_610_C.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_610_C.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_610_C.RSV1 is '备用字段';
comment on column MBT_PM_610_C.RSV2 is '备用字段';
comment on column MBT_PM_610_C.RSV3 is '备用字段';
comment on column MBT_PM_610_C.RSV4 is '备用字段';
comment on column MBT_PM_610_C.RSV5 is '备用字段';
create table MBT_PM_610_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ACCOUNTS_PAYABLE NUMBER(17),
D_ACCOUNTS_RECEIVABLE NUMBER(17),
D_BONDS_PAYABLE NUMBER(17),
D_CAPITALR_RSERVE NUMBER(17),
D_CONSTRUCTION_IN_PROGRESS NUMBER(17),
D_CONSTRUCTION_MATERIALS NUMBER(17),
D_CURRENCY_FUNDS NUMBER(17),
D_CURRENT_PORTION_LIABILITIES NUMBER(17),
D_CURRENT_PORTION_NCA NUMBER(17),
D_DEFERRED_TAX_ASSETS NUMBER(17),
D_DEFERRED_TAX_LIABILITIES NUMBER(17),
D_DEVELOPMENT_DISBURSEMENTS NUMBER(17),
D_DIVIDENDS_PAYABLE NUMBER(17),
D_DIVIDENDS_RECEIVABLE NUMBER(17),
D_EMPLOYEE_BENEFITS_PAYABLE NUMBER(17),
D_FINANCIAL_ASS_AVAILABLE_SALE NUMBER(17),
D_FINANCIAL_ASS_HELD_TRADING NUMBER(17),
D_FINANCIAL_LIABILITIES_HFT NUMBER(17),
D_FIXED_ASSETS NUMBER(17),
D_FIXED_ASS_PENDING_DISPOSAL NUMBER(17),
D_GOODWILL NUMBER(17),
D_GRANTS_PAYABLE NUMBER(17),
D_HELD_MATURITY_INVESTMENTS NUMBER(17),
D_INTANGIBLE_ASSETS NUMBER(17),
D_INTEREST_PAYABLE NUMBER(17),
D_INTEREST_RECEIVABLE NUMBER(17),
D_INVENTORIES NUMBER(17),
D_INVESTMENT_PROPERTIES NUMBER(17),
D_LAND_USE_RIGHTS NUMBER(17),
D_LESS_TREASURY_STOCKS NUMBER(17),
D_LONG_TERM_BORROWINGSORROWING NUMBER(17),
D_LONG_TERM_DEFERRED_EXPENSES NUMBER(17),
D_LONG_TERM_EQUITY_INVESTMENT NUMBER(17),
D_LONG_TERM_PAYABLES NUMBER(17),
D_LONG_TERM_RECEIVABLES NUMBER(17),
D_NET_VALUE_OF_FIXE_ASSETS NUMBER(17),
D_NON_CURRENT_BIOLOGICAL_ASS NUMBER(17),
D_NOTES_PAYABLE NUMBER(17),
D_NOTES_RECEIVABLE NUMBER(17),
D_OIL_AND_GAS_ASSETS NUMBER(17),
D_OTHER_CURRENT_ASSETS NUMBER(17),
D_OTHER_CURRENT_LIABILITIES NUMBER(17),
D_OTHER_NON_CURRENT_ASSETS NUMBER(17),
D_OTHER_NON_CURRENT_LIABILITIE NUMBER(17),
D_OTHER_PAYABLE NUMBER(17),
D_OTHER_RECEIVABLES NUMBER(17),
D_PAID_IN_CAPITAL_SHARE_CAPITA NUMBER(17),
D_PREPAYMENTS NUMBER(17),
D_PROVISIONS NUMBER(17),
D_RECEIPTS_IN_ADVANCE NUMBER(17),
D_SHORT_TERM_BORROWINGS NUMBER(17),
D_SURPLUS_RESERVE NUMBER(17),
D_TAXES_PAYABLE NUMBER(17),
D_TOTAL_ASSETS NUMBER(17),
D_TOTAL_CURRENT_ASSETS NUMBER(17),
D_TOTAL_CURRENT_LIABILITIES NUMBER(17),
D_TOTAL_EQUITY NUMBER(17),
D_TOTAL_EQUITY_LIABILITIES NUMBER(17),
D_TOTAL_LIABILITIES NUMBER(17),
D_TOTAL_NON_CURRENT_ASSETS NUMBER(17),
D_TOTAL_NON_CURRENT_LIABILITIE NUMBER(17),
D_UNAPPROPRIATED_PROFIT NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_610_D is '企业资产负债表信息-2007版资产负债表段';
comment on column MBT_PM_610_D.DATA_ID is '数据ID';
comment on column MBT_PM_610_D.DATA_DATE is '数据日期';
comment on column MBT_PM_610_D.CORP_ID is '法人ID';
comment on column MBT_PM_610_D.ORG_ID is '机构ID';
comment on column MBT_PM_610_D.GROUP_ID is '数据分组';
comment on column MBT_PM_610_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_610_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_610_D.D_ACCOUNTS_PAYABLE is '应付账款';
comment on column MBT_PM_610_D.D_ACCOUNTS_RECEIVABLE is '应收账款';
comment on column MBT_PM_610_D.D_BONDS_PAYABLE is '应付债券';
comment on column MBT_PM_610_D.D_CAPITALR_RSERVE is '资本公积';
comment on column MBT_PM_610_D.D_CONSTRUCTION_IN_PROGRESS is '在建工程';
comment on column MBT_PM_610_D.D_CONSTRUCTION_MATERIALS is '工程物资';
comment on column MBT_PM_610_D.D_CURRENCY_FUNDS is '货币资金';
comment on column MBT_PM_610_D.D_CURRENT_PORTION_LIABILITIES is '一年内到期的非流动负债';
comment on column MBT_PM_610_D.D_CURRENT_PORTION_NCA is '一年内到期的非流动资产';
comment on column MBT_PM_610_D.D_DEFERRED_TAX_ASSETS is '递延所得税资产';
comment on column MBT_PM_610_D.D_DEFERRED_TAX_LIABILITIES is '递延所得税负债';
comment on column MBT_PM_610_D.D_DEVELOPMENT_DISBURSEMENTS is '开发支出';
comment on column MBT_PM_610_D.D_DIVIDENDS_PAYABLE is '应付股利';
comment on column MBT_PM_610_D.D_DIVIDENDS_RECEIVABLE is '应收股利';
comment on column MBT_PM_610_D.D_EMPLOYEE_BENEFITS_PAYABLE is '应付职工薪酬';
comment on column MBT_PM_610_D.D_FINANCIAL_ASS_AVAILABLE_SALE is '可供出售的金融资产';
comment on column MBT_PM_610_D.D_FINANCIAL_ASS_HELD_TRADING is '交易性金融资产';
comment on column MBT_PM_610_D.D_FINANCIAL_LIABILITIES_HFT is '交易性金融负债';
comment on column MBT_PM_610_D.D_FIXED_ASSETS is '固定资产';
comment on column MBT_PM_610_D.D_FIXED_ASS_PENDING_DISPOSAL is '固定资产清理';
comment on column MBT_PM_610_D.D_GOODWILL is '商誉';
comment on column MBT_PM_610_D.D_GRANTS_PAYABLE is '专项应付款';
comment on column MBT_PM_610_D.D_HELD_MATURITY_INVESTMENTS is '持有至到期投资';
comment on column MBT_PM_610_D.D_INTANGIBLE_ASSETS is '无形资产';
comment on column MBT_PM_610_D.D_INTEREST_PAYABLE is '应付利息';
comment on column MBT_PM_610_D.D_INTEREST_RECEIVABLE is '应收利息';
comment on column MBT_PM_610_D.D_INVENTORIES is '存货';
comment on column MBT_PM_610_D.D_INVESTMENT_PROPERTIES is '投资性房地产';
comment on column MBT_PM_610_D.D_LAND_USE_RIGHTS is '（无形资产科目下）土地使用权';
comment on column MBT_PM_610_D.D_LESS_TREASURY_STOCKS is '减：库存股';
comment on column MBT_PM_610_D.D_LONG_TERM_BORROWINGSORROWING is '长期借款';
comment on column MBT_PM_610_D.D_LONG_TERM_DEFERRED_EXPENSES is '长期待摊费用';
comment on column MBT_PM_610_D.D_LONG_TERM_EQUITY_INVESTMENT is '长期股权投资';
comment on column MBT_PM_610_D.D_LONG_TERM_PAYABLES is '长期应付款';
comment on column MBT_PM_610_D.D_LONG_TERM_RECEIVABLES is '长期应收款';
comment on column MBT_PM_610_D.D_NET_VALUE_OF_FIXE_ASSETS is '固定资产净额';
comment on column MBT_PM_610_D.D_NON_CURRENT_BIOLOGICAL_ASS is '生产性生物资产';
comment on column MBT_PM_610_D.D_NOTES_PAYABLE is '应付票据';
comment on column MBT_PM_610_D.D_NOTES_RECEIVABLE is '应收票据';
comment on column MBT_PM_610_D.D_OIL_AND_GAS_ASSETS is '油气资产';
comment on column MBT_PM_610_D.D_OTHER_CURRENT_ASSETS is '其他流动资产';
comment on column MBT_PM_610_D.D_OTHER_CURRENT_LIABILITIES is '其他流动负债';
comment on column MBT_PM_610_D.D_OTHER_NON_CURRENT_ASSETS is '其他非流动资产';
comment on column MBT_PM_610_D.D_OTHER_NON_CURRENT_LIABILITIE is '其他非流动负债';
comment on column MBT_PM_610_D.D_OTHER_PAYABLE is '其他应付款';
comment on column MBT_PM_610_D.D_OTHER_RECEIVABLES is '其他应收款';
comment on column MBT_PM_610_D.D_PAID_IN_CAPITAL_SHARE_CAPITA is '实收资本（或股本）';
comment on column MBT_PM_610_D.D_PREPAYMENTS is '预付账款';
comment on column MBT_PM_610_D.D_PROVISIONS is '预计负债';
comment on column MBT_PM_610_D.D_RECEIPTS_IN_ADVANCE is '预收账款';
comment on column MBT_PM_610_D.D_SHORT_TERM_BORROWINGS is '短期借款';
comment on column MBT_PM_610_D.D_SURPLUS_RESERVE is '盈余公积';
comment on column MBT_PM_610_D.D_TAXES_PAYABLE is '应交税费';
comment on column MBT_PM_610_D.D_TOTAL_ASSETS is '资产总计';
comment on column MBT_PM_610_D.D_TOTAL_CURRENT_ASSETS is '流动资产合计';
comment on column MBT_PM_610_D.D_TOTAL_CURRENT_LIABILITIES is '流动负债合计';
comment on column MBT_PM_610_D.D_TOTAL_EQUITY is '所有者权益合计';
comment on column MBT_PM_610_D.D_TOTAL_EQUITY_LIABILITIES is '负债和所有者权益合计';
comment on column MBT_PM_610_D.D_TOTAL_LIABILITIES is '负债合计';
comment on column MBT_PM_610_D.D_TOTAL_NON_CURRENT_ASSETS is '非流动资产合计';
comment on column MBT_PM_610_D.D_TOTAL_NON_CURRENT_LIABILITIE is '非流动负债合计';
comment on column MBT_PM_610_D.D_UNAPPROPRIATED_PROFIT is '未分配利润';
comment on column MBT_PM_610_D.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_PM_610_D.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_PM_610_D.B_SHEET_TYPE is '报表类型';
comment on column MBT_PM_610_D.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_PM_610_D.B_SHEET_YEAR is '报表年份';
comment on column MBT_PM_610_D.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_PM_610_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_610_D.CUST_NO is '客户号';
comment on column MBT_PM_610_D.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_610_D.PART_TYPE is '段标识';
comment on column MBT_PM_610_D.PART_NAME is '段名称';
comment on column MBT_PM_610_D.START_DATE is '起始日期';
comment on column MBT_PM_610_D.END_DATE is '结束日期';
comment on column MBT_PM_610_D.BATCH_NO is '批次号';
comment on column MBT_PM_610_D.ROW_NUM is '行号';
comment on column MBT_PM_610_D.IS_RPT is '是否报送';
comment on column MBT_PM_610_D.IS_VALID is '是否有效';
comment on column MBT_PM_610_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_610_D.OPT_FLAG is '操作标识';
comment on column MBT_PM_610_D.RPT_DATE is '报送日期';
comment on column MBT_PM_610_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_610_D.RPT_STATUS is '报送状态';
comment on column MBT_PM_610_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_610_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_610_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_610_D.REMARKS is '备注';
comment on column MBT_PM_610_D.CHECK_FLAG is '校验标志';
comment on column MBT_PM_610_D.CHECK_DESC is '校验说明';
comment on column MBT_PM_610_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_610_D.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_610_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_610_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_610_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_610_D.DATA_FLAG is '数据标志';
comment on column MBT_PM_610_D.DATA_OP is '操作标志';
comment on column MBT_PM_610_D.DATA_SOURCE is '数据来源';
comment on column MBT_PM_610_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_610_D.DATA_HASH is '数据HASH';
comment on column MBT_PM_610_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_610_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_610_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_610_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_610_D.DATA_CRT_USER is '创建人';
comment on column MBT_PM_610_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_610_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_610_D.DATA_CHG_USER is '修改人';
comment on column MBT_PM_610_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_610_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_610_D.DATA_APV_USER is '审核人';
comment on column MBT_PM_610_D.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_610_D.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_610_D.RSV1 is '备用字段';
comment on column MBT_PM_610_D.RSV2 is '备用字段';
comment on column MBT_PM_610_D.RSV3 is '备用字段';
comment on column MBT_PM_610_D.RSV4 is '备用字段';
comment on column MBT_PM_610_D.RSV5 is '备用字段';
create table MBT_RPT_610 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_610 is '企业资产负债表信息';
comment on column MBT_RPT_610.DATA_ID is '数据ID';
comment on column MBT_RPT_610.DATA_DATE is '数据日期';
comment on column MBT_RPT_610.CORP_ID is '法人ID';
comment on column MBT_RPT_610.ORG_ID is '机构ID';
comment on column MBT_RPT_610.GROUP_ID is '数据分组';
comment on column MBT_RPT_610.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_610.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_610.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_610.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_610.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_610.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_610.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_610.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_610.B_ENT_NAME is '企业名称';
comment on column MBT_RPT_610.SECTION_CHG_CNT is '段变更';
comment on column MBT_RPT_610.SECTION_DEL_CNT is '段删除';
comment on column MBT_RPT_610.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_RPT_610.IDN_CHG_CNT is '标识项变更';
comment on column MBT_RPT_610.CUST_NO is '客户号';
comment on column MBT_RPT_610.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_610.PART_TYPE is '段标识';
comment on column MBT_RPT_610.PART_NAME is '段名称';
comment on column MBT_RPT_610.START_DATE is '起始日期';
comment on column MBT_RPT_610.END_DATE is '结束日期';
comment on column MBT_RPT_610.BATCH_NO is '批次号';
comment on column MBT_RPT_610.ROW_NUM is '行号';
comment on column MBT_RPT_610.IS_RPT is '是否报送';
comment on column MBT_RPT_610.IS_VALID is '是否有效';
comment on column MBT_RPT_610.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_610.OPT_FLAG is '操作标识';
comment on column MBT_RPT_610.RPT_DATE is '报送日期';
comment on column MBT_RPT_610.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_610.RPT_STATUS is '报送状态';
comment on column MBT_RPT_610.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_610.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_610.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_610.REMARKS is '备注';
comment on column MBT_RPT_610.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_610.CHECK_DESC is '校验说明';
comment on column MBT_RPT_610.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_610.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_610.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_610.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_610.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_610.DATA_FLAG is '数据标志';
comment on column MBT_RPT_610.DATA_OP is '操作标志';
comment on column MBT_RPT_610.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_610.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_610.DATA_HASH is '数据HASH';
comment on column MBT_RPT_610.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_610.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_610.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_610.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_610.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_610.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_610.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_610.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_610.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_610.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_610.DATA_APV_USER is '审核人';
comment on column MBT_RPT_610.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_610.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_610.RSV1 is '备用字段';
comment on column MBT_RPT_610.RSV2 is '备用字段';
comment on column MBT_RPT_610.RSV3 is '备用字段';
comment on column MBT_RPT_610.RSV4 is '备用字段';
comment on column MBT_RPT_610.RSV5 is '备用字段';
create table MBT_RPT_610_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_ENT_NAME VARCHAR(160),
B_AUDITOR_NAME VARCHAR(60),
B_AUDIT_FIRM_NAME VARCHAR(160),
B_AUDIT_TIME VARCHAR(8),
B_CIMOC VARCHAR(28),
B_INF_REC_TYPE VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_610_B is '企业资产负债表信息-基础段';
comment on column MBT_RPT_610_B.DATA_ID is '数据ID';
comment on column MBT_RPT_610_B.DATA_DATE is '数据日期';
comment on column MBT_RPT_610_B.CORP_ID is '法人ID';
comment on column MBT_RPT_610_B.ORG_ID is '机构ID';
comment on column MBT_RPT_610_B.GROUP_ID is '数据分组';
comment on column MBT_RPT_610_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_610_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_610_B.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_610_B.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_610_B.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_610_B.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_610_B.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_610_B.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_610_B.B_ENT_NAME is '企业名称';
comment on column MBT_RPT_610_B.B_AUDITOR_NAME is '审计人员名称';
comment on column MBT_RPT_610_B.B_AUDIT_FIRM_NAME is '审计事务所名称';
comment on column MBT_RPT_610_B.B_AUDIT_TIME is '审计时间';
comment on column MBT_RPT_610_B.B_CIMOC is '客户资料维护机构代码';
comment on column MBT_RPT_610_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_RPT_610_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_610_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_RPT_610_B.CUST_NO is '客户号';
comment on column MBT_RPT_610_B.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_610_B.PART_TYPE is '段标识';
comment on column MBT_RPT_610_B.PART_NAME is '段名称';
comment on column MBT_RPT_610_B.START_DATE is '起始日期';
comment on column MBT_RPT_610_B.END_DATE is '结束日期';
comment on column MBT_RPT_610_B.BATCH_NO is '批次号';
comment on column MBT_RPT_610_B.ROW_NUM is '行号';
comment on column MBT_RPT_610_B.IS_RPT is '是否报送';
comment on column MBT_RPT_610_B.IS_VALID is '是否有效';
comment on column MBT_RPT_610_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_610_B.OPT_FLAG is '操作标识';
comment on column MBT_RPT_610_B.RPT_DATE is '报送日期';
comment on column MBT_RPT_610_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_610_B.RPT_STATUS is '报送状态';
comment on column MBT_RPT_610_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_610_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_610_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_610_B.REMARKS is '备注';
comment on column MBT_RPT_610_B.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_610_B.CHECK_DESC is '校验说明';
comment on column MBT_RPT_610_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_610_B.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_610_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_610_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_610_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_610_B.DATA_FLAG is '数据标志';
comment on column MBT_RPT_610_B.DATA_OP is '操作标志';
comment on column MBT_RPT_610_B.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_610_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_610_B.DATA_HASH is '数据HASH';
comment on column MBT_RPT_610_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_610_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_610_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_610_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_610_B.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_610_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_610_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_610_B.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_610_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_610_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_610_B.DATA_APV_USER is '审核人';
comment on column MBT_RPT_610_B.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_610_B.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_610_B.RSV1 is '备用字段';
comment on column MBT_RPT_610_B.RSV2 is '备用字段';
comment on column MBT_RPT_610_B.RSV3 is '备用字段';
comment on column MBT_RPT_610_B.RSV4 is '备用字段';
comment on column MBT_RPT_610_B.RSV5 is '备用字段';
create table MBT_RPT_610_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ACCOUNTS_PAYABLE NUMBER(17),
C_ACCOUNTS_RECEIVABLE NUMBER(17),
C_ALLOWANCE_RECEIVABLE NUMBER(17),
C_AMONG_IT_SPE_APPR_RES_MAT NUMBER(17),
C_BONDS_PAYABLE NUMBER(17),
C_CAPITALR_RSERVE NUMBER(17),
C_COLLECTIVE_CAPITAL NUMBER(17),
C_COLLECTIVE_LP_CAPITAL NUMBER(17),
C_CONSTRUCTION_IN_PROGRESS NUMBER(17),
C_CONSTRUCTION_MATERIALS NUMBER(17),
C_CURRENCY_FUNDS NUMBER(17),
C_DEFERRED_ASSETS NUMBER(17),
C_DEFERRED_ASSETS_DEBITS NUMBER(17),
C_DEFERRED_EXPENSES NUMBER(17),
C_DEFERRED_TAXATION_CREDIT NUMBER(17),
C_DIVIDENDS_RECEIVABLE NUMBER(17),
C_DT_FC_FINANCIAL_STA NUMBER(17),
C_EMPLOYEE_BENEFITS NUMBER(17),
C_EXPORT_DRAWBACK_RECEIVABLE NUMBER(17),
C_FA_ACC_DEPRECIATION NUMBER(17),
C_FA_NET_VALUE NUMBER(17),
C_FA_PENDING_DISPOSAL NUMBER(17),
C_FINISHED_PRODUCTS NUMBER(17),
C_FOREIGN_BUS_CAPITAL NUMBER(17),
C_FUTURE_GUARANTEE NUMBER(17),
C_GRANTS_PAYABLE NUMBER(17),
C_IMPROVEMENT_EXPENDITURE_FA NUMBER(17),
C_INCLUDING_FA_REPAIR NUMBER(17),
C_INCOME_PAYABLE NUMBER(17),
C_INC_PRICE_DIFFERENCE NUMBER(17),
C_INTANGIBLE_ASSETS NUMBER(17),
C_INTEREST_RECEIVABLE NUMBER(17),
C_INVENTORIES NUMBER(17),
C_LAND_USE_RIGHTS NUMBER(17),
C_LEGAL_PERSONS_CAPITAL NUMBER(17),
C_LONG_TERM_PAYABLES NUMBER(17),
C_LT_BORROWINGS NUMBER(17),
C_LT_DI_FALLINGDUEINAYEAR NUMBER(17),
C_LT_EQUITYINVESTMENT NUMBER(17),
C_LT_INVESTMENT NUMBER(17),
C_LT_LIABILITIES_DUE_ONEYEAR NUMBER(17),
C_LT_SECURITIES_INVESTMENT NUMBER(17),
C_MINORITY_INTEREST NUMBER(17),
C_NATIONAL_CAPITAL NUMBER(17),
C_NET_VALUE_FA NUMBER(17),
C_NOTES_PAYABLE NUMBER(17),
C_NOTES_RECEIVABLE NUMBER(17),
C_ORIGINAL_COST_FA NUMBER(17),
C_OTHER_CURRENT_ASSETS NUMBER(17),
C_OTHER_CURRENT_LIABILITIES NUMBER(17),
C_OTHER_LONG_TERM_ASSETS NUMBER(17),
C_OTHER_LT_LIABILITIES NUMBER(17),
C_OTHER_PAYABLE NUMBER(17),
C_OTHER_PAYABLE_GOVERNMENT NUMBER(17),
C_OTHER_RECEIVABLES NUMBER(17),
C_PAID_IN_CAPITAL NUMBER(17),
C_PERSONAL_CAPITAL NUMBER(17),
C_PREPAYMENTS NUMBER(17),
C_PROVISIONS NUMBER(17),
C_PROVISION_FOR_EXPENSES NUMBER(17),
C_PROVISION_IMPAIRMENT_FA NUMBER(17),
C_PUBLIC_WELFARE_FUND NUMBER(17),
C_RAW_MATERIALS NUMBER(17),
C_RECEIPTS_IN_ADVANCE NUMBER(17),
C_SHORT_TERM_BORROWINGS NUMBER(17),
C_SHORT_TERM_INVESTMENTS NUMBER(17),
C_SPECIAL_RESERVE_FUND NUMBER(17),
C_STATE_OWNED_LP_CAPITAL NUMBER(17),
C_STATUTORY_SURPLUS_RESERVE NUMBER(17),
C_SUPPLER_CURRENT_CAPITAL NUMBER(17),
C_SURPLUS_RESERVE NUMBER(17),
C_TAXES_PAYABLE NUMBER(17),
C_TOTAL_ASSETS NUMBER(17),
C_TOTAL_CURRENT_ASSETS NUMBER(17),
C_TOTAL_CURRENT_LIABILITIES NUMBER(17),
C_TOTAL_EQUITY NUMBER(17),
C_TOTAL_EQUITY_LIABILITIES NUMBER(17),
C_TOTAL_FIXED_ASSETS NUMBER(17),
C_TOTAL_INTANGIBLE_OTHER_ASS NUMBER(17),
C_TOTAL_LIABILITIES NUMBER(17),
C_TOTAL_LT_INVESTMENT NUMBER(17),
C_TOTAL_LT_LIABILITIES NUMBER(17),
C_UNAFFIRMED_INVESTMENT_LOSS NUMBER(17),
C_UNAPPROPRIATED_PROFIT NUMBER(17),
C_UNSETTLED_GL_CURRENT_ASSETS NUMBER(17),
C_UNSETTLED_GL_ON_FA NUMBER(17),
C_WAGES_SALARIES_PAYABLES NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_610_C is '企业资产负债表信息-2002版资产负债表段';
comment on column MBT_RPT_610_C.DATA_ID is '数据ID';
comment on column MBT_RPT_610_C.DATA_DATE is '数据日期';
comment on column MBT_RPT_610_C.CORP_ID is '法人ID';
comment on column MBT_RPT_610_C.ORG_ID is '机构ID';
comment on column MBT_RPT_610_C.GROUP_ID is '数据分组';
comment on column MBT_RPT_610_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_610_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_610_C.C_ACCOUNTS_PAYABLE is '应付账款';
comment on column MBT_RPT_610_C.C_ACCOUNTS_RECEIVABLE is '应收账款';
comment on column MBT_RPT_610_C.C_ALLOWANCE_RECEIVABLE is '应收补贴款';
comment on column MBT_RPT_610_C.C_AMONG_IT_SPE_APPR_RES_MAT is '（其他长期资产科目下）特准储备物资';
comment on column MBT_RPT_610_C.C_BONDS_PAYABLE is '应付债券';
comment on column MBT_RPT_610_C.C_CAPITALR_RSERVE is '资本公积';
comment on column MBT_RPT_610_C.C_COLLECTIVE_CAPITAL is '集体资本';
comment on column MBT_RPT_610_C.C_COLLECTIVE_LP_CAPITAL is '（法人资本科目下）集体法人资本';
comment on column MBT_RPT_610_C.C_CONSTRUCTION_IN_PROGRESS is '在建工程';
comment on column MBT_RPT_610_C.C_CONSTRUCTION_MATERIALS is '工程物资';
comment on column MBT_RPT_610_C.C_CURRENCY_FUNDS is '货币资金';
comment on column MBT_RPT_610_C.C_DEFERRED_ASSETS is '递延资产';
comment on column MBT_RPT_610_C.C_DEFERRED_ASSETS_DEBITS is '递延税款借项';
comment on column MBT_RPT_610_C.C_DEFERRED_EXPENSES is '待摊费用';
comment on column MBT_RPT_610_C.C_DEFERRED_TAXATION_CREDIT is '递延税款贷项';
comment on column MBT_RPT_610_C.C_DIVIDENDS_RECEIVABLE is '应收股利';
comment on column MBT_RPT_610_C.C_DT_FC_FINANCIAL_STA is '外币报表折算差额';
comment on column MBT_RPT_610_C.C_EMPLOYEE_BENEFITS is '应付福利费';
comment on column MBT_RPT_610_C.C_EXPORT_DRAWBACK_RECEIVABLE is '应收出口退税';
comment on column MBT_RPT_610_C.C_FA_ACC_DEPRECIATION is '累计折旧';
comment on column MBT_RPT_610_C.C_FA_NET_VALUE is '固定资产净值';
comment on column MBT_RPT_610_C.C_FA_PENDING_DISPOSAL is '固定资产清理';
comment on column MBT_RPT_610_C.C_FINISHED_PRODUCTS is '存货产成品';
comment on column MBT_RPT_610_C.C_FOREIGN_BUS_CAPITAL is '外商资本';
comment on column MBT_RPT_610_C.C_FUTURE_GUARANTEE is '期货保证金';
comment on column MBT_RPT_610_C.C_GRANTS_PAYABLE is '专项应付款';
comment on column MBT_RPT_610_C.C_IMPROVEMENT_EXPENDITURE_FA is '（递延资产科目下）固定资产改良支出';
comment on column MBT_RPT_610_C.C_INCLUDING_FA_REPAIR is '（递延资产科目下）固定资产修理';
comment on column MBT_RPT_610_C.C_INCOME_PAYABLE is '应付利润';
comment on column MBT_RPT_610_C.C_INC_PRICE_DIFFERENCE is '合并价差';
comment on column MBT_RPT_610_C.C_INTANGIBLE_ASSETS is '无形资产';
comment on column MBT_RPT_610_C.C_INTEREST_RECEIVABLE is '应收利息';
comment on column MBT_RPT_610_C.C_INVENTORIES is '存货';
comment on column MBT_RPT_610_C.C_LAND_USE_RIGHTS is '（无形资产科目下）土地使用权';
comment on column MBT_RPT_610_C.C_LEGAL_PERSONS_CAPITAL is '法人资本';
comment on column MBT_RPT_610_C.C_LONG_TERM_PAYABLES is '长期应付款';
comment on column MBT_RPT_610_C.C_LT_BORROWINGS is '长期借款';
comment on column MBT_RPT_610_C.C_LT_DI_FALLINGDUEINAYEAR is '一年内到期的长期债权投资';
comment on column MBT_RPT_610_C.C_LT_EQUITYINVESTMENT is '长期股权投资';
comment on column MBT_RPT_610_C.C_LT_INVESTMENT is '长期投资';
comment on column MBT_RPT_610_C.C_LT_LIABILITIES_DUE_ONEYEAR is '一年内到期的长期负债';
comment on column MBT_RPT_610_C.C_LT_SECURITIES_INVESTMENT is '长期债权投资';
comment on column MBT_RPT_610_C.C_MINORITY_INTEREST is '少数股东权益';
comment on column MBT_RPT_610_C.C_NATIONAL_CAPITAL is '国家资本';
comment on column MBT_RPT_610_C.C_NET_VALUE_FA is '固定资产净额';
comment on column MBT_RPT_610_C.C_NOTES_PAYABLE is '应付票据';
comment on column MBT_RPT_610_C.C_NOTES_RECEIVABLE is '应收票据';
comment on column MBT_RPT_610_C.C_ORIGINAL_COST_FA is '固定资产原价';
comment on column MBT_RPT_610_C.C_OTHER_CURRENT_ASSETS is '其他流动资产';
comment on column MBT_RPT_610_C.C_OTHER_CURRENT_LIABILITIES is '其他流动负债';
comment on column MBT_RPT_610_C.C_OTHER_LONG_TERM_ASSETS is '其他长期资产';
comment on column MBT_RPT_610_C.C_OTHER_LT_LIABILITIES is '其他长期负债';
comment on column MBT_RPT_610_C.C_OTHER_PAYABLE is '其他应付款';
comment on column MBT_RPT_610_C.C_OTHER_PAYABLE_GOVERNMENT is '其他应交款';
comment on column MBT_RPT_610_C.C_OTHER_RECEIVABLES is '其他应收款';
comment on column MBT_RPT_610_C.C_PAID_IN_CAPITAL is '实收资本';
comment on column MBT_RPT_610_C.C_PERSONAL_CAPITAL is '个人资本';
comment on column MBT_RPT_610_C.C_PREPAYMENTS is '预付账款';
comment on column MBT_RPT_610_C.C_PROVISIONS is '预计负债';
comment on column MBT_RPT_610_C.C_PROVISION_FOR_EXPENSES is '预提费用';
comment on column MBT_RPT_610_C.C_PROVISION_IMPAIRMENT_FA is '固定资产值减值准备';
comment on column MBT_RPT_610_C.C_PUBLIC_WELFARE_FUND is '（盈余公积科目下）公益金';
comment on column MBT_RPT_610_C.C_RAW_MATERIALS is '存货原材料';
comment on column MBT_RPT_610_C.C_RECEIPTS_IN_ADVANCE is '预收账款';
comment on column MBT_RPT_610_C.C_SHORT_TERM_BORROWINGS is '短期借款';
comment on column MBT_RPT_610_C.C_SHORT_TERM_INVESTMENTS is '短期投资';
comment on column MBT_RPT_610_C.C_SPECIAL_RESERVE_FUND is '（其他长期负债科目下）特准储备基金';
comment on column MBT_RPT_610_C.C_STATE_OWNED_LP_CAPITAL is '（法人资本科目下）国有法人资本';
comment on column MBT_RPT_610_C.C_STATUTORY_SURPLUS_RESERVE is '（盈余公积科目下）法定盈余公积';
comment on column MBT_RPT_610_C.C_SUPPLER_CURRENT_CAPITAL is '（盈余公积科目下）补充流动资本';
comment on column MBT_RPT_610_C.C_SURPLUS_RESERVE is '盈余公积';
comment on column MBT_RPT_610_C.C_TAXES_PAYABLE is '应交税金';
comment on column MBT_RPT_610_C.C_TOTAL_ASSETS is '资产总计';
comment on column MBT_RPT_610_C.C_TOTAL_CURRENT_ASSETS is '流动资产合计';
comment on column MBT_RPT_610_C.C_TOTAL_CURRENT_LIABILITIES is '流动负债合计';
comment on column MBT_RPT_610_C.C_TOTAL_EQUITY is '所有者权益合计';
comment on column MBT_RPT_610_C.C_TOTAL_EQUITY_LIABILITIES is '负债和所有者权益总计';
comment on column MBT_RPT_610_C.C_TOTAL_FIXED_ASSETS is '固定资产合计';
comment on column MBT_RPT_610_C.C_TOTAL_INTANGIBLE_OTHER_ASS is '无形及其他资产合计';
comment on column MBT_RPT_610_C.C_TOTAL_LIABILITIES is '负债合计';
comment on column MBT_RPT_610_C.C_TOTAL_LT_INVESTMENT is '长期投资合计';
comment on column MBT_RPT_610_C.C_TOTAL_LT_LIABILITIES is '长期负债合计';
comment on column MBT_RPT_610_C.C_UNAFFIRMED_INVESTMENT_LOSS is '未确认的投资损失';
comment on column MBT_RPT_610_C.C_UNAPPROPRIATED_PROFIT is '未分配利润';
comment on column MBT_RPT_610_C.C_UNSETTLED_GL_CURRENT_ASSETS is '待处理流动资产净损失';
comment on column MBT_RPT_610_C.C_UNSETTLED_GL_ON_FA is '待处理固定资产净损失';
comment on column MBT_RPT_610_C.C_WAGES_SALARIES_PAYABLES is '应付工资';
comment on column MBT_RPT_610_C.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_610_C.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_610_C.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_610_C.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_610_C.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_610_C.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_610_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_610_C.CUST_NO is '客户号';
comment on column MBT_RPT_610_C.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_610_C.PART_TYPE is '段标识';
comment on column MBT_RPT_610_C.PART_NAME is '段名称';
comment on column MBT_RPT_610_C.START_DATE is '起始日期';
comment on column MBT_RPT_610_C.END_DATE is '结束日期';
comment on column MBT_RPT_610_C.BATCH_NO is '批次号';
comment on column MBT_RPT_610_C.ROW_NUM is '行号';
comment on column MBT_RPT_610_C.IS_RPT is '是否报送';
comment on column MBT_RPT_610_C.IS_VALID is '是否有效';
comment on column MBT_RPT_610_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_610_C.OPT_FLAG is '操作标识';
comment on column MBT_RPT_610_C.RPT_DATE is '报送日期';
comment on column MBT_RPT_610_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_610_C.RPT_STATUS is '报送状态';
comment on column MBT_RPT_610_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_610_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_610_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_610_C.REMARKS is '备注';
comment on column MBT_RPT_610_C.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_610_C.CHECK_DESC is '校验说明';
comment on column MBT_RPT_610_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_610_C.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_610_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_610_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_610_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_610_C.DATA_FLAG is '数据标志';
comment on column MBT_RPT_610_C.DATA_OP is '操作标志';
comment on column MBT_RPT_610_C.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_610_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_610_C.DATA_HASH is '数据HASH';
comment on column MBT_RPT_610_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_610_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_610_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_610_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_610_C.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_610_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_610_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_610_C.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_610_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_610_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_610_C.DATA_APV_USER is '审核人';
comment on column MBT_RPT_610_C.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_610_C.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_610_C.RSV1 is '备用字段';
comment on column MBT_RPT_610_C.RSV2 is '备用字段';
comment on column MBT_RPT_610_C.RSV3 is '备用字段';
comment on column MBT_RPT_610_C.RSV4 is '备用字段';
comment on column MBT_RPT_610_C.RSV5 is '备用字段';
create table MBT_RPT_610_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ACCOUNTS_PAYABLE NUMBER(17),
D_ACCOUNTS_RECEIVABLE NUMBER(17),
D_BONDS_PAYABLE NUMBER(17),
D_CAPITALR_RSERVE NUMBER(17),
D_CONSTRUCTION_IN_PROGRESS NUMBER(17),
D_CONSTRUCTION_MATERIALS NUMBER(17),
D_CURRENCY_FUNDS NUMBER(17),
D_CURRENT_PORTION_LIABILITIES NUMBER(17),
D_CURRENT_PORTION_NCA NUMBER(17),
D_DEFERRED_TAX_ASSETS NUMBER(17),
D_DEFERRED_TAX_LIABILITIES NUMBER(17),
D_DEVELOPMENT_DISBURSEMENTS NUMBER(17),
D_DIVIDENDS_PAYABLE NUMBER(17),
D_DIVIDENDS_RECEIVABLE NUMBER(17),
D_EMPLOYEE_BENEFITS_PAYABLE NUMBER(17),
D_FINANCIAL_ASS_AVAILABLE_SALE NUMBER(17),
D_FINANCIAL_ASS_HELD_TRADING NUMBER(17),
D_FINANCIAL_LIABILITIES_HFT NUMBER(17),
D_FIXED_ASSETS NUMBER(17),
D_FIXED_ASS_PENDING_DISPOSAL NUMBER(17),
D_GOODWILL NUMBER(17),
D_GRANTS_PAYABLE NUMBER(17),
D_HELD_MATURITY_INVESTMENTS NUMBER(17),
D_INTANGIBLE_ASSETS NUMBER(17),
D_INTEREST_PAYABLE NUMBER(17),
D_INTEREST_RECEIVABLE NUMBER(17),
D_INVENTORIES NUMBER(17),
D_INVESTMENT_PROPERTIES NUMBER(17),
D_LAND_USE_RIGHTS NUMBER(17),
D_LESS_TREASURY_STOCKS NUMBER(17),
D_LONG_TERM_BORROWINGSORROWING NUMBER(17),
D_LONG_TERM_DEFERRED_EXPENSES NUMBER(17),
D_LONG_TERM_EQUITY_INVESTMENT NUMBER(17),
D_LONG_TERM_PAYABLES NUMBER(17),
D_LONG_TERM_RECEIVABLES NUMBER(17),
D_NET_VALUE_OF_FIXE_ASSETS NUMBER(17),
D_NON_CURRENT_BIOLOGICAL_ASS NUMBER(17),
D_NOTES_PAYABLE NUMBER(17),
D_NOTES_RECEIVABLE NUMBER(17),
D_OIL_AND_GAS_ASSETS NUMBER(17),
D_OTHER_CURRENT_ASSETS NUMBER(17),
D_OTHER_CURRENT_LIABILITIES NUMBER(17),
D_OTHER_NON_CURRENT_ASSETS NUMBER(17),
D_OTHER_NON_CURRENT_LIABILITIE NUMBER(17),
D_OTHER_PAYABLE NUMBER(17),
D_OTHER_RECEIVABLES NUMBER(17),
D_PAID_IN_CAPITAL_SHARE_CAPITA NUMBER(17),
D_PREPAYMENTS NUMBER(17),
D_PROVISIONS NUMBER(17),
D_RECEIPTS_IN_ADVANCE NUMBER(17),
D_SHORT_TERM_BORROWINGS NUMBER(17),
D_SURPLUS_RESERVE NUMBER(17),
D_TAXES_PAYABLE NUMBER(17),
D_TOTAL_ASSETS NUMBER(17),
D_TOTAL_CURRENT_ASSETS NUMBER(17),
D_TOTAL_CURRENT_LIABILITIES NUMBER(17),
D_TOTAL_EQUITY NUMBER(17),
D_TOTAL_EQUITY_LIABILITIES NUMBER(17),
D_TOTAL_LIABILITIES NUMBER(17),
D_TOTAL_NON_CURRENT_ASSETS NUMBER(17),
D_TOTAL_NON_CURRENT_LIABILITIE NUMBER(17),
D_UNAPPROPRIATED_PROFIT NUMBER(17),
B_ENT_CERT_NUM VARCHAR(40),
B_ENT_CERT_TYPE VARCHAR(2),
B_SHEET_TYPE VARCHAR(2),
B_SHEET_TYPE_DIVIDE VARCHAR(2),
B_SHEET_YEAR VARCHAR(4),
B_INF_SURC_CODE VARCHAR(20),
B_RPT_DATE VARCHAR(8),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_610_D is '企业资产负债表信息-2007版资产负债表段';
comment on column MBT_RPT_610_D.DATA_ID is '数据ID';
comment on column MBT_RPT_610_D.DATA_DATE is '数据日期';
comment on column MBT_RPT_610_D.CORP_ID is '法人ID';
comment on column MBT_RPT_610_D.ORG_ID is '机构ID';
comment on column MBT_RPT_610_D.GROUP_ID is '数据分组';
comment on column MBT_RPT_610_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_610_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_610_D.D_ACCOUNTS_PAYABLE is '应付账款';
comment on column MBT_RPT_610_D.D_ACCOUNTS_RECEIVABLE is '应收账款';
comment on column MBT_RPT_610_D.D_BONDS_PAYABLE is '应付债券';
comment on column MBT_RPT_610_D.D_CAPITALR_RSERVE is '资本公积';
comment on column MBT_RPT_610_D.D_CONSTRUCTION_IN_PROGRESS is '在建工程';
comment on column MBT_RPT_610_D.D_CONSTRUCTION_MATERIALS is '工程物资';
comment on column MBT_RPT_610_D.D_CURRENCY_FUNDS is '货币资金';
comment on column MBT_RPT_610_D.D_CURRENT_PORTION_LIABILITIES is '一年内到期的非流动负债';
comment on column MBT_RPT_610_D.D_CURRENT_PORTION_NCA is '一年内到期的非流动资产';
comment on column MBT_RPT_610_D.D_DEFERRED_TAX_ASSETS is '递延所得税资产';
comment on column MBT_RPT_610_D.D_DEFERRED_TAX_LIABILITIES is '递延所得税负债';
comment on column MBT_RPT_610_D.D_DEVELOPMENT_DISBURSEMENTS is '开发支出';
comment on column MBT_RPT_610_D.D_DIVIDENDS_PAYABLE is '应付股利';
comment on column MBT_RPT_610_D.D_DIVIDENDS_RECEIVABLE is '应收股利';
comment on column MBT_RPT_610_D.D_EMPLOYEE_BENEFITS_PAYABLE is '应付职工薪酬';
comment on column MBT_RPT_610_D.D_FINANCIAL_ASS_AVAILABLE_SALE is '可供出售的金融资产';
comment on column MBT_RPT_610_D.D_FINANCIAL_ASS_HELD_TRADING is '交易性金融资产';
comment on column MBT_RPT_610_D.D_FINANCIAL_LIABILITIES_HFT is '交易性金融负债';
comment on column MBT_RPT_610_D.D_FIXED_ASSETS is '固定资产';
comment on column MBT_RPT_610_D.D_FIXED_ASS_PENDING_DISPOSAL is '固定资产清理';
comment on column MBT_RPT_610_D.D_GOODWILL is '商誉';
comment on column MBT_RPT_610_D.D_GRANTS_PAYABLE is '专项应付款';
comment on column MBT_RPT_610_D.D_HELD_MATURITY_INVESTMENTS is '持有至到期投资';
comment on column MBT_RPT_610_D.D_INTANGIBLE_ASSETS is '无形资产';
comment on column MBT_RPT_610_D.D_INTEREST_PAYABLE is '应付利息';
comment on column MBT_RPT_610_D.D_INTEREST_RECEIVABLE is '应收利息';
comment on column MBT_RPT_610_D.D_INVENTORIES is '存货';
comment on column MBT_RPT_610_D.D_INVESTMENT_PROPERTIES is '投资性房地产';
comment on column MBT_RPT_610_D.D_LAND_USE_RIGHTS is '（无形资产科目下）土地使用权';
comment on column MBT_RPT_610_D.D_LESS_TREASURY_STOCKS is '减：库存股';
comment on column MBT_RPT_610_D.D_LONG_TERM_BORROWINGSORROWING is '长期借款';
comment on column MBT_RPT_610_D.D_LONG_TERM_DEFERRED_EXPENSES is '长期待摊费用';
comment on column MBT_RPT_610_D.D_LONG_TERM_EQUITY_INVESTMENT is '长期股权投资';
comment on column MBT_RPT_610_D.D_LONG_TERM_PAYABLES is '长期应付款';
comment on column MBT_RPT_610_D.D_LONG_TERM_RECEIVABLES is '长期应收款';
comment on column MBT_RPT_610_D.D_NET_VALUE_OF_FIXE_ASSETS is '固定资产净额';
comment on column MBT_RPT_610_D.D_NON_CURRENT_BIOLOGICAL_ASS is '生产性生物资产';
comment on column MBT_RPT_610_D.D_NOTES_PAYABLE is '应付票据';
comment on column MBT_RPT_610_D.D_NOTES_RECEIVABLE is '应收票据';
comment on column MBT_RPT_610_D.D_OIL_AND_GAS_ASSETS is '油气资产';
comment on column MBT_RPT_610_D.D_OTHER_CURRENT_ASSETS is '其他流动资产';
comment on column MBT_RPT_610_D.D_OTHER_CURRENT_LIABILITIES is '其他流动负债';
comment on column MBT_RPT_610_D.D_OTHER_NON_CURRENT_ASSETS is '其他非流动资产';
comment on column MBT_RPT_610_D.D_OTHER_NON_CURRENT_LIABILITIE is '其他非流动负债';
comment on column MBT_RPT_610_D.D_OTHER_PAYABLE is '其他应付款';
comment on column MBT_RPT_610_D.D_OTHER_RECEIVABLES is '其他应收款';
comment on column MBT_RPT_610_D.D_PAID_IN_CAPITAL_SHARE_CAPITA is '实收资本（或股本）';
comment on column MBT_RPT_610_D.D_PREPAYMENTS is '预付账款';
comment on column MBT_RPT_610_D.D_PROVISIONS is '预计负债';
comment on column MBT_RPT_610_D.D_RECEIPTS_IN_ADVANCE is '预收账款';
comment on column MBT_RPT_610_D.D_SHORT_TERM_BORROWINGS is '短期借款';
comment on column MBT_RPT_610_D.D_SURPLUS_RESERVE is '盈余公积';
comment on column MBT_RPT_610_D.D_TAXES_PAYABLE is '应交税费';
comment on column MBT_RPT_610_D.D_TOTAL_ASSETS is '资产总计';
comment on column MBT_RPT_610_D.D_TOTAL_CURRENT_ASSETS is '流动资产合计';
comment on column MBT_RPT_610_D.D_TOTAL_CURRENT_LIABILITIES is '流动负债合计';
comment on column MBT_RPT_610_D.D_TOTAL_EQUITY is '所有者权益合计';
comment on column MBT_RPT_610_D.D_TOTAL_EQUITY_LIABILITIES is '负债和所有者权益合计';
comment on column MBT_RPT_610_D.D_TOTAL_LIABILITIES is '负债合计';
comment on column MBT_RPT_610_D.D_TOTAL_NON_CURRENT_ASSETS is '非流动资产合计';
comment on column MBT_RPT_610_D.D_TOTAL_NON_CURRENT_LIABILITIE is '非流动负债合计';
comment on column MBT_RPT_610_D.D_UNAPPROPRIATED_PROFIT is '未分配利润';
comment on column MBT_RPT_610_D.B_ENT_CERT_NUM is '企业身份标识号码';
comment on column MBT_RPT_610_D.B_ENT_CERT_TYPE is '企业身份标识类型';
comment on column MBT_RPT_610_D.B_SHEET_TYPE is '报表类型';
comment on column MBT_RPT_610_D.B_SHEET_TYPE_DIVIDE is '报表类型细分';
comment on column MBT_RPT_610_D.B_SHEET_YEAR is '报表年份';
comment on column MBT_RPT_610_D.B_INF_SURC_CODE is '信息来源编码';
comment on column MBT_RPT_610_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_610_D.CUST_NO is '客户号';
comment on column MBT_RPT_610_D.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_610_D.PART_TYPE is '段标识';
comment on column MBT_RPT_610_D.PART_NAME is '段名称';
comment on column MBT_RPT_610_D.START_DATE is '起始日期';
comment on column MBT_RPT_610_D.END_DATE is '结束日期';
comment on column MBT_RPT_610_D.BATCH_NO is '批次号';
comment on column MBT_RPT_610_D.ROW_NUM is '行号';
comment on column MBT_RPT_610_D.IS_RPT is '是否报送';
comment on column MBT_RPT_610_D.IS_VALID is '是否有效';
comment on column MBT_RPT_610_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_610_D.OPT_FLAG is '操作标识';
comment on column MBT_RPT_610_D.RPT_DATE is '报送日期';
comment on column MBT_RPT_610_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_610_D.RPT_STATUS is '报送状态';
comment on column MBT_RPT_610_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_610_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_610_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_610_D.REMARKS is '备注';
comment on column MBT_RPT_610_D.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_610_D.CHECK_DESC is '校验说明';
comment on column MBT_RPT_610_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_610_D.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_610_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_610_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_610_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_610_D.DATA_FLAG is '数据标志';
comment on column MBT_RPT_610_D.DATA_OP is '操作标志';
comment on column MBT_RPT_610_D.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_610_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_610_D.DATA_HASH is '数据HASH';
comment on column MBT_RPT_610_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_610_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_610_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_610_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_610_D.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_610_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_610_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_610_D.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_610_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_610_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_610_D.DATA_APV_USER is '审核人';
comment on column MBT_RPT_610_D.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_610_D.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_610_D.RSV1 is '备用字段';
comment on column MBT_RPT_610_D.RSV2 is '备用字段';
comment on column MBT_RPT_610_D.RSV3 is '备用字段';
comment on column MBT_RPT_610_D.RSV4 is '备用字段';
comment on column MBT_RPT_610_D.RSV5 is '备用字段';
