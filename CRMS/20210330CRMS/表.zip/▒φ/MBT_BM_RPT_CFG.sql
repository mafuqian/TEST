-- Create table
create table MBT_BM_RPT_CFG
(
  data_id        VARCHAR2(64) not null,
  data_date      VARCHAR2(8),
  corp_id        VARCHAR2(14),
  org_id         VARCHAR2(14),
  group_id       VARCHAR2(14),
  module_id      VARCHAR2(32),
  report_code    VARCHAR2(80),
  report_name    VARCHAR2(200),
  table_name     VARCHAR2(80),
  collect_mode   VARCHAR2(2),
  report_period  VARCHAR2(2),
  report_offset  VARCHAR2(20),
  file_type      VARCHAR2(20),
  report_type    VARCHAR2(200),
  separator_char VARCHAR2(20),
  query_funcid   VARCHAR2(20),
  revise_funcid  VARCHAR2(20),
  file_funcid    VARCHAR2(20),
  divide_column  VARCHAR2(30),
  divide_rule    VARCHAR2(2),
  repleace_rule  VARCHAR2(4000),
  report_status  VARCHAR2(2),
  hand_out_task  VARCHAR2(2),
  provid_file    VARCHAR2(2),
  cfg_enable     VARCHAR2(1),
  remarks        VARCHAR2(512),
  check_flag     VARCHAR2(1),
  check_desc     VARCHAR2(4000),
  check_err_type VARCHAR2(1),
  next_action    VARCHAR2(2),
  data_status    VARCHAR2(2),
  data_flag      VARCHAR2(1),
  data_source    VARCHAR2(1),
  data_version   NUMBER(8),
  data_rej_desc  VARCHAR2(128),
  data_del_desc  VARCHAR2(128),
  data_rpt_date  VARCHAR2(8),
  data_crt_user  VARCHAR2(20),
  data_crt_date  VARCHAR2(8),
  data_crt_time  VARCHAR2(14),
  data_chg_user  VARCHAR2(20),
  data_chg_date  VARCHAR2(8),
  data_chg_time  VARCHAR2(14),
  data_apv_user  VARCHAR2(20),
  data_apv_date  VARCHAR2(8),
  data_apv_time  VARCHAR2(14),
  rsv1           VARCHAR2(180),
  rsv2           VARCHAR2(180),
  rsv3           VARCHAR2(180),
  rsv4           VARCHAR2(180),
  rsv5           VARCHAR2(180),
  c_rsv1         VARCHAR2(180),
  c_rsv2         VARCHAR2(180),
  c_rsv3         VARCHAR2(180),
  c_rsv4         VARCHAR2(180),
  c_rsv5         VARCHAR2(180)
);
-- Add comments to the table 
comment on table MBT_BM_RPT_CFG
  is '报表配置信息表';
-- Add comments to the columns 
comment on column MBT_BM_RPT_CFG.data_id
  is '数据ID';
comment on column MBT_BM_RPT_CFG.data_date
  is '数据日期';
comment on column MBT_BM_RPT_CFG.corp_id
  is '法人机构号';
comment on column MBT_BM_RPT_CFG.org_id
  is '分行机构号';
comment on column MBT_BM_RPT_CFG.group_id
  is '部门编号';
comment on column MBT_BM_RPT_CFG.module_id
  is '模块ID';
comment on column MBT_BM_RPT_CFG.report_code
  is '报表编码';
comment on column MBT_BM_RPT_CFG.report_name
  is '报表名称';
comment on column MBT_BM_RPT_CFG.table_name
  is '数据库表名';
comment on column MBT_BM_RPT_CFG.collect_mode
  is '采集模式';
comment on column MBT_BM_RPT_CFG.report_period
  is '报表频率';
comment on column MBT_BM_RPT_CFG.report_offset
  is '报送偏差';
comment on column MBT_BM_RPT_CFG.file_type
  is '生成文件类型';
comment on column MBT_BM_RPT_CFG.report_type
  is '报表类别';
comment on column MBT_BM_RPT_CFG.separator_char
  is '字段分隔符';
comment on column MBT_BM_RPT_CFG.query_funcid
  is '查询页面ID';
comment on column MBT_BM_RPT_CFG.revise_funcid
  is '补录页面ID';
comment on column MBT_BM_RPT_CFG.file_funcid
  is 'FILE查询页面ID';
comment on column MBT_BM_RPT_CFG.divide_column
  is '拆分字段';
comment on column MBT_BM_RPT_CFG.divide_rule
  is '拆分规则';
comment on column MBT_BM_RPT_CFG.repleace_rule
  is '替换规则';
comment on column MBT_BM_RPT_CFG.report_status
  is '报表状态';
comment on column MBT_BM_RPT_CFG.hand_out_task
  is '是否下发任务';
comment on column MBT_BM_RPT_CFG.provid_file
  is '是否生成文件';
comment on column MBT_BM_RPT_CFG.cfg_enable
  is '是否生效';
comment on column MBT_BM_RPT_CFG.remarks
  is '备注';
comment on column MBT_BM_RPT_CFG.check_flag
  is '校验标识';
comment on column MBT_BM_RPT_CFG.check_desc
  is '校验结果';
comment on column MBT_BM_RPT_CFG.check_err_type
  is '校验失败类型';
comment on column MBT_BM_RPT_CFG.next_action
  is '下一动作';
comment on column MBT_BM_RPT_CFG.data_status
  is '数据状态';
comment on column MBT_BM_RPT_CFG.data_flag
  is '数据是否已删除';
comment on column MBT_BM_RPT_CFG.data_source
  is '数据来源';
comment on column MBT_BM_RPT_CFG.data_version
  is '数据版本号';
comment on column MBT_BM_RPT_CFG.data_rej_desc
  is '数据审核拒绝描述';
comment on column MBT_BM_RPT_CFG.data_del_desc
  is '数据删除描述';
comment on column MBT_BM_RPT_CFG.data_rpt_date
  is '报表日期';
comment on column MBT_BM_RPT_CFG.data_crt_user
  is '数据创建/导入用户';
comment on column MBT_BM_RPT_CFG.data_crt_date
  is '数据创建/导入日期';
comment on column MBT_BM_RPT_CFG.data_crt_time
  is '数据创建/导入时间';
comment on column MBT_BM_RPT_CFG.data_chg_user
  is '数据修改/删除用户';
comment on column MBT_BM_RPT_CFG.data_chg_date
  is '数据修改/删除日期';
comment on column MBT_BM_RPT_CFG.data_chg_time
  is '数据修改/删除时间';
comment on column MBT_BM_RPT_CFG.data_apv_user
  is '数据审核/拒绝用户';
comment on column MBT_BM_RPT_CFG.data_apv_date
  is '数据审核/拒绝日期';
comment on column MBT_BM_RPT_CFG.data_apv_time
  is '数据审核/拒绝时间';
-- Create/Recreate primary, unique and foreign key constraints 
alter table MBT_BM_RPT_CFG
  add constraint MBT_BM_RPT_CFG_K primary key (DATA_ID);
