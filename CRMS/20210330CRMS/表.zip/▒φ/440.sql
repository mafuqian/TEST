create table MBT_DM_440 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
O_BIZ_CODE VARCHAR(60),
N_BIZ_CODE VARCHAR(60),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_440 is '企业担保账户信息';
comment on column MBT_DM_440.DATA_ID is '数据ID';
comment on column MBT_DM_440.DATA_DATE is '数据日期';
comment on column MBT_DM_440.CORP_ID is '法人ID';
comment on column MBT_DM_440.ORG_ID is '机构ID';
comment on column MBT_DM_440.GROUP_ID is '数据分组';
comment on column MBT_DM_440.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_440.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_440.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_440.O_BIZ_CODE is '原业务标识码';
comment on column MBT_DM_440.N_BIZ_CODE is '新业务标识码';
comment on column MBT_DM_440.SECTION_CHG_CNT is '段变更';
comment on column MBT_DM_440.SECTION_DEL_CNT is '段删除';
comment on column MBT_DM_440.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_DM_440.IDN_CHG_CNT is '标识项变更';
comment on column MBT_DM_440.CUST_NO is '客户号';
comment on column MBT_DM_440.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_440.PART_TYPE is '段标识';
comment on column MBT_DM_440.PART_NAME is '段名称';
comment on column MBT_DM_440.START_DATE is '起始日期';
comment on column MBT_DM_440.END_DATE is '结束日期';
comment on column MBT_DM_440.BATCH_NO is '批次号';
comment on column MBT_DM_440.ROW_NUM is '行号';
comment on column MBT_DM_440.IS_RPT is '是否报送';
comment on column MBT_DM_440.IS_VALID is '是否有效';
comment on column MBT_DM_440.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_440.OPT_FLAG is '操作标识';
comment on column MBT_DM_440.RPT_DATE is '报送日期';
comment on column MBT_DM_440.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_440.RPT_STATUS is '报送状态';
comment on column MBT_DM_440.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_440.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_440.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_440.REMARKS is '备注';
comment on column MBT_DM_440.CHECK_FLAG is '校验标志';
comment on column MBT_DM_440.CHECK_DESC is '校验说明';
comment on column MBT_DM_440.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_440.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_440.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_440.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_440.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_440.DATA_FLAG is '数据标志';
comment on column MBT_DM_440.DATA_OP is '操作标志';
comment on column MBT_DM_440.DATA_SOURCE is '数据来源';
comment on column MBT_DM_440.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_440.DATA_HASH is '数据HASH';
comment on column MBT_DM_440.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_440.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_440.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_440.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_440.DATA_CRT_USER is '创建人';
comment on column MBT_DM_440.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_440.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_440.DATA_CHG_USER is '修改人';
comment on column MBT_DM_440.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_440.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_440.DATA_APV_USER is '审核人';
comment on column MBT_DM_440.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_440.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_440.RSV1 is '备用字段';
comment on column MBT_DM_440.RSV2 is '备用字段';
comment on column MBT_DM_440.RSV3 is '备用字段';
comment on column MBT_DM_440.RSV4 is '备用字段';
comment on column MBT_DM_440.RSV5 is '备用字段';
create table MBT_DM_440_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
B_ACCT_TYPE VARCHAR(2),
B_CUST_NO VARCHAR(32),
B_ID_NUM VARCHAR(80),
B_ID_TYPE VARCHAR(2),
B_INFO_UP_DATE VARCHAR(8),
B_INF_REC_TYPE VARCHAR(3),
B_MNGMT_ORG_CODE VARCHAR(14),
B_NAME VARCHAR(160),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_440_B is '企业担保账户信息-基础段';
comment on column MBT_DM_440_B.DATA_ID is '数据ID';
comment on column MBT_DM_440_B.DATA_DATE is '数据日期';
comment on column MBT_DM_440_B.CORP_ID is '法人ID';
comment on column MBT_DM_440_B.ORG_ID is '机构ID';
comment on column MBT_DM_440_B.GROUP_ID is '数据分组';
comment on column MBT_DM_440_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_440_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_440_B.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_440_B.B_ACCT_TYPE is '账户类型';
comment on column MBT_DM_440_B.B_CUST_NO is '客户号';
comment on column MBT_DM_440_B.B_ID_NUM is '债务人身份标识号码';
comment on column MBT_DM_440_B.B_ID_TYPE is '债务人身份标识类型';
comment on column MBT_DM_440_B.B_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_440_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_DM_440_B.B_MNGMT_ORG_CODE is '业务管理机构代码';
comment on column MBT_DM_440_B.B_NAME is '债务人名称';
comment on column MBT_DM_440_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_440_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_DM_440_B.CUST_NO is '客户号';
comment on column MBT_DM_440_B.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_440_B.PART_TYPE is '段标识';
comment on column MBT_DM_440_B.PART_NAME is '段名称';
comment on column MBT_DM_440_B.START_DATE is '起始日期';
comment on column MBT_DM_440_B.END_DATE is '结束日期';
comment on column MBT_DM_440_B.BATCH_NO is '批次号';
comment on column MBT_DM_440_B.ROW_NUM is '行号';
comment on column MBT_DM_440_B.IS_RPT is '是否报送';
comment on column MBT_DM_440_B.IS_VALID is '是否有效';
comment on column MBT_DM_440_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_440_B.OPT_FLAG is '操作标识';
comment on column MBT_DM_440_B.RPT_DATE is '报送日期';
comment on column MBT_DM_440_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_440_B.RPT_STATUS is '报送状态';
comment on column MBT_DM_440_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_440_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_440_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_440_B.REMARKS is '备注';
comment on column MBT_DM_440_B.CHECK_FLAG is '校验标志';
comment on column MBT_DM_440_B.CHECK_DESC is '校验说明';
comment on column MBT_DM_440_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_440_B.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_440_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_440_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_440_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_440_B.DATA_FLAG is '数据标志';
comment on column MBT_DM_440_B.DATA_OP is '操作标志';
comment on column MBT_DM_440_B.DATA_SOURCE is '数据来源';
comment on column MBT_DM_440_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_440_B.DATA_HASH is '数据HASH';
comment on column MBT_DM_440_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_440_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_440_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_440_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_440_B.DATA_CRT_USER is '创建人';
comment on column MBT_DM_440_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_440_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_440_B.DATA_CHG_USER is '修改人';
comment on column MBT_DM_440_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_440_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_440_B.DATA_APV_USER is '审核人';
comment on column MBT_DM_440_B.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_440_B.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_440_B.RSV1 is '备用字段';
comment on column MBT_DM_440_B.RSV2 is '备用字段';
comment on column MBT_DM_440_B.RSV3 is '备用字段';
comment on column MBT_DM_440_B.RSV4 is '备用字段';
comment on column MBT_DM_440_B.RSV5 is '备用字段';
create table MBT_DM_440_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_BUSI_DTIL_LINES VARCHAR(2),
C_BUSI_LINES VARCHAR(1),
C_CTRCT_TXT_CODE VARCHAR(120),
C_CY VARCHAR(3),
C_DUE_DATE VARCHAR(8),
C_GUAR_AMT NUMBER(15),
C_GUAR_AMT_LCY NUMBER(15),
C_GUAR_MODE VARCHAR(1),
C_OPEN_DATE VARCHAR(8),
C_OTH_REPY_GUAR_WAY VARCHAR(1),
C_SEC_DEP NUMBER(10),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_440_C is '企业担保账户信息-基本信息段';
comment on column MBT_DM_440_C.DATA_ID is '数据ID';
comment on column MBT_DM_440_C.DATA_DATE is '数据日期';
comment on column MBT_DM_440_C.CORP_ID is '法人ID';
comment on column MBT_DM_440_C.ORG_ID is '机构ID';
comment on column MBT_DM_440_C.GROUP_ID is '数据分组';
comment on column MBT_DM_440_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_440_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_440_C.C_BUSI_DTIL_LINES is '担保业务种类细分';
comment on column MBT_DM_440_C.C_BUSI_LINES is '担保业务大类';
comment on column MBT_DM_440_C.C_CTRCT_TXT_CODE is '担保合同文本编号';
comment on column MBT_DM_440_C.C_CY is '币种';
comment on column MBT_DM_440_C.C_DUE_DATE is '到期日期';
comment on column MBT_DM_440_C.C_GUAR_AMT is '担保金额';
comment on column MBT_DM_440_C.C_GUAR_AMT_LCY is '担保金额人民币金额';
comment on column MBT_DM_440_C.C_GUAR_MODE is '反担保方式';
comment on column MBT_DM_440_C.C_OPEN_DATE is '开户日期';
comment on column MBT_DM_440_C.C_OTH_REPY_GUAR_WAY is '其他还款保证方式';
comment on column MBT_DM_440_C.C_SEC_DEP is '保证金百分比';
comment on column MBT_DM_440_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_440_C.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_440_C.CUST_NO is '客户号';
comment on column MBT_DM_440_C.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_440_C.PART_TYPE is '段标识';
comment on column MBT_DM_440_C.PART_NAME is '段名称';
comment on column MBT_DM_440_C.START_DATE is '起始日期';
comment on column MBT_DM_440_C.END_DATE is '结束日期';
comment on column MBT_DM_440_C.BATCH_NO is '批次号';
comment on column MBT_DM_440_C.ROW_NUM is '行号';
comment on column MBT_DM_440_C.IS_RPT is '是否报送';
comment on column MBT_DM_440_C.IS_VALID is '是否有效';
comment on column MBT_DM_440_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_440_C.OPT_FLAG is '操作标识';
comment on column MBT_DM_440_C.RPT_DATE is '报送日期';
comment on column MBT_DM_440_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_440_C.RPT_STATUS is '报送状态';
comment on column MBT_DM_440_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_440_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_440_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_440_C.REMARKS is '备注';
comment on column MBT_DM_440_C.CHECK_FLAG is '校验标志';
comment on column MBT_DM_440_C.CHECK_DESC is '校验说明';
comment on column MBT_DM_440_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_440_C.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_440_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_440_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_440_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_440_C.DATA_FLAG is '数据标志';
comment on column MBT_DM_440_C.DATA_OP is '操作标志';
comment on column MBT_DM_440_C.DATA_SOURCE is '数据来源';
comment on column MBT_DM_440_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_440_C.DATA_HASH is '数据HASH';
comment on column MBT_DM_440_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_440_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_440_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_440_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_440_C.DATA_CRT_USER is '创建人';
comment on column MBT_DM_440_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_440_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_440_C.DATA_CHG_USER is '修改人';
comment on column MBT_DM_440_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_440_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_440_C.DATA_APV_USER is '审核人';
comment on column MBT_DM_440_C.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_440_C.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_440_C.RSV1 is '备用字段';
comment on column MBT_DM_440_C.RSV2 is '备用字段';
comment on column MBT_DM_440_C.RSV3 is '备用字段';
comment on column MBT_DM_440_C.RSV4 is '备用字段';
comment on column MBT_DM_440_C.RSV5 is '备用字段';
create table MBT_DM_440_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ACCT_STATUS VARCHAR(1),
D_CLOSE_DATE VARCHAR(8),
D_COMP_ADV_FLAG VARCHAR(1),
D_FIVE_CATE VARCHAR(1),
D_FIVE_CATE_ADJ_DATE VARCHAR(8),
D_LOAN_AMT NUMBER(15),
D_LOAN_AMT_LCY NUMBER(15),
D_REPAY_PRD VARCHAR(8),
D_RI_EX NUMBER(19),
D_RI_EX_LCY NUMBER(19),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_440_D is '企业担保账户信息-在保责任信息段';
comment on column MBT_DM_440_D.DATA_ID is '数据ID';
comment on column MBT_DM_440_D.DATA_DATE is '数据日期';
comment on column MBT_DM_440_D.CORP_ID is '法人ID';
comment on column MBT_DM_440_D.ORG_ID is '机构ID';
comment on column MBT_DM_440_D.GROUP_ID is '数据分组';
comment on column MBT_DM_440_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_440_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_440_D.D_ACCT_STATUS is '账户状态';
comment on column MBT_DM_440_D.D_CLOSE_DATE is '账户关闭日期';
comment on column MBT_DM_440_D.D_COMP_ADV_FLAG is '代偿（垫款）标识';
comment on column MBT_DM_440_D.D_FIVE_CATE is '五级分类';
comment on column MBT_DM_440_D.D_FIVE_CATE_ADJ_DATE is '五级分类认定日期';
comment on column MBT_DM_440_D.D_LOAN_AMT is '在保余额';
comment on column MBT_DM_440_D.D_LOAN_AMT_LCY is '在保余额人民币金额';
comment on column MBT_DM_440_D.D_REPAY_PRD is '余额变化日期';
comment on column MBT_DM_440_D.D_RI_EX is '风险敞口';
comment on column MBT_DM_440_D.D_RI_EX_LCY is '风险敞口人民币金额';
comment on column MBT_DM_440_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_440_D.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_440_D.CUST_NO is '客户号';
comment on column MBT_DM_440_D.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_440_D.PART_TYPE is '段标识';
comment on column MBT_DM_440_D.PART_NAME is '段名称';
comment on column MBT_DM_440_D.START_DATE is '起始日期';
comment on column MBT_DM_440_D.END_DATE is '结束日期';
comment on column MBT_DM_440_D.BATCH_NO is '批次号';
comment on column MBT_DM_440_D.ROW_NUM is '行号';
comment on column MBT_DM_440_D.IS_RPT is '是否报送';
comment on column MBT_DM_440_D.IS_VALID is '是否有效';
comment on column MBT_DM_440_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_440_D.OPT_FLAG is '操作标识';
comment on column MBT_DM_440_D.RPT_DATE is '报送日期';
comment on column MBT_DM_440_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_440_D.RPT_STATUS is '报送状态';
comment on column MBT_DM_440_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_440_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_440_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_440_D.REMARKS is '备注';
comment on column MBT_DM_440_D.CHECK_FLAG is '校验标志';
comment on column MBT_DM_440_D.CHECK_DESC is '校验说明';
comment on column MBT_DM_440_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_440_D.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_440_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_440_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_440_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_440_D.DATA_FLAG is '数据标志';
comment on column MBT_DM_440_D.DATA_OP is '操作标志';
comment on column MBT_DM_440_D.DATA_SOURCE is '数据来源';
comment on column MBT_DM_440_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_440_D.DATA_HASH is '数据HASH';
comment on column MBT_DM_440_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_440_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_440_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_440_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_440_D.DATA_CRT_USER is '创建人';
comment on column MBT_DM_440_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_440_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_440_D.DATA_CHG_USER is '修改人';
comment on column MBT_DM_440_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_440_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_440_D.DATA_APV_USER is '审核人';
comment on column MBT_DM_440_D.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_440_D.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_440_D.RSV1 is '备用字段';
comment on column MBT_DM_440_D.RSV2 is '备用字段';
comment on column MBT_DM_440_D.RSV3 is '备用字段';
comment on column MBT_DM_440_D.RSV4 is '备用字段';
comment on column MBT_DM_440_D.RSV5 is '备用字段';
create table MBT_DM_440_E (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
ARLP_AMT NUMBER(15),
ARLP_AMT_ORG NUMBER(15),
C_CY VARCHAR(3),
ARLP_CERT_NUM VARCHAR(80),
ARLP_CERT_TYPE VARCHAR(2),
ARLP_NAME VARCHAR(160),
ARLP_TYPE VARCHAR(1),
WARTY_SIGN VARCHAR(1),
INFO_ID_TYPE VARCHAR(1),
MAX_GUAR_MCC VARCHAR(60),
ACTU_COTRL_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_440_E is '企业担保账户信息-相关还款责任人段';
comment on column MBT_DM_440_E.DATA_ID is '数据ID';
comment on column MBT_DM_440_E.DATA_DATE is '数据日期';
comment on column MBT_DM_440_E.CORP_ID is '法人ID';
comment on column MBT_DM_440_E.ORG_ID is '机构ID';
comment on column MBT_DM_440_E.GROUP_ID is '数据分组';
comment on column MBT_DM_440_E.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_440_E.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_440_E.ARLP_AMT is '还款责任金额';
comment on column MBT_DM_440_E.ARLP_AMT_ORG is '还款责任金额_原始数据金额';
comment on column MBT_DM_440_E.C_CY is '币种';
comment on column MBT_DM_440_E.ARLP_CERT_NUM is '责任人身份标识号码';
comment on column MBT_DM_440_E.ARLP_CERT_TYPE is '责任人身份标识类型';
comment on column MBT_DM_440_E.ARLP_NAME is '责任人名称';
comment on column MBT_DM_440_E.ARLP_TYPE is '还款责任人类型';
comment on column MBT_DM_440_E.WARTY_SIGN is '联保标志';
comment on column MBT_DM_440_E.INFO_ID_TYPE is '身份类别';
comment on column MBT_DM_440_E.MAX_GUAR_MCC is '保证合同编号';
comment on column MBT_DM_440_E.ACTU_COTRL_INFO_UP_DATE is '信息更新日期';
comment on column MBT_DM_440_E.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_440_E.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_440_E.CUST_NO is '客户号';
comment on column MBT_DM_440_E.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_440_E.PART_TYPE is '段标识';
comment on column MBT_DM_440_E.PART_NAME is '段名称';
comment on column MBT_DM_440_E.START_DATE is '起始日期';
comment on column MBT_DM_440_E.END_DATE is '结束日期';
comment on column MBT_DM_440_E.BATCH_NO is '批次号';
comment on column MBT_DM_440_E.ROW_NUM is '行号';
comment on column MBT_DM_440_E.IS_RPT is '是否报送';
comment on column MBT_DM_440_E.IS_VALID is '是否有效';
comment on column MBT_DM_440_E.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_440_E.OPT_FLAG is '操作标识';
comment on column MBT_DM_440_E.RPT_DATE is '报送日期';
comment on column MBT_DM_440_E.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_440_E.RPT_STATUS is '报送状态';
comment on column MBT_DM_440_E.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_440_E.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_440_E.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_440_E.REMARKS is '备注';
comment on column MBT_DM_440_E.CHECK_FLAG is '校验标志';
comment on column MBT_DM_440_E.CHECK_DESC is '校验说明';
comment on column MBT_DM_440_E.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_440_E.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_440_E.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_440_E.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_440_E.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_440_E.DATA_FLAG is '数据标志';
comment on column MBT_DM_440_E.DATA_OP is '操作标志';
comment on column MBT_DM_440_E.DATA_SOURCE is '数据来源';
comment on column MBT_DM_440_E.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_440_E.DATA_HASH is '数据HASH';
comment on column MBT_DM_440_E.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_440_E.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_440_E.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_440_E.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_440_E.DATA_CRT_USER is '创建人';
comment on column MBT_DM_440_E.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_440_E.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_440_E.DATA_CHG_USER is '修改人';
comment on column MBT_DM_440_E.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_440_E.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_440_E.DATA_APV_USER is '审核人';
comment on column MBT_DM_440_E.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_440_E.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_440_E.RSV1 is '备用字段';
comment on column MBT_DM_440_E.RSV2 is '备用字段';
comment on column MBT_DM_440_E.RSV3 is '备用字段';
comment on column MBT_DM_440_E.RSV4 is '备用字段';
comment on column MBT_DM_440_E.RSV5 is '备用字段';
create table MBT_DM_440_F (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
CCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_440_F is '企业担保账户信息-抵质押物信息段';
comment on column MBT_DM_440_F.DATA_ID is '数据ID';
comment on column MBT_DM_440_F.DATA_DATE is '数据日期';
comment on column MBT_DM_440_F.CORP_ID is '法人ID';
comment on column MBT_DM_440_F.ORG_ID is '机构ID';
comment on column MBT_DM_440_F.GROUP_ID is '数据分组';
comment on column MBT_DM_440_F.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_440_F.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_440_F.CCC is '抵（质）押合同标识码';
comment on column MBT_DM_440_F.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_440_F.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_440_F.CUST_NO is '客户号';
comment on column MBT_DM_440_F.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_440_F.PART_TYPE is '段标识';
comment on column MBT_DM_440_F.PART_NAME is '段名称';
comment on column MBT_DM_440_F.START_DATE is '起始日期';
comment on column MBT_DM_440_F.END_DATE is '结束日期';
comment on column MBT_DM_440_F.BATCH_NO is '批次号';
comment on column MBT_DM_440_F.ROW_NUM is '行号';
comment on column MBT_DM_440_F.IS_RPT is '是否报送';
comment on column MBT_DM_440_F.IS_VALID is '是否有效';
comment on column MBT_DM_440_F.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_440_F.OPT_FLAG is '操作标识';
comment on column MBT_DM_440_F.RPT_DATE is '报送日期';
comment on column MBT_DM_440_F.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_440_F.RPT_STATUS is '报送状态';
comment on column MBT_DM_440_F.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_440_F.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_440_F.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_440_F.REMARKS is '备注';
comment on column MBT_DM_440_F.CHECK_FLAG is '校验标志';
comment on column MBT_DM_440_F.CHECK_DESC is '校验说明';
comment on column MBT_DM_440_F.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_440_F.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_440_F.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_440_F.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_440_F.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_440_F.DATA_FLAG is '数据标志';
comment on column MBT_DM_440_F.DATA_OP is '操作标志';
comment on column MBT_DM_440_F.DATA_SOURCE is '数据来源';
comment on column MBT_DM_440_F.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_440_F.DATA_HASH is '数据HASH';
comment on column MBT_DM_440_F.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_440_F.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_440_F.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_440_F.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_440_F.DATA_CRT_USER is '创建人';
comment on column MBT_DM_440_F.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_440_F.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_440_F.DATA_CHG_USER is '修改人';
comment on column MBT_DM_440_F.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_440_F.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_440_F.DATA_APV_USER is '审核人';
comment on column MBT_DM_440_F.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_440_F.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_440_F.RSV1 is '备用字段';
comment on column MBT_DM_440_F.RSV2 is '备用字段';
comment on column MBT_DM_440_F.RSV3 is '备用字段';
comment on column MBT_DM_440_F.RSV4 is '备用字段';
comment on column MBT_DM_440_F.RSV5 is '备用字段';
create table MBT_DM_440_G (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_MCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_440_G is '企业担保账户信息-授信额度信息段';
comment on column MBT_DM_440_G.DATA_ID is '数据ID';
comment on column MBT_DM_440_G.DATA_DATE is '数据日期';
comment on column MBT_DM_440_G.CORP_ID is '法人ID';
comment on column MBT_DM_440_G.ORG_ID is '机构ID';
comment on column MBT_DM_440_G.GROUP_ID is '数据分组';
comment on column MBT_DM_440_G.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_440_G.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_440_G.G_MCC is '授信协议标识码';
comment on column MBT_DM_440_G.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_440_G.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_440_G.CUST_NO is '客户号';
comment on column MBT_DM_440_G.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_440_G.PART_TYPE is '段标识';
comment on column MBT_DM_440_G.PART_NAME is '段名称';
comment on column MBT_DM_440_G.START_DATE is '起始日期';
comment on column MBT_DM_440_G.END_DATE is '结束日期';
comment on column MBT_DM_440_G.BATCH_NO is '批次号';
comment on column MBT_DM_440_G.ROW_NUM is '行号';
comment on column MBT_DM_440_G.IS_RPT is '是否报送';
comment on column MBT_DM_440_G.IS_VALID is '是否有效';
comment on column MBT_DM_440_G.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_440_G.OPT_FLAG is '操作标识';
comment on column MBT_DM_440_G.RPT_DATE is '报送日期';
comment on column MBT_DM_440_G.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_440_G.RPT_STATUS is '报送状态';
comment on column MBT_DM_440_G.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_440_G.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_440_G.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_440_G.REMARKS is '备注';
comment on column MBT_DM_440_G.CHECK_FLAG is '校验标志';
comment on column MBT_DM_440_G.CHECK_DESC is '校验说明';
comment on column MBT_DM_440_G.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_440_G.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_440_G.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_440_G.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_440_G.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_440_G.DATA_FLAG is '数据标志';
comment on column MBT_DM_440_G.DATA_OP is '操作标志';
comment on column MBT_DM_440_G.DATA_SOURCE is '数据来源';
comment on column MBT_DM_440_G.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_440_G.DATA_HASH is '数据HASH';
comment on column MBT_DM_440_G.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_440_G.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_440_G.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_440_G.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_440_G.DATA_CRT_USER is '创建人';
comment on column MBT_DM_440_G.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_440_G.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_440_G.DATA_CHG_USER is '修改人';
comment on column MBT_DM_440_G.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_440_G.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_440_G.DATA_APV_USER is '审核人';
comment on column MBT_DM_440_G.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_440_G.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_440_G.RSV1 is '备用字段';
comment on column MBT_DM_440_G.RSV2 is '备用字段';
comment on column MBT_DM_440_G.RSV3 is '备用字段';
comment on column MBT_DM_440_G.RSV4 is '备用字段';
comment on column MBT_DM_440_G.RSV5 is '备用字段';
create table MBT_PM_440 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
O_BIZ_CODE VARCHAR(60),
N_BIZ_CODE VARCHAR(60),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_440 is '企业担保账户信息';
comment on column MBT_PM_440.DATA_ID is '数据ID';
comment on column MBT_PM_440.DATA_DATE is '数据日期';
comment on column MBT_PM_440.CORP_ID is '法人ID';
comment on column MBT_PM_440.ORG_ID is '机构ID';
comment on column MBT_PM_440.GROUP_ID is '数据分组';
comment on column MBT_PM_440.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_440.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_440.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_440.O_BIZ_CODE is '原业务标识码';
comment on column MBT_PM_440.N_BIZ_CODE is '新业务标识码';
comment on column MBT_PM_440.SECTION_CHG_CNT is '段变更';
comment on column MBT_PM_440.SECTION_DEL_CNT is '段删除';
comment on column MBT_PM_440.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_PM_440.IDN_CHG_CNT is '标识项变更';
comment on column MBT_PM_440.CUST_NO is '客户号';
comment on column MBT_PM_440.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_440.PART_TYPE is '段标识';
comment on column MBT_PM_440.PART_NAME is '段名称';
comment on column MBT_PM_440.START_DATE is '起始日期';
comment on column MBT_PM_440.END_DATE is '结束日期';
comment on column MBT_PM_440.BATCH_NO is '批次号';
comment on column MBT_PM_440.ROW_NUM is '行号';
comment on column MBT_PM_440.IS_RPT is '是否报送';
comment on column MBT_PM_440.IS_VALID is '是否有效';
comment on column MBT_PM_440.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_440.OPT_FLAG is '操作标识';
comment on column MBT_PM_440.RPT_DATE is '报送日期';
comment on column MBT_PM_440.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_440.RPT_STATUS is '报送状态';
comment on column MBT_PM_440.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_440.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_440.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_440.REMARKS is '备注';
comment on column MBT_PM_440.CHECK_FLAG is '校验标志';
comment on column MBT_PM_440.CHECK_DESC is '校验说明';
comment on column MBT_PM_440.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_440.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_440.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_440.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_440.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_440.DATA_FLAG is '数据标志';
comment on column MBT_PM_440.DATA_OP is '操作标志';
comment on column MBT_PM_440.DATA_SOURCE is '数据来源';
comment on column MBT_PM_440.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_440.DATA_HASH is '数据HASH';
comment on column MBT_PM_440.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_440.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_440.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_440.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_440.DATA_CRT_USER is '创建人';
comment on column MBT_PM_440.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_440.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_440.DATA_CHG_USER is '修改人';
comment on column MBT_PM_440.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_440.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_440.DATA_APV_USER is '审核人';
comment on column MBT_PM_440.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_440.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_440.RSV1 is '备用字段';
comment on column MBT_PM_440.RSV2 is '备用字段';
comment on column MBT_PM_440.RSV3 is '备用字段';
comment on column MBT_PM_440.RSV4 is '备用字段';
comment on column MBT_PM_440.RSV5 is '备用字段';
create table MBT_PM_440_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
B_ACCT_TYPE VARCHAR(2),
B_CUST_NO VARCHAR(32),
B_ID_NUM VARCHAR(80),
B_ID_TYPE VARCHAR(2),
B_INFO_UP_DATE VARCHAR(8),
B_INF_REC_TYPE VARCHAR(3),
B_MNGMT_ORG_CODE VARCHAR(14),
B_NAME VARCHAR(160),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_440_B is '企业担保账户信息-基础段';
comment on column MBT_PM_440_B.DATA_ID is '数据ID';
comment on column MBT_PM_440_B.DATA_DATE is '数据日期';
comment on column MBT_PM_440_B.CORP_ID is '法人ID';
comment on column MBT_PM_440_B.ORG_ID is '机构ID';
comment on column MBT_PM_440_B.GROUP_ID is '数据分组';
comment on column MBT_PM_440_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_440_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_440_B.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_440_B.B_ACCT_TYPE is '账户类型';
comment on column MBT_PM_440_B.B_CUST_NO is '客户号';
comment on column MBT_PM_440_B.B_ID_NUM is '债务人身份标识号码';
comment on column MBT_PM_440_B.B_ID_TYPE is '债务人身份标识类型';
comment on column MBT_PM_440_B.B_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_440_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_PM_440_B.B_MNGMT_ORG_CODE is '业务管理机构代码';
comment on column MBT_PM_440_B.B_NAME is '债务人名称';
comment on column MBT_PM_440_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_440_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_PM_440_B.CUST_NO is '客户号';
comment on column MBT_PM_440_B.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_440_B.PART_TYPE is '段标识';
comment on column MBT_PM_440_B.PART_NAME is '段名称';
comment on column MBT_PM_440_B.START_DATE is '起始日期';
comment on column MBT_PM_440_B.END_DATE is '结束日期';
comment on column MBT_PM_440_B.BATCH_NO is '批次号';
comment on column MBT_PM_440_B.ROW_NUM is '行号';
comment on column MBT_PM_440_B.IS_RPT is '是否报送';
comment on column MBT_PM_440_B.IS_VALID is '是否有效';
comment on column MBT_PM_440_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_440_B.OPT_FLAG is '操作标识';
comment on column MBT_PM_440_B.RPT_DATE is '报送日期';
comment on column MBT_PM_440_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_440_B.RPT_STATUS is '报送状态';
comment on column MBT_PM_440_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_440_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_440_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_440_B.REMARKS is '备注';
comment on column MBT_PM_440_B.CHECK_FLAG is '校验标志';
comment on column MBT_PM_440_B.CHECK_DESC is '校验说明';
comment on column MBT_PM_440_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_440_B.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_440_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_440_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_440_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_440_B.DATA_FLAG is '数据标志';
comment on column MBT_PM_440_B.DATA_OP is '操作标志';
comment on column MBT_PM_440_B.DATA_SOURCE is '数据来源';
comment on column MBT_PM_440_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_440_B.DATA_HASH is '数据HASH';
comment on column MBT_PM_440_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_440_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_440_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_440_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_440_B.DATA_CRT_USER is '创建人';
comment on column MBT_PM_440_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_440_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_440_B.DATA_CHG_USER is '修改人';
comment on column MBT_PM_440_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_440_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_440_B.DATA_APV_USER is '审核人';
comment on column MBT_PM_440_B.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_440_B.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_440_B.RSV1 is '备用字段';
comment on column MBT_PM_440_B.RSV2 is '备用字段';
comment on column MBT_PM_440_B.RSV3 is '备用字段';
comment on column MBT_PM_440_B.RSV4 is '备用字段';
comment on column MBT_PM_440_B.RSV5 is '备用字段';
create table MBT_PM_440_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_BUSI_DTIL_LINES VARCHAR(2),
C_BUSI_LINES VARCHAR(1),
C_CTRCT_TXT_CODE VARCHAR(120),
C_CY VARCHAR(3),
C_DUE_DATE VARCHAR(8),
C_GUAR_AMT NUMBER(15),
C_GUAR_AMT_LCY NUMBER(15),
C_GUAR_MODE VARCHAR(1),
C_OPEN_DATE VARCHAR(8),
C_OTH_REPY_GUAR_WAY VARCHAR(1),
C_SEC_DEP NUMBER(10),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_440_C is '企业担保账户信息-基本信息段';
comment on column MBT_PM_440_C.DATA_ID is '数据ID';
comment on column MBT_PM_440_C.DATA_DATE is '数据日期';
comment on column MBT_PM_440_C.CORP_ID is '法人ID';
comment on column MBT_PM_440_C.ORG_ID is '机构ID';
comment on column MBT_PM_440_C.GROUP_ID is '数据分组';
comment on column MBT_PM_440_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_440_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_440_C.C_BUSI_DTIL_LINES is '担保业务种类细分';
comment on column MBT_PM_440_C.C_BUSI_LINES is '担保业务大类';
comment on column MBT_PM_440_C.C_CTRCT_TXT_CODE is '担保合同文本编号';
comment on column MBT_PM_440_C.C_CY is '币种';
comment on column MBT_PM_440_C.C_DUE_DATE is '到期日期';
comment on column MBT_PM_440_C.C_GUAR_AMT is '担保金额';
comment on column MBT_PM_440_C.C_GUAR_AMT_LCY is '担保金额人民币金额';
comment on column MBT_PM_440_C.C_GUAR_MODE is '反担保方式';
comment on column MBT_PM_440_C.C_OPEN_DATE is '开户日期';
comment on column MBT_PM_440_C.C_OTH_REPY_GUAR_WAY is '其他还款保证方式';
comment on column MBT_PM_440_C.C_SEC_DEP is '保证金百分比';
comment on column MBT_PM_440_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_440_C.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_440_C.CUST_NO is '客户号';
comment on column MBT_PM_440_C.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_440_C.PART_TYPE is '段标识';
comment on column MBT_PM_440_C.PART_NAME is '段名称';
comment on column MBT_PM_440_C.START_DATE is '起始日期';
comment on column MBT_PM_440_C.END_DATE is '结束日期';
comment on column MBT_PM_440_C.BATCH_NO is '批次号';
comment on column MBT_PM_440_C.ROW_NUM is '行号';
comment on column MBT_PM_440_C.IS_RPT is '是否报送';
comment on column MBT_PM_440_C.IS_VALID is '是否有效';
comment on column MBT_PM_440_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_440_C.OPT_FLAG is '操作标识';
comment on column MBT_PM_440_C.RPT_DATE is '报送日期';
comment on column MBT_PM_440_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_440_C.RPT_STATUS is '报送状态';
comment on column MBT_PM_440_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_440_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_440_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_440_C.REMARKS is '备注';
comment on column MBT_PM_440_C.CHECK_FLAG is '校验标志';
comment on column MBT_PM_440_C.CHECK_DESC is '校验说明';
comment on column MBT_PM_440_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_440_C.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_440_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_440_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_440_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_440_C.DATA_FLAG is '数据标志';
comment on column MBT_PM_440_C.DATA_OP is '操作标志';
comment on column MBT_PM_440_C.DATA_SOURCE is '数据来源';
comment on column MBT_PM_440_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_440_C.DATA_HASH is '数据HASH';
comment on column MBT_PM_440_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_440_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_440_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_440_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_440_C.DATA_CRT_USER is '创建人';
comment on column MBT_PM_440_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_440_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_440_C.DATA_CHG_USER is '修改人';
comment on column MBT_PM_440_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_440_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_440_C.DATA_APV_USER is '审核人';
comment on column MBT_PM_440_C.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_440_C.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_440_C.RSV1 is '备用字段';
comment on column MBT_PM_440_C.RSV2 is '备用字段';
comment on column MBT_PM_440_C.RSV3 is '备用字段';
comment on column MBT_PM_440_C.RSV4 is '备用字段';
comment on column MBT_PM_440_C.RSV5 is '备用字段';
create table MBT_PM_440_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ACCT_STATUS VARCHAR(1),
D_CLOSE_DATE VARCHAR(8),
D_COMP_ADV_FLAG VARCHAR(1),
D_FIVE_CATE VARCHAR(1),
D_FIVE_CATE_ADJ_DATE VARCHAR(8),
D_LOAN_AMT NUMBER(15),
D_LOAN_AMT_LCY NUMBER(15),
D_REPAY_PRD VARCHAR(8),
D_RI_EX NUMBER(19),
D_RI_EX_LCY NUMBER(19),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_440_D is '企业担保账户信息-在保责任信息段';
comment on column MBT_PM_440_D.DATA_ID is '数据ID';
comment on column MBT_PM_440_D.DATA_DATE is '数据日期';
comment on column MBT_PM_440_D.CORP_ID is '法人ID';
comment on column MBT_PM_440_D.ORG_ID is '机构ID';
comment on column MBT_PM_440_D.GROUP_ID is '数据分组';
comment on column MBT_PM_440_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_440_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_440_D.D_ACCT_STATUS is '账户状态';
comment on column MBT_PM_440_D.D_CLOSE_DATE is '账户关闭日期';
comment on column MBT_PM_440_D.D_COMP_ADV_FLAG is '代偿（垫款）标识';
comment on column MBT_PM_440_D.D_FIVE_CATE is '五级分类';
comment on column MBT_PM_440_D.D_FIVE_CATE_ADJ_DATE is '五级分类认定日期';
comment on column MBT_PM_440_D.D_LOAN_AMT is '在保余额';
comment on column MBT_PM_440_D.D_LOAN_AMT_LCY is '在保余额人民币金额';
comment on column MBT_PM_440_D.D_REPAY_PRD is '余额变化日期';
comment on column MBT_PM_440_D.D_RI_EX is '风险敞口';
comment on column MBT_PM_440_D.D_RI_EX_LCY is '风险敞口人民币金额';
comment on column MBT_PM_440_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_440_D.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_440_D.CUST_NO is '客户号';
comment on column MBT_PM_440_D.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_440_D.PART_TYPE is '段标识';
comment on column MBT_PM_440_D.PART_NAME is '段名称';
comment on column MBT_PM_440_D.START_DATE is '起始日期';
comment on column MBT_PM_440_D.END_DATE is '结束日期';
comment on column MBT_PM_440_D.BATCH_NO is '批次号';
comment on column MBT_PM_440_D.ROW_NUM is '行号';
comment on column MBT_PM_440_D.IS_RPT is '是否报送';
comment on column MBT_PM_440_D.IS_VALID is '是否有效';
comment on column MBT_PM_440_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_440_D.OPT_FLAG is '操作标识';
comment on column MBT_PM_440_D.RPT_DATE is '报送日期';
comment on column MBT_PM_440_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_440_D.RPT_STATUS is '报送状态';
comment on column MBT_PM_440_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_440_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_440_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_440_D.REMARKS is '备注';
comment on column MBT_PM_440_D.CHECK_FLAG is '校验标志';
comment on column MBT_PM_440_D.CHECK_DESC is '校验说明';
comment on column MBT_PM_440_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_440_D.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_440_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_440_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_440_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_440_D.DATA_FLAG is '数据标志';
comment on column MBT_PM_440_D.DATA_OP is '操作标志';
comment on column MBT_PM_440_D.DATA_SOURCE is '数据来源';
comment on column MBT_PM_440_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_440_D.DATA_HASH is '数据HASH';
comment on column MBT_PM_440_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_440_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_440_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_440_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_440_D.DATA_CRT_USER is '创建人';
comment on column MBT_PM_440_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_440_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_440_D.DATA_CHG_USER is '修改人';
comment on column MBT_PM_440_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_440_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_440_D.DATA_APV_USER is '审核人';
comment on column MBT_PM_440_D.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_440_D.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_440_D.RSV1 is '备用字段';
comment on column MBT_PM_440_D.RSV2 is '备用字段';
comment on column MBT_PM_440_D.RSV3 is '备用字段';
comment on column MBT_PM_440_D.RSV4 is '备用字段';
comment on column MBT_PM_440_D.RSV5 is '备用字段';
create table MBT_PM_440_E (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
ARLP_AMT NUMBER(15),
ARLP_AMT_ORG NUMBER(15),
C_CY VARCHAR(3),
ARLP_CERT_NUM VARCHAR(80),
ARLP_CERT_TYPE VARCHAR(2),
ARLP_NAME VARCHAR(160),
ARLP_TYPE VARCHAR(1),
WARTY_SIGN VARCHAR(1),
INFO_ID_TYPE VARCHAR(1),
MAX_GUAR_MCC VARCHAR(60),
ACTU_COTRL_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_440_E is '企业担保账户信息-相关还款责任人段';
comment on column MBT_PM_440_E.DATA_ID is '数据ID';
comment on column MBT_PM_440_E.DATA_DATE is '数据日期';
comment on column MBT_PM_440_E.CORP_ID is '法人ID';
comment on column MBT_PM_440_E.ORG_ID is '机构ID';
comment on column MBT_PM_440_E.GROUP_ID is '数据分组';
comment on column MBT_PM_440_E.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_440_E.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_440_E.ARLP_AMT is '还款责任金额';
comment on column MBT_PM_440_E.ARLP_AMT_ORG is '还款责任金额_原始数据金额';
comment on column MBT_PM_440_E.C_CY is '币种';
comment on column MBT_PM_440_E.ARLP_CERT_NUM is '责任人身份标识号码';
comment on column MBT_PM_440_E.ARLP_CERT_TYPE is '责任人身份标识类型';
comment on column MBT_PM_440_E.ARLP_NAME is '责任人名称';
comment on column MBT_PM_440_E.ARLP_TYPE is '还款责任人类型';
comment on column MBT_PM_440_E.WARTY_SIGN is '联保标志';
comment on column MBT_PM_440_E.INFO_ID_TYPE is '身份类别';
comment on column MBT_PM_440_E.MAX_GUAR_MCC is '保证合同编号';
comment on column MBT_PM_440_E.ACTU_COTRL_INFO_UP_DATE is '信息更新日期';
comment on column MBT_PM_440_E.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_440_E.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_440_E.CUST_NO is '客户号';
comment on column MBT_PM_440_E.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_440_E.PART_TYPE is '段标识';
comment on column MBT_PM_440_E.PART_NAME is '段名称';
comment on column MBT_PM_440_E.START_DATE is '起始日期';
comment on column MBT_PM_440_E.END_DATE is '结束日期';
comment on column MBT_PM_440_E.BATCH_NO is '批次号';
comment on column MBT_PM_440_E.ROW_NUM is '行号';
comment on column MBT_PM_440_E.IS_RPT is '是否报送';
comment on column MBT_PM_440_E.IS_VALID is '是否有效';
comment on column MBT_PM_440_E.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_440_E.OPT_FLAG is '操作标识';
comment on column MBT_PM_440_E.RPT_DATE is '报送日期';
comment on column MBT_PM_440_E.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_440_E.RPT_STATUS is '报送状态';
comment on column MBT_PM_440_E.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_440_E.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_440_E.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_440_E.REMARKS is '备注';
comment on column MBT_PM_440_E.CHECK_FLAG is '校验标志';
comment on column MBT_PM_440_E.CHECK_DESC is '校验说明';
comment on column MBT_PM_440_E.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_440_E.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_440_E.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_440_E.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_440_E.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_440_E.DATA_FLAG is '数据标志';
comment on column MBT_PM_440_E.DATA_OP is '操作标志';
comment on column MBT_PM_440_E.DATA_SOURCE is '数据来源';
comment on column MBT_PM_440_E.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_440_E.DATA_HASH is '数据HASH';
comment on column MBT_PM_440_E.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_440_E.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_440_E.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_440_E.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_440_E.DATA_CRT_USER is '创建人';
comment on column MBT_PM_440_E.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_440_E.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_440_E.DATA_CHG_USER is '修改人';
comment on column MBT_PM_440_E.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_440_E.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_440_E.DATA_APV_USER is '审核人';
comment on column MBT_PM_440_E.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_440_E.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_440_E.RSV1 is '备用字段';
comment on column MBT_PM_440_E.RSV2 is '备用字段';
comment on column MBT_PM_440_E.RSV3 is '备用字段';
comment on column MBT_PM_440_E.RSV4 is '备用字段';
comment on column MBT_PM_440_E.RSV5 is '备用字段';
create table MBT_PM_440_F (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
CCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_440_F is '企业担保账户信息-抵质押物信息段';
comment on column MBT_PM_440_F.DATA_ID is '数据ID';
comment on column MBT_PM_440_F.DATA_DATE is '数据日期';
comment on column MBT_PM_440_F.CORP_ID is '法人ID';
comment on column MBT_PM_440_F.ORG_ID is '机构ID';
comment on column MBT_PM_440_F.GROUP_ID is '数据分组';
comment on column MBT_PM_440_F.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_440_F.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_440_F.CCC is '抵（质）押合同标识码';
comment on column MBT_PM_440_F.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_440_F.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_440_F.CUST_NO is '客户号';
comment on column MBT_PM_440_F.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_440_F.PART_TYPE is '段标识';
comment on column MBT_PM_440_F.PART_NAME is '段名称';
comment on column MBT_PM_440_F.START_DATE is '起始日期';
comment on column MBT_PM_440_F.END_DATE is '结束日期';
comment on column MBT_PM_440_F.BATCH_NO is '批次号';
comment on column MBT_PM_440_F.ROW_NUM is '行号';
comment on column MBT_PM_440_F.IS_RPT is '是否报送';
comment on column MBT_PM_440_F.IS_VALID is '是否有效';
comment on column MBT_PM_440_F.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_440_F.OPT_FLAG is '操作标识';
comment on column MBT_PM_440_F.RPT_DATE is '报送日期';
comment on column MBT_PM_440_F.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_440_F.RPT_STATUS is '报送状态';
comment on column MBT_PM_440_F.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_440_F.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_440_F.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_440_F.REMARKS is '备注';
comment on column MBT_PM_440_F.CHECK_FLAG is '校验标志';
comment on column MBT_PM_440_F.CHECK_DESC is '校验说明';
comment on column MBT_PM_440_F.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_440_F.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_440_F.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_440_F.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_440_F.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_440_F.DATA_FLAG is '数据标志';
comment on column MBT_PM_440_F.DATA_OP is '操作标志';
comment on column MBT_PM_440_F.DATA_SOURCE is '数据来源';
comment on column MBT_PM_440_F.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_440_F.DATA_HASH is '数据HASH';
comment on column MBT_PM_440_F.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_440_F.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_440_F.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_440_F.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_440_F.DATA_CRT_USER is '创建人';
comment on column MBT_PM_440_F.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_440_F.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_440_F.DATA_CHG_USER is '修改人';
comment on column MBT_PM_440_F.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_440_F.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_440_F.DATA_APV_USER is '审核人';
comment on column MBT_PM_440_F.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_440_F.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_440_F.RSV1 is '备用字段';
comment on column MBT_PM_440_F.RSV2 is '备用字段';
comment on column MBT_PM_440_F.RSV3 is '备用字段';
comment on column MBT_PM_440_F.RSV4 is '备用字段';
comment on column MBT_PM_440_F.RSV5 is '备用字段';
create table MBT_PM_440_G (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_MCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_440_G is '企业担保账户信息-授信额度信息段';
comment on column MBT_PM_440_G.DATA_ID is '数据ID';
comment on column MBT_PM_440_G.DATA_DATE is '数据日期';
comment on column MBT_PM_440_G.CORP_ID is '法人ID';
comment on column MBT_PM_440_G.ORG_ID is '机构ID';
comment on column MBT_PM_440_G.GROUP_ID is '数据分组';
comment on column MBT_PM_440_G.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_440_G.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_440_G.G_MCC is '授信协议标识码';
comment on column MBT_PM_440_G.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_440_G.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_440_G.CUST_NO is '客户号';
comment on column MBT_PM_440_G.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_440_G.PART_TYPE is '段标识';
comment on column MBT_PM_440_G.PART_NAME is '段名称';
comment on column MBT_PM_440_G.START_DATE is '起始日期';
comment on column MBT_PM_440_G.END_DATE is '结束日期';
comment on column MBT_PM_440_G.BATCH_NO is '批次号';
comment on column MBT_PM_440_G.ROW_NUM is '行号';
comment on column MBT_PM_440_G.IS_RPT is '是否报送';
comment on column MBT_PM_440_G.IS_VALID is '是否有效';
comment on column MBT_PM_440_G.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_440_G.OPT_FLAG is '操作标识';
comment on column MBT_PM_440_G.RPT_DATE is '报送日期';
comment on column MBT_PM_440_G.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_440_G.RPT_STATUS is '报送状态';
comment on column MBT_PM_440_G.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_440_G.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_440_G.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_440_G.REMARKS is '备注';
comment on column MBT_PM_440_G.CHECK_FLAG is '校验标志';
comment on column MBT_PM_440_G.CHECK_DESC is '校验说明';
comment on column MBT_PM_440_G.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_440_G.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_440_G.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_440_G.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_440_G.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_440_G.DATA_FLAG is '数据标志';
comment on column MBT_PM_440_G.DATA_OP is '操作标志';
comment on column MBT_PM_440_G.DATA_SOURCE is '数据来源';
comment on column MBT_PM_440_G.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_440_G.DATA_HASH is '数据HASH';
comment on column MBT_PM_440_G.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_440_G.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_440_G.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_440_G.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_440_G.DATA_CRT_USER is '创建人';
comment on column MBT_PM_440_G.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_440_G.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_440_G.DATA_CHG_USER is '修改人';
comment on column MBT_PM_440_G.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_440_G.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_440_G.DATA_APV_USER is '审核人';
comment on column MBT_PM_440_G.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_440_G.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_440_G.RSV1 is '备用字段';
comment on column MBT_PM_440_G.RSV2 is '备用字段';
comment on column MBT_PM_440_G.RSV3 is '备用字段';
comment on column MBT_PM_440_G.RSV4 is '备用字段';
comment on column MBT_PM_440_G.RSV5 is '备用字段';
create table MBT_RPT_440 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
O_BIZ_CODE VARCHAR(60),
N_BIZ_CODE VARCHAR(60),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_440 is '企业担保账户信息';
comment on column MBT_RPT_440.DATA_ID is '数据ID';
comment on column MBT_RPT_440.DATA_DATE is '数据日期';
comment on column MBT_RPT_440.CORP_ID is '法人ID';
comment on column MBT_RPT_440.ORG_ID is '机构ID';
comment on column MBT_RPT_440.GROUP_ID is '数据分组';
comment on column MBT_RPT_440.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_440.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_440.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_440.O_BIZ_CODE is '原业务标识码';
comment on column MBT_RPT_440.N_BIZ_CODE is '新业务标识码';
comment on column MBT_RPT_440.SECTION_CHG_CNT is '段变更';
comment on column MBT_RPT_440.SECTION_DEL_CNT is '段删除';
comment on column MBT_RPT_440.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_RPT_440.IDN_CHG_CNT is '标识项变更';
comment on column MBT_RPT_440.CUST_NO is '客户号';
comment on column MBT_RPT_440.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_440.PART_TYPE is '段标识';
comment on column MBT_RPT_440.PART_NAME is '段名称';
comment on column MBT_RPT_440.START_DATE is '起始日期';
comment on column MBT_RPT_440.END_DATE is '结束日期';
comment on column MBT_RPT_440.BATCH_NO is '批次号';
comment on column MBT_RPT_440.ROW_NUM is '行号';
comment on column MBT_RPT_440.IS_RPT is '是否报送';
comment on column MBT_RPT_440.IS_VALID is '是否有效';
comment on column MBT_RPT_440.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_440.OPT_FLAG is '操作标识';
comment on column MBT_RPT_440.RPT_DATE is '报送日期';
comment on column MBT_RPT_440.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_440.RPT_STATUS is '报送状态';
comment on column MBT_RPT_440.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_440.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_440.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_440.REMARKS is '备注';
comment on column MBT_RPT_440.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_440.CHECK_DESC is '校验说明';
comment on column MBT_RPT_440.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_440.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_440.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_440.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_440.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_440.DATA_FLAG is '数据标志';
comment on column MBT_RPT_440.DATA_OP is '操作标志';
comment on column MBT_RPT_440.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_440.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_440.DATA_HASH is '数据HASH';
comment on column MBT_RPT_440.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_440.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_440.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_440.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_440.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_440.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_440.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_440.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_440.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_440.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_440.DATA_APV_USER is '审核人';
comment on column MBT_RPT_440.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_440.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_440.RSV1 is '备用字段';
comment on column MBT_RPT_440.RSV2 is '备用字段';
comment on column MBT_RPT_440.RSV3 is '备用字段';
comment on column MBT_RPT_440.RSV4 is '备用字段';
comment on column MBT_RPT_440.RSV5 is '备用字段';
create table MBT_RPT_440_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
B_ACCT_TYPE VARCHAR(2),
B_CUST_NO VARCHAR(32),
B_ID_NUM VARCHAR(80),
B_ID_TYPE VARCHAR(2),
B_INFO_UP_DATE VARCHAR(8),
B_INF_REC_TYPE VARCHAR(3),
B_MNGMT_ORG_CODE VARCHAR(14),
B_NAME VARCHAR(160),
B_RPT_DATE VARCHAR(8),
B_RPT_DATE_CODE VARCHAR(2),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_440_B is '企业担保账户信息-基础段';
comment on column MBT_RPT_440_B.DATA_ID is '数据ID';
comment on column MBT_RPT_440_B.DATA_DATE is '数据日期';
comment on column MBT_RPT_440_B.CORP_ID is '法人ID';
comment on column MBT_RPT_440_B.ORG_ID is '机构ID';
comment on column MBT_RPT_440_B.GROUP_ID is '数据分组';
comment on column MBT_RPT_440_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_440_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_440_B.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_440_B.B_ACCT_TYPE is '账户类型';
comment on column MBT_RPT_440_B.B_CUST_NO is '客户号';
comment on column MBT_RPT_440_B.B_ID_NUM is '债务人身份标识号码';
comment on column MBT_RPT_440_B.B_ID_TYPE is '债务人身份标识类型';
comment on column MBT_RPT_440_B.B_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_440_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_RPT_440_B.B_MNGMT_ORG_CODE is '业务管理机构代码';
comment on column MBT_RPT_440_B.B_NAME is '债务人名称';
comment on column MBT_RPT_440_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_440_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_RPT_440_B.CUST_NO is '客户号';
comment on column MBT_RPT_440_B.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_440_B.PART_TYPE is '段标识';
comment on column MBT_RPT_440_B.PART_NAME is '段名称';
comment on column MBT_RPT_440_B.START_DATE is '起始日期';
comment on column MBT_RPT_440_B.END_DATE is '结束日期';
comment on column MBT_RPT_440_B.BATCH_NO is '批次号';
comment on column MBT_RPT_440_B.ROW_NUM is '行号';
comment on column MBT_RPT_440_B.IS_RPT is '是否报送';
comment on column MBT_RPT_440_B.IS_VALID is '是否有效';
comment on column MBT_RPT_440_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_440_B.OPT_FLAG is '操作标识';
comment on column MBT_RPT_440_B.RPT_DATE is '报送日期';
comment on column MBT_RPT_440_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_440_B.RPT_STATUS is '报送状态';
comment on column MBT_RPT_440_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_440_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_440_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_440_B.REMARKS is '备注';
comment on column MBT_RPT_440_B.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_440_B.CHECK_DESC is '校验说明';
comment on column MBT_RPT_440_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_440_B.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_440_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_440_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_440_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_440_B.DATA_FLAG is '数据标志';
comment on column MBT_RPT_440_B.DATA_OP is '操作标志';
comment on column MBT_RPT_440_B.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_440_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_440_B.DATA_HASH is '数据HASH';
comment on column MBT_RPT_440_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_440_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_440_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_440_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_440_B.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_440_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_440_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_440_B.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_440_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_440_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_440_B.DATA_APV_USER is '审核人';
comment on column MBT_RPT_440_B.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_440_B.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_440_B.RSV1 is '备用字段';
comment on column MBT_RPT_440_B.RSV2 is '备用字段';
comment on column MBT_RPT_440_B.RSV3 is '备用字段';
comment on column MBT_RPT_440_B.RSV4 is '备用字段';
comment on column MBT_RPT_440_B.RSV5 is '备用字段';
create table MBT_RPT_440_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_BUSI_DTIL_LINES VARCHAR(2),
C_BUSI_LINES VARCHAR(1),
C_CTRCT_TXT_CODE VARCHAR(120),
C_CY VARCHAR(3),
C_DUE_DATE VARCHAR(8),
C_GUAR_AMT NUMBER(15),
C_GUAR_AMT_LCY NUMBER(15),
C_GUAR_MODE VARCHAR(1),
C_OPEN_DATE VARCHAR(8),
C_OTH_REPY_GUAR_WAY VARCHAR(1),
C_SEC_DEP NUMBER(10),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_440_C is '企业担保账户信息-基本信息段';
comment on column MBT_RPT_440_C.DATA_ID is '数据ID';
comment on column MBT_RPT_440_C.DATA_DATE is '数据日期';
comment on column MBT_RPT_440_C.CORP_ID is '法人ID';
comment on column MBT_RPT_440_C.ORG_ID is '机构ID';
comment on column MBT_RPT_440_C.GROUP_ID is '数据分组';
comment on column MBT_RPT_440_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_440_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_440_C.C_BUSI_DTIL_LINES is '担保业务种类细分';
comment on column MBT_RPT_440_C.C_BUSI_LINES is '担保业务大类';
comment on column MBT_RPT_440_C.C_CTRCT_TXT_CODE is '担保合同文本编号';
comment on column MBT_RPT_440_C.C_CY is '币种';
comment on column MBT_RPT_440_C.C_DUE_DATE is '到期日期';
comment on column MBT_RPT_440_C.C_GUAR_AMT is '担保金额';
comment on column MBT_RPT_440_C.C_GUAR_AMT_LCY is '担保金额人民币金额';
comment on column MBT_RPT_440_C.C_GUAR_MODE is '反担保方式';
comment on column MBT_RPT_440_C.C_OPEN_DATE is '开户日期';
comment on column MBT_RPT_440_C.C_OTH_REPY_GUAR_WAY is '其他还款保证方式';
comment on column MBT_RPT_440_C.C_SEC_DEP is '保证金百分比';
comment on column MBT_RPT_440_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_440_C.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_440_C.CUST_NO is '客户号';
comment on column MBT_RPT_440_C.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_440_C.PART_TYPE is '段标识';
comment on column MBT_RPT_440_C.PART_NAME is '段名称';
comment on column MBT_RPT_440_C.START_DATE is '起始日期';
comment on column MBT_RPT_440_C.END_DATE is '结束日期';
comment on column MBT_RPT_440_C.BATCH_NO is '批次号';
comment on column MBT_RPT_440_C.ROW_NUM is '行号';
comment on column MBT_RPT_440_C.IS_RPT is '是否报送';
comment on column MBT_RPT_440_C.IS_VALID is '是否有效';
comment on column MBT_RPT_440_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_440_C.OPT_FLAG is '操作标识';
comment on column MBT_RPT_440_C.RPT_DATE is '报送日期';
comment on column MBT_RPT_440_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_440_C.RPT_STATUS is '报送状态';
comment on column MBT_RPT_440_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_440_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_440_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_440_C.REMARKS is '备注';
comment on column MBT_RPT_440_C.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_440_C.CHECK_DESC is '校验说明';
comment on column MBT_RPT_440_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_440_C.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_440_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_440_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_440_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_440_C.DATA_FLAG is '数据标志';
comment on column MBT_RPT_440_C.DATA_OP is '操作标志';
comment on column MBT_RPT_440_C.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_440_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_440_C.DATA_HASH is '数据HASH';
comment on column MBT_RPT_440_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_440_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_440_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_440_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_440_C.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_440_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_440_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_440_C.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_440_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_440_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_440_C.DATA_APV_USER is '审核人';
comment on column MBT_RPT_440_C.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_440_C.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_440_C.RSV1 is '备用字段';
comment on column MBT_RPT_440_C.RSV2 is '备用字段';
comment on column MBT_RPT_440_C.RSV3 is '备用字段';
comment on column MBT_RPT_440_C.RSV4 is '备用字段';
comment on column MBT_RPT_440_C.RSV5 is '备用字段';
create table MBT_RPT_440_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ACCT_STATUS VARCHAR(1),
D_CLOSE_DATE VARCHAR(8),
D_COMP_ADV_FLAG VARCHAR(1),
D_FIVE_CATE VARCHAR(1),
D_FIVE_CATE_ADJ_DATE VARCHAR(8),
D_LOAN_AMT NUMBER(15),
D_LOAN_AMT_LCY NUMBER(15),
D_REPAY_PRD VARCHAR(8),
D_RI_EX NUMBER(19),
D_RI_EX_LCY NUMBER(19),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_440_D is '企业担保账户信息-在保责任信息段';
comment on column MBT_RPT_440_D.DATA_ID is '数据ID';
comment on column MBT_RPT_440_D.DATA_DATE is '数据日期';
comment on column MBT_RPT_440_D.CORP_ID is '法人ID';
comment on column MBT_RPT_440_D.ORG_ID is '机构ID';
comment on column MBT_RPT_440_D.GROUP_ID is '数据分组';
comment on column MBT_RPT_440_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_440_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_440_D.D_ACCT_STATUS is '账户状态';
comment on column MBT_RPT_440_D.D_CLOSE_DATE is '账户关闭日期';
comment on column MBT_RPT_440_D.D_COMP_ADV_FLAG is '代偿（垫款）标识';
comment on column MBT_RPT_440_D.D_FIVE_CATE is '五级分类';
comment on column MBT_RPT_440_D.D_FIVE_CATE_ADJ_DATE is '五级分类认定日期';
comment on column MBT_RPT_440_D.D_LOAN_AMT is '在保余额';
comment on column MBT_RPT_440_D.D_LOAN_AMT_LCY is '在保余额人民币金额';
comment on column MBT_RPT_440_D.D_REPAY_PRD is '余额变化日期';
comment on column MBT_RPT_440_D.D_RI_EX is '风险敞口';
comment on column MBT_RPT_440_D.D_RI_EX_LCY is '风险敞口人民币金额';
comment on column MBT_RPT_440_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_440_D.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_440_D.CUST_NO is '客户号';
comment on column MBT_RPT_440_D.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_440_D.PART_TYPE is '段标识';
comment on column MBT_RPT_440_D.PART_NAME is '段名称';
comment on column MBT_RPT_440_D.START_DATE is '起始日期';
comment on column MBT_RPT_440_D.END_DATE is '结束日期';
comment on column MBT_RPT_440_D.BATCH_NO is '批次号';
comment on column MBT_RPT_440_D.ROW_NUM is '行号';
comment on column MBT_RPT_440_D.IS_RPT is '是否报送';
comment on column MBT_RPT_440_D.IS_VALID is '是否有效';
comment on column MBT_RPT_440_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_440_D.OPT_FLAG is '操作标识';
comment on column MBT_RPT_440_D.RPT_DATE is '报送日期';
comment on column MBT_RPT_440_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_440_D.RPT_STATUS is '报送状态';
comment on column MBT_RPT_440_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_440_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_440_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_440_D.REMARKS is '备注';
comment on column MBT_RPT_440_D.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_440_D.CHECK_DESC is '校验说明';
comment on column MBT_RPT_440_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_440_D.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_440_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_440_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_440_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_440_D.DATA_FLAG is '数据标志';
comment on column MBT_RPT_440_D.DATA_OP is '操作标志';
comment on column MBT_RPT_440_D.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_440_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_440_D.DATA_HASH is '数据HASH';
comment on column MBT_RPT_440_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_440_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_440_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_440_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_440_D.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_440_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_440_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_440_D.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_440_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_440_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_440_D.DATA_APV_USER is '审核人';
comment on column MBT_RPT_440_D.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_440_D.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_440_D.RSV1 is '备用字段';
comment on column MBT_RPT_440_D.RSV2 is '备用字段';
comment on column MBT_RPT_440_D.RSV3 is '备用字段';
comment on column MBT_RPT_440_D.RSV4 is '备用字段';
comment on column MBT_RPT_440_D.RSV5 is '备用字段';
create table MBT_RPT_440_E (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
ARLP_AMT NUMBER(15),
ARLP_AMT_ORG NUMBER(15),
C_CY VARCHAR(3),
ARLP_CERT_NUM VARCHAR(80),
ARLP_CERT_TYPE VARCHAR(2),
ARLP_NAME VARCHAR(160),
ARLP_TYPE VARCHAR(1),
WARTY_SIGN VARCHAR(1),
INFO_ID_TYPE VARCHAR(1),
MAX_GUAR_MCC VARCHAR(60),
ACTU_COTRL_INFO_UP_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_440_E is '企业担保账户信息-相关还款责任人段';
comment on column MBT_RPT_440_E.DATA_ID is '数据ID';
comment on column MBT_RPT_440_E.DATA_DATE is '数据日期';
comment on column MBT_RPT_440_E.CORP_ID is '法人ID';
comment on column MBT_RPT_440_E.ORG_ID is '机构ID';
comment on column MBT_RPT_440_E.GROUP_ID is '数据分组';
comment on column MBT_RPT_440_E.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_440_E.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_440_E.ARLP_AMT is '还款责任金额';
comment on column MBT_RPT_440_E.ARLP_AMT_ORG is '还款责任金额_原始数据金额';
comment on column MBT_RPT_440_E.C_CY is '币种';
comment on column MBT_RPT_440_E.ARLP_CERT_NUM is '责任人身份标识号码';
comment on column MBT_RPT_440_E.ARLP_CERT_TYPE is '责任人身份标识类型';
comment on column MBT_RPT_440_E.ARLP_NAME is '责任人名称';
comment on column MBT_RPT_440_E.ARLP_TYPE is '还款责任人类型';
comment on column MBT_RPT_440_E.WARTY_SIGN is '联保标志';
comment on column MBT_RPT_440_E.INFO_ID_TYPE is '身份类别';
comment on column MBT_RPT_440_E.MAX_GUAR_MCC is '保证合同编号';
comment on column MBT_RPT_440_E.ACTU_COTRL_INFO_UP_DATE is '信息更新日期';
comment on column MBT_RPT_440_E.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_440_E.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_440_E.CUST_NO is '客户号';
comment on column MBT_RPT_440_E.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_440_E.PART_TYPE is '段标识';
comment on column MBT_RPT_440_E.PART_NAME is '段名称';
comment on column MBT_RPT_440_E.START_DATE is '起始日期';
comment on column MBT_RPT_440_E.END_DATE is '结束日期';
comment on column MBT_RPT_440_E.BATCH_NO is '批次号';
comment on column MBT_RPT_440_E.ROW_NUM is '行号';
comment on column MBT_RPT_440_E.IS_RPT is '是否报送';
comment on column MBT_RPT_440_E.IS_VALID is '是否有效';
comment on column MBT_RPT_440_E.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_440_E.OPT_FLAG is '操作标识';
comment on column MBT_RPT_440_E.RPT_DATE is '报送日期';
comment on column MBT_RPT_440_E.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_440_E.RPT_STATUS is '报送状态';
comment on column MBT_RPT_440_E.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_440_E.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_440_E.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_440_E.REMARKS is '备注';
comment on column MBT_RPT_440_E.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_440_E.CHECK_DESC is '校验说明';
comment on column MBT_RPT_440_E.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_440_E.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_440_E.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_440_E.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_440_E.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_440_E.DATA_FLAG is '数据标志';
comment on column MBT_RPT_440_E.DATA_OP is '操作标志';
comment on column MBT_RPT_440_E.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_440_E.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_440_E.DATA_HASH is '数据HASH';
comment on column MBT_RPT_440_E.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_440_E.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_440_E.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_440_E.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_440_E.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_440_E.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_440_E.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_440_E.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_440_E.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_440_E.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_440_E.DATA_APV_USER is '审核人';
comment on column MBT_RPT_440_E.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_440_E.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_440_E.RSV1 is '备用字段';
comment on column MBT_RPT_440_E.RSV2 is '备用字段';
comment on column MBT_RPT_440_E.RSV3 is '备用字段';
comment on column MBT_RPT_440_E.RSV4 is '备用字段';
comment on column MBT_RPT_440_E.RSV5 is '备用字段';
create table MBT_RPT_440_F (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
CCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_440_F is '企业担保账户信息-抵质押物信息段';
comment on column MBT_RPT_440_F.DATA_ID is '数据ID';
comment on column MBT_RPT_440_F.DATA_DATE is '数据日期';
comment on column MBT_RPT_440_F.CORP_ID is '法人ID';
comment on column MBT_RPT_440_F.ORG_ID is '机构ID';
comment on column MBT_RPT_440_F.GROUP_ID is '数据分组';
comment on column MBT_RPT_440_F.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_440_F.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_440_F.CCC is '抵（质）押合同标识码';
comment on column MBT_RPT_440_F.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_440_F.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_440_F.CUST_NO is '客户号';
comment on column MBT_RPT_440_F.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_440_F.PART_TYPE is '段标识';
comment on column MBT_RPT_440_F.PART_NAME is '段名称';
comment on column MBT_RPT_440_F.START_DATE is '起始日期';
comment on column MBT_RPT_440_F.END_DATE is '结束日期';
comment on column MBT_RPT_440_F.BATCH_NO is '批次号';
comment on column MBT_RPT_440_F.ROW_NUM is '行号';
comment on column MBT_RPT_440_F.IS_RPT is '是否报送';
comment on column MBT_RPT_440_F.IS_VALID is '是否有效';
comment on column MBT_RPT_440_F.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_440_F.OPT_FLAG is '操作标识';
comment on column MBT_RPT_440_F.RPT_DATE is '报送日期';
comment on column MBT_RPT_440_F.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_440_F.RPT_STATUS is '报送状态';
comment on column MBT_RPT_440_F.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_440_F.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_440_F.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_440_F.REMARKS is '备注';
comment on column MBT_RPT_440_F.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_440_F.CHECK_DESC is '校验说明';
comment on column MBT_RPT_440_F.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_440_F.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_440_F.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_440_F.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_440_F.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_440_F.DATA_FLAG is '数据标志';
comment on column MBT_RPT_440_F.DATA_OP is '操作标志';
comment on column MBT_RPT_440_F.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_440_F.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_440_F.DATA_HASH is '数据HASH';
comment on column MBT_RPT_440_F.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_440_F.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_440_F.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_440_F.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_440_F.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_440_F.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_440_F.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_440_F.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_440_F.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_440_F.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_440_F.DATA_APV_USER is '审核人';
comment on column MBT_RPT_440_F.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_440_F.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_440_F.RSV1 is '备用字段';
comment on column MBT_RPT_440_F.RSV2 is '备用字段';
comment on column MBT_RPT_440_F.RSV3 is '备用字段';
comment on column MBT_RPT_440_F.RSV4 is '备用字段';
comment on column MBT_RPT_440_F.RSV5 is '备用字段';
create table MBT_RPT_440_G (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_MCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_440_G is '企业担保账户信息-授信额度信息段';
comment on column MBT_RPT_440_G.DATA_ID is '数据ID';
comment on column MBT_RPT_440_G.DATA_DATE is '数据日期';
comment on column MBT_RPT_440_G.CORP_ID is '法人ID';
comment on column MBT_RPT_440_G.ORG_ID is '机构ID';
comment on column MBT_RPT_440_G.GROUP_ID is '数据分组';
comment on column MBT_RPT_440_G.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_440_G.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_440_G.G_MCC is '授信协议标识码';
comment on column MBT_RPT_440_G.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_440_G.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_440_G.CUST_NO is '客户号';
comment on column MBT_RPT_440_G.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_440_G.PART_TYPE is '段标识';
comment on column MBT_RPT_440_G.PART_NAME is '段名称';
comment on column MBT_RPT_440_G.START_DATE is '起始日期';
comment on column MBT_RPT_440_G.END_DATE is '结束日期';
comment on column MBT_RPT_440_G.BATCH_NO is '批次号';
comment on column MBT_RPT_440_G.ROW_NUM is '行号';
comment on column MBT_RPT_440_G.IS_RPT is '是否报送';
comment on column MBT_RPT_440_G.IS_VALID is '是否有效';
comment on column MBT_RPT_440_G.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_440_G.OPT_FLAG is '操作标识';
comment on column MBT_RPT_440_G.RPT_DATE is '报送日期';
comment on column MBT_RPT_440_G.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_440_G.RPT_STATUS is '报送状态';
comment on column MBT_RPT_440_G.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_440_G.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_440_G.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_440_G.REMARKS is '备注';
comment on column MBT_RPT_440_G.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_440_G.CHECK_DESC is '校验说明';
comment on column MBT_RPT_440_G.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_440_G.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_440_G.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_440_G.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_440_G.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_440_G.DATA_FLAG is '数据标志';
comment on column MBT_RPT_440_G.DATA_OP is '操作标志';
comment on column MBT_RPT_440_G.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_440_G.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_440_G.DATA_HASH is '数据HASH';
comment on column MBT_RPT_440_G.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_440_G.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_440_G.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_440_G.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_440_G.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_440_G.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_440_G.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_440_G.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_440_G.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_440_G.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_440_G.DATA_APV_USER is '审核人';
comment on column MBT_RPT_440_G.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_440_G.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_440_G.RSV1 is '备用字段';
comment on column MBT_RPT_440_G.RSV2 is '备用字段';
comment on column MBT_RPT_440_G.RSV3 is '备用字段';
comment on column MBT_RPT_440_G.RSV4 is '备用字段';
comment on column MBT_RPT_440_G.RSV5 is '备用字段';
