create table MBT_DM_210 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
O_BIZ_CODE VARCHAR(60),
N_BIZ_CODE VARCHAR(60),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_210 is '个人借贷账户信息';
comment on column MBT_DM_210.DATA_ID is '数据ID';
comment on column MBT_DM_210.DATA_DATE is '数据日期';
comment on column MBT_DM_210.CORP_ID is '法人ID';
comment on column MBT_DM_210.ORG_ID is '机构ID';
comment on column MBT_DM_210.GROUP_ID is '数据分组';
comment on column MBT_DM_210.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_210.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_210.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_210.O_BIZ_CODE is '原业务标识码';
comment on column MBT_DM_210.N_BIZ_CODE is '新业务标识码';
comment on column MBT_DM_210.SECTION_CHG_CNT is '段变更';
comment on column MBT_DM_210.SECTION_DEL_CNT is '段删除';
comment on column MBT_DM_210.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_DM_210.IDN_CHG_CNT is '标识项变更';
comment on column MBT_DM_210.CUST_NO is '客户号';
comment on column MBT_DM_210.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_210.PART_TYPE is '段标识';
comment on column MBT_DM_210.PART_NAME is '段名称';
comment on column MBT_DM_210.START_DATE is '起始日期';
comment on column MBT_DM_210.END_DATE is '结束日期';
comment on column MBT_DM_210.BATCH_NO is '批次号';
comment on column MBT_DM_210.ROW_NUM is '行号';
comment on column MBT_DM_210.IS_RPT is '是否报送';
comment on column MBT_DM_210.IS_VALID is '是否有效';
comment on column MBT_DM_210.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_210.OPT_FLAG is '操作标识';
comment on column MBT_DM_210.RPT_DATE is '报送日期';
comment on column MBT_DM_210.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_210.RPT_STATUS is '报送状态';
comment on column MBT_DM_210.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_210.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_210.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_210.REMARKS is '备注';
comment on column MBT_DM_210.CHECK_FLAG is '校验标志';
comment on column MBT_DM_210.CHECK_DESC is '校验说明';
comment on column MBT_DM_210.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_210.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_210.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_210.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_210.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_210.DATA_FLAG is '数据标志';
comment on column MBT_DM_210.DATA_OP is '操作标志';
comment on column MBT_DM_210.DATA_SOURCE is '数据来源';
comment on column MBT_DM_210.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_210.DATA_HASH is '数据HASH';
comment on column MBT_DM_210.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_210.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_210.DATA_CRT_USER is '创建人';
comment on column MBT_DM_210.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_210.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_210.DATA_CHG_USER is '修改人';
comment on column MBT_DM_210.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_210.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_210.DATA_APV_USER is '审核人';
comment on column MBT_DM_210.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_210.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_210.RSV1 is '备用字段';
comment on column MBT_DM_210.RSV2 is '备用字段';
comment on column MBT_DM_210.RSV3 is '备用字段';
comment on column MBT_DM_210.RSV4 is '备用字段';
comment on column MBT_DM_210.RSV5 is '备用字段';
create table MBT_DM_210_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_TYPE VARCHAR(2),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_REC_TYPE VARCHAR(3),
B_MNGMT_ORG_CODE VARCHAR(14),
B_NAME VARCHAR(60),
B_RPT_DATE_CODE VARCHAR(2),
MON_SETTLE_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_210_B is '个人借贷账户信息-基础段';
comment on column MBT_DM_210_B.DATA_ID is '数据ID';
comment on column MBT_DM_210_B.DATA_DATE is '数据日期';
comment on column MBT_DM_210_B.CORP_ID is '法人ID';
comment on column MBT_DM_210_B.ORG_ID is '机构ID';
comment on column MBT_DM_210_B.GROUP_ID is '数据分组';
comment on column MBT_DM_210_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_210_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_210_B.B_ACCT_TYPE is '账户类型';
comment on column MBT_DM_210_B.B_ID_NUM is '借款人证件号码';
comment on column MBT_DM_210_B.B_ID_TYPE is '借款人证件类型';
comment on column MBT_DM_210_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_DM_210_B.B_MNGMT_ORG_CODE is '业务管理机构代码';
comment on column MBT_DM_210_B.B_NAME is '借款人姓名';
comment on column MBT_DM_210_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_DM_210_B.MON_SETTLE_DATE is '月度结算日';
comment on column MBT_DM_210_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_210_B.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_210_B.CUST_NO is '客户号';
comment on column MBT_DM_210_B.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_210_B.PART_TYPE is '段标识';
comment on column MBT_DM_210_B.PART_NAME is '段名称';
comment on column MBT_DM_210_B.START_DATE is '起始日期';
comment on column MBT_DM_210_B.END_DATE is '结束日期';
comment on column MBT_DM_210_B.BATCH_NO is '批次号';
comment on column MBT_DM_210_B.ROW_NUM is '行号';
comment on column MBT_DM_210_B.IS_RPT is '是否报送';
comment on column MBT_DM_210_B.IS_VALID is '是否有效';
comment on column MBT_DM_210_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_210_B.OPT_FLAG is '操作标识';
comment on column MBT_DM_210_B.RPT_DATE is '报送日期';
comment on column MBT_DM_210_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_210_B.RPT_STATUS is '报送状态';
comment on column MBT_DM_210_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_210_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_210_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_210_B.REMARKS is '备注';
comment on column MBT_DM_210_B.CHECK_FLAG is '校验标志';
comment on column MBT_DM_210_B.CHECK_DESC is '校验说明';
comment on column MBT_DM_210_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_210_B.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_210_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_210_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_210_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_210_B.DATA_FLAG is '数据标志';
comment on column MBT_DM_210_B.DATA_OP is '操作标志';
comment on column MBT_DM_210_B.DATA_SOURCE is '数据来源';
comment on column MBT_DM_210_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_210_B.DATA_HASH is '数据HASH';
comment on column MBT_DM_210_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_210_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_210_B.DATA_CRT_USER is '创建人';
comment on column MBT_DM_210_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_210_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_210_B.DATA_CHG_USER is '修改人';
comment on column MBT_DM_210_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_210_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_210_B.DATA_APV_USER is '审核人';
comment on column MBT_DM_210_B.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_210_B.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_210_B.RSV1 is '备用字段';
comment on column MBT_DM_210_B.RSV2 is '备用字段';
comment on column MBT_DM_210_B.RSV3 is '备用字段';
comment on column MBT_DM_210_B.RSV4 is '备用字段';
comment on column MBT_DM_210_B.RSV5 is '备用字段';
create table MBT_DM_210_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ACCT_CRED_LINE_AMT NUMBER(15),
C_ACCT_CRED_LINE_AMT_LCY NUMBER(15),
C_ACCT_CRED_LINE_AMT_ORG NUMBER(15),
C_APPLY_BUSI_DIST VARCHAR(6),
C_ASSET_TRAND_FLAG VARCHAR(1),
C_BUSI_DTL_LINES VARCHAR(2),
C_BUSI_LINES VARCHAR(1),
C_CREDIT_ID VARCHAR(4),
C_CY VARCHAR(3),
C_DUE_DATE VARCHAR(8),
C_FIRST_HOU_LOAN_FLAG VARCHAR(2),
C_FLAG VARCHAR(1),
C_FUND_SOU VARCHAR(2),
C_GUAR_MODE VARCHAR(1),
C_LOAN_AMT NUMBER(15),
C_LOAN_AMT_LCY NUMBER(15),
C_LOAN_AMT_ORG NUMBER(15),
C_LOAN_CON_CODE VARCHAR(200),
C_LOAN_FORM VARCHAR(1),
C_OPEN_DATE VARCHAR(8),
C_OTH_REPY_GUAR_WAY VARCHAR(2),
C_REPAY_FREQCY VARCHAR(2),
C_REPAY_MODE VARCHAR(2),
C_REPAY_PRD NUMBER(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_210_C is '个人借贷账户信息-基本信息段';
comment on column MBT_DM_210_C.DATA_ID is '数据ID';
comment on column MBT_DM_210_C.DATA_DATE is '数据日期';
comment on column MBT_DM_210_C.CORP_ID is '法人ID';
comment on column MBT_DM_210_C.ORG_ID is '机构ID';
comment on column MBT_DM_210_C.GROUP_ID is '数据分组';
comment on column MBT_DM_210_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_210_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_210_C.C_ACCT_CRED_LINE_AMT is '信用额度';
comment on column MBT_DM_210_C.C_ACCT_CRED_LINE_AMT_LCY is '信用额度人民币金额';
comment on column MBT_DM_210_C.C_ACCT_CRED_LINE_AMT_ORG is '信用额度_原始数据金额';
comment on column MBT_DM_210_C.C_APPLY_BUSI_DIST is '业务申请地行政区划代码';
comment on column MBT_DM_210_C.C_ASSET_TRAND_FLAG is '资产转让标志';
comment on column MBT_DM_210_C.C_BUSI_DTL_LINES is '借贷业务种类细分';
comment on column MBT_DM_210_C.C_BUSI_LINES is '借贷业务大类';
comment on column MBT_DM_210_C.C_CREDIT_ID is '卡片标识号';
comment on column MBT_DM_210_C.C_CY is '币种';
comment on column MBT_DM_210_C.C_DUE_DATE is '到期日期';
comment on column MBT_DM_210_C.C_FIRST_HOU_LOAN_FLAG is '是否为首套住房贷款';
comment on column MBT_DM_210_C.C_FLAG is '分次放款标志';
comment on column MBT_DM_210_C.C_FUND_SOU is '业务经营类型';
comment on column MBT_DM_210_C.C_GUAR_MODE is '担保方式';
comment on column MBT_DM_210_C.C_LOAN_AMT is '借款金额';
comment on column MBT_DM_210_C.C_LOAN_AMT_LCY is '借款金额人民币金额';
comment on column MBT_DM_210_C.C_LOAN_AMT_ORG is '借款金额_原始数据金额';
comment on column MBT_DM_210_C.C_LOAN_CON_CODE is '贷款合同编号';
comment on column MBT_DM_210_C.C_LOAN_FORM is '贷款发放形式';
comment on column MBT_DM_210_C.C_OPEN_DATE is '开户日期';
comment on column MBT_DM_210_C.C_OTH_REPY_GUAR_WAY is '其他还款保证方式';
comment on column MBT_DM_210_C.C_REPAY_FREQCY is '还款频率';
comment on column MBT_DM_210_C.C_REPAY_MODE is '还款方式';
comment on column MBT_DM_210_C.C_REPAY_PRD is '还款期数';
comment on column MBT_DM_210_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_210_C.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_210_C.CUST_NO is '客户号';
comment on column MBT_DM_210_C.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_210_C.PART_TYPE is '段标识';
comment on column MBT_DM_210_C.PART_NAME is '段名称';
comment on column MBT_DM_210_C.START_DATE is '起始日期';
comment on column MBT_DM_210_C.END_DATE is '结束日期';
comment on column MBT_DM_210_C.BATCH_NO is '批次号';
comment on column MBT_DM_210_C.ROW_NUM is '行号';
comment on column MBT_DM_210_C.IS_RPT is '是否报送';
comment on column MBT_DM_210_C.IS_VALID is '是否有效';
comment on column MBT_DM_210_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_210_C.OPT_FLAG is '操作标识';
comment on column MBT_DM_210_C.RPT_DATE is '报送日期';
comment on column MBT_DM_210_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_210_C.RPT_STATUS is '报送状态';
comment on column MBT_DM_210_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_210_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_210_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_210_C.REMARKS is '备注';
comment on column MBT_DM_210_C.CHECK_FLAG is '校验标志';
comment on column MBT_DM_210_C.CHECK_DESC is '校验说明';
comment on column MBT_DM_210_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_210_C.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_210_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_210_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_210_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_210_C.DATA_FLAG is '数据标志';
comment on column MBT_DM_210_C.DATA_OP is '操作标志';
comment on column MBT_DM_210_C.DATA_SOURCE is '数据来源';
comment on column MBT_DM_210_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_210_C.DATA_HASH is '数据HASH';
comment on column MBT_DM_210_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_210_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_210_C.DATA_CRT_USER is '创建人';
comment on column MBT_DM_210_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_210_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_210_C.DATA_CHG_USER is '修改人';
comment on column MBT_DM_210_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_210_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_210_C.DATA_APV_USER is '审核人';
comment on column MBT_DM_210_C.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_210_C.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_210_C.RSV1 is '备用字段';
comment on column MBT_DM_210_C.RSV2 is '备用字段';
comment on column MBT_DM_210_C.RSV3 is '备用字段';
comment on column MBT_DM_210_C.RSV4 is '备用字段';
comment on column MBT_DM_210_C.RSV5 is '备用字段';
create table MBT_DM_210_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ARLP_AMT NUMBER(15),
D_ARLP_AMT_LCY NUMBER(15),
D_ARLP_AMT_ORG NUMBER(15),
D_ARLP_CERT_NUM VARCHAR(80),
D_ARLP_CERT_TYPE VARCHAR(2),
D_ARLP_ID_TYPE VARCHAR(2),
D_ARLP_NAME VARCHAR(160),
D_ARLP_TYPE VARCHAR(1),
D_MAX_GUAR_MCC VARCHAR(60),
D_WARTY_SIGN VARCHAR(1),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_210_D is '个人借贷账户信息-相关还款责任人段';
comment on column MBT_DM_210_D.DATA_ID is '数据ID';
comment on column MBT_DM_210_D.DATA_DATE is '数据日期';
comment on column MBT_DM_210_D.CORP_ID is '法人ID';
comment on column MBT_DM_210_D.ORG_ID is '机构ID';
comment on column MBT_DM_210_D.GROUP_ID is '数据分组';
comment on column MBT_DM_210_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_210_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_210_D.D_ARLP_AMT is '还款责任金额';
comment on column MBT_DM_210_D.D_ARLP_AMT_LCY is '还款责任金额人民币金额';
comment on column MBT_DM_210_D.D_ARLP_AMT_ORG is '还款责任金额_原始数据金额';
comment on column MBT_DM_210_D.D_ARLP_CERT_NUM is '责任人身份标识号码';
comment on column MBT_DM_210_D.D_ARLP_CERT_TYPE is '责任人身份标识类型';
comment on column MBT_DM_210_D.D_ARLP_ID_TYPE is '身份类别';
comment on column MBT_DM_210_D.D_ARLP_NAME is '责任人名称';
comment on column MBT_DM_210_D.D_ARLP_TYPE is '还款责任人类型';
comment on column MBT_DM_210_D.D_MAX_GUAR_MCC is '保证合同编号';
comment on column MBT_DM_210_D.D_WARTY_SIGN is '联保标志';
comment on column MBT_DM_210_D.C_CY is '币种';
comment on column MBT_DM_210_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_210_D.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_210_D.CUST_NO is '客户号';
comment on column MBT_DM_210_D.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_210_D.PART_TYPE is '段标识';
comment on column MBT_DM_210_D.PART_NAME is '段名称';
comment on column MBT_DM_210_D.START_DATE is '起始日期';
comment on column MBT_DM_210_D.END_DATE is '结束日期';
comment on column MBT_DM_210_D.BATCH_NO is '批次号';
comment on column MBT_DM_210_D.ROW_NUM is '行号';
comment on column MBT_DM_210_D.IS_RPT is '是否报送';
comment on column MBT_DM_210_D.IS_VALID is '是否有效';
comment on column MBT_DM_210_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_210_D.OPT_FLAG is '操作标识';
comment on column MBT_DM_210_D.RPT_DATE is '报送日期';
comment on column MBT_DM_210_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_210_D.RPT_STATUS is '报送状态';
comment on column MBT_DM_210_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_210_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_210_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_210_D.REMARKS is '备注';
comment on column MBT_DM_210_D.CHECK_FLAG is '校验标志';
comment on column MBT_DM_210_D.CHECK_DESC is '校验说明';
comment on column MBT_DM_210_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_210_D.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_210_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_210_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_210_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_210_D.DATA_FLAG is '数据标志';
comment on column MBT_DM_210_D.DATA_OP is '操作标志';
comment on column MBT_DM_210_D.DATA_SOURCE is '数据来源';
comment on column MBT_DM_210_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_210_D.DATA_HASH is '数据HASH';
comment on column MBT_DM_210_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_210_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_210_D.DATA_CRT_USER is '创建人';
comment on column MBT_DM_210_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_210_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_210_D.DATA_CHG_USER is '修改人';
comment on column MBT_DM_210_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_210_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_210_D.DATA_APV_USER is '审核人';
comment on column MBT_DM_210_D.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_210_D.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_210_D.RSV1 is '备用字段';
comment on column MBT_DM_210_D.RSV2 is '备用字段';
comment on column MBT_DM_210_D.RSV3 is '备用字段';
comment on column MBT_DM_210_D.RSV4 is '备用字段';
comment on column MBT_DM_210_D.RSV5 is '备用字段';
create table MBT_DM_210_E (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
E_CCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_210_E is '个人借贷账户信息-抵质押物信息段';
comment on column MBT_DM_210_E.DATA_ID is '数据ID';
comment on column MBT_DM_210_E.DATA_DATE is '数据日期';
comment on column MBT_DM_210_E.CORP_ID is '法人ID';
comment on column MBT_DM_210_E.ORG_ID is '机构ID';
comment on column MBT_DM_210_E.GROUP_ID is '数据分组';
comment on column MBT_DM_210_E.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_210_E.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_210_E.E_CCC is '抵（质）押合同标识码';
comment on column MBT_DM_210_E.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_210_E.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_210_E.CUST_NO is '客户号';
comment on column MBT_DM_210_E.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_210_E.PART_TYPE is '段标识';
comment on column MBT_DM_210_E.PART_NAME is '段名称';
comment on column MBT_DM_210_E.START_DATE is '起始日期';
comment on column MBT_DM_210_E.END_DATE is '结束日期';
comment on column MBT_DM_210_E.BATCH_NO is '批次号';
comment on column MBT_DM_210_E.ROW_NUM is '行号';
comment on column MBT_DM_210_E.IS_RPT is '是否报送';
comment on column MBT_DM_210_E.IS_VALID is '是否有效';
comment on column MBT_DM_210_E.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_210_E.OPT_FLAG is '操作标识';
comment on column MBT_DM_210_E.RPT_DATE is '报送日期';
comment on column MBT_DM_210_E.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_210_E.RPT_STATUS is '报送状态';
comment on column MBT_DM_210_E.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_210_E.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_210_E.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_210_E.REMARKS is '备注';
comment on column MBT_DM_210_E.CHECK_FLAG is '校验标志';
comment on column MBT_DM_210_E.CHECK_DESC is '校验说明';
comment on column MBT_DM_210_E.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_210_E.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_210_E.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_210_E.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_210_E.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_210_E.DATA_FLAG is '数据标志';
comment on column MBT_DM_210_E.DATA_OP is '操作标志';
comment on column MBT_DM_210_E.DATA_SOURCE is '数据来源';
comment on column MBT_DM_210_E.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_210_E.DATA_HASH is '数据HASH';
comment on column MBT_DM_210_E.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_E.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_E.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_210_E.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_210_E.DATA_CRT_USER is '创建人';
comment on column MBT_DM_210_E.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_210_E.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_210_E.DATA_CHG_USER is '修改人';
comment on column MBT_DM_210_E.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_210_E.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_210_E.DATA_APV_USER is '审核人';
comment on column MBT_DM_210_E.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_210_E.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_210_E.RSV1 is '备用字段';
comment on column MBT_DM_210_E.RSV2 is '备用字段';
comment on column MBT_DM_210_E.RSV3 is '备用字段';
comment on column MBT_DM_210_E.RSV4 is '备用字段';
comment on column MBT_DM_210_E.RSV5 is '备用字段';
create table MBT_DM_210_F (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
F_MCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_210_F is '个人借贷账户信息-授信额度信息段';
comment on column MBT_DM_210_F.DATA_ID is '数据ID';
comment on column MBT_DM_210_F.DATA_DATE is '数据日期';
comment on column MBT_DM_210_F.CORP_ID is '法人ID';
comment on column MBT_DM_210_F.ORG_ID is '机构ID';
comment on column MBT_DM_210_F.GROUP_ID is '数据分组';
comment on column MBT_DM_210_F.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_210_F.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_210_F.F_MCC is '授信协议标识码';
comment on column MBT_DM_210_F.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_210_F.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_210_F.CUST_NO is '客户号';
comment on column MBT_DM_210_F.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_210_F.PART_TYPE is '段标识';
comment on column MBT_DM_210_F.PART_NAME is '段名称';
comment on column MBT_DM_210_F.START_DATE is '起始日期';
comment on column MBT_DM_210_F.END_DATE is '结束日期';
comment on column MBT_DM_210_F.BATCH_NO is '批次号';
comment on column MBT_DM_210_F.ROW_NUM is '行号';
comment on column MBT_DM_210_F.IS_RPT is '是否报送';
comment on column MBT_DM_210_F.IS_VALID is '是否有效';
comment on column MBT_DM_210_F.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_210_F.OPT_FLAG is '操作标识';
comment on column MBT_DM_210_F.RPT_DATE is '报送日期';
comment on column MBT_DM_210_F.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_210_F.RPT_STATUS is '报送状态';
comment on column MBT_DM_210_F.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_210_F.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_210_F.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_210_F.REMARKS is '备注';
comment on column MBT_DM_210_F.CHECK_FLAG is '校验标志';
comment on column MBT_DM_210_F.CHECK_DESC is '校验说明';
comment on column MBT_DM_210_F.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_210_F.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_210_F.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_210_F.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_210_F.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_210_F.DATA_FLAG is '数据标志';
comment on column MBT_DM_210_F.DATA_OP is '操作标志';
comment on column MBT_DM_210_F.DATA_SOURCE is '数据来源';
comment on column MBT_DM_210_F.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_210_F.DATA_HASH is '数据HASH';
comment on column MBT_DM_210_F.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_F.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_F.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_210_F.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_210_F.DATA_CRT_USER is '创建人';
comment on column MBT_DM_210_F.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_210_F.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_210_F.DATA_CHG_USER is '修改人';
comment on column MBT_DM_210_F.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_210_F.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_210_F.DATA_APV_USER is '审核人';
comment on column MBT_DM_210_F.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_210_F.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_210_F.RSV1 is '备用字段';
comment on column MBT_DM_210_F.RSV2 is '备用字段';
comment on column MBT_DM_210_F.RSV3 is '备用字段';
comment on column MBT_DM_210_F.RSV4 is '备用字段';
comment on column MBT_DM_210_F.RSV5 is '备用字段';
create table MBT_DM_210_G (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_INIT_CRED_NAME VARCHAR(160),
G_INIT_CRED_ORG_NM VARCHAR(18),
G_INIT_RPY_STS VARCHAR(1),
G_ORIG_DBT_CATE VARCHAR(1),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_210_G is '个人借贷账户信息-初始债权说明段';
comment on column MBT_DM_210_G.DATA_ID is '数据ID';
comment on column MBT_DM_210_G.DATA_DATE is '数据日期';
comment on column MBT_DM_210_G.CORP_ID is '法人ID';
comment on column MBT_DM_210_G.ORG_ID is '机构ID';
comment on column MBT_DM_210_G.GROUP_ID is '数据分组';
comment on column MBT_DM_210_G.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_210_G.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_210_G.G_INIT_CRED_NAME is '初始债权人名称';
comment on column MBT_DM_210_G.G_INIT_CRED_ORG_NM is '初始债权人机构代码';
comment on column MBT_DM_210_G.G_INIT_RPY_STS is '债权转移时的还款状态';
comment on column MBT_DM_210_G.G_ORIG_DBT_CATE is '原债务种类';
comment on column MBT_DM_210_G.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_210_G.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_210_G.CUST_NO is '客户号';
comment on column MBT_DM_210_G.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_210_G.PART_TYPE is '段标识';
comment on column MBT_DM_210_G.PART_NAME is '段名称';
comment on column MBT_DM_210_G.START_DATE is '起始日期';
comment on column MBT_DM_210_G.END_DATE is '结束日期';
comment on column MBT_DM_210_G.BATCH_NO is '批次号';
comment on column MBT_DM_210_G.ROW_NUM is '行号';
comment on column MBT_DM_210_G.IS_RPT is '是否报送';
comment on column MBT_DM_210_G.IS_VALID is '是否有效';
comment on column MBT_DM_210_G.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_210_G.OPT_FLAG is '操作标识';
comment on column MBT_DM_210_G.RPT_DATE is '报送日期';
comment on column MBT_DM_210_G.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_210_G.RPT_STATUS is '报送状态';
comment on column MBT_DM_210_G.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_210_G.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_210_G.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_210_G.REMARKS is '备注';
comment on column MBT_DM_210_G.CHECK_FLAG is '校验标志';
comment on column MBT_DM_210_G.CHECK_DESC is '校验说明';
comment on column MBT_DM_210_G.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_210_G.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_210_G.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_210_G.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_210_G.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_210_G.DATA_FLAG is '数据标志';
comment on column MBT_DM_210_G.DATA_OP is '操作标志';
comment on column MBT_DM_210_G.DATA_SOURCE is '数据来源';
comment on column MBT_DM_210_G.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_210_G.DATA_HASH is '数据HASH';
comment on column MBT_DM_210_G.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_G.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_G.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_210_G.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_210_G.DATA_CRT_USER is '创建人';
comment on column MBT_DM_210_G.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_210_G.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_210_G.DATA_CHG_USER is '修改人';
comment on column MBT_DM_210_G.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_210_G.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_210_G.DATA_APV_USER is '审核人';
comment on column MBT_DM_210_G.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_210_G.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_210_G.RSV1 is '备用字段';
comment on column MBT_DM_210_G.RSV2 is '备用字段';
comment on column MBT_DM_210_G.RSV3 is '备用字段';
comment on column MBT_DM_210_G.RSV4 is '备用字段';
comment on column MBT_DM_210_G.RSV5 is '备用字段';
create table MBT_DM_210_H (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
H_ACCT_BAL NUMBER(15),
H_ACCT_BAL_LCY NUMBER(15),
H_ACCT_BAL_ORG NUMBER(15),
H_ACCT_STATUS VARCHAR(2),
H_ACT_RPY_AMT NUMBER(15),
H_ACT_RPY_AMT_LCY NUMBER(15),
H_ACT_RPY_AMT_ORG NUMBER(15),
H_CLOSE_DATE VARCHAR(8),
H_CUR_RPY_AMT NUMBER(15),
H_CUR_RPY_AMT_LCY NUMBER(15),
H_CUR_RPY_AMT_ORG NUMBER(15),
H_FIVE_CATE VARCHAR(1),
H_FIVE_CATE_ADJ_DATE VARCHAR(8),
H_LAT_RPY_DATE VARCHAR(8),
H_MONTH VARCHAR(7),
H_NOTLSU_BAL NUMBER(15),
H_NOTLSU_BAL_LCY NUMBER(15),
H_NOTLSU_BAL_ORG NUMBER(15),
H_OVAER_PRINC NUMBER(15),
H_OVAER_PRINC_LCY NUMBER(15),
H_OVAER_PRINC_ORG NUMBER(15),
H_OVERD31_60PRINC NUMBER(15),
H_OVERD31_60PRINC_LCY NUMBER(15),
H_OVERD31_60PRINC_ORG NUMBER(15),
H_OVERD61_90PRINC NUMBER(15),
H_OVERD61_90PRINC_LCY NUMBER(15),
H_OVERD61_90PRINC_ORG NUMBER(15),
H_OVERD91_180PRINC NUMBER(15),
H_OVERD91_180PRINC_LCY NUMBER(15),
H_OVERD91_180PRINC_ORG NUMBER(15),
H_OVERD_PRD NUMBER(3),
H_OVERD_PRINC180 NUMBER(15),
H_OVERD_PRINC180_LCY NUMBER(15),
H_OVERD_PRINC180_ORG NUMBER(15),
H_OVERD_RAW_BA_OVE180 NUMBER(15),
H_OVERD_RAW_BA_OVE180_LCY NUMBER(15),
H_OVERD_RAW_BA_OVE180_ORG NUMBER(15),
H_PRID_ACCT_BAL NUMBER(15),
H_PRID_ACCT_BAL_LCY NUMBER(15),
H_PRID_ACCT_BAL_ORG NUMBER(15),
H_REM_REP_PRD NUMBER(3),
H_RPY_PRCT NUMBER(3),
H_RPY_STATUS VARCHAR(1),
H_SETT_DATE VARCHAR(8),
H_TOT_OVERD NUMBER(15),
H_TOT_OVERD_LCY NUMBER(15),
H_TOT_OVERD_ORG NUMBER(15),
H_USED_AMT NUMBER(15),
H_USED_AMT_LCY NUMBER(15),
H_USED_AMT_ORG NUMBER(15),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_210_H is '个人借贷账户信息-月度表现信息段';
comment on column MBT_DM_210_H.DATA_ID is '数据ID';
comment on column MBT_DM_210_H.DATA_DATE is '数据日期';
comment on column MBT_DM_210_H.CORP_ID is '法人ID';
comment on column MBT_DM_210_H.ORG_ID is '机构ID';
comment on column MBT_DM_210_H.GROUP_ID is '数据分组';
comment on column MBT_DM_210_H.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_210_H.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_210_H.H_ACCT_BAL is '余额';
comment on column MBT_DM_210_H.H_ACCT_BAL_LCY is '余额人民币金额';
comment on column MBT_DM_210_H.H_ACCT_BAL_ORG is '余额_原始数据金额';
comment on column MBT_DM_210_H.H_ACCT_STATUS is '账户状态';
comment on column MBT_DM_210_H.H_ACT_RPY_AMT is '本月实际还款金额';
comment on column MBT_DM_210_H.H_ACT_RPY_AMT_LCY is '本月实际还款金额人民币金额';
comment on column MBT_DM_210_H.H_ACT_RPY_AMT_ORG is '本月实际还款金额_原始数据金额';
comment on column MBT_DM_210_H.H_CLOSE_DATE is '账户关闭日期';
comment on column MBT_DM_210_H.H_CUR_RPY_AMT is '本月应还款金额';
comment on column MBT_DM_210_H.H_CUR_RPY_AMT_LCY is '本月应还款金额人民币金额';
comment on column MBT_DM_210_H.H_CUR_RPY_AMT_ORG is '本月应还款金额_原始数据金额';
comment on column MBT_DM_210_H.H_FIVE_CATE is '五级分类';
comment on column MBT_DM_210_H.H_FIVE_CATE_ADJ_DATE is '五级分类认定日期';
comment on column MBT_DM_210_H.H_LAT_RPY_DATE is '最近一次实际还款日期';
comment on column MBT_DM_210_H.H_MONTH is '月份';
comment on column MBT_DM_210_H.H_NOTLSU_BAL is '未出单的大额专项分期余额';
comment on column MBT_DM_210_H.H_NOTLSU_BAL_LCY is '未出单的大额专项分期余额人民币金额';
comment on column MBT_DM_210_H.H_NOTLSU_BAL_ORG is '未出单的大额专项分期余额_原始数据金额';
comment on column MBT_DM_210_H.H_OVAER_PRINC is '当前逾期本金';
comment on column MBT_DM_210_H.H_OVAER_PRINC_LCY is '当前逾期本金人民币金额';
comment on column MBT_DM_210_H.H_OVAER_PRINC_ORG is '当前逾期本金_原始数据金额';
comment on column MBT_DM_210_H.H_OVERD31_60PRINC is '逾期31-60天未归还本金';
comment on column MBT_DM_210_H.H_OVERD31_60PRINC_LCY is '逾期31-60天未归还本金人民币金额';
comment on column MBT_DM_210_H.H_OVERD31_60PRINC_ORG is '逾期31-60天未归还本金_原始数据金额';
comment on column MBT_DM_210_H.H_OVERD61_90PRINC is '逾期61-90天未归还本金';
comment on column MBT_DM_210_H.H_OVERD61_90PRINC_LCY is '逾期61-90天未归还本金人民币金额';
comment on column MBT_DM_210_H.H_OVERD61_90PRINC_ORG is '逾期61-90天未归还本金_原始数据金额';
comment on column MBT_DM_210_H.H_OVERD91_180PRINC is '逾期91-180天未归还本金';
comment on column MBT_DM_210_H.H_OVERD91_180PRINC_LCY is '逾期91-180天未归还本金人民币金额';
comment on column MBT_DM_210_H.H_OVERD91_180PRINC_ORG is '逾期91-180天未归还本金_原始数据金额';
comment on column MBT_DM_210_H.H_OVERD_PRD is '当前逾期期数';
comment on column MBT_DM_210_H.H_OVERD_PRINC180 is '逾期180天以上未归还本金';
comment on column MBT_DM_210_H.H_OVERD_PRINC180_LCY is '逾期180天以上未归还本金人民币金额';
comment on column MBT_DM_210_H.H_OVERD_PRINC180_ORG is '逾期180天以上未归还本金_原始数据金额';
comment on column MBT_DM_210_H.H_OVERD_RAW_BA_OVE180 is '透支180天以上未还余额';
comment on column MBT_DM_210_H.H_OVERD_RAW_BA_OVE180_LCY is '透支180天以上未还余额人民币金额';
comment on column MBT_DM_210_H.H_OVERD_RAW_BA_OVE180_ORG is '透支180天以上未还余额_原始数据金额';
comment on column MBT_DM_210_H.H_PRID_ACCT_BAL is '本期账单余额';
comment on column MBT_DM_210_H.H_PRID_ACCT_BAL_LCY is '本期账单余额人民币金额';
comment on column MBT_DM_210_H.H_PRID_ACCT_BAL_ORG is '本期账单余额_原始数据金额';
comment on column MBT_DM_210_H.H_REM_REP_PRD is '剩余还款期数';
comment on column MBT_DM_210_H.H_RPY_PRCT is '实际还款百分比';
comment on column MBT_DM_210_H.H_RPY_STATUS is '当前还款状态';
comment on column MBT_DM_210_H.H_SETT_DATE is '结算/应还款日';
comment on column MBT_DM_210_H.H_TOT_OVERD is '当前逾期总额';
comment on column MBT_DM_210_H.H_TOT_OVERD_LCY is '当前逾期总额人民币金额';
comment on column MBT_DM_210_H.H_TOT_OVERD_ORG is '当前逾期总额_原始数据金额';
comment on column MBT_DM_210_H.H_USED_AMT is '已使用额度';
comment on column MBT_DM_210_H.H_USED_AMT_LCY is '已使用额度人民币金额';
comment on column MBT_DM_210_H.H_USED_AMT_ORG is '已使用额度_原始数据金额';
comment on column MBT_DM_210_H.C_CY is '币种';
comment on column MBT_DM_210_H.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_210_H.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_210_H.CUST_NO is '客户号';
comment on column MBT_DM_210_H.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_210_H.PART_TYPE is '段标识';
comment on column MBT_DM_210_H.PART_NAME is '段名称';
comment on column MBT_DM_210_H.START_DATE is '起始日期';
comment on column MBT_DM_210_H.END_DATE is '结束日期';
comment on column MBT_DM_210_H.BATCH_NO is '批次号';
comment on column MBT_DM_210_H.ROW_NUM is '行号';
comment on column MBT_DM_210_H.IS_RPT is '是否报送';
comment on column MBT_DM_210_H.IS_VALID is '是否有效';
comment on column MBT_DM_210_H.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_210_H.OPT_FLAG is '操作标识';
comment on column MBT_DM_210_H.RPT_DATE is '报送日期';
comment on column MBT_DM_210_H.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_210_H.RPT_STATUS is '报送状态';
comment on column MBT_DM_210_H.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_210_H.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_210_H.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_210_H.REMARKS is '备注';
comment on column MBT_DM_210_H.CHECK_FLAG is '校验标志';
comment on column MBT_DM_210_H.CHECK_DESC is '校验说明';
comment on column MBT_DM_210_H.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_210_H.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_210_H.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_210_H.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_210_H.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_210_H.DATA_FLAG is '数据标志';
comment on column MBT_DM_210_H.DATA_OP is '操作标志';
comment on column MBT_DM_210_H.DATA_SOURCE is '数据来源';
comment on column MBT_DM_210_H.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_210_H.DATA_HASH is '数据HASH';
comment on column MBT_DM_210_H.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_H.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_H.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_210_H.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_210_H.DATA_CRT_USER is '创建人';
comment on column MBT_DM_210_H.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_210_H.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_210_H.DATA_CHG_USER is '修改人';
comment on column MBT_DM_210_H.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_210_H.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_210_H.DATA_APV_USER is '审核人';
comment on column MBT_DM_210_H.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_210_H.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_210_H.RSV1 is '备用字段';
comment on column MBT_DM_210_H.RSV2 is '备用字段';
comment on column MBT_DM_210_H.RSV3 is '备用字段';
comment on column MBT_DM_210_H.RSV4 is '备用字段';
comment on column MBT_DM_210_H.RSV5 is '备用字段';
create table MBT_DM_210_I (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
I_SPEC_EFCT_DATE VARCHAR(8),
I_SPEC_END_DATE VARCHAR(8),
I_SPEC_LINE NUMBER(15),
I_SPEC_LINE_LCY NUMBER(15),
I_SPEC_LINE_ORG NUMBER(15),
I_USED_INST_AMT NUMBER(15),
I_USED_INST_AMT_LCY NUMBER(15),
I_USED_INST_AMT_ORG NUMBER(15),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_210_I is '个人借贷账户信息-大额专项分期信息段';
comment on column MBT_DM_210_I.DATA_ID is '数据ID';
comment on column MBT_DM_210_I.DATA_DATE is '数据日期';
comment on column MBT_DM_210_I.CORP_ID is '法人ID';
comment on column MBT_DM_210_I.ORG_ID is '机构ID';
comment on column MBT_DM_210_I.GROUP_ID is '数据分组';
comment on column MBT_DM_210_I.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_210_I.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_210_I.I_SPEC_EFCT_DATE is '分期额度生效日期';
comment on column MBT_DM_210_I.I_SPEC_END_DATE is '分期额度到期日期';
comment on column MBT_DM_210_I.I_SPEC_LINE is '大额专项分期额度';
comment on column MBT_DM_210_I.I_SPEC_LINE_LCY is '大额专项分期额度人民币金额';
comment on column MBT_DM_210_I.I_SPEC_LINE_ORG is '大额专项分期额度_原始数据金额';
comment on column MBT_DM_210_I.I_USED_INST_AMT is '已用分期金额';
comment on column MBT_DM_210_I.I_USED_INST_AMT_LCY is '已用分期金额人民币金额';
comment on column MBT_DM_210_I.I_USED_INST_AMT_ORG is '已用分期金额_原始数据金额';
comment on column MBT_DM_210_I.C_CY is '币种';
comment on column MBT_DM_210_I.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_210_I.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_210_I.CUST_NO is '客户号';
comment on column MBT_DM_210_I.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_210_I.PART_TYPE is '段标识';
comment on column MBT_DM_210_I.PART_NAME is '段名称';
comment on column MBT_DM_210_I.START_DATE is '起始日期';
comment on column MBT_DM_210_I.END_DATE is '结束日期';
comment on column MBT_DM_210_I.BATCH_NO is '批次号';
comment on column MBT_DM_210_I.ROW_NUM is '行号';
comment on column MBT_DM_210_I.IS_RPT is '是否报送';
comment on column MBT_DM_210_I.IS_VALID is '是否有效';
comment on column MBT_DM_210_I.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_210_I.OPT_FLAG is '操作标识';
comment on column MBT_DM_210_I.RPT_DATE is '报送日期';
comment on column MBT_DM_210_I.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_210_I.RPT_STATUS is '报送状态';
comment on column MBT_DM_210_I.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_210_I.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_210_I.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_210_I.REMARKS is '备注';
comment on column MBT_DM_210_I.CHECK_FLAG is '校验标志';
comment on column MBT_DM_210_I.CHECK_DESC is '校验说明';
comment on column MBT_DM_210_I.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_210_I.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_210_I.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_210_I.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_210_I.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_210_I.DATA_FLAG is '数据标志';
comment on column MBT_DM_210_I.DATA_OP is '操作标志';
comment on column MBT_DM_210_I.DATA_SOURCE is '数据来源';
comment on column MBT_DM_210_I.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_210_I.DATA_HASH is '数据HASH';
comment on column MBT_DM_210_I.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_I.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_I.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_210_I.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_210_I.DATA_CRT_USER is '创建人';
comment on column MBT_DM_210_I.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_210_I.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_210_I.DATA_CHG_USER is '修改人';
comment on column MBT_DM_210_I.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_210_I.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_210_I.DATA_APV_USER is '审核人';
comment on column MBT_DM_210_I.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_210_I.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_210_I.RSV1 is '备用字段';
comment on column MBT_DM_210_I.RSV2 is '备用字段';
comment on column MBT_DM_210_I.RSV3 is '备用字段';
comment on column MBT_DM_210_I.RSV4 is '备用字段';
comment on column MBT_DM_210_I.RSV5 is '备用字段';
create table MBT_DM_210_J (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
J_ACCT_BAL NUMBER(15),
J_ACCT_BAL_LCY NUMBER(15),
J_ACCT_BAL_ORG NUMBER(15),
J_ACCT_STATUS VARCHAR(2),
J_CLOSE_DATE VARCHAR(8),
J_FIVE_CATE VARCHAR(1),
J_FIVE_CATE_ADJ_DATE VARCHAR(8),
J_LAT_RPY_AMT NUMBER(15),
J_LAT_RPY_AMT_LCY NUMBER(15),
J_LAT_RPY_AMT_ORG NUMBER(15),
J_LAT_RPY_DATE VARCHAR(8),
J_OVERD_PRD NUMBER(3),
J_REM_REP_PRD NUMBER(3),
J_RPY_STATUS VARCHAR(1),
J_TOT_OVERD NUMBER(15),
J_TOT_OVERD_LCY NUMBER(15),
J_TOT_OVERD_ORG NUMBER(15),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_210_J is '个人借贷账户信息-非月度表现信息段';
comment on column MBT_DM_210_J.DATA_ID is '数据ID';
comment on column MBT_DM_210_J.DATA_DATE is '数据日期';
comment on column MBT_DM_210_J.CORP_ID is '法人ID';
comment on column MBT_DM_210_J.ORG_ID is '机构ID';
comment on column MBT_DM_210_J.GROUP_ID is '数据分组';
comment on column MBT_DM_210_J.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_210_J.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_210_J.J_ACCT_BAL is '余额';
comment on column MBT_DM_210_J.J_ACCT_BAL_LCY is '余额人民币金额';
comment on column MBT_DM_210_J.J_ACCT_BAL_ORG is '余额_原始数据金额';
comment on column MBT_DM_210_J.J_ACCT_STATUS is '账户状态';
comment on column MBT_DM_210_J.J_CLOSE_DATE is '账户关闭日期';
comment on column MBT_DM_210_J.J_FIVE_CATE is '五级分类';
comment on column MBT_DM_210_J.J_FIVE_CATE_ADJ_DATE is '五级分类认定日期';
comment on column MBT_DM_210_J.J_LAT_RPY_AMT is '最近一次实际还款金额';
comment on column MBT_DM_210_J.J_LAT_RPY_AMT_LCY is '最近一次实际还款金额人民币金额';
comment on column MBT_DM_210_J.J_LAT_RPY_AMT_ORG is '最近一次实际还款金额_原始数据金额';
comment on column MBT_DM_210_J.J_LAT_RPY_DATE is '最近一次实际还款日期';
comment on column MBT_DM_210_J.J_OVERD_PRD is '当前逾期期数';
comment on column MBT_DM_210_J.J_REM_REP_PRD is '剩余还款期数';
comment on column MBT_DM_210_J.J_RPY_STATUS is '当前还款状态';
comment on column MBT_DM_210_J.J_TOT_OVERD is '当前逾期总额';
comment on column MBT_DM_210_J.J_TOT_OVERD_LCY is '当前逾期总额人民币金额';
comment on column MBT_DM_210_J.J_TOT_OVERD_ORG is '当前逾期总额_原始数据金额';
comment on column MBT_DM_210_J.C_CY is '币种';
comment on column MBT_DM_210_J.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_210_J.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_210_J.CUST_NO is '客户号';
comment on column MBT_DM_210_J.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_210_J.PART_TYPE is '段标识';
comment on column MBT_DM_210_J.PART_NAME is '段名称';
comment on column MBT_DM_210_J.START_DATE is '起始日期';
comment on column MBT_DM_210_J.END_DATE is '结束日期';
comment on column MBT_DM_210_J.BATCH_NO is '批次号';
comment on column MBT_DM_210_J.ROW_NUM is '行号';
comment on column MBT_DM_210_J.IS_RPT is '是否报送';
comment on column MBT_DM_210_J.IS_VALID is '是否有效';
comment on column MBT_DM_210_J.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_210_J.OPT_FLAG is '操作标识';
comment on column MBT_DM_210_J.RPT_DATE is '报送日期';
comment on column MBT_DM_210_J.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_210_J.RPT_STATUS is '报送状态';
comment on column MBT_DM_210_J.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_210_J.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_210_J.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_210_J.REMARKS is '备注';
comment on column MBT_DM_210_J.CHECK_FLAG is '校验标志';
comment on column MBT_DM_210_J.CHECK_DESC is '校验说明';
comment on column MBT_DM_210_J.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_210_J.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_210_J.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_210_J.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_210_J.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_210_J.DATA_FLAG is '数据标志';
comment on column MBT_DM_210_J.DATA_OP is '操作标志';
comment on column MBT_DM_210_J.DATA_SOURCE is '数据来源';
comment on column MBT_DM_210_J.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_210_J.DATA_HASH is '数据HASH';
comment on column MBT_DM_210_J.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_J.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_J.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_210_J.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_210_J.DATA_CRT_USER is '创建人';
comment on column MBT_DM_210_J.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_210_J.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_210_J.DATA_CHG_USER is '修改人';
comment on column MBT_DM_210_J.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_210_J.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_210_J.DATA_APV_USER is '审核人';
comment on column MBT_DM_210_J.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_210_J.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_210_J.RSV1 is '备用字段';
comment on column MBT_DM_210_J.RSV2 is '备用字段';
comment on column MBT_DM_210_J.RSV3 is '备用字段';
comment on column MBT_DM_210_J.RSV4 is '备用字段';
comment on column MBT_DM_210_J.RSV5 is '备用字段';
create table MBT_DM_210_K (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
K_CHAN_TRAN_TYPE VARCHAR(2),
K_DET_INFO VARCHAR(400),
K_DUE_TRAN_MON NUMBER(3),
K_TRAN_AMT NUMBER(15),
K_TRAN_AMT_LCY NUMBER(15),
K_TRAN_AMT_ORG NUMBER(15),
K_TRAN_DATE VARCHAR(8),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_DM_210_K is '个人借贷账户信息-特殊交易说明段';
comment on column MBT_DM_210_K.DATA_ID is '数据ID';
comment on column MBT_DM_210_K.DATA_DATE is '数据日期';
comment on column MBT_DM_210_K.CORP_ID is '法人ID';
comment on column MBT_DM_210_K.ORG_ID is '机构ID';
comment on column MBT_DM_210_K.GROUP_ID is '数据分组';
comment on column MBT_DM_210_K.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_DM_210_K.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_DM_210_K.K_CHAN_TRAN_TYPE is '交易类型';
comment on column MBT_DM_210_K.K_DET_INFO is '交易明细信息';
comment on column MBT_DM_210_K.K_DUE_TRAN_MON is '到期日期变更月数';
comment on column MBT_DM_210_K.K_TRAN_AMT is '交易金额';
comment on column MBT_DM_210_K.K_TRAN_AMT_LCY is '交易金额人民币金额';
comment on column MBT_DM_210_K.K_TRAN_AMT_ORG is '交易金额_原始数据金额';
comment on column MBT_DM_210_K.K_TRAN_DATE is '交易日期';
comment on column MBT_DM_210_K.C_CY is '币种';
comment on column MBT_DM_210_K.B_RPT_DATE is '信息报告日期';
comment on column MBT_DM_210_K.B_ACCT_CODE is '账户标识码';
comment on column MBT_DM_210_K.CUST_NO is '客户号';
comment on column MBT_DM_210_K.UNV_IDN is '通用业务标识项';
comment on column MBT_DM_210_K.PART_TYPE is '段标识';
comment on column MBT_DM_210_K.PART_NAME is '段名称';
comment on column MBT_DM_210_K.START_DATE is '起始日期';
comment on column MBT_DM_210_K.END_DATE is '结束日期';
comment on column MBT_DM_210_K.BATCH_NO is '批次号';
comment on column MBT_DM_210_K.ROW_NUM is '行号';
comment on column MBT_DM_210_K.IS_RPT is '是否报送';
comment on column MBT_DM_210_K.IS_VALID is '是否有效';
comment on column MBT_DM_210_K.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_DM_210_K.OPT_FLAG is '操作标识';
comment on column MBT_DM_210_K.RPT_DATE is '报送日期';
comment on column MBT_DM_210_K.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_DM_210_K.RPT_STATUS is '报送状态';
comment on column MBT_DM_210_K.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_DM_210_K.RPT_FB_DATE is '反馈日期';
comment on column MBT_DM_210_K.RPT_FB_MSG is '反馈信息';
comment on column MBT_DM_210_K.REMARKS is '备注';
comment on column MBT_DM_210_K.CHECK_FLAG is '校验标志';
comment on column MBT_DM_210_K.CHECK_DESC is '校验说明';
comment on column MBT_DM_210_K.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_DM_210_K.NEXT_ACTION is '工作流节点';
comment on column MBT_DM_210_K.DATA_STATUS is '正常处理数据状态';
comment on column MBT_DM_210_K.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_DM_210_K.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_DM_210_K.DATA_FLAG is '数据标志';
comment on column MBT_DM_210_K.DATA_OP is '操作标志';
comment on column MBT_DM_210_K.DATA_SOURCE is '数据来源';
comment on column MBT_DM_210_K.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_DM_210_K.DATA_HASH is '数据HASH';
comment on column MBT_DM_210_K.DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_K.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_DM_210_K.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_DM_210_K.DATA_DEL_DESC is '删除描述';
comment on column MBT_DM_210_K.DATA_CRT_USER is '创建人';
comment on column MBT_DM_210_K.DATA_CRT_DATE is '创建日期';
comment on column MBT_DM_210_K.DATA_CRT_TIME is '创建时间';
comment on column MBT_DM_210_K.DATA_CHG_USER is '修改人';
comment on column MBT_DM_210_K.DATA_CHG_DATE is '修改日期';
comment on column MBT_DM_210_K.DATA_CHG_TIME is '修改时间';
comment on column MBT_DM_210_K.DATA_APV_USER is '审核人';
comment on column MBT_DM_210_K.DATA_APV_DATE is '审核日期';
comment on column MBT_DM_210_K.DATA_APV_TIME is '审核时间';
comment on column MBT_DM_210_K.RSV1 is '备用字段';
comment on column MBT_DM_210_K.RSV2 is '备用字段';
comment on column MBT_DM_210_K.RSV3 is '备用字段';
comment on column MBT_DM_210_K.RSV4 is '备用字段';
comment on column MBT_DM_210_K.RSV5 is '备用字段';
create table MBT_PM_210 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
O_BIZ_CODE VARCHAR(60),
N_BIZ_CODE VARCHAR(60),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_210 is '个人借贷账户信息';
comment on column MBT_PM_210.DATA_ID is '数据ID';
comment on column MBT_PM_210.DATA_DATE is '数据日期';
comment on column MBT_PM_210.CORP_ID is '法人ID';
comment on column MBT_PM_210.ORG_ID is '机构ID';
comment on column MBT_PM_210.GROUP_ID is '数据分组';
comment on column MBT_PM_210.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_210.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_210.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_210.O_BIZ_CODE is '原业务标识码';
comment on column MBT_PM_210.N_BIZ_CODE is '新业务标识码';
comment on column MBT_PM_210.SECTION_CHG_CNT is '段变更';
comment on column MBT_PM_210.SECTION_DEL_CNT is '段删除';
comment on column MBT_PM_210.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_PM_210.IDN_CHG_CNT is '标识项变更';
comment on column MBT_PM_210.CUST_NO is '客户号';
comment on column MBT_PM_210.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_210.PART_TYPE is '段标识';
comment on column MBT_PM_210.PART_NAME is '段名称';
comment on column MBT_PM_210.START_DATE is '起始日期';
comment on column MBT_PM_210.END_DATE is '结束日期';
comment on column MBT_PM_210.BATCH_NO is '批次号';
comment on column MBT_PM_210.ROW_NUM is '行号';
comment on column MBT_PM_210.IS_RPT is '是否报送';
comment on column MBT_PM_210.IS_VALID is '是否有效';
comment on column MBT_PM_210.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_210.OPT_FLAG is '操作标识';
comment on column MBT_PM_210.RPT_DATE is '报送日期';
comment on column MBT_PM_210.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_210.RPT_STATUS is '报送状态';
comment on column MBT_PM_210.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_210.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_210.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_210.REMARKS is '备注';
comment on column MBT_PM_210.CHECK_FLAG is '校验标志';
comment on column MBT_PM_210.CHECK_DESC is '校验说明';
comment on column MBT_PM_210.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_210.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_210.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_210.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_210.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_210.DATA_FLAG is '数据标志';
comment on column MBT_PM_210.DATA_OP is '操作标志';
comment on column MBT_PM_210.DATA_SOURCE is '数据来源';
comment on column MBT_PM_210.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_210.DATA_HASH is '数据HASH';
comment on column MBT_PM_210.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_210.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_210.DATA_CRT_USER is '创建人';
comment on column MBT_PM_210.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_210.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_210.DATA_CHG_USER is '修改人';
comment on column MBT_PM_210.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_210.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_210.DATA_APV_USER is '审核人';
comment on column MBT_PM_210.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_210.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_210.RSV1 is '备用字段';
comment on column MBT_PM_210.RSV2 is '备用字段';
comment on column MBT_PM_210.RSV3 is '备用字段';
comment on column MBT_PM_210.RSV4 is '备用字段';
comment on column MBT_PM_210.RSV5 is '备用字段';
create table MBT_PM_210_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_TYPE VARCHAR(2),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_REC_TYPE VARCHAR(3),
B_MNGMT_ORG_CODE VARCHAR(14),
B_NAME VARCHAR(60),
B_RPT_DATE_CODE VARCHAR(2),
MON_SETTLE_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_210_B is '个人借贷账户信息-基础段';
comment on column MBT_PM_210_B.DATA_ID is '数据ID';
comment on column MBT_PM_210_B.DATA_DATE is '数据日期';
comment on column MBT_PM_210_B.CORP_ID is '法人ID';
comment on column MBT_PM_210_B.ORG_ID is '机构ID';
comment on column MBT_PM_210_B.GROUP_ID is '数据分组';
comment on column MBT_PM_210_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_210_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_210_B.B_ACCT_TYPE is '账户类型';
comment on column MBT_PM_210_B.B_ID_NUM is '借款人证件号码';
comment on column MBT_PM_210_B.B_ID_TYPE is '借款人证件类型';
comment on column MBT_PM_210_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_PM_210_B.B_MNGMT_ORG_CODE is '业务管理机构代码';
comment on column MBT_PM_210_B.B_NAME is '借款人姓名';
comment on column MBT_PM_210_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_PM_210_B.MON_SETTLE_DATE is '月度结算日';
comment on column MBT_PM_210_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_210_B.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_210_B.CUST_NO is '客户号';
comment on column MBT_PM_210_B.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_210_B.PART_TYPE is '段标识';
comment on column MBT_PM_210_B.PART_NAME is '段名称';
comment on column MBT_PM_210_B.START_DATE is '起始日期';
comment on column MBT_PM_210_B.END_DATE is '结束日期';
comment on column MBT_PM_210_B.BATCH_NO is '批次号';
comment on column MBT_PM_210_B.ROW_NUM is '行号';
comment on column MBT_PM_210_B.IS_RPT is '是否报送';
comment on column MBT_PM_210_B.IS_VALID is '是否有效';
comment on column MBT_PM_210_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_210_B.OPT_FLAG is '操作标识';
comment on column MBT_PM_210_B.RPT_DATE is '报送日期';
comment on column MBT_PM_210_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_210_B.RPT_STATUS is '报送状态';
comment on column MBT_PM_210_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_210_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_210_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_210_B.REMARKS is '备注';
comment on column MBT_PM_210_B.CHECK_FLAG is '校验标志';
comment on column MBT_PM_210_B.CHECK_DESC is '校验说明';
comment on column MBT_PM_210_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_210_B.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_210_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_210_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_210_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_210_B.DATA_FLAG is '数据标志';
comment on column MBT_PM_210_B.DATA_OP is '操作标志';
comment on column MBT_PM_210_B.DATA_SOURCE is '数据来源';
comment on column MBT_PM_210_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_210_B.DATA_HASH is '数据HASH';
comment on column MBT_PM_210_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_210_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_210_B.DATA_CRT_USER is '创建人';
comment on column MBT_PM_210_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_210_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_210_B.DATA_CHG_USER is '修改人';
comment on column MBT_PM_210_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_210_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_210_B.DATA_APV_USER is '审核人';
comment on column MBT_PM_210_B.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_210_B.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_210_B.RSV1 is '备用字段';
comment on column MBT_PM_210_B.RSV2 is '备用字段';
comment on column MBT_PM_210_B.RSV3 is '备用字段';
comment on column MBT_PM_210_B.RSV4 is '备用字段';
comment on column MBT_PM_210_B.RSV5 is '备用字段';
create table MBT_PM_210_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ACCT_CRED_LINE_AMT NUMBER(15),
C_ACCT_CRED_LINE_AMT_LCY NUMBER(15),
C_ACCT_CRED_LINE_AMT_ORG NUMBER(15),
C_APPLY_BUSI_DIST VARCHAR(6),
C_ASSET_TRAND_FLAG VARCHAR(1),
C_BUSI_DTL_LINES VARCHAR(2),
C_BUSI_LINES VARCHAR(1),
C_CREDIT_ID VARCHAR(4),
C_CY VARCHAR(3),
C_DUE_DATE VARCHAR(8),
C_FIRST_HOU_LOAN_FLAG VARCHAR(2),
C_FLAG VARCHAR(1),
C_FUND_SOU VARCHAR(2),
C_GUAR_MODE VARCHAR(1),
C_LOAN_AMT NUMBER(15),
C_LOAN_AMT_LCY NUMBER(15),
C_LOAN_AMT_ORG NUMBER(15),
C_LOAN_CON_CODE VARCHAR(200),
C_LOAN_FORM VARCHAR(1),
C_OPEN_DATE VARCHAR(8),
C_OTH_REPY_GUAR_WAY VARCHAR(2),
C_REPAY_FREQCY VARCHAR(2),
C_REPAY_MODE VARCHAR(2),
C_REPAY_PRD NUMBER(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_210_C is '个人借贷账户信息-基本信息段';
comment on column MBT_PM_210_C.DATA_ID is '数据ID';
comment on column MBT_PM_210_C.DATA_DATE is '数据日期';
comment on column MBT_PM_210_C.CORP_ID is '法人ID';
comment on column MBT_PM_210_C.ORG_ID is '机构ID';
comment on column MBT_PM_210_C.GROUP_ID is '数据分组';
comment on column MBT_PM_210_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_210_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_210_C.C_ACCT_CRED_LINE_AMT is '信用额度';
comment on column MBT_PM_210_C.C_ACCT_CRED_LINE_AMT_LCY is '信用额度人民币金额';
comment on column MBT_PM_210_C.C_ACCT_CRED_LINE_AMT_ORG is '信用额度_原始数据金额';
comment on column MBT_PM_210_C.C_APPLY_BUSI_DIST is '业务申请地行政区划代码';
comment on column MBT_PM_210_C.C_ASSET_TRAND_FLAG is '资产转让标志';
comment on column MBT_PM_210_C.C_BUSI_DTL_LINES is '借贷业务种类细分';
comment on column MBT_PM_210_C.C_BUSI_LINES is '借贷业务大类';
comment on column MBT_PM_210_C.C_CREDIT_ID is '卡片标识号';
comment on column MBT_PM_210_C.C_CY is '币种';
comment on column MBT_PM_210_C.C_DUE_DATE is '到期日期';
comment on column MBT_PM_210_C.C_FIRST_HOU_LOAN_FLAG is '是否为首套住房贷款';
comment on column MBT_PM_210_C.C_FLAG is '分次放款标志';
comment on column MBT_PM_210_C.C_FUND_SOU is '业务经营类型';
comment on column MBT_PM_210_C.C_GUAR_MODE is '担保方式';
comment on column MBT_PM_210_C.C_LOAN_AMT is '借款金额';
comment on column MBT_PM_210_C.C_LOAN_AMT_LCY is '借款金额人民币金额';
comment on column MBT_PM_210_C.C_LOAN_AMT_ORG is '借款金额_原始数据金额';
comment on column MBT_PM_210_C.C_LOAN_CON_CODE is '贷款合同编号';
comment on column MBT_PM_210_C.C_LOAN_FORM is '贷款发放形式';
comment on column MBT_PM_210_C.C_OPEN_DATE is '开户日期';
comment on column MBT_PM_210_C.C_OTH_REPY_GUAR_WAY is '其他还款保证方式';
comment on column MBT_PM_210_C.C_REPAY_FREQCY is '还款频率';
comment on column MBT_PM_210_C.C_REPAY_MODE is '还款方式';
comment on column MBT_PM_210_C.C_REPAY_PRD is '还款期数';
comment on column MBT_PM_210_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_210_C.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_210_C.CUST_NO is '客户号';
comment on column MBT_PM_210_C.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_210_C.PART_TYPE is '段标识';
comment on column MBT_PM_210_C.PART_NAME is '段名称';
comment on column MBT_PM_210_C.START_DATE is '起始日期';
comment on column MBT_PM_210_C.END_DATE is '结束日期';
comment on column MBT_PM_210_C.BATCH_NO is '批次号';
comment on column MBT_PM_210_C.ROW_NUM is '行号';
comment on column MBT_PM_210_C.IS_RPT is '是否报送';
comment on column MBT_PM_210_C.IS_VALID is '是否有效';
comment on column MBT_PM_210_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_210_C.OPT_FLAG is '操作标识';
comment on column MBT_PM_210_C.RPT_DATE is '报送日期';
comment on column MBT_PM_210_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_210_C.RPT_STATUS is '报送状态';
comment on column MBT_PM_210_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_210_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_210_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_210_C.REMARKS is '备注';
comment on column MBT_PM_210_C.CHECK_FLAG is '校验标志';
comment on column MBT_PM_210_C.CHECK_DESC is '校验说明';
comment on column MBT_PM_210_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_210_C.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_210_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_210_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_210_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_210_C.DATA_FLAG is '数据标志';
comment on column MBT_PM_210_C.DATA_OP is '操作标志';
comment on column MBT_PM_210_C.DATA_SOURCE is '数据来源';
comment on column MBT_PM_210_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_210_C.DATA_HASH is '数据HASH';
comment on column MBT_PM_210_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_210_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_210_C.DATA_CRT_USER is '创建人';
comment on column MBT_PM_210_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_210_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_210_C.DATA_CHG_USER is '修改人';
comment on column MBT_PM_210_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_210_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_210_C.DATA_APV_USER is '审核人';
comment on column MBT_PM_210_C.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_210_C.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_210_C.RSV1 is '备用字段';
comment on column MBT_PM_210_C.RSV2 is '备用字段';
comment on column MBT_PM_210_C.RSV3 is '备用字段';
comment on column MBT_PM_210_C.RSV4 is '备用字段';
comment on column MBT_PM_210_C.RSV5 is '备用字段';
create table MBT_PM_210_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ARLP_AMT NUMBER(15),
D_ARLP_AMT_LCY NUMBER(15),
D_ARLP_AMT_ORG NUMBER(15),
D_ARLP_CERT_NUM VARCHAR(80),
D_ARLP_CERT_TYPE VARCHAR(2),
D_ARLP_ID_TYPE VARCHAR(2),
D_ARLP_NAME VARCHAR(160),
D_ARLP_TYPE VARCHAR(1),
D_MAX_GUAR_MCC VARCHAR(60),
D_WARTY_SIGN VARCHAR(1),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_210_D is '个人借贷账户信息-相关还款责任人段';
comment on column MBT_PM_210_D.DATA_ID is '数据ID';
comment on column MBT_PM_210_D.DATA_DATE is '数据日期';
comment on column MBT_PM_210_D.CORP_ID is '法人ID';
comment on column MBT_PM_210_D.ORG_ID is '机构ID';
comment on column MBT_PM_210_D.GROUP_ID is '数据分组';
comment on column MBT_PM_210_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_210_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_210_D.D_ARLP_AMT is '还款责任金额';
comment on column MBT_PM_210_D.D_ARLP_AMT_LCY is '还款责任金额人民币金额';
comment on column MBT_PM_210_D.D_ARLP_AMT_ORG is '还款责任金额_原始数据金额';
comment on column MBT_PM_210_D.D_ARLP_CERT_NUM is '责任人身份标识号码';
comment on column MBT_PM_210_D.D_ARLP_CERT_TYPE is '责任人身份标识类型';
comment on column MBT_PM_210_D.D_ARLP_ID_TYPE is '身份类别';
comment on column MBT_PM_210_D.D_ARLP_NAME is '责任人名称';
comment on column MBT_PM_210_D.D_ARLP_TYPE is '还款责任人类型';
comment on column MBT_PM_210_D.D_MAX_GUAR_MCC is '保证合同编号';
comment on column MBT_PM_210_D.D_WARTY_SIGN is '联保标志';
comment on column MBT_PM_210_D.C_CY is '币种';
comment on column MBT_PM_210_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_210_D.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_210_D.CUST_NO is '客户号';
comment on column MBT_PM_210_D.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_210_D.PART_TYPE is '段标识';
comment on column MBT_PM_210_D.PART_NAME is '段名称';
comment on column MBT_PM_210_D.START_DATE is '起始日期';
comment on column MBT_PM_210_D.END_DATE is '结束日期';
comment on column MBT_PM_210_D.BATCH_NO is '批次号';
comment on column MBT_PM_210_D.ROW_NUM is '行号';
comment on column MBT_PM_210_D.IS_RPT is '是否报送';
comment on column MBT_PM_210_D.IS_VALID is '是否有效';
comment on column MBT_PM_210_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_210_D.OPT_FLAG is '操作标识';
comment on column MBT_PM_210_D.RPT_DATE is '报送日期';
comment on column MBT_PM_210_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_210_D.RPT_STATUS is '报送状态';
comment on column MBT_PM_210_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_210_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_210_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_210_D.REMARKS is '备注';
comment on column MBT_PM_210_D.CHECK_FLAG is '校验标志';
comment on column MBT_PM_210_D.CHECK_DESC is '校验说明';
comment on column MBT_PM_210_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_210_D.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_210_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_210_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_210_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_210_D.DATA_FLAG is '数据标志';
comment on column MBT_PM_210_D.DATA_OP is '操作标志';
comment on column MBT_PM_210_D.DATA_SOURCE is '数据来源';
comment on column MBT_PM_210_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_210_D.DATA_HASH is '数据HASH';
comment on column MBT_PM_210_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_210_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_210_D.DATA_CRT_USER is '创建人';
comment on column MBT_PM_210_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_210_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_210_D.DATA_CHG_USER is '修改人';
comment on column MBT_PM_210_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_210_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_210_D.DATA_APV_USER is '审核人';
comment on column MBT_PM_210_D.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_210_D.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_210_D.RSV1 is '备用字段';
comment on column MBT_PM_210_D.RSV2 is '备用字段';
comment on column MBT_PM_210_D.RSV3 is '备用字段';
comment on column MBT_PM_210_D.RSV4 is '备用字段';
comment on column MBT_PM_210_D.RSV5 is '备用字段';
create table MBT_PM_210_E (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
E_CCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_210_E is '个人借贷账户信息-抵质押物信息段';
comment on column MBT_PM_210_E.DATA_ID is '数据ID';
comment on column MBT_PM_210_E.DATA_DATE is '数据日期';
comment on column MBT_PM_210_E.CORP_ID is '法人ID';
comment on column MBT_PM_210_E.ORG_ID is '机构ID';
comment on column MBT_PM_210_E.GROUP_ID is '数据分组';
comment on column MBT_PM_210_E.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_210_E.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_210_E.E_CCC is '抵（质）押合同标识码';
comment on column MBT_PM_210_E.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_210_E.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_210_E.CUST_NO is '客户号';
comment on column MBT_PM_210_E.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_210_E.PART_TYPE is '段标识';
comment on column MBT_PM_210_E.PART_NAME is '段名称';
comment on column MBT_PM_210_E.START_DATE is '起始日期';
comment on column MBT_PM_210_E.END_DATE is '结束日期';
comment on column MBT_PM_210_E.BATCH_NO is '批次号';
comment on column MBT_PM_210_E.ROW_NUM is '行号';
comment on column MBT_PM_210_E.IS_RPT is '是否报送';
comment on column MBT_PM_210_E.IS_VALID is '是否有效';
comment on column MBT_PM_210_E.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_210_E.OPT_FLAG is '操作标识';
comment on column MBT_PM_210_E.RPT_DATE is '报送日期';
comment on column MBT_PM_210_E.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_210_E.RPT_STATUS is '报送状态';
comment on column MBT_PM_210_E.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_210_E.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_210_E.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_210_E.REMARKS is '备注';
comment on column MBT_PM_210_E.CHECK_FLAG is '校验标志';
comment on column MBT_PM_210_E.CHECK_DESC is '校验说明';
comment on column MBT_PM_210_E.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_210_E.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_210_E.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_210_E.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_210_E.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_210_E.DATA_FLAG is '数据标志';
comment on column MBT_PM_210_E.DATA_OP is '操作标志';
comment on column MBT_PM_210_E.DATA_SOURCE is '数据来源';
comment on column MBT_PM_210_E.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_210_E.DATA_HASH is '数据HASH';
comment on column MBT_PM_210_E.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_E.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_E.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_210_E.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_210_E.DATA_CRT_USER is '创建人';
comment on column MBT_PM_210_E.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_210_E.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_210_E.DATA_CHG_USER is '修改人';
comment on column MBT_PM_210_E.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_210_E.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_210_E.DATA_APV_USER is '审核人';
comment on column MBT_PM_210_E.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_210_E.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_210_E.RSV1 is '备用字段';
comment on column MBT_PM_210_E.RSV2 is '备用字段';
comment on column MBT_PM_210_E.RSV3 is '备用字段';
comment on column MBT_PM_210_E.RSV4 is '备用字段';
comment on column MBT_PM_210_E.RSV5 is '备用字段';
create table MBT_PM_210_F (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
F_MCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_210_F is '个人借贷账户信息-授信额度信息段';
comment on column MBT_PM_210_F.DATA_ID is '数据ID';
comment on column MBT_PM_210_F.DATA_DATE is '数据日期';
comment on column MBT_PM_210_F.CORP_ID is '法人ID';
comment on column MBT_PM_210_F.ORG_ID is '机构ID';
comment on column MBT_PM_210_F.GROUP_ID is '数据分组';
comment on column MBT_PM_210_F.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_210_F.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_210_F.F_MCC is '授信协议标识码';
comment on column MBT_PM_210_F.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_210_F.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_210_F.CUST_NO is '客户号';
comment on column MBT_PM_210_F.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_210_F.PART_TYPE is '段标识';
comment on column MBT_PM_210_F.PART_NAME is '段名称';
comment on column MBT_PM_210_F.START_DATE is '起始日期';
comment on column MBT_PM_210_F.END_DATE is '结束日期';
comment on column MBT_PM_210_F.BATCH_NO is '批次号';
comment on column MBT_PM_210_F.ROW_NUM is '行号';
comment on column MBT_PM_210_F.IS_RPT is '是否报送';
comment on column MBT_PM_210_F.IS_VALID is '是否有效';
comment on column MBT_PM_210_F.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_210_F.OPT_FLAG is '操作标识';
comment on column MBT_PM_210_F.RPT_DATE is '报送日期';
comment on column MBT_PM_210_F.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_210_F.RPT_STATUS is '报送状态';
comment on column MBT_PM_210_F.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_210_F.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_210_F.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_210_F.REMARKS is '备注';
comment on column MBT_PM_210_F.CHECK_FLAG is '校验标志';
comment on column MBT_PM_210_F.CHECK_DESC is '校验说明';
comment on column MBT_PM_210_F.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_210_F.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_210_F.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_210_F.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_210_F.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_210_F.DATA_FLAG is '数据标志';
comment on column MBT_PM_210_F.DATA_OP is '操作标志';
comment on column MBT_PM_210_F.DATA_SOURCE is '数据来源';
comment on column MBT_PM_210_F.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_210_F.DATA_HASH is '数据HASH';
comment on column MBT_PM_210_F.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_F.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_F.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_210_F.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_210_F.DATA_CRT_USER is '创建人';
comment on column MBT_PM_210_F.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_210_F.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_210_F.DATA_CHG_USER is '修改人';
comment on column MBT_PM_210_F.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_210_F.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_210_F.DATA_APV_USER is '审核人';
comment on column MBT_PM_210_F.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_210_F.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_210_F.RSV1 is '备用字段';
comment on column MBT_PM_210_F.RSV2 is '备用字段';
comment on column MBT_PM_210_F.RSV3 is '备用字段';
comment on column MBT_PM_210_F.RSV4 is '备用字段';
comment on column MBT_PM_210_F.RSV5 is '备用字段';
create table MBT_PM_210_G (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_INIT_CRED_NAME VARCHAR(160),
G_INIT_CRED_ORG_NM VARCHAR(18),
G_INIT_RPY_STS VARCHAR(1),
G_ORIG_DBT_CATE VARCHAR(1),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_210_G is '个人借贷账户信息-初始债权说明段';
comment on column MBT_PM_210_G.DATA_ID is '数据ID';
comment on column MBT_PM_210_G.DATA_DATE is '数据日期';
comment on column MBT_PM_210_G.CORP_ID is '法人ID';
comment on column MBT_PM_210_G.ORG_ID is '机构ID';
comment on column MBT_PM_210_G.GROUP_ID is '数据分组';
comment on column MBT_PM_210_G.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_210_G.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_210_G.G_INIT_CRED_NAME is '初始债权人名称';
comment on column MBT_PM_210_G.G_INIT_CRED_ORG_NM is '初始债权人机构代码';
comment on column MBT_PM_210_G.G_INIT_RPY_STS is '债权转移时的还款状态';
comment on column MBT_PM_210_G.G_ORIG_DBT_CATE is '原债务种类';
comment on column MBT_PM_210_G.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_210_G.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_210_G.CUST_NO is '客户号';
comment on column MBT_PM_210_G.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_210_G.PART_TYPE is '段标识';
comment on column MBT_PM_210_G.PART_NAME is '段名称';
comment on column MBT_PM_210_G.START_DATE is '起始日期';
comment on column MBT_PM_210_G.END_DATE is '结束日期';
comment on column MBT_PM_210_G.BATCH_NO is '批次号';
comment on column MBT_PM_210_G.ROW_NUM is '行号';
comment on column MBT_PM_210_G.IS_RPT is '是否报送';
comment on column MBT_PM_210_G.IS_VALID is '是否有效';
comment on column MBT_PM_210_G.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_210_G.OPT_FLAG is '操作标识';
comment on column MBT_PM_210_G.RPT_DATE is '报送日期';
comment on column MBT_PM_210_G.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_210_G.RPT_STATUS is '报送状态';
comment on column MBT_PM_210_G.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_210_G.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_210_G.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_210_G.REMARKS is '备注';
comment on column MBT_PM_210_G.CHECK_FLAG is '校验标志';
comment on column MBT_PM_210_G.CHECK_DESC is '校验说明';
comment on column MBT_PM_210_G.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_210_G.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_210_G.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_210_G.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_210_G.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_210_G.DATA_FLAG is '数据标志';
comment on column MBT_PM_210_G.DATA_OP is '操作标志';
comment on column MBT_PM_210_G.DATA_SOURCE is '数据来源';
comment on column MBT_PM_210_G.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_210_G.DATA_HASH is '数据HASH';
comment on column MBT_PM_210_G.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_G.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_G.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_210_G.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_210_G.DATA_CRT_USER is '创建人';
comment on column MBT_PM_210_G.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_210_G.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_210_G.DATA_CHG_USER is '修改人';
comment on column MBT_PM_210_G.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_210_G.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_210_G.DATA_APV_USER is '审核人';
comment on column MBT_PM_210_G.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_210_G.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_210_G.RSV1 is '备用字段';
comment on column MBT_PM_210_G.RSV2 is '备用字段';
comment on column MBT_PM_210_G.RSV3 is '备用字段';
comment on column MBT_PM_210_G.RSV4 is '备用字段';
comment on column MBT_PM_210_G.RSV5 is '备用字段';
create table MBT_PM_210_H (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
H_ACCT_BAL NUMBER(15),
H_ACCT_BAL_LCY NUMBER(15),
H_ACCT_BAL_ORG NUMBER(15),
H_ACCT_STATUS VARCHAR(2),
H_ACT_RPY_AMT NUMBER(15),
H_ACT_RPY_AMT_LCY NUMBER(15),
H_ACT_RPY_AMT_ORG NUMBER(15),
H_CLOSE_DATE VARCHAR(8),
H_CUR_RPY_AMT NUMBER(15),
H_CUR_RPY_AMT_LCY NUMBER(15),
H_CUR_RPY_AMT_ORG NUMBER(15),
H_FIVE_CATE VARCHAR(1),
H_FIVE_CATE_ADJ_DATE VARCHAR(8),
H_LAT_RPY_DATE VARCHAR(8),
H_MONTH VARCHAR(7),
H_NOTLSU_BAL NUMBER(15),
H_NOTLSU_BAL_LCY NUMBER(15),
H_NOTLSU_BAL_ORG NUMBER(15),
H_OVAER_PRINC NUMBER(15),
H_OVAER_PRINC_LCY NUMBER(15),
H_OVAER_PRINC_ORG NUMBER(15),
H_OVERD31_60PRINC NUMBER(15),
H_OVERD31_60PRINC_LCY NUMBER(15),
H_OVERD31_60PRINC_ORG NUMBER(15),
H_OVERD61_90PRINC NUMBER(15),
H_OVERD61_90PRINC_LCY NUMBER(15),
H_OVERD61_90PRINC_ORG NUMBER(15),
H_OVERD91_180PRINC NUMBER(15),
H_OVERD91_180PRINC_LCY NUMBER(15),
H_OVERD91_180PRINC_ORG NUMBER(15),
H_OVERD_PRD NUMBER(3),
H_OVERD_PRINC180 NUMBER(15),
H_OVERD_PRINC180_LCY NUMBER(15),
H_OVERD_PRINC180_ORG NUMBER(15),
H_OVERD_RAW_BA_OVE180 NUMBER(15),
H_OVERD_RAW_BA_OVE180_LCY NUMBER(15),
H_OVERD_RAW_BA_OVE180_ORG NUMBER(15),
H_PRID_ACCT_BAL NUMBER(15),
H_PRID_ACCT_BAL_LCY NUMBER(15),
H_PRID_ACCT_BAL_ORG NUMBER(15),
H_REM_REP_PRD NUMBER(3),
H_RPY_PRCT NUMBER(3),
H_RPY_STATUS VARCHAR(1),
H_SETT_DATE VARCHAR(8),
H_TOT_OVERD NUMBER(15),
H_TOT_OVERD_LCY NUMBER(15),
H_TOT_OVERD_ORG NUMBER(15),
H_USED_AMT NUMBER(15),
H_USED_AMT_LCY NUMBER(15),
H_USED_AMT_ORG NUMBER(15),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_210_H is '个人借贷账户信息-月度表现信息段';
comment on column MBT_PM_210_H.DATA_ID is '数据ID';
comment on column MBT_PM_210_H.DATA_DATE is '数据日期';
comment on column MBT_PM_210_H.CORP_ID is '法人ID';
comment on column MBT_PM_210_H.ORG_ID is '机构ID';
comment on column MBT_PM_210_H.GROUP_ID is '数据分组';
comment on column MBT_PM_210_H.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_210_H.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_210_H.H_ACCT_BAL is '余额';
comment on column MBT_PM_210_H.H_ACCT_BAL_LCY is '余额人民币金额';
comment on column MBT_PM_210_H.H_ACCT_BAL_ORG is '余额_原始数据金额';
comment on column MBT_PM_210_H.H_ACCT_STATUS is '账户状态';
comment on column MBT_PM_210_H.H_ACT_RPY_AMT is '本月实际还款金额';
comment on column MBT_PM_210_H.H_ACT_RPY_AMT_LCY is '本月实际还款金额人民币金额';
comment on column MBT_PM_210_H.H_ACT_RPY_AMT_ORG is '本月实际还款金额_原始数据金额';
comment on column MBT_PM_210_H.H_CLOSE_DATE is '账户关闭日期';
comment on column MBT_PM_210_H.H_CUR_RPY_AMT is '本月应还款金额';
comment on column MBT_PM_210_H.H_CUR_RPY_AMT_LCY is '本月应还款金额人民币金额';
comment on column MBT_PM_210_H.H_CUR_RPY_AMT_ORG is '本月应还款金额_原始数据金额';
comment on column MBT_PM_210_H.H_FIVE_CATE is '五级分类';
comment on column MBT_PM_210_H.H_FIVE_CATE_ADJ_DATE is '五级分类认定日期';
comment on column MBT_PM_210_H.H_LAT_RPY_DATE is '最近一次实际还款日期';
comment on column MBT_PM_210_H.H_MONTH is '月份';
comment on column MBT_PM_210_H.H_NOTLSU_BAL is '未出单的大额专项分期余额';
comment on column MBT_PM_210_H.H_NOTLSU_BAL_LCY is '未出单的大额专项分期余额人民币金额';
comment on column MBT_PM_210_H.H_NOTLSU_BAL_ORG is '未出单的大额专项分期余额_原始数据金额';
comment on column MBT_PM_210_H.H_OVAER_PRINC is '当前逾期本金';
comment on column MBT_PM_210_H.H_OVAER_PRINC_LCY is '当前逾期本金人民币金额';
comment on column MBT_PM_210_H.H_OVAER_PRINC_ORG is '当前逾期本金_原始数据金额';
comment on column MBT_PM_210_H.H_OVERD31_60PRINC is '逾期31-60天未归还本金';
comment on column MBT_PM_210_H.H_OVERD31_60PRINC_LCY is '逾期31-60天未归还本金人民币金额';
comment on column MBT_PM_210_H.H_OVERD31_60PRINC_ORG is '逾期31-60天未归还本金_原始数据金额';
comment on column MBT_PM_210_H.H_OVERD61_90PRINC is '逾期61-90天未归还本金';
comment on column MBT_PM_210_H.H_OVERD61_90PRINC_LCY is '逾期61-90天未归还本金人民币金额';
comment on column MBT_PM_210_H.H_OVERD61_90PRINC_ORG is '逾期61-90天未归还本金_原始数据金额';
comment on column MBT_PM_210_H.H_OVERD91_180PRINC is '逾期91-180天未归还本金';
comment on column MBT_PM_210_H.H_OVERD91_180PRINC_LCY is '逾期91-180天未归还本金人民币金额';
comment on column MBT_PM_210_H.H_OVERD91_180PRINC_ORG is '逾期91-180天未归还本金_原始数据金额';
comment on column MBT_PM_210_H.H_OVERD_PRD is '当前逾期期数';
comment on column MBT_PM_210_H.H_OVERD_PRINC180 is '逾期180天以上未归还本金';
comment on column MBT_PM_210_H.H_OVERD_PRINC180_LCY is '逾期180天以上未归还本金人民币金额';
comment on column MBT_PM_210_H.H_OVERD_PRINC180_ORG is '逾期180天以上未归还本金_原始数据金额';
comment on column MBT_PM_210_H.H_OVERD_RAW_BA_OVE180 is '透支180天以上未还余额';
comment on column MBT_PM_210_H.H_OVERD_RAW_BA_OVE180_LCY is '透支180天以上未还余额人民币金额';
comment on column MBT_PM_210_H.H_OVERD_RAW_BA_OVE180_ORG is '透支180天以上未还余额_原始数据金额';
comment on column MBT_PM_210_H.H_PRID_ACCT_BAL is '本期账单余额';
comment on column MBT_PM_210_H.H_PRID_ACCT_BAL_LCY is '本期账单余额人民币金额';
comment on column MBT_PM_210_H.H_PRID_ACCT_BAL_ORG is '本期账单余额_原始数据金额';
comment on column MBT_PM_210_H.H_REM_REP_PRD is '剩余还款期数';
comment on column MBT_PM_210_H.H_RPY_PRCT is '实际还款百分比';
comment on column MBT_PM_210_H.H_RPY_STATUS is '当前还款状态';
comment on column MBT_PM_210_H.H_SETT_DATE is '结算/应还款日';
comment on column MBT_PM_210_H.H_TOT_OVERD is '当前逾期总额';
comment on column MBT_PM_210_H.H_TOT_OVERD_LCY is '当前逾期总额人民币金额';
comment on column MBT_PM_210_H.H_TOT_OVERD_ORG is '当前逾期总额_原始数据金额';
comment on column MBT_PM_210_H.H_USED_AMT is '已使用额度';
comment on column MBT_PM_210_H.H_USED_AMT_LCY is '已使用额度人民币金额';
comment on column MBT_PM_210_H.H_USED_AMT_ORG is '已使用额度_原始数据金额';
comment on column MBT_PM_210_H.C_CY is '币种';
comment on column MBT_PM_210_H.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_210_H.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_210_H.CUST_NO is '客户号';
comment on column MBT_PM_210_H.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_210_H.PART_TYPE is '段标识';
comment on column MBT_PM_210_H.PART_NAME is '段名称';
comment on column MBT_PM_210_H.START_DATE is '起始日期';
comment on column MBT_PM_210_H.END_DATE is '结束日期';
comment on column MBT_PM_210_H.BATCH_NO is '批次号';
comment on column MBT_PM_210_H.ROW_NUM is '行号';
comment on column MBT_PM_210_H.IS_RPT is '是否报送';
comment on column MBT_PM_210_H.IS_VALID is '是否有效';
comment on column MBT_PM_210_H.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_210_H.OPT_FLAG is '操作标识';
comment on column MBT_PM_210_H.RPT_DATE is '报送日期';
comment on column MBT_PM_210_H.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_210_H.RPT_STATUS is '报送状态';
comment on column MBT_PM_210_H.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_210_H.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_210_H.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_210_H.REMARKS is '备注';
comment on column MBT_PM_210_H.CHECK_FLAG is '校验标志';
comment on column MBT_PM_210_H.CHECK_DESC is '校验说明';
comment on column MBT_PM_210_H.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_210_H.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_210_H.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_210_H.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_210_H.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_210_H.DATA_FLAG is '数据标志';
comment on column MBT_PM_210_H.DATA_OP is '操作标志';
comment on column MBT_PM_210_H.DATA_SOURCE is '数据来源';
comment on column MBT_PM_210_H.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_210_H.DATA_HASH is '数据HASH';
comment on column MBT_PM_210_H.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_H.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_H.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_210_H.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_210_H.DATA_CRT_USER is '创建人';
comment on column MBT_PM_210_H.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_210_H.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_210_H.DATA_CHG_USER is '修改人';
comment on column MBT_PM_210_H.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_210_H.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_210_H.DATA_APV_USER is '审核人';
comment on column MBT_PM_210_H.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_210_H.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_210_H.RSV1 is '备用字段';
comment on column MBT_PM_210_H.RSV2 is '备用字段';
comment on column MBT_PM_210_H.RSV3 is '备用字段';
comment on column MBT_PM_210_H.RSV4 is '备用字段';
comment on column MBT_PM_210_H.RSV5 is '备用字段';
create table MBT_PM_210_I (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
I_SPEC_EFCT_DATE VARCHAR(8),
I_SPEC_END_DATE VARCHAR(8),
I_SPEC_LINE NUMBER(15),
I_SPEC_LINE_LCY NUMBER(15),
I_SPEC_LINE_ORG NUMBER(15),
I_USED_INST_AMT NUMBER(15),
I_USED_INST_AMT_LCY NUMBER(15),
I_USED_INST_AMT_ORG NUMBER(15),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_210_I is '个人借贷账户信息-大额专项分期信息段';
comment on column MBT_PM_210_I.DATA_ID is '数据ID';
comment on column MBT_PM_210_I.DATA_DATE is '数据日期';
comment on column MBT_PM_210_I.CORP_ID is '法人ID';
comment on column MBT_PM_210_I.ORG_ID is '机构ID';
comment on column MBT_PM_210_I.GROUP_ID is '数据分组';
comment on column MBT_PM_210_I.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_210_I.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_210_I.I_SPEC_EFCT_DATE is '分期额度生效日期';
comment on column MBT_PM_210_I.I_SPEC_END_DATE is '分期额度到期日期';
comment on column MBT_PM_210_I.I_SPEC_LINE is '大额专项分期额度';
comment on column MBT_PM_210_I.I_SPEC_LINE_LCY is '大额专项分期额度人民币金额';
comment on column MBT_PM_210_I.I_SPEC_LINE_ORG is '大额专项分期额度_原始数据金额';
comment on column MBT_PM_210_I.I_USED_INST_AMT is '已用分期金额';
comment on column MBT_PM_210_I.I_USED_INST_AMT_LCY is '已用分期金额人民币金额';
comment on column MBT_PM_210_I.I_USED_INST_AMT_ORG is '已用分期金额_原始数据金额';
comment on column MBT_PM_210_I.C_CY is '币种';
comment on column MBT_PM_210_I.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_210_I.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_210_I.CUST_NO is '客户号';
comment on column MBT_PM_210_I.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_210_I.PART_TYPE is '段标识';
comment on column MBT_PM_210_I.PART_NAME is '段名称';
comment on column MBT_PM_210_I.START_DATE is '起始日期';
comment on column MBT_PM_210_I.END_DATE is '结束日期';
comment on column MBT_PM_210_I.BATCH_NO is '批次号';
comment on column MBT_PM_210_I.ROW_NUM is '行号';
comment on column MBT_PM_210_I.IS_RPT is '是否报送';
comment on column MBT_PM_210_I.IS_VALID is '是否有效';
comment on column MBT_PM_210_I.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_210_I.OPT_FLAG is '操作标识';
comment on column MBT_PM_210_I.RPT_DATE is '报送日期';
comment on column MBT_PM_210_I.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_210_I.RPT_STATUS is '报送状态';
comment on column MBT_PM_210_I.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_210_I.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_210_I.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_210_I.REMARKS is '备注';
comment on column MBT_PM_210_I.CHECK_FLAG is '校验标志';
comment on column MBT_PM_210_I.CHECK_DESC is '校验说明';
comment on column MBT_PM_210_I.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_210_I.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_210_I.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_210_I.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_210_I.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_210_I.DATA_FLAG is '数据标志';
comment on column MBT_PM_210_I.DATA_OP is '操作标志';
comment on column MBT_PM_210_I.DATA_SOURCE is '数据来源';
comment on column MBT_PM_210_I.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_210_I.DATA_HASH is '数据HASH';
comment on column MBT_PM_210_I.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_I.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_I.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_210_I.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_210_I.DATA_CRT_USER is '创建人';
comment on column MBT_PM_210_I.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_210_I.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_210_I.DATA_CHG_USER is '修改人';
comment on column MBT_PM_210_I.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_210_I.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_210_I.DATA_APV_USER is '审核人';
comment on column MBT_PM_210_I.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_210_I.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_210_I.RSV1 is '备用字段';
comment on column MBT_PM_210_I.RSV2 is '备用字段';
comment on column MBT_PM_210_I.RSV3 is '备用字段';
comment on column MBT_PM_210_I.RSV4 is '备用字段';
comment on column MBT_PM_210_I.RSV5 is '备用字段';
create table MBT_PM_210_J (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
J_ACCT_BAL NUMBER(15),
J_ACCT_BAL_LCY NUMBER(15),
J_ACCT_BAL_ORG NUMBER(15),
J_ACCT_STATUS VARCHAR(2),
J_CLOSE_DATE VARCHAR(8),
J_FIVE_CATE VARCHAR(1),
J_FIVE_CATE_ADJ_DATE VARCHAR(8),
J_LAT_RPY_AMT NUMBER(15),
J_LAT_RPY_AMT_LCY NUMBER(15),
J_LAT_RPY_AMT_ORG NUMBER(15),
J_LAT_RPY_DATE VARCHAR(8),
J_OVERD_PRD NUMBER(3),
J_REM_REP_PRD NUMBER(3),
J_RPY_STATUS VARCHAR(1),
J_TOT_OVERD NUMBER(15),
J_TOT_OVERD_LCY NUMBER(15),
J_TOT_OVERD_ORG NUMBER(15),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_210_J is '个人借贷账户信息-非月度表现信息段';
comment on column MBT_PM_210_J.DATA_ID is '数据ID';
comment on column MBT_PM_210_J.DATA_DATE is '数据日期';
comment on column MBT_PM_210_J.CORP_ID is '法人ID';
comment on column MBT_PM_210_J.ORG_ID is '机构ID';
comment on column MBT_PM_210_J.GROUP_ID is '数据分组';
comment on column MBT_PM_210_J.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_210_J.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_210_J.J_ACCT_BAL is '余额';
comment on column MBT_PM_210_J.J_ACCT_BAL_LCY is '余额人民币金额';
comment on column MBT_PM_210_J.J_ACCT_BAL_ORG is '余额_原始数据金额';
comment on column MBT_PM_210_J.J_ACCT_STATUS is '账户状态';
comment on column MBT_PM_210_J.J_CLOSE_DATE is '账户关闭日期';
comment on column MBT_PM_210_J.J_FIVE_CATE is '五级分类';
comment on column MBT_PM_210_J.J_FIVE_CATE_ADJ_DATE is '五级分类认定日期';
comment on column MBT_PM_210_J.J_LAT_RPY_AMT is '最近一次实际还款金额';
comment on column MBT_PM_210_J.J_LAT_RPY_AMT_LCY is '最近一次实际还款金额人民币金额';
comment on column MBT_PM_210_J.J_LAT_RPY_AMT_ORG is '最近一次实际还款金额_原始数据金额';
comment on column MBT_PM_210_J.J_LAT_RPY_DATE is '最近一次实际还款日期';
comment on column MBT_PM_210_J.J_OVERD_PRD is '当前逾期期数';
comment on column MBT_PM_210_J.J_REM_REP_PRD is '剩余还款期数';
comment on column MBT_PM_210_J.J_RPY_STATUS is '当前还款状态';
comment on column MBT_PM_210_J.J_TOT_OVERD is '当前逾期总额';
comment on column MBT_PM_210_J.J_TOT_OVERD_LCY is '当前逾期总额人民币金额';
comment on column MBT_PM_210_J.J_TOT_OVERD_ORG is '当前逾期总额_原始数据金额';
comment on column MBT_PM_210_J.C_CY is '币种';
comment on column MBT_PM_210_J.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_210_J.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_210_J.CUST_NO is '客户号';
comment on column MBT_PM_210_J.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_210_J.PART_TYPE is '段标识';
comment on column MBT_PM_210_J.PART_NAME is '段名称';
comment on column MBT_PM_210_J.START_DATE is '起始日期';
comment on column MBT_PM_210_J.END_DATE is '结束日期';
comment on column MBT_PM_210_J.BATCH_NO is '批次号';
comment on column MBT_PM_210_J.ROW_NUM is '行号';
comment on column MBT_PM_210_J.IS_RPT is '是否报送';
comment on column MBT_PM_210_J.IS_VALID is '是否有效';
comment on column MBT_PM_210_J.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_210_J.OPT_FLAG is '操作标识';
comment on column MBT_PM_210_J.RPT_DATE is '报送日期';
comment on column MBT_PM_210_J.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_210_J.RPT_STATUS is '报送状态';
comment on column MBT_PM_210_J.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_210_J.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_210_J.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_210_J.REMARKS is '备注';
comment on column MBT_PM_210_J.CHECK_FLAG is '校验标志';
comment on column MBT_PM_210_J.CHECK_DESC is '校验说明';
comment on column MBT_PM_210_J.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_210_J.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_210_J.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_210_J.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_210_J.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_210_J.DATA_FLAG is '数据标志';
comment on column MBT_PM_210_J.DATA_OP is '操作标志';
comment on column MBT_PM_210_J.DATA_SOURCE is '数据来源';
comment on column MBT_PM_210_J.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_210_J.DATA_HASH is '数据HASH';
comment on column MBT_PM_210_J.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_J.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_J.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_210_J.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_210_J.DATA_CRT_USER is '创建人';
comment on column MBT_PM_210_J.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_210_J.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_210_J.DATA_CHG_USER is '修改人';
comment on column MBT_PM_210_J.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_210_J.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_210_J.DATA_APV_USER is '审核人';
comment on column MBT_PM_210_J.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_210_J.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_210_J.RSV1 is '备用字段';
comment on column MBT_PM_210_J.RSV2 is '备用字段';
comment on column MBT_PM_210_J.RSV3 is '备用字段';
comment on column MBT_PM_210_J.RSV4 is '备用字段';
comment on column MBT_PM_210_J.RSV5 is '备用字段';
create table MBT_PM_210_K (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
K_CHAN_TRAN_TYPE VARCHAR(2),
K_DET_INFO VARCHAR(400),
K_DUE_TRAN_MON NUMBER(3),
K_TRAN_AMT NUMBER(15),
K_TRAN_AMT_LCY NUMBER(15),
K_TRAN_AMT_ORG NUMBER(15),
K_TRAN_DATE VARCHAR(8),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_PM_210_K is '个人借贷账户信息-特殊交易说明段';
comment on column MBT_PM_210_K.DATA_ID is '数据ID';
comment on column MBT_PM_210_K.DATA_DATE is '数据日期';
comment on column MBT_PM_210_K.CORP_ID is '法人ID';
comment on column MBT_PM_210_K.ORG_ID is '机构ID';
comment on column MBT_PM_210_K.GROUP_ID is '数据分组';
comment on column MBT_PM_210_K.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_PM_210_K.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_PM_210_K.K_CHAN_TRAN_TYPE is '交易类型';
comment on column MBT_PM_210_K.K_DET_INFO is '交易明细信息';
comment on column MBT_PM_210_K.K_DUE_TRAN_MON is '到期日期变更月数';
comment on column MBT_PM_210_K.K_TRAN_AMT is '交易金额';
comment on column MBT_PM_210_K.K_TRAN_AMT_LCY is '交易金额人民币金额';
comment on column MBT_PM_210_K.K_TRAN_AMT_ORG is '交易金额_原始数据金额';
comment on column MBT_PM_210_K.K_TRAN_DATE is '交易日期';
comment on column MBT_PM_210_K.C_CY is '币种';
comment on column MBT_PM_210_K.B_RPT_DATE is '信息报告日期';
comment on column MBT_PM_210_K.B_ACCT_CODE is '账户标识码';
comment on column MBT_PM_210_K.CUST_NO is '客户号';
comment on column MBT_PM_210_K.UNV_IDN is '通用业务标识项';
comment on column MBT_PM_210_K.PART_TYPE is '段标识';
comment on column MBT_PM_210_K.PART_NAME is '段名称';
comment on column MBT_PM_210_K.START_DATE is '起始日期';
comment on column MBT_PM_210_K.END_DATE is '结束日期';
comment on column MBT_PM_210_K.BATCH_NO is '批次号';
comment on column MBT_PM_210_K.ROW_NUM is '行号';
comment on column MBT_PM_210_K.IS_RPT is '是否报送';
comment on column MBT_PM_210_K.IS_VALID is '是否有效';
comment on column MBT_PM_210_K.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_PM_210_K.OPT_FLAG is '操作标识';
comment on column MBT_PM_210_K.RPT_DATE is '报送日期';
comment on column MBT_PM_210_K.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_PM_210_K.RPT_STATUS is '报送状态';
comment on column MBT_PM_210_K.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_PM_210_K.RPT_FB_DATE is '反馈日期';
comment on column MBT_PM_210_K.RPT_FB_MSG is '反馈信息';
comment on column MBT_PM_210_K.REMARKS is '备注';
comment on column MBT_PM_210_K.CHECK_FLAG is '校验标志';
comment on column MBT_PM_210_K.CHECK_DESC is '校验说明';
comment on column MBT_PM_210_K.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_PM_210_K.NEXT_ACTION is '工作流节点';
comment on column MBT_PM_210_K.DATA_STATUS is '正常处理数据状态';
comment on column MBT_PM_210_K.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_PM_210_K.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_PM_210_K.DATA_FLAG is '数据标志';
comment on column MBT_PM_210_K.DATA_OP is '操作标志';
comment on column MBT_PM_210_K.DATA_SOURCE is '数据来源';
comment on column MBT_PM_210_K.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_PM_210_K.DATA_HASH is '数据HASH';
comment on column MBT_PM_210_K.DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_K.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_PM_210_K.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_PM_210_K.DATA_DEL_DESC is '删除描述';
comment on column MBT_PM_210_K.DATA_CRT_USER is '创建人';
comment on column MBT_PM_210_K.DATA_CRT_DATE is '创建日期';
comment on column MBT_PM_210_K.DATA_CRT_TIME is '创建时间';
comment on column MBT_PM_210_K.DATA_CHG_USER is '修改人';
comment on column MBT_PM_210_K.DATA_CHG_DATE is '修改日期';
comment on column MBT_PM_210_K.DATA_CHG_TIME is '修改时间';
comment on column MBT_PM_210_K.DATA_APV_USER is '审核人';
comment on column MBT_PM_210_K.DATA_APV_DATE is '审核日期';
comment on column MBT_PM_210_K.DATA_APV_TIME is '审核时间';
comment on column MBT_PM_210_K.RSV1 is '备用字段';
comment on column MBT_PM_210_K.RSV2 is '备用字段';
comment on column MBT_PM_210_K.RSV3 is '备用字段';
comment on column MBT_PM_210_K.RSV4 is '备用字段';
comment on column MBT_PM_210_K.RSV5 is '备用字段';
create table MBT_RPT_210 (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_CODE VARCHAR(60),
O_BIZ_CODE VARCHAR(60),
N_BIZ_CODE VARCHAR(60),
SECTION_CHG_CNT NUMBER(10),
SECTION_DEL_CNT NUMBER(10),
WHOLE_DEL_CNT NUMBER(10),
IDN_CHG_CNT NUMBER(10),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_210 is '个人借贷账户信息';
comment on column MBT_RPT_210.DATA_ID is '数据ID';
comment on column MBT_RPT_210.DATA_DATE is '数据日期';
comment on column MBT_RPT_210.CORP_ID is '法人ID';
comment on column MBT_RPT_210.ORG_ID is '机构ID';
comment on column MBT_RPT_210.GROUP_ID is '数据分组';
comment on column MBT_RPT_210.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_210.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_210.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_210.O_BIZ_CODE is '原业务标识码';
comment on column MBT_RPT_210.N_BIZ_CODE is '新业务标识码';
comment on column MBT_RPT_210.SECTION_CHG_CNT is '段变更';
comment on column MBT_RPT_210.SECTION_DEL_CNT is '段删除';
comment on column MBT_RPT_210.WHOLE_DEL_CNT is '整笔删除';
comment on column MBT_RPT_210.IDN_CHG_CNT is '标识项变更';
comment on column MBT_RPT_210.CUST_NO is '客户号';
comment on column MBT_RPT_210.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_210.PART_TYPE is '段标识';
comment on column MBT_RPT_210.PART_NAME is '段名称';
comment on column MBT_RPT_210.START_DATE is '起始日期';
comment on column MBT_RPT_210.END_DATE is '结束日期';
comment on column MBT_RPT_210.BATCH_NO is '批次号';
comment on column MBT_RPT_210.ROW_NUM is '行号';
comment on column MBT_RPT_210.IS_RPT is '是否报送';
comment on column MBT_RPT_210.IS_VALID is '是否有效';
comment on column MBT_RPT_210.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_210.OPT_FLAG is '操作标识';
comment on column MBT_RPT_210.RPT_DATE is '报送日期';
comment on column MBT_RPT_210.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_210.RPT_STATUS is '报送状态';
comment on column MBT_RPT_210.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_210.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_210.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_210.REMARKS is '备注';
comment on column MBT_RPT_210.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_210.CHECK_DESC is '校验说明';
comment on column MBT_RPT_210.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_210.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_210.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_210.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_210.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_210.DATA_FLAG is '数据标志';
comment on column MBT_RPT_210.DATA_OP is '操作标志';
comment on column MBT_RPT_210.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_210.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_210.DATA_HASH is '数据HASH';
comment on column MBT_RPT_210.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_210.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_210.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_210.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_210.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_210.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_210.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_210.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_210.DATA_APV_USER is '审核人';
comment on column MBT_RPT_210.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_210.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_210.RSV1 is '备用字段';
comment on column MBT_RPT_210.RSV2 is '备用字段';
comment on column MBT_RPT_210.RSV3 is '备用字段';
comment on column MBT_RPT_210.RSV4 is '备用字段';
comment on column MBT_RPT_210.RSV5 is '备用字段';
create table MBT_RPT_210_B (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
B_ACCT_TYPE VARCHAR(2),
B_ID_NUM VARCHAR(40),
B_ID_TYPE VARCHAR(2),
B_INF_REC_TYPE VARCHAR(3),
B_MNGMT_ORG_CODE VARCHAR(14),
B_NAME VARCHAR(60),
B_RPT_DATE_CODE VARCHAR(2),
MON_SETTLE_DATE VARCHAR(8),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_210_B is '个人借贷账户信息-基础段';
comment on column MBT_RPT_210_B.DATA_ID is '数据ID';
comment on column MBT_RPT_210_B.DATA_DATE is '数据日期';
comment on column MBT_RPT_210_B.CORP_ID is '法人ID';
comment on column MBT_RPT_210_B.ORG_ID is '机构ID';
comment on column MBT_RPT_210_B.GROUP_ID is '数据分组';
comment on column MBT_RPT_210_B.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_210_B.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_210_B.B_ACCT_TYPE is '账户类型';
comment on column MBT_RPT_210_B.B_ID_NUM is '借款人证件号码';
comment on column MBT_RPT_210_B.B_ID_TYPE is '借款人证件类型';
comment on column MBT_RPT_210_B.B_INF_REC_TYPE is '信息记录类型';
comment on column MBT_RPT_210_B.B_MNGMT_ORG_CODE is '业务管理机构代码';
comment on column MBT_RPT_210_B.B_NAME is '借款人姓名';
comment on column MBT_RPT_210_B.B_RPT_DATE_CODE is '报告时点说明代码';
comment on column MBT_RPT_210_B.MON_SETTLE_DATE is '月度结算日';
comment on column MBT_RPT_210_B.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_210_B.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_210_B.CUST_NO is '客户号';
comment on column MBT_RPT_210_B.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_210_B.PART_TYPE is '段标识';
comment on column MBT_RPT_210_B.PART_NAME is '段名称';
comment on column MBT_RPT_210_B.START_DATE is '起始日期';
comment on column MBT_RPT_210_B.END_DATE is '结束日期';
comment on column MBT_RPT_210_B.BATCH_NO is '批次号';
comment on column MBT_RPT_210_B.ROW_NUM is '行号';
comment on column MBT_RPT_210_B.IS_RPT is '是否报送';
comment on column MBT_RPT_210_B.IS_VALID is '是否有效';
comment on column MBT_RPT_210_B.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_210_B.OPT_FLAG is '操作标识';
comment on column MBT_RPT_210_B.RPT_DATE is '报送日期';
comment on column MBT_RPT_210_B.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_210_B.RPT_STATUS is '报送状态';
comment on column MBT_RPT_210_B.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_210_B.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_210_B.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_210_B.REMARKS is '备注';
comment on column MBT_RPT_210_B.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_210_B.CHECK_DESC is '校验说明';
comment on column MBT_RPT_210_B.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_210_B.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_210_B.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_210_B.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_210_B.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_210_B.DATA_FLAG is '数据标志';
comment on column MBT_RPT_210_B.DATA_OP is '操作标志';
comment on column MBT_RPT_210_B.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_210_B.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_210_B.DATA_HASH is '数据HASH';
comment on column MBT_RPT_210_B.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_B.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_B.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_210_B.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_210_B.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_210_B.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_210_B.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_210_B.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_210_B.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_210_B.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_210_B.DATA_APV_USER is '审核人';
comment on column MBT_RPT_210_B.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_210_B.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_210_B.RSV1 is '备用字段';
comment on column MBT_RPT_210_B.RSV2 is '备用字段';
comment on column MBT_RPT_210_B.RSV3 is '备用字段';
comment on column MBT_RPT_210_B.RSV4 is '备用字段';
comment on column MBT_RPT_210_B.RSV5 is '备用字段';
create table MBT_RPT_210_C (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
C_ACCT_CRED_LINE_AMT NUMBER(15),
C_ACCT_CRED_LINE_AMT_LCY NUMBER(15),
C_ACCT_CRED_LINE_AMT_ORG NUMBER(15),
C_APPLY_BUSI_DIST VARCHAR(6),
C_ASSET_TRAND_FLAG VARCHAR(1),
C_BUSI_DTL_LINES VARCHAR(2),
C_BUSI_LINES VARCHAR(1),
C_CREDIT_ID VARCHAR(4),
C_CY VARCHAR(3),
C_DUE_DATE VARCHAR(8),
C_FIRST_HOU_LOAN_FLAG VARCHAR(2),
C_FLAG VARCHAR(1),
C_FUND_SOU VARCHAR(2),
C_GUAR_MODE VARCHAR(1),
C_LOAN_AMT NUMBER(15),
C_LOAN_AMT_LCY NUMBER(15),
C_LOAN_AMT_ORG NUMBER(15),
C_LOAN_CON_CODE VARCHAR(200),
C_LOAN_FORM VARCHAR(1),
C_OPEN_DATE VARCHAR(8),
C_OTH_REPY_GUAR_WAY VARCHAR(2),
C_REPAY_FREQCY VARCHAR(2),
C_REPAY_MODE VARCHAR(2),
C_REPAY_PRD NUMBER(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_210_C is '个人借贷账户信息-基本信息段';
comment on column MBT_RPT_210_C.DATA_ID is '数据ID';
comment on column MBT_RPT_210_C.DATA_DATE is '数据日期';
comment on column MBT_RPT_210_C.CORP_ID is '法人ID';
comment on column MBT_RPT_210_C.ORG_ID is '机构ID';
comment on column MBT_RPT_210_C.GROUP_ID is '数据分组';
comment on column MBT_RPT_210_C.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_210_C.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_210_C.C_ACCT_CRED_LINE_AMT is '信用额度';
comment on column MBT_RPT_210_C.C_ACCT_CRED_LINE_AMT_LCY is '信用额度人民币金额';
comment on column MBT_RPT_210_C.C_ACCT_CRED_LINE_AMT_ORG is '信用额度_原始数据金额';
comment on column MBT_RPT_210_C.C_APPLY_BUSI_DIST is '业务申请地行政区划代码';
comment on column MBT_RPT_210_C.C_ASSET_TRAND_FLAG is '资产转让标志';
comment on column MBT_RPT_210_C.C_BUSI_DTL_LINES is '借贷业务种类细分';
comment on column MBT_RPT_210_C.C_BUSI_LINES is '借贷业务大类';
comment on column MBT_RPT_210_C.C_CREDIT_ID is '卡片标识号';
comment on column MBT_RPT_210_C.C_CY is '币种';
comment on column MBT_RPT_210_C.C_DUE_DATE is '到期日期';
comment on column MBT_RPT_210_C.C_FIRST_HOU_LOAN_FLAG is '是否为首套住房贷款';
comment on column MBT_RPT_210_C.C_FLAG is '分次放款标志';
comment on column MBT_RPT_210_C.C_FUND_SOU is '业务经营类型';
comment on column MBT_RPT_210_C.C_GUAR_MODE is '担保方式';
comment on column MBT_RPT_210_C.C_LOAN_AMT is '借款金额';
comment on column MBT_RPT_210_C.C_LOAN_AMT_LCY is '借款金额人民币金额';
comment on column MBT_RPT_210_C.C_LOAN_AMT_ORG is '借款金额_原始数据金额';
comment on column MBT_RPT_210_C.C_LOAN_CON_CODE is '贷款合同编号';
comment on column MBT_RPT_210_C.C_LOAN_FORM is '贷款发放形式';
comment on column MBT_RPT_210_C.C_OPEN_DATE is '开户日期';
comment on column MBT_RPT_210_C.C_OTH_REPY_GUAR_WAY is '其他还款保证方式';
comment on column MBT_RPT_210_C.C_REPAY_FREQCY is '还款频率';
comment on column MBT_RPT_210_C.C_REPAY_MODE is '还款方式';
comment on column MBT_RPT_210_C.C_REPAY_PRD is '还款期数';
comment on column MBT_RPT_210_C.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_210_C.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_210_C.CUST_NO is '客户号';
comment on column MBT_RPT_210_C.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_210_C.PART_TYPE is '段标识';
comment on column MBT_RPT_210_C.PART_NAME is '段名称';
comment on column MBT_RPT_210_C.START_DATE is '起始日期';
comment on column MBT_RPT_210_C.END_DATE is '结束日期';
comment on column MBT_RPT_210_C.BATCH_NO is '批次号';
comment on column MBT_RPT_210_C.ROW_NUM is '行号';
comment on column MBT_RPT_210_C.IS_RPT is '是否报送';
comment on column MBT_RPT_210_C.IS_VALID is '是否有效';
comment on column MBT_RPT_210_C.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_210_C.OPT_FLAG is '操作标识';
comment on column MBT_RPT_210_C.RPT_DATE is '报送日期';
comment on column MBT_RPT_210_C.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_210_C.RPT_STATUS is '报送状态';
comment on column MBT_RPT_210_C.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_210_C.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_210_C.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_210_C.REMARKS is '备注';
comment on column MBT_RPT_210_C.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_210_C.CHECK_DESC is '校验说明';
comment on column MBT_RPT_210_C.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_210_C.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_210_C.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_210_C.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_210_C.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_210_C.DATA_FLAG is '数据标志';
comment on column MBT_RPT_210_C.DATA_OP is '操作标志';
comment on column MBT_RPT_210_C.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_210_C.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_210_C.DATA_HASH is '数据HASH';
comment on column MBT_RPT_210_C.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_C.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_C.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_210_C.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_210_C.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_210_C.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_210_C.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_210_C.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_210_C.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_210_C.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_210_C.DATA_APV_USER is '审核人';
comment on column MBT_RPT_210_C.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_210_C.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_210_C.RSV1 is '备用字段';
comment on column MBT_RPT_210_C.RSV2 is '备用字段';
comment on column MBT_RPT_210_C.RSV3 is '备用字段';
comment on column MBT_RPT_210_C.RSV4 is '备用字段';
comment on column MBT_RPT_210_C.RSV5 is '备用字段';
create table MBT_RPT_210_D (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
D_ARLP_AMT NUMBER(15),
D_ARLP_AMT_LCY NUMBER(15),
D_ARLP_AMT_ORG NUMBER(15),
D_ARLP_CERT_NUM VARCHAR(80),
D_ARLP_CERT_TYPE VARCHAR(2),
D_ARLP_ID_TYPE VARCHAR(2),
D_ARLP_NAME VARCHAR(160),
D_ARLP_TYPE VARCHAR(1),
D_MAX_GUAR_MCC VARCHAR(60),
D_WARTY_SIGN VARCHAR(1),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_210_D is '个人借贷账户信息-相关还款责任人段';
comment on column MBT_RPT_210_D.DATA_ID is '数据ID';
comment on column MBT_RPT_210_D.DATA_DATE is '数据日期';
comment on column MBT_RPT_210_D.CORP_ID is '法人ID';
comment on column MBT_RPT_210_D.ORG_ID is '机构ID';
comment on column MBT_RPT_210_D.GROUP_ID is '数据分组';
comment on column MBT_RPT_210_D.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_210_D.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_210_D.D_ARLP_AMT is '还款责任金额';
comment on column MBT_RPT_210_D.D_ARLP_AMT_LCY is '还款责任金额人民币金额';
comment on column MBT_RPT_210_D.D_ARLP_AMT_ORG is '还款责任金额_原始数据金额';
comment on column MBT_RPT_210_D.D_ARLP_CERT_NUM is '责任人身份标识号码';
comment on column MBT_RPT_210_D.D_ARLP_CERT_TYPE is '责任人身份标识类型';
comment on column MBT_RPT_210_D.D_ARLP_ID_TYPE is '身份类别';
comment on column MBT_RPT_210_D.D_ARLP_NAME is '责任人名称';
comment on column MBT_RPT_210_D.D_ARLP_TYPE is '还款责任人类型';
comment on column MBT_RPT_210_D.D_MAX_GUAR_MCC is '保证合同编号';
comment on column MBT_RPT_210_D.D_WARTY_SIGN is '联保标志';
comment on column MBT_RPT_210_D.C_CY is '币种';
comment on column MBT_RPT_210_D.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_210_D.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_210_D.CUST_NO is '客户号';
comment on column MBT_RPT_210_D.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_210_D.PART_TYPE is '段标识';
comment on column MBT_RPT_210_D.PART_NAME is '段名称';
comment on column MBT_RPT_210_D.START_DATE is '起始日期';
comment on column MBT_RPT_210_D.END_DATE is '结束日期';
comment on column MBT_RPT_210_D.BATCH_NO is '批次号';
comment on column MBT_RPT_210_D.ROW_NUM is '行号';
comment on column MBT_RPT_210_D.IS_RPT is '是否报送';
comment on column MBT_RPT_210_D.IS_VALID is '是否有效';
comment on column MBT_RPT_210_D.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_210_D.OPT_FLAG is '操作标识';
comment on column MBT_RPT_210_D.RPT_DATE is '报送日期';
comment on column MBT_RPT_210_D.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_210_D.RPT_STATUS is '报送状态';
comment on column MBT_RPT_210_D.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_210_D.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_210_D.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_210_D.REMARKS is '备注';
comment on column MBT_RPT_210_D.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_210_D.CHECK_DESC is '校验说明';
comment on column MBT_RPT_210_D.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_210_D.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_210_D.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_210_D.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_210_D.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_210_D.DATA_FLAG is '数据标志';
comment on column MBT_RPT_210_D.DATA_OP is '操作标志';
comment on column MBT_RPT_210_D.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_210_D.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_210_D.DATA_HASH is '数据HASH';
comment on column MBT_RPT_210_D.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_D.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_D.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_210_D.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_210_D.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_210_D.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_210_D.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_210_D.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_210_D.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_210_D.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_210_D.DATA_APV_USER is '审核人';
comment on column MBT_RPT_210_D.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_210_D.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_210_D.RSV1 is '备用字段';
comment on column MBT_RPT_210_D.RSV2 is '备用字段';
comment on column MBT_RPT_210_D.RSV3 is '备用字段';
comment on column MBT_RPT_210_D.RSV4 is '备用字段';
comment on column MBT_RPT_210_D.RSV5 is '备用字段';
create table MBT_RPT_210_E (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
E_CCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_210_E is '个人借贷账户信息-抵质押物信息段';
comment on column MBT_RPT_210_E.DATA_ID is '数据ID';
comment on column MBT_RPT_210_E.DATA_DATE is '数据日期';
comment on column MBT_RPT_210_E.CORP_ID is '法人ID';
comment on column MBT_RPT_210_E.ORG_ID is '机构ID';
comment on column MBT_RPT_210_E.GROUP_ID is '数据分组';
comment on column MBT_RPT_210_E.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_210_E.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_210_E.E_CCC is '抵（质）押合同标识码';
comment on column MBT_RPT_210_E.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_210_E.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_210_E.CUST_NO is '客户号';
comment on column MBT_RPT_210_E.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_210_E.PART_TYPE is '段标识';
comment on column MBT_RPT_210_E.PART_NAME is '段名称';
comment on column MBT_RPT_210_E.START_DATE is '起始日期';
comment on column MBT_RPT_210_E.END_DATE is '结束日期';
comment on column MBT_RPT_210_E.BATCH_NO is '批次号';
comment on column MBT_RPT_210_E.ROW_NUM is '行号';
comment on column MBT_RPT_210_E.IS_RPT is '是否报送';
comment on column MBT_RPT_210_E.IS_VALID is '是否有效';
comment on column MBT_RPT_210_E.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_210_E.OPT_FLAG is '操作标识';
comment on column MBT_RPT_210_E.RPT_DATE is '报送日期';
comment on column MBT_RPT_210_E.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_210_E.RPT_STATUS is '报送状态';
comment on column MBT_RPT_210_E.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_210_E.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_210_E.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_210_E.REMARKS is '备注';
comment on column MBT_RPT_210_E.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_210_E.CHECK_DESC is '校验说明';
comment on column MBT_RPT_210_E.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_210_E.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_210_E.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_210_E.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_210_E.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_210_E.DATA_FLAG is '数据标志';
comment on column MBT_RPT_210_E.DATA_OP is '操作标志';
comment on column MBT_RPT_210_E.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_210_E.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_210_E.DATA_HASH is '数据HASH';
comment on column MBT_RPT_210_E.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_E.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_E.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_210_E.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_210_E.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_210_E.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_210_E.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_210_E.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_210_E.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_210_E.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_210_E.DATA_APV_USER is '审核人';
comment on column MBT_RPT_210_E.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_210_E.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_210_E.RSV1 is '备用字段';
comment on column MBT_RPT_210_E.RSV2 is '备用字段';
comment on column MBT_RPT_210_E.RSV3 is '备用字段';
comment on column MBT_RPT_210_E.RSV4 is '备用字段';
comment on column MBT_RPT_210_E.RSV5 is '备用字段';
create table MBT_RPT_210_F (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
F_MCC VARCHAR(60),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_210_F is '个人借贷账户信息-授信额度信息段';
comment on column MBT_RPT_210_F.DATA_ID is '数据ID';
comment on column MBT_RPT_210_F.DATA_DATE is '数据日期';
comment on column MBT_RPT_210_F.CORP_ID is '法人ID';
comment on column MBT_RPT_210_F.ORG_ID is '机构ID';
comment on column MBT_RPT_210_F.GROUP_ID is '数据分组';
comment on column MBT_RPT_210_F.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_210_F.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_210_F.F_MCC is '授信协议标识码';
comment on column MBT_RPT_210_F.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_210_F.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_210_F.CUST_NO is '客户号';
comment on column MBT_RPT_210_F.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_210_F.PART_TYPE is '段标识';
comment on column MBT_RPT_210_F.PART_NAME is '段名称';
comment on column MBT_RPT_210_F.START_DATE is '起始日期';
comment on column MBT_RPT_210_F.END_DATE is '结束日期';
comment on column MBT_RPT_210_F.BATCH_NO is '批次号';
comment on column MBT_RPT_210_F.ROW_NUM is '行号';
comment on column MBT_RPT_210_F.IS_RPT is '是否报送';
comment on column MBT_RPT_210_F.IS_VALID is '是否有效';
comment on column MBT_RPT_210_F.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_210_F.OPT_FLAG is '操作标识';
comment on column MBT_RPT_210_F.RPT_DATE is '报送日期';
comment on column MBT_RPT_210_F.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_210_F.RPT_STATUS is '报送状态';
comment on column MBT_RPT_210_F.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_210_F.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_210_F.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_210_F.REMARKS is '备注';
comment on column MBT_RPT_210_F.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_210_F.CHECK_DESC is '校验说明';
comment on column MBT_RPT_210_F.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_210_F.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_210_F.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_210_F.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_210_F.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_210_F.DATA_FLAG is '数据标志';
comment on column MBT_RPT_210_F.DATA_OP is '操作标志';
comment on column MBT_RPT_210_F.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_210_F.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_210_F.DATA_HASH is '数据HASH';
comment on column MBT_RPT_210_F.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_F.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_F.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_210_F.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_210_F.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_210_F.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_210_F.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_210_F.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_210_F.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_210_F.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_210_F.DATA_APV_USER is '审核人';
comment on column MBT_RPT_210_F.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_210_F.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_210_F.RSV1 is '备用字段';
comment on column MBT_RPT_210_F.RSV2 is '备用字段';
comment on column MBT_RPT_210_F.RSV3 is '备用字段';
comment on column MBT_RPT_210_F.RSV4 is '备用字段';
comment on column MBT_RPT_210_F.RSV5 is '备用字段';
create table MBT_RPT_210_G (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
G_INIT_CRED_NAME VARCHAR(160),
G_INIT_CRED_ORG_NM VARCHAR(18),
G_INIT_RPY_STS VARCHAR(1),
G_ORIG_DBT_CATE VARCHAR(1),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_210_G is '个人借贷账户信息-初始债权说明段';
comment on column MBT_RPT_210_G.DATA_ID is '数据ID';
comment on column MBT_RPT_210_G.DATA_DATE is '数据日期';
comment on column MBT_RPT_210_G.CORP_ID is '法人ID';
comment on column MBT_RPT_210_G.ORG_ID is '机构ID';
comment on column MBT_RPT_210_G.GROUP_ID is '数据分组';
comment on column MBT_RPT_210_G.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_210_G.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_210_G.G_INIT_CRED_NAME is '初始债权人名称';
comment on column MBT_RPT_210_G.G_INIT_CRED_ORG_NM is '初始债权人机构代码';
comment on column MBT_RPT_210_G.G_INIT_RPY_STS is '债权转移时的还款状态';
comment on column MBT_RPT_210_G.G_ORIG_DBT_CATE is '原债务种类';
comment on column MBT_RPT_210_G.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_210_G.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_210_G.CUST_NO is '客户号';
comment on column MBT_RPT_210_G.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_210_G.PART_TYPE is '段标识';
comment on column MBT_RPT_210_G.PART_NAME is '段名称';
comment on column MBT_RPT_210_G.START_DATE is '起始日期';
comment on column MBT_RPT_210_G.END_DATE is '结束日期';
comment on column MBT_RPT_210_G.BATCH_NO is '批次号';
comment on column MBT_RPT_210_G.ROW_NUM is '行号';
comment on column MBT_RPT_210_G.IS_RPT is '是否报送';
comment on column MBT_RPT_210_G.IS_VALID is '是否有效';
comment on column MBT_RPT_210_G.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_210_G.OPT_FLAG is '操作标识';
comment on column MBT_RPT_210_G.RPT_DATE is '报送日期';
comment on column MBT_RPT_210_G.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_210_G.RPT_STATUS is '报送状态';
comment on column MBT_RPT_210_G.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_210_G.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_210_G.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_210_G.REMARKS is '备注';
comment on column MBT_RPT_210_G.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_210_G.CHECK_DESC is '校验说明';
comment on column MBT_RPT_210_G.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_210_G.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_210_G.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_210_G.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_210_G.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_210_G.DATA_FLAG is '数据标志';
comment on column MBT_RPT_210_G.DATA_OP is '操作标志';
comment on column MBT_RPT_210_G.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_210_G.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_210_G.DATA_HASH is '数据HASH';
comment on column MBT_RPT_210_G.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_G.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_G.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_210_G.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_210_G.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_210_G.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_210_G.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_210_G.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_210_G.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_210_G.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_210_G.DATA_APV_USER is '审核人';
comment on column MBT_RPT_210_G.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_210_G.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_210_G.RSV1 is '备用字段';
comment on column MBT_RPT_210_G.RSV2 is '备用字段';
comment on column MBT_RPT_210_G.RSV3 is '备用字段';
comment on column MBT_RPT_210_G.RSV4 is '备用字段';
comment on column MBT_RPT_210_G.RSV5 is '备用字段';
create table MBT_RPT_210_H (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
H_ACCT_BAL NUMBER(15),
H_ACCT_BAL_LCY NUMBER(15),
H_ACCT_BAL_ORG NUMBER(15),
H_ACCT_STATUS VARCHAR(2),
H_ACT_RPY_AMT NUMBER(15),
H_ACT_RPY_AMT_LCY NUMBER(15),
H_ACT_RPY_AMT_ORG NUMBER(15),
H_CLOSE_DATE VARCHAR(8),
H_CUR_RPY_AMT NUMBER(15),
H_CUR_RPY_AMT_LCY NUMBER(15),
H_CUR_RPY_AMT_ORG NUMBER(15),
H_FIVE_CATE VARCHAR(1),
H_FIVE_CATE_ADJ_DATE VARCHAR(8),
H_LAT_RPY_DATE VARCHAR(8),
H_MONTH VARCHAR(7),
H_NOTLSU_BAL NUMBER(15),
H_NOTLSU_BAL_LCY NUMBER(15),
H_NOTLSU_BAL_ORG NUMBER(15),
H_OVAER_PRINC NUMBER(15),
H_OVAER_PRINC_LCY NUMBER(15),
H_OVAER_PRINC_ORG NUMBER(15),
H_OVERD31_60PRINC NUMBER(15),
H_OVERD31_60PRINC_LCY NUMBER(15),
H_OVERD31_60PRINC_ORG NUMBER(15),
H_OVERD61_90PRINC NUMBER(15),
H_OVERD61_90PRINC_LCY NUMBER(15),
H_OVERD61_90PRINC_ORG NUMBER(15),
H_OVERD91_180PRINC NUMBER(15),
H_OVERD91_180PRINC_LCY NUMBER(15),
H_OVERD91_180PRINC_ORG NUMBER(15),
H_OVERD_PRD NUMBER(3),
H_OVERD_PRINC180 NUMBER(15),
H_OVERD_PRINC180_LCY NUMBER(15),
H_OVERD_PRINC180_ORG NUMBER(15),
H_OVERD_RAW_BA_OVE180 NUMBER(15),
H_OVERD_RAW_BA_OVE180_LCY NUMBER(15),
H_OVERD_RAW_BA_OVE180_ORG NUMBER(15),
H_PRID_ACCT_BAL NUMBER(15),
H_PRID_ACCT_BAL_LCY NUMBER(15),
H_PRID_ACCT_BAL_ORG NUMBER(15),
H_REM_REP_PRD NUMBER(3),
H_RPY_PRCT NUMBER(3),
H_RPY_STATUS VARCHAR(1),
H_SETT_DATE VARCHAR(8),
H_TOT_OVERD NUMBER(15),
H_TOT_OVERD_LCY NUMBER(15),
H_TOT_OVERD_ORG NUMBER(15),
H_USED_AMT NUMBER(15),
H_USED_AMT_LCY NUMBER(15),
H_USED_AMT_ORG NUMBER(15),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_210_H is '个人借贷账户信息-月度表现信息段';
comment on column MBT_RPT_210_H.DATA_ID is '数据ID';
comment on column MBT_RPT_210_H.DATA_DATE is '数据日期';
comment on column MBT_RPT_210_H.CORP_ID is '法人ID';
comment on column MBT_RPT_210_H.ORG_ID is '机构ID';
comment on column MBT_RPT_210_H.GROUP_ID is '数据分组';
comment on column MBT_RPT_210_H.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_210_H.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_210_H.H_ACCT_BAL is '余额';
comment on column MBT_RPT_210_H.H_ACCT_BAL_LCY is '余额人民币金额';
comment on column MBT_RPT_210_H.H_ACCT_BAL_ORG is '余额_原始数据金额';
comment on column MBT_RPT_210_H.H_ACCT_STATUS is '账户状态';
comment on column MBT_RPT_210_H.H_ACT_RPY_AMT is '本月实际还款金额';
comment on column MBT_RPT_210_H.H_ACT_RPY_AMT_LCY is '本月实际还款金额人民币金额';
comment on column MBT_RPT_210_H.H_ACT_RPY_AMT_ORG is '本月实际还款金额_原始数据金额';
comment on column MBT_RPT_210_H.H_CLOSE_DATE is '账户关闭日期';
comment on column MBT_RPT_210_H.H_CUR_RPY_AMT is '本月应还款金额';
comment on column MBT_RPT_210_H.H_CUR_RPY_AMT_LCY is '本月应还款金额人民币金额';
comment on column MBT_RPT_210_H.H_CUR_RPY_AMT_ORG is '本月应还款金额_原始数据金额';
comment on column MBT_RPT_210_H.H_FIVE_CATE is '五级分类';
comment on column MBT_RPT_210_H.H_FIVE_CATE_ADJ_DATE is '五级分类认定日期';
comment on column MBT_RPT_210_H.H_LAT_RPY_DATE is '最近一次实际还款日期';
comment on column MBT_RPT_210_H.H_MONTH is '月份';
comment on column MBT_RPT_210_H.H_NOTLSU_BAL is '未出单的大额专项分期余额';
comment on column MBT_RPT_210_H.H_NOTLSU_BAL_LCY is '未出单的大额专项分期余额人民币金额';
comment on column MBT_RPT_210_H.H_NOTLSU_BAL_ORG is '未出单的大额专项分期余额_原始数据金额';
comment on column MBT_RPT_210_H.H_OVAER_PRINC is '当前逾期本金';
comment on column MBT_RPT_210_H.H_OVAER_PRINC_LCY is '当前逾期本金人民币金额';
comment on column MBT_RPT_210_H.H_OVAER_PRINC_ORG is '当前逾期本金_原始数据金额';
comment on column MBT_RPT_210_H.H_OVERD31_60PRINC is '逾期31-60天未归还本金';
comment on column MBT_RPT_210_H.H_OVERD31_60PRINC_LCY is '逾期31-60天未归还本金人民币金额';
comment on column MBT_RPT_210_H.H_OVERD31_60PRINC_ORG is '逾期31-60天未归还本金_原始数据金额';
comment on column MBT_RPT_210_H.H_OVERD61_90PRINC is '逾期61-90天未归还本金';
comment on column MBT_RPT_210_H.H_OVERD61_90PRINC_LCY is '逾期61-90天未归还本金人民币金额';
comment on column MBT_RPT_210_H.H_OVERD61_90PRINC_ORG is '逾期61-90天未归还本金_原始数据金额';
comment on column MBT_RPT_210_H.H_OVERD91_180PRINC is '逾期91-180天未归还本金';
comment on column MBT_RPT_210_H.H_OVERD91_180PRINC_LCY is '逾期91-180天未归还本金人民币金额';
comment on column MBT_RPT_210_H.H_OVERD91_180PRINC_ORG is '逾期91-180天未归还本金_原始数据金额';
comment on column MBT_RPT_210_H.H_OVERD_PRD is '当前逾期期数';
comment on column MBT_RPT_210_H.H_OVERD_PRINC180 is '逾期180天以上未归还本金';
comment on column MBT_RPT_210_H.H_OVERD_PRINC180_LCY is '逾期180天以上未归还本金人民币金额';
comment on column MBT_RPT_210_H.H_OVERD_PRINC180_ORG is '逾期180天以上未归还本金_原始数据金额';
comment on column MBT_RPT_210_H.H_OVERD_RAW_BA_OVE180 is '透支180天以上未还余额';
comment on column MBT_RPT_210_H.H_OVERD_RAW_BA_OVE180_LCY is '透支180天以上未还余额人民币金额';
comment on column MBT_RPT_210_H.H_OVERD_RAW_BA_OVE180_ORG is '透支180天以上未还余额_原始数据金额';
comment on column MBT_RPT_210_H.H_PRID_ACCT_BAL is '本期账单余额';
comment on column MBT_RPT_210_H.H_PRID_ACCT_BAL_LCY is '本期账单余额人民币金额';
comment on column MBT_RPT_210_H.H_PRID_ACCT_BAL_ORG is '本期账单余额_原始数据金额';
comment on column MBT_RPT_210_H.H_REM_REP_PRD is '剩余还款期数';
comment on column MBT_RPT_210_H.H_RPY_PRCT is '实际还款百分比';
comment on column MBT_RPT_210_H.H_RPY_STATUS is '当前还款状态';
comment on column MBT_RPT_210_H.H_SETT_DATE is '结算/应还款日';
comment on column MBT_RPT_210_H.H_TOT_OVERD is '当前逾期总额';
comment on column MBT_RPT_210_H.H_TOT_OVERD_LCY is '当前逾期总额人民币金额';
comment on column MBT_RPT_210_H.H_TOT_OVERD_ORG is '当前逾期总额_原始数据金额';
comment on column MBT_RPT_210_H.H_USED_AMT is '已使用额度';
comment on column MBT_RPT_210_H.H_USED_AMT_LCY is '已使用额度人民币金额';
comment on column MBT_RPT_210_H.H_USED_AMT_ORG is '已使用额度_原始数据金额';
comment on column MBT_RPT_210_H.C_CY is '币种';
comment on column MBT_RPT_210_H.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_210_H.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_210_H.CUST_NO is '客户号';
comment on column MBT_RPT_210_H.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_210_H.PART_TYPE is '段标识';
comment on column MBT_RPT_210_H.PART_NAME is '段名称';
comment on column MBT_RPT_210_H.START_DATE is '起始日期';
comment on column MBT_RPT_210_H.END_DATE is '结束日期';
comment on column MBT_RPT_210_H.BATCH_NO is '批次号';
comment on column MBT_RPT_210_H.ROW_NUM is '行号';
comment on column MBT_RPT_210_H.IS_RPT is '是否报送';
comment on column MBT_RPT_210_H.IS_VALID is '是否有效';
comment on column MBT_RPT_210_H.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_210_H.OPT_FLAG is '操作标识';
comment on column MBT_RPT_210_H.RPT_DATE is '报送日期';
comment on column MBT_RPT_210_H.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_210_H.RPT_STATUS is '报送状态';
comment on column MBT_RPT_210_H.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_210_H.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_210_H.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_210_H.REMARKS is '备注';
comment on column MBT_RPT_210_H.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_210_H.CHECK_DESC is '校验说明';
comment on column MBT_RPT_210_H.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_210_H.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_210_H.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_210_H.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_210_H.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_210_H.DATA_FLAG is '数据标志';
comment on column MBT_RPT_210_H.DATA_OP is '操作标志';
comment on column MBT_RPT_210_H.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_210_H.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_210_H.DATA_HASH is '数据HASH';
comment on column MBT_RPT_210_H.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_H.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_H.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_210_H.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_210_H.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_210_H.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_210_H.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_210_H.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_210_H.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_210_H.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_210_H.DATA_APV_USER is '审核人';
comment on column MBT_RPT_210_H.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_210_H.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_210_H.RSV1 is '备用字段';
comment on column MBT_RPT_210_H.RSV2 is '备用字段';
comment on column MBT_RPT_210_H.RSV3 is '备用字段';
comment on column MBT_RPT_210_H.RSV4 is '备用字段';
comment on column MBT_RPT_210_H.RSV5 is '备用字段';
create table MBT_RPT_210_I (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
I_SPEC_EFCT_DATE VARCHAR(8),
I_SPEC_END_DATE VARCHAR(8),
I_SPEC_LINE NUMBER(15),
I_SPEC_LINE_LCY NUMBER(15),
I_SPEC_LINE_ORG NUMBER(15),
I_USED_INST_AMT NUMBER(15),
I_USED_INST_AMT_LCY NUMBER(15),
I_USED_INST_AMT_ORG NUMBER(15),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_210_I is '个人借贷账户信息-大额专项分期信息段';
comment on column MBT_RPT_210_I.DATA_ID is '数据ID';
comment on column MBT_RPT_210_I.DATA_DATE is '数据日期';
comment on column MBT_RPT_210_I.CORP_ID is '法人ID';
comment on column MBT_RPT_210_I.ORG_ID is '机构ID';
comment on column MBT_RPT_210_I.GROUP_ID is '数据分组';
comment on column MBT_RPT_210_I.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_210_I.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_210_I.I_SPEC_EFCT_DATE is '分期额度生效日期';
comment on column MBT_RPT_210_I.I_SPEC_END_DATE is '分期额度到期日期';
comment on column MBT_RPT_210_I.I_SPEC_LINE is '大额专项分期额度';
comment on column MBT_RPT_210_I.I_SPEC_LINE_LCY is '大额专项分期额度人民币金额';
comment on column MBT_RPT_210_I.I_SPEC_LINE_ORG is '大额专项分期额度_原始数据金额';
comment on column MBT_RPT_210_I.I_USED_INST_AMT is '已用分期金额';
comment on column MBT_RPT_210_I.I_USED_INST_AMT_LCY is '已用分期金额人民币金额';
comment on column MBT_RPT_210_I.I_USED_INST_AMT_ORG is '已用分期金额_原始数据金额';
comment on column MBT_RPT_210_I.C_CY is '币种';
comment on column MBT_RPT_210_I.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_210_I.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_210_I.CUST_NO is '客户号';
comment on column MBT_RPT_210_I.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_210_I.PART_TYPE is '段标识';
comment on column MBT_RPT_210_I.PART_NAME is '段名称';
comment on column MBT_RPT_210_I.START_DATE is '起始日期';
comment on column MBT_RPT_210_I.END_DATE is '结束日期';
comment on column MBT_RPT_210_I.BATCH_NO is '批次号';
comment on column MBT_RPT_210_I.ROW_NUM is '行号';
comment on column MBT_RPT_210_I.IS_RPT is '是否报送';
comment on column MBT_RPT_210_I.IS_VALID is '是否有效';
comment on column MBT_RPT_210_I.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_210_I.OPT_FLAG is '操作标识';
comment on column MBT_RPT_210_I.RPT_DATE is '报送日期';
comment on column MBT_RPT_210_I.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_210_I.RPT_STATUS is '报送状态';
comment on column MBT_RPT_210_I.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_210_I.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_210_I.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_210_I.REMARKS is '备注';
comment on column MBT_RPT_210_I.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_210_I.CHECK_DESC is '校验说明';
comment on column MBT_RPT_210_I.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_210_I.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_210_I.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_210_I.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_210_I.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_210_I.DATA_FLAG is '数据标志';
comment on column MBT_RPT_210_I.DATA_OP is '操作标志';
comment on column MBT_RPT_210_I.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_210_I.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_210_I.DATA_HASH is '数据HASH';
comment on column MBT_RPT_210_I.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_I.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_I.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_210_I.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_210_I.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_210_I.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_210_I.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_210_I.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_210_I.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_210_I.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_210_I.DATA_APV_USER is '审核人';
comment on column MBT_RPT_210_I.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_210_I.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_210_I.RSV1 is '备用字段';
comment on column MBT_RPT_210_I.RSV2 is '备用字段';
comment on column MBT_RPT_210_I.RSV3 is '备用字段';
comment on column MBT_RPT_210_I.RSV4 is '备用字段';
comment on column MBT_RPT_210_I.RSV5 is '备用字段';
create table MBT_RPT_210_J (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
J_ACCT_BAL NUMBER(15),
J_ACCT_BAL_LCY NUMBER(15),
J_ACCT_BAL_ORG NUMBER(15),
J_ACCT_STATUS VARCHAR(2),
J_CLOSE_DATE VARCHAR(8),
J_FIVE_CATE VARCHAR(1),
J_FIVE_CATE_ADJ_DATE VARCHAR(8),
J_LAT_RPY_AMT NUMBER(15),
J_LAT_RPY_AMT_LCY NUMBER(15),
J_LAT_RPY_AMT_ORG NUMBER(15),
J_LAT_RPY_DATE VARCHAR(8),
J_OVERD_PRD NUMBER(3),
J_REM_REP_PRD NUMBER(3),
J_RPY_STATUS VARCHAR(1),
J_TOT_OVERD NUMBER(15),
J_TOT_OVERD_LCY NUMBER(15),
J_TOT_OVERD_ORG NUMBER(15),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_210_J is '个人借贷账户信息-非月度表现信息段';
comment on column MBT_RPT_210_J.DATA_ID is '数据ID';
comment on column MBT_RPT_210_J.DATA_DATE is '数据日期';
comment on column MBT_RPT_210_J.CORP_ID is '法人ID';
comment on column MBT_RPT_210_J.ORG_ID is '机构ID';
comment on column MBT_RPT_210_J.GROUP_ID is '数据分组';
comment on column MBT_RPT_210_J.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_210_J.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_210_J.J_ACCT_BAL is '余额';
comment on column MBT_RPT_210_J.J_ACCT_BAL_LCY is '余额人民币金额';
comment on column MBT_RPT_210_J.J_ACCT_BAL_ORG is '余额_原始数据金额';
comment on column MBT_RPT_210_J.J_ACCT_STATUS is '账户状态';
comment on column MBT_RPT_210_J.J_CLOSE_DATE is '账户关闭日期';
comment on column MBT_RPT_210_J.J_FIVE_CATE is '五级分类';
comment on column MBT_RPT_210_J.J_FIVE_CATE_ADJ_DATE is '五级分类认定日期';
comment on column MBT_RPT_210_J.J_LAT_RPY_AMT is '最近一次实际还款金额';
comment on column MBT_RPT_210_J.J_LAT_RPY_AMT_LCY is '最近一次实际还款金额人民币金额';
comment on column MBT_RPT_210_J.J_LAT_RPY_AMT_ORG is '最近一次实际还款金额_原始数据金额';
comment on column MBT_RPT_210_J.J_LAT_RPY_DATE is '最近一次实际还款日期';
comment on column MBT_RPT_210_J.J_OVERD_PRD is '当前逾期期数';
comment on column MBT_RPT_210_J.J_REM_REP_PRD is '剩余还款期数';
comment on column MBT_RPT_210_J.J_RPY_STATUS is '当前还款状态';
comment on column MBT_RPT_210_J.J_TOT_OVERD is '当前逾期总额';
comment on column MBT_RPT_210_J.J_TOT_OVERD_LCY is '当前逾期总额人民币金额';
comment on column MBT_RPT_210_J.J_TOT_OVERD_ORG is '当前逾期总额_原始数据金额';
comment on column MBT_RPT_210_J.C_CY is '币种';
comment on column MBT_RPT_210_J.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_210_J.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_210_J.CUST_NO is '客户号';
comment on column MBT_RPT_210_J.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_210_J.PART_TYPE is '段标识';
comment on column MBT_RPT_210_J.PART_NAME is '段名称';
comment on column MBT_RPT_210_J.START_DATE is '起始日期';
comment on column MBT_RPT_210_J.END_DATE is '结束日期';
comment on column MBT_RPT_210_J.BATCH_NO is '批次号';
comment on column MBT_RPT_210_J.ROW_NUM is '行号';
comment on column MBT_RPT_210_J.IS_RPT is '是否报送';
comment on column MBT_RPT_210_J.IS_VALID is '是否有效';
comment on column MBT_RPT_210_J.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_210_J.OPT_FLAG is '操作标识';
comment on column MBT_RPT_210_J.RPT_DATE is '报送日期';
comment on column MBT_RPT_210_J.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_210_J.RPT_STATUS is '报送状态';
comment on column MBT_RPT_210_J.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_210_J.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_210_J.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_210_J.REMARKS is '备注';
comment on column MBT_RPT_210_J.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_210_J.CHECK_DESC is '校验说明';
comment on column MBT_RPT_210_J.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_210_J.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_210_J.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_210_J.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_210_J.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_210_J.DATA_FLAG is '数据标志';
comment on column MBT_RPT_210_J.DATA_OP is '操作标志';
comment on column MBT_RPT_210_J.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_210_J.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_210_J.DATA_HASH is '数据HASH';
comment on column MBT_RPT_210_J.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_J.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_J.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_210_J.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_210_J.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_210_J.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_210_J.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_210_J.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_210_J.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_210_J.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_210_J.DATA_APV_USER is '审核人';
comment on column MBT_RPT_210_J.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_210_J.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_210_J.RSV1 is '备用字段';
comment on column MBT_RPT_210_J.RSV2 is '备用字段';
comment on column MBT_RPT_210_J.RSV3 is '备用字段';
comment on column MBT_RPT_210_J.RSV4 is '备用字段';
comment on column MBT_RPT_210_J.RSV5 is '备用字段';
create table MBT_RPT_210_K (
DATA_ID VARCHAR(64) not null,
DATA_DATE CHAR(8),
CORP_ID VARCHAR(14),
ORG_ID VARCHAR(100),
GROUP_ID VARCHAR(100),
INQ_ORG_ID CHAR(24),
INQ_GROUP_ID CHAR(24),
K_CHAN_TRAN_TYPE VARCHAR(2),
K_DET_INFO VARCHAR(400),
K_DUE_TRAN_MON NUMBER(3),
K_TRAN_AMT NUMBER(15),
K_TRAN_AMT_LCY NUMBER(15),
K_TRAN_AMT_ORG NUMBER(15),
K_TRAN_DATE VARCHAR(8),
C_CY VARCHAR(3),
B_RPT_DATE VARCHAR(8),
B_ACCT_CODE VARCHAR(60),
CUST_NO VARCHAR(60),
UNV_IDN VARCHAR(500),
PART_TYPE VARCHAR(10),
PART_NAME VARCHAR(64),
START_DATE VARCHAR(8),
END_DATE VARCHAR(8),
BATCH_NO VARCHAR(64),
ROW_NUM NUMBER(10),
IS_RPT CHAR(1),
IS_VALID CHAR(1),
IS_RPT_SUCC CHAR(1),
OPT_FLAG CHAR(1),
RPT_DATE CHAR(8),
LAST_RPT_DATE CHAR(8),
RPT_STATUS CHAR(2),
CHG_RPT_STATUS CHAR(2),
RPT_FB_DATE VARCHAR(8),
RPT_FB_MSG VARCHAR(1024),
REMARKS VARCHAR(512),
CHECK_FLAG CHAR(1),
CHECK_DESC VARCHAR(512),
CHECK_ERR_TYPE CHAR(1),
NEXT_ACTION CHAR(2),
DATA_STATUS CHAR(2),
CHG_DATA_STATUS CHAR(3),
RPT_OPT_TYPE CHAR(2),
DATA_FLAG CHAR(1),
DATA_OP CHAR(1),
DATA_SOURCE CHAR(1),
DATA_VERSION NUMBER(8),
DATA_HASH VARCHAR(64),
DATA_REF_ID VARCHAR(128),
P_DATA_REF_ID VARCHAR(128),
DATA_REJ_DESC VARCHAR(128),
DATA_DEL_DESC VARCHAR(128),
DATA_CRT_USER VARCHAR(20),
DATA_CRT_DATE CHAR(8),
DATA_CRT_TIME CHAR(14),
DATA_CHG_USER VARCHAR(20),
DATA_CHG_DATE CHAR(8),
DATA_CHG_TIME CHAR(14),
DATA_APV_USER VARCHAR(20),
DATA_APV_DATE CHAR(8),
DATA_APV_TIME CHAR(14),
RSV1 VARCHAR(180),
RSV2 VARCHAR(180),
RSV3 VARCHAR(180),
RSV4 VARCHAR(180),
RSV5 VARCHAR(180),
PRIMARY KEY(DATA_ID)
);
comment on table MBT_RPT_210_K is '个人借贷账户信息-特殊交易说明段';
comment on column MBT_RPT_210_K.DATA_ID is '数据ID';
comment on column MBT_RPT_210_K.DATA_DATE is '数据日期';
comment on column MBT_RPT_210_K.CORP_ID is '法人ID';
comment on column MBT_RPT_210_K.ORG_ID is '机构ID';
comment on column MBT_RPT_210_K.GROUP_ID is '数据分组';
comment on column MBT_RPT_210_K.INQ_ORG_ID is '机构查询权限ID';
comment on column MBT_RPT_210_K.INQ_GROUP_ID is '部门查询权限ID';
comment on column MBT_RPT_210_K.K_CHAN_TRAN_TYPE is '交易类型';
comment on column MBT_RPT_210_K.K_DET_INFO is '交易明细信息';
comment on column MBT_RPT_210_K.K_DUE_TRAN_MON is '到期日期变更月数';
comment on column MBT_RPT_210_K.K_TRAN_AMT is '交易金额';
comment on column MBT_RPT_210_K.K_TRAN_AMT_LCY is '交易金额人民币金额';
comment on column MBT_RPT_210_K.K_TRAN_AMT_ORG is '交易金额_原始数据金额';
comment on column MBT_RPT_210_K.K_TRAN_DATE is '交易日期';
comment on column MBT_RPT_210_K.C_CY is '币种';
comment on column MBT_RPT_210_K.B_RPT_DATE is '信息报告日期';
comment on column MBT_RPT_210_K.B_ACCT_CODE is '账户标识码';
comment on column MBT_RPT_210_K.CUST_NO is '客户号';
comment on column MBT_RPT_210_K.UNV_IDN is '通用业务标识项';
comment on column MBT_RPT_210_K.PART_TYPE is '段标识';
comment on column MBT_RPT_210_K.PART_NAME is '段名称';
comment on column MBT_RPT_210_K.START_DATE is '起始日期';
comment on column MBT_RPT_210_K.END_DATE is '结束日期';
comment on column MBT_RPT_210_K.BATCH_NO is '批次号';
comment on column MBT_RPT_210_K.ROW_NUM is '行号';
comment on column MBT_RPT_210_K.IS_RPT is '是否报送';
comment on column MBT_RPT_210_K.IS_VALID is '是否有效';
comment on column MBT_RPT_210_K.IS_RPT_SUCC is '是否报送成功过';
comment on column MBT_RPT_210_K.OPT_FLAG is '操作标识';
comment on column MBT_RPT_210_K.RPT_DATE is '报送日期';
comment on column MBT_RPT_210_K.LAST_RPT_DATE is '最近报送日期';
comment on column MBT_RPT_210_K.RPT_STATUS is '报送状态';
comment on column MBT_RPT_210_K.CHG_RPT_STATUS is '变更报送状态';
comment on column MBT_RPT_210_K.RPT_FB_DATE is '反馈日期';
comment on column MBT_RPT_210_K.RPT_FB_MSG is '反馈信息';
comment on column MBT_RPT_210_K.REMARKS is '备注';
comment on column MBT_RPT_210_K.CHECK_FLAG is '校验标志';
comment on column MBT_RPT_210_K.CHECK_DESC is '校验说明';
comment on column MBT_RPT_210_K.CHECK_ERR_TYPE is '校验错误类型';
comment on column MBT_RPT_210_K.NEXT_ACTION is '工作流节点';
comment on column MBT_RPT_210_K.DATA_STATUS is '正常处理数据状态';
comment on column MBT_RPT_210_K.CHG_DATA_STATUS is '变更处理数据状态';
comment on column MBT_RPT_210_K.RPT_OPT_TYPE is '报送操作类型';
comment on column MBT_RPT_210_K.DATA_FLAG is '数据标志';
comment on column MBT_RPT_210_K.DATA_OP is '操作标志';
comment on column MBT_RPT_210_K.DATA_SOURCE is '数据来源';
comment on column MBT_RPT_210_K.DATA_VERSION is '数据版本-乐观锁';
comment on column MBT_RPT_210_K.DATA_HASH is '数据HASH';
comment on column MBT_RPT_210_K.DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_K.P_DATA_REF_ID is '数据引用ID';
comment on column MBT_RPT_210_K.DATA_REJ_DESC is '拒绝描述';
comment on column MBT_RPT_210_K.DATA_DEL_DESC is '删除描述';
comment on column MBT_RPT_210_K.DATA_CRT_USER is '创建人';
comment on column MBT_RPT_210_K.DATA_CRT_DATE is '创建日期';
comment on column MBT_RPT_210_K.DATA_CRT_TIME is '创建时间';
comment on column MBT_RPT_210_K.DATA_CHG_USER is '修改人';
comment on column MBT_RPT_210_K.DATA_CHG_DATE is '修改日期';
comment on column MBT_RPT_210_K.DATA_CHG_TIME is '修改时间';
comment on column MBT_RPT_210_K.DATA_APV_USER is '审核人';
comment on column MBT_RPT_210_K.DATA_APV_DATE is '审核日期';
comment on column MBT_RPT_210_K.DATA_APV_TIME is '审核时间';
comment on column MBT_RPT_210_K.RSV1 is '备用字段';
comment on column MBT_RPT_210_K.RSV2 is '备用字段';
comment on column MBT_RPT_210_K.RSV3 is '备用字段';
comment on column MBT_RPT_210_K.RSV4 is '备用字段';
comment on column MBT_RPT_210_K.RSV5 is '备用字段';
