CREATE OR REPLACE FUNCTION GET_ISRPT_CHANGE (PRI_ISRPT IN VARCHAR2, DATA_ISRPT IN VARCHAR2)RETURN VARCHAR2 AS
    /*
    Author: DENGCX
    Create Date: 20200924
    Description:
    ����mbt��ʱ����ݱ仯����1���������ݼ�¼��isrpt
    */
V_COUNT    NUMBER(10) := 0;
V_STR      VARCHAR2(50) := 0;
ISRPT      VARCHAR2(50) := NULL;
BEGIN
    
    IF LENGTH(PRI_ISRPT) = 0 THEN
      ISRPT := DATA_ISRPT;
    ELSE      
      V_STR := DATA_ISRPT;
      IF INSTR(PRI_ISRPT,'|') > 0 THEN 
         V_STR := V_STR || SUBSTR(PRI_ISRPT,INSTR(PRI_ISRPT,'|',1));
      END IF;    
      V_COUNT := LENGTH(V_STR);
      FOR I IN 1..V_COUNT LOOP
        IF SUBSTR(V_STR,I,1) = '|' THEN
              ISRPT := ISRPT || '|';
        ELSIF SUBSTR(V_STR,I,1) = '1' THEN
              ISRPT := ISRPT || '1';
        ELSE
              ISRPT := ISRPT || SUBSTR(PRI_ISRPT,I,1);
        END IF;
      END LOOP;
    END IF;
    RETURN ISRPT;
    DBMS_OUTPUT.PUT_LINE(ISRPT);

END;

