prompt PL/SQL Developer Export Tables for user MBT_USER@10.1.3.62:1521/ORADB
prompt Created by bin on 2020年10月27日
set feedback off
set define off

prompt Creating MBT_FEEDBACK_INFO...
create table MBT_FEEDBACK_INFO
(
  fb_code   CHAR(6) not null,
  fb_msg    VARCHAR2(100) not null,
  role_code VARCHAR2(20),
  remark    VARCHAR2(2000),
  belong    VARCHAR2(50)
)
;
comment on table MBT_FEEDBACK_INFO
  is '征信报文反馈码值映射信息表';
comment on column MBT_FEEDBACK_INFO.fb_code
  is '反馈信息代码';
comment on column MBT_FEEDBACK_INFO.fb_msg
  is '反馈信息';
comment on column MBT_FEEDBACK_INFO.role_code
  is '对应的规则编码';
comment on column MBT_FEEDBACK_INFO.remark
  is '备注';
comment on column MBT_FEEDBACK_INFO.belong
  is '描述来源';
alter table MBT_FEEDBACK_INFO
  add primary key (FB_CODE, FB_MSG);

prompt Loading MBT_FEEDBACK_INFO...
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR000', 'OrigCreditorInfSgmt', 'R2100101', '当“报告时点说明代码”为“10-新开户”时，个人借贷账户信息记录至少包含基本信息段。对于不同的账户类型至少还应包含的信息段如下：若“账户类型”为“C1”，还应包括初始债权说明段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR001', 'OrigCreditorInfSgmt', 'R2100102', '当“报告时点说明代码”为“10-新开户”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，不应包含初始债权说明段若“账户类型”为“R1/R3/R4”，不应包含初始债权说明段若“账户类型”为“R2”，不应包含初始债权说明段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR001', 'AcctDbtInfSgmt', 'R2100102', '当“报告时点说明代码”为“10-新开户”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，不应包含非月度表现信息段若“账户类型”为“R1/R3/R4”，不应包含非月度表现信息段若“账户类型”为“R2”，不应包含非月度表现信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR001', 'AcctSpecTrstDspnSgmt', 'R2100102', '当“报告时点说明代码”为“10-新开户”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，不应包含特殊交易说明段若“账户类型”为“R1/R3/R4”，不应包含特殊交易说明段若“账户类型”为“R2”，不应包含特殊交易说明段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR001', 'SpecPrdSgmt', 'R2100102', '当“报告时点说明代码”为“10-新开户”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，不应包含大额专项分期信息段若“账户类型”为“R1/R3/R4”，不应包含大额专项分期信息段；若“账户类型”为“C1”，不应包括大额专项分期信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR001', 'AcctCredSgmt', 'R2100102', '当“报告时点说明代码”为“10-新开户”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，如果基本信息段中“分次放款标志”为“否”，则还不应包含授信额度信息段；若“账户类型”为“R2”，如果基本信息段中的“借贷业务种类细分”是“大额专项分期卡”，则还不应包含授信额度信息段；若“账户类型”为“C1”，不应包括授信额度信息段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR001', 'AcctMthlyBlgInfSgmt', 'R2100102', '当“报告时点说明代码”为“10-新开户”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“C1”，不应包括月度表现段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR001', 'MotgaCltalCtrctInfSgmt', 'R2100102', '当“报告时点说明代码”为“10-新开户”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“C1”，不应包括抵质押物信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR002', 'AcctBsInfSgmt', 'R2100103', '当“报告时点说明代码”为“31-月结日首次上报存量账户”时，个人借贷账户信息记录至少包含基本信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR002', 'AcctMthlyBlgInfSgmt', 'R2100103', '当“报告时点说明代码”为“31-月结日首次上报存量账户”时。对于不同的账户类型至少还应包含的信息段如下：若“账户类型”为“D1”，则还应包含月度表现信息段若“账户类型”为“R1/R3/R4”还应包含月度表现信息段若“账户类型”为“R2”，则还应包含月度表现段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR002', 'AcctCredSgmt', 'R2100103', '当“报告时点说明代码”为“31-月结日首次上报存量账户”时。对于不同的账户类型至少还应包含的信息段如下：若“账户类型”为“D1”，如果基本信息段中“分次放款标志”为“是”，则还应包含授信额度信息段若“账户类型”为“R1/R3/R4”还应包含授信额度信息段；若“账户类型”为“R2”，如果基本信息段中的“借贷业务种类细分”不是“大额专项分期卡”，则还应包含授信额度信息段；', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR002', 'AcctType', 'R2100103', '当“报告时点说明代码”为“31-月结日首次上报存量账户”时，“账户类型”不能为“C1”。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR003', 'OrigCreditorInfSgmt', 'R2100104', '当“报告时点说明代码”为“31-月结日首次上报存量账户”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，不应包含初始债权说明段若“账户类型”为“R1/R3/R4”，不应包含初始债权说明段若“账户类型”为“R2”，不应包含初始债权说明段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR003', 'AcctDbtInfSgmt', 'R2100104', '当“报告时点说明代码”为“31-月结日首次上报存量账户”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，不应包含非月度表现信息段若“账户类型”为“R1/R3/R4”，不应包含非月度表现信息段若“账户类型”为“R2”，不应包含非月度表现信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR003', 'SpecPrdSgmt', 'R2100104', '当“报告时点说明代码”为“31-月结日首次上报存量账户”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，不应包含大额专项分期信息段若“账户类型”为“R1/R3/R4”，不应包含大额专项分期信息段；', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR003', 'AcctCredSgmt', 'R2100104', '当“报告时点说明代码”为“31-月结日首次上报存量账户”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，如果基本信息段中“分次放款标志”为“否”，则还不应包含授信额度信息段；若“账户类型”为“R2”，如果基本信息段中的“借贷业务种类细分”是“大额专项分期卡”，则还不应包含授信额度信息段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR006', 'AcctMthlyBlgInfSgmt', 'R2100107', '当“报告时点说明代码”为“30-月度结算”时，至少应包含月度表现信息段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR006', 'AcctType', 'R2100107', '当“报告时点说明代码”为“30-月度结算”时，“账户类型”不能为“C1”。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR007', 'OrigCreditorInfSgmt', 'R2100108', '当“报告时点说明代码”为“30-月度结算”时：对于D1账户不应包含初始债权说明段对于R1/R3/R4账户都不应包含初始债权说明段对于R2账户不应包含初始债权说明段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR007', 'AcctDbtInfSgmt', 'R2100108', '当“报告时点说明代码”为“30-月度结算”时：对于D1账户不应包含非月度表现信息段对于R1/R3/R4账户都不应包含非月度表现信息段对于R2账户不应包含非月度表现信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR007', 'SpecPrdSgmt', 'R2100108', '当“报告时点说明代码”为“30-月度结算”时：对于D1账户不应包含大额专项分期信息段对于R1/R3/R4账户都不应包含大额专项分期信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR005', 'BsSgmt', 'R3100103', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR002', 'MnMmbInfSgmt', 'R3101201', '新增信息记录首次入库时，除基础段外，待入库记录必须至少包含主要组成人员段。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR007', 'AcctCredSgmt', 'R2100108', '当“报告时点说明代码”为“30-月度结算”时：对于D1账户，如果基本信息段中“分次放款标志”为“否”，则还不应包含授信额度信息段；对于R2账户，如果基本信息段中的“借贷业务种类细分”是“大额专项分期卡”，则还不应包含授信额度信息段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR008', 'AcctDbtInfSgmt', 'R2100109', '当“报告时点说明代码”为“40-收回逾期款项”时，至少应包含非月度表现信息段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR008', 'AcctType', 'R2100109', '当“报告时点说明代码”为“40-收回逾期款项”时，账户类型不能为“R3”。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR009', 'AcctMthlyBlgInfSgmt', 'R2100110', '当“报告时点说明代码”为“40-收回逾期款项”时，不应包含月度表现信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR009', 'SpecPrdSgmt', 'R2100110', '当“报告时点说明代码”为“40-收回逾期款项”时，不应包大额专项分期信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR009', 'MotgaCltalCtrctInfSgmt', 'R2100110', '当“报告时点说明代码”为“40-收回逾期款项”时，不应包含抵质押物信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR009', 'AcctCredSgmt', 'R2100110', '当“报告时点说明代码”为“40-收回逾期款项”时，不应包含授信额度信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR009', 'OrigCreditorInfSgmt', 'R2100110', '当“报告时点说明代码”为“40-收回逾期款项”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1/R1/R2/R4”，不应包括初债权说明段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR009', 'AcctSpecTrstDspnSgmt', 'R2100110', '当“报告时点说明代码”为“40-收回逾期款项”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1/R1/R2/R4”，不应包括特殊交易说明段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR009', 'AcctBsInfSgmt', 'R2100110', '当“报告时点说明代码”为“40-收回逾期款项”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1/R1/R2/R4”，不应包括基本信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR009', 'RltRepymtInfSgmt', 'R2100110', '当“报告时点说明代码”为“40-收回逾期款项”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1/R1/R2/R4”，不应包括相关还款责任人段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR010', 'AcctMthlyBlgInfSgmt', 'R2100111', '当“报告时点说明代码”为“20-账户关闭”时：若“账户类型”为“D1/R1/R2/R3/R4”还应包含月度表现信息段；', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR010', 'AcctDbtInfSgmt', 'R2100111', '当“报告时点说明代码”为“20-账户关闭”时：若“账户类型”为“C1”还应包含非月度表现信息段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR011', 'OrigCreditorInfSgmt', 'R2100112', '当“报告时点说明代码”为“20-账户关闭”时：若“账户类型”为“D1”，不应包含初始债权说明段若“账户类型”为“R1/R3/R4”，不应包含初始债权说明段若“账户类型”为“R2”，不应包含初始债权说明段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR011', 'AcctDbtInfSgmt', 'R2100112', '当“报告时点说明代码”为“20-账户关闭”时：若“账户类型”为“D1”，不应包含非月度表现信息段若“账户类型”为“R1/R3/R4”，不应包含非月度表现信息段若“账户类型”为“R2”，不应包含非月度表现信息段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR011', 'SpecPrdSgmt', 'R2100112', '当“报告时点说明代码”为“20-账户关闭”时：若“账户类型”为“D1”，不应包含大额专项分期信息段若“账户类型”为“R1/R3/R4”，不应包含大额专项分期信息段若“账户类型”为“C1”，不应包括大额专项分期信息段、', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR011', 'AcctCredSgmt', 'R2100112', '当“报告时点说明代码”为“20-账户关闭”时：若“账户类型”为“D1”，如果基本信息段中“分次放款标志”为“否”，则还不应包含授信额度信息段；若“账户类型”为“R2”，如果基本信息段中的“借贷业务种类细分”是“大额专项分期卡”，则还不应包含授信额度信息段；若“账户类型”为“C1”，不应包括授信额度信息段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR011', 'AcctMthlyBlgInfSgmt', 'R2100112', '当“报告时点说明代码”为“20-账户关闭”时：若“账户类型”为“C1”，不应包括月度表现段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR011', 'MotgaCltalCtrctInfSgmt', 'R2100112', '当“报告时点说明代码”为“20-账户关闭”时：若“账户类型”为“C1”，不应包括抵质押物信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR012', 'AcctMthlyBlgInfSgmt', 'R2100113', '当“报告时点说明代码”为“32-月结日账户关闭”时，至少应包括月度表现信息段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR012', 'AcctType', 'R2100113', '当“报告时点说明代码”为“32-月结日账户关闭”时，“账户类型”不能为“C1”。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR013', 'OrigCreditorInfSgmt', 'R2100114', '当“报告时点说明代码”为“32-月结日账户关闭”时，借款账户信息记录对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，不应包含初始债权说明段若“账户类型”为“R1/R3/R4”，不应包含初始债权说明段若“账户类型”为“R2”，不应包含初始债权说明段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR013', 'AcctDbtInfSgmt', 'R2100114', '当“报告时点说明代码”为“32-月结日账户关闭”时，借款账户信息记录对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，不应包含非月度表现信息段若“账户类型”为“R1/R3/R4”，不应包含非月度表现信息段若“账户类型”为“R2”，不应包含非月度表现信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR013', 'SpecPrdSgmt', 'R2100114', '当“报告时点说明代码”为“32-月结日账户关闭”时，借款账户信息记录对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，不应包含大额专项分期信息段若“账户类型”为“R1/R3/R4”，不应包含大额专项分期信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR013', 'AcctCredSgmt', 'R2100114', '当“报告时点说明代码”为“32-月结日账户关闭”时，借款账户信息记录对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，如果基本信息段中“分次放款标志”为“否”，则还不应包含授信额度信息段。若“账户类型”为“R2”，如果基本信息段中的“借贷业务种类细分”是“大额专项分期卡”，则还不应包含授信额度信息段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABF000', '0000', '-', '报文文件解密出错。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABF001', '0000', '-', '报文文件解压出错。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABF002', '0000', '-', '未知错误，导致文件无法解析。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABN003', '0000', 'F0000201', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABN004', '0000', 'F0001202', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABH006', '0000', 'F0001302', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABF010', '0000', 'F0000502', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABF011', '0000', '-', '在信息交换时采用“Unicode”字符集以及UTF-8编码。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABR000', '0000', 'R0000101', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABR006', '0000', '-', '未知错误，导致记录无法解析。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABD000', '未出现的 A 型数据项标签', 'S0000101', 'A型数据项必须出现在相应的信息段中。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE000', '空的 M 型数据项标签', 'I0000101', 'M型数据项不能为空值且不能为空格（含全角和半角空格）。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE001', '不符合类型规定的数据项标签', 'I0000201', '记录中各个数据项的值，应符合类型规定。对于枚举型数据项，取值需要在代码表中；对于非枚举型数据项需要长度合规，类型相符。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE002', 'InfSurcCode', 'I0001301', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE004', '不符合编码规则的各类身份标识号码的标签', 'I0000401', '各类身份标识号码应符合相应的编码规则。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE005', 'EntCertNum', 'I0001402', '基础段企业身份标识号码为中征码时应在库中存在；B企业其他身份标识号码为中征码时应在库中存在/企业身份标识整合信息记录中企业身份标号码为中征码时应在库中存在/企业其他身份标识号码为中征码时应在库中存在', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE005', 'SharHodIDNum', 'I0001402', '出资人身份标识号码为中征码时应在库中存在', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE005', 'ActuCotrlIDNum', 'I0001402', '实际控制人身份标识号码为中征码时应在库中存在', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE005', 'SupOrgCertNum', 'I0001402', '上级机构身份标识号码为中征码时应在库中存在', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE005', 'AssoEntCertNum', 'I0001402', 'A企业其他身份标识号码为中征码时应在库中存在', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'IDInfoUpDate', 'I0000501', '个人/企业基本信息记录的“信息报告日期”应不早于其他标识信息段信息更新日期', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'FcsInfoUpDate', 'I0000501', '个人/企业基本信息记录的“信息报告日期”应不早于基本概况信息段信息更新日期', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'MnMmbInfoUpDate', 'I0000501', '个人/企业基本信息记录的“信息报告日期”应不早于主要组成人员段信息更新日期', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'MnShaHodInfoUpDate', 'I0000501', '个人/企业基本信息记录的“信息报告日期”应不早于注册资本及主要出资人段信息更新日期', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'ActuCotrlInfoUpDate', 'I0000501', '个人/企业基本信息记录的“信息报告日期”应不早于实际控制人段信息更新日期', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'CotaInfoUpDate', 'I0000501', '个人/企业基本信息记录的“信息报告日期”应不早于联系方式段信息更新日期', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'EstablishDate', 'I0000501', '个人/企业基本信息记录的“信息报告日期”应不早于成立日期', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE008', '超出范围的时间类数据项标签', 'I0000601', '所有时间必须是有效时间：1901-01-01T00:00:00—2099-12-31T23:59:59。所有日期必须是有效日期：1901-01-01—2099-12-31。所有月份必须是有效月份：1901-01—2099-12。所有年份必须为有效年份：1901—2099。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE010', 'IDNm', 'I0000701', '对于一组可出现多次的数据项：其他标识信息，其出现次数必须与其个数相匹配。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE010', 'MmbNm', 'I0000701', '对于一组可出现多次的数据项：主要组成人员信息，其出现次数必须与其个数相匹配。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE010', 'ActuCotrlNm', 'I0000701', '对于一组可出现多次的数据项：实际控制人信息，其出现次数必须与其个数相匹配。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE011', 'IDNm', 'I0000702', '对于其他标识信息段中一组可出现多次的数据项,当出现多次时，内容不能重复。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE011', 'MmbNm', 'I0000702', '对于主要组成人员段中一组可出现多次的数据项,当出现多次时，内容不能重复。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE011', 'MnSharHodNm', 'I0000702', '对于注册资本及主要出资人段中一组可出现多次的数据项,当出现多次时，内容不能重复。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE011', 'ActuCotrlNm', 'I0000702', '对于实际控制人段中一组可出现多次的数据项,当出现多次时，内容不能重复。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE012', '0000', 'I0001801', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR000', 'MnMmbInfSgmt', 'R3100101', '当报告时点说明代码为“报告时新增客户/首次上报”时，记录必须至少包含“主要组成人员段”。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR000', 'CotaInfSgmt', 'R3100101', '当报告时点说明代码为“报告时新增客户/首次上报”时，记录必须至少包含“联系方式段”。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR002', 'FcsInfSgmt', 'R3101201', '首次加载入库时，除基础段外，待入库记录必须至少包含基本概况段。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR002', 'CotaInfSgmt', 'R3101201', '新增信息记录首次入库时，除基础段外，待入库记录必须至少包含联系方式段。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR003', 'RptDate', 'R3101202', '待入库的企业基本信息记录（“两标/三标”+“信息来源编码”在库中存在），其“信息报告日期”早于库中信息记录最新的信息报告日期，该记录不能入库。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR003', 'FcsInfoUpDate', 'R3101202', '待入库的企业基本信息记录（“两标/三标”+“信息来源编码”在库中存在），基本概况信息段信息更新日期早于最新的基本概况信息段信息更新日期，该记录不能入库。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR003', 'MnMmbInfoUpDate', 'R3101202', '待入库的企业基本信息记录（“两标/三标”+“信息来源编码”在库中存在），主要组成人员段信息更新日期早于最新的主要组成人员段信息更新日期，该记录不能入库。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR003', 'MnShaHodInfoUpDate', 'R3101202', '待入库的企业基本信息记录（“两标/三标”+“信息来源编码”在库中存在），注册资本及主要出资人段信息更新日期早于最新的注册资本及主要出资人段信息更新日期，该记录不能入库。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR003', 'ActuCotrlInfoUpDate', 'R3101202', '待入库的企业基本信息记录（“两标/三标”+“信息来源编码”在库中存在），实际控制人段信息更新日期早于最新的实际控制人段信息更新日期，该记录不能入库。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR003', 'SupOrgInfoUpDate', 'R3101202', '待入库的企业基本信息记录（“两标/三标”+“信息来源编码”在库中存在），上级机构段信息更新日期早于最新的上级机构段信息更新日期，该记录不能入库。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR003', 'CotaInfoUpDate', 'R3101202', '待入库的企业基本信息记录（“两标/三标”+“信息来源编码”在库中存在），联系方式段信息更新日期早于最新的联系方式段信息更新日期，该记录不能入库。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR004', 'OrgType', 'R3101203', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE012', '0000', 'I3100C01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE013', '0000', 'I3100D01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE011', 'EstablishDate', 'I3100D02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE001', '0000', 'I3100E02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
commit;
prompt 100 records committed...
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE003', 'ShholderIDType', 'I3100F01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE005', 'ActuCotrlCertType', 'I3100G01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE007', 'OthEntCertType', 'I3100A02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE009', 'OthEntCertType', 'I3100A04', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE011', '0000', 'I3100A07', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CGR000', 'RptDate', 'R3401201', '企业身份标识整合信息记录错误', '企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CGE000', '0000', 'I3400B01', '企业身份标识整合信息记录错误', '企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CFR000', 'RptDate', 'R3501201', '企业身份标识整合信息记录错误', '企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CFR000', '0000', 'I3500B01', '企业身份标识整合信息记录错误', '企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CDR000', '0000', 'R3141201', '企业身份标识整合信息记录错误', '企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR014', 'RltRepymtInfSgmt', 'R2100115', '当“报告时点说明代码”为“10-新开户”或“31-月结日首次上报存量账户”时，若D1/R1/R2/R3/R4类账户的“基本信息段”中“担保方式”为“3-保证”、“5-组合（含保证）”时，则应包含相关还款责任人段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR020', 'AcctStatus', 'R2101205', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR023', '0000', 'R2101208', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR025', 'AcctStatus', 'R2101210', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR028', 'RptDate', 'R2101213', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR004', 'AcctBsInfSgmt', 'R2101215', '当首次上报时（库中不存在该账户），个人借贷账户信息记录至少包含基本信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR004', 'AcctMthlyBlgInfSgmt', 'R2101215', '当首次上报时（库中不存在该账户），对于不同的账户类型至少还应包含的信息段如下：若“账户类型”为“D1”，则还应包含月度表现信息段，若“账户类型”为“R1/R3/R4”还应包含月度表现信息段若“账户类型”为“R2”，则还应包含月度表现段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR004', 'AcctCredSgmt', 'R2101215', '当首次上报时（库中不存在该账户），对于不同的账户类型至少还应包含的信息段如下：若“账户类型”为“D1”，如果基本信息段中“分次放款标志”为“是”，则还应包含授信额度信息段；若“账户类型”为“R1/R3/R4”还应包含授信额度信息段；若“账户类型”为“R2”，如果基本信息段中的“借贷业务种类细分”不是“大额专项分期卡”，则还应包含授信额度信息段；', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR004', 'AcctDbtInfSgmt', 'R2101215', '当首次上报时（库中不存在该账户），对于不同的账户类型至少还应包含的信息段如下：若“账户类型”为“C1”，还应包括非月度表现信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR004', 'OrigCreditorInfSgmt', 'R2101215', '当首次上报时（库中不存在该账户），对于不同的账户类型至少还应包含的信息段如下：若“账户类型”为“C1”，还应包括初始债权说明段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR005', 'OrigCreditorInfSgmt', 'R2101214', '当首次上报时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，不应包含初始债权说明段若“账户类型”为“R1/R3/R4”，不应包含初始债权说明段若“账户类型”为“R2”，不应包含初始债权说明段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR005', 'AcctDbtInfSgmt', 'R2101214', '当首次上报时，对于不同的账户类型不应包含的信息段如下若“账户类型”为“D1”，不应包含非月度表现信息段若“账户类型”为“R1/R3/R4”，不应包含非月度表现信息段若“账户类型”为“R2”，不应包含非月度表现信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR005', 'SpecPrdSgmt', 'R2101214', '当首次上报时，对于不同的账户类型不应包含的信息段如下若“账户类型”为“D1”，不应包含大额专项分期信息段若“账户类型”为“R1/R3/R4”，不应包含大额专项分期信息段若“账户类型”为“C1”，不应包括大额专项分期信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR005', 'AcctCredSgmt', 'R2101214', '当首次上报时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“D1”，如果基本信息段中“分次放款标志”为“否”，则还不应包含授信额度信息段；若“账户类型”为“R2”，如果基本信息段中的“借贷业务种类细分”是“大额专项分期卡”，则还不应包含授信额度信息段；若“账户类型”为“C1”，不应包括授信额度信息段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR005', 'AcctMthlyBlgInfSgmt', 'R2101214', '当首次上报时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“C1”，不应包括月度表现段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR031', 'OrigCreditorInfSgmt', 'R4101213', '首次上报时（即库中不存在该账户）：若账户类型为“D1/D2/R1/R4”,则企业借贷账户信息记录不应包含初始债权说明段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABR002', 'ContractCode', 'R0000201', '对于正常情况下的数据报送，报送文件中的不应存在标识项相同的个人借贷账户信息记录。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR031', 'AcctCredSgmt', 'R4101213', '首次上报时（即库中不存在该账户）：若账户类型为“D1”，基本信息段中“分次放款标志”为“0”或者账户类型为“C1/D2”，则企业借贷账户信息记录不应包含授信额度信息段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR031', 'MotgaCltalCtrctInfSgmt', 'R4101213', '首次上报时（即库中不存在该账户）：若账户类型为“C1/D2”，则企业借贷账户信息记录不应包含抵质押物信息段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLD000', '不符合 S 型出现约束的数据项标签', 'S4100101', '除A型数据项外，对于不同的账户类型S型数据项出现约束见“企业借贷账户约束条件表”。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE002', 'ContractCode', 'I0001301', '个人授信协议记录中的“授信协议标识码”与文件头中“数据提供机构区段码”应对应同一数据提供机构。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE001', 'OpenDate', 'I4100C02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE002', 'RepayFreqcy', 'I4100C03', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE002', 'CreditRestCode', 'I0001301', '个人授信协议记录中的“授信限额编号”与文件头中“数据提供机构区段码”应对应同一数据提供机构。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE002', 'OdBnesCode', 'I0001301', '标识变更请求记录中的“原业务标识码”与文件头中“数据提供机构区段码”应对应同一数据提供机构。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE002', 'NwBnesCode', 'I0001301', '标识变更请求记录中的“新业务标识码”与文件头中“数据提供机构区段码”应对应同一数据提供机构。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE002', 'ModRecCode', 'I0001301', '按段更正记录中的“待更正业务标识码”与文件头中“数据提供机构区段码”应对应同一数据提供机构。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE002', 'DelRecCode', 'I0001301', '按段删除或整笔删除记录中的“待删除业务标识码”与文件头中“数据提供机构区段码”应对应同一数据提供机构。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE003', 'MngmtOrgCode', 'I0001302', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE005', 'ArlpCertNum', 'I0001402', '责任人身份标识号码为中征码时应在库中存在。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE005', 'CertRelIDNum', 'I0001402', '共同受信人身份标识号码中征码时应在库中存在。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE003', 'RepayFreqcy', 'I4100C04', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'SettDate', 'I0000501', '个人借贷账户信息记录的信息报告日期应不早于结算/应还款日期', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE004', 'RepayMode', 'I4100C05', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'LatRpyDate', 'I0000501', '个人借贷账户信息记录的信息报告日期应不早于最近一次实际还款日期', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE005', 'RepayMode', 'I4100C06', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'SpecEfctDate', 'I0000501', '个人借贷账户信息记录的信息报告日期应不早于分期额度生效日期', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'TranDate', 'I0000501', '个人借贷账户信息记录的信息报告日期应不早于交易日期', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'ConEffDate', 'I0000501', '个人授信协议信息记录的信息报告日期应不早于额度生效日期。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE006', 'ArlpAmt', 'I4100D01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE010', 'CcNm', 'I0000701', '对于一组可出现多次的数据项：抵质押合同信息，其出现次数必须与其个数相匹配。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE010', 'CagOfTrdNm', 'I0000701', '对于一组可出现多次的数据项：交易信息，其出现次数必须与其个数相匹配。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE010', 'BrerNm', 'I0000701', '对于一组可出现多次的数据项：共同授信人信息，其出现次数必须与其个数相匹配。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE011', 'RltRepymtNm', 'I0000702', '对于相关还款责任人段中一组可出现多次的数据项，当出现多次时，内容不能重复。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE011', 'CcNm', 'I0000702', '对于抵质押物信息段中一组可出现多次的数据项，当出现多次时，内容不能重复。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE011', 'CagOfTrdNm', 'I0000702', '对于特定交易说明段中一组可出现多次的数据项，当出现多次时，内容不能重复。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE011', 'BrerNm', 'I0000702', '对于共同受信人信息段中一组可出现多次的数据项，当出现多次时，内容不能重复。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR000', 'AcctBsInfSgmt', 'R2100101', '当“报告时点说明代码”为“10-新开户”时，个人借贷账户信息记录至少包含基本信息段。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR000', 'AcctMthlyBlgInfSgmt', 'R2100101', '当“报告时点说明代码”为“10-新开户”时，个人借贷账户信息记录至少包含基本信息段。对于不同的账户类型至少还应包含的信息段如下：若“账户类型”为“D1”，则还应包含月度表现信息段，若“账户类型”为“R1/R3/R4”还应包含月度表现信息段若“账户类型”为“R2”，则还应包含月度表现段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR000', 'AcctCredSgmt', 'R2100101', '当“报告时点说明代码”为“10-新开户”时，个人借贷账户信息记录至少包含基本信息段。对于不同的账户类型至少还应包含的信息段如下：若“账户类型”为“D1”，则如果基本信息段中“分次放款标志”为“是”，则还应包含授信额度信息段；若“账户类型”为“R1/R3/R4”还应包含授信额度信息段；若“账户类型”为“R2”，则如果基本信息段中的“借贷业务种类细分”不是“大额专项分期卡”，则还应包含授信额度信息段；', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR000', 'AcctDbtInfSgmt', 'R2100101', '当“报告时点说明代码”为“10-新开户”时，个人借贷账户信息记录至少包含基本信息段。对于不同的账户类型至少还应包含的信息段如下：若“账户类型”为“C1”，还应包括非月度表现信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE007', 'WartySign', 'I4100D02', '相关还款责任人段中“还款责任人类型”为“2-保证人”时，“联保标志”必须不能为空值。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE007', 'MaxGuarMcc', 'I4100D02', '相关还款责任人段中“还款责任人类型”为“2-保证人”时，“保证合同编号”必须不能为空值。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE008', '0000', 'I4100D03', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE012', 'AcctBal', 'I4100H02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE013', 'CloseDate', 'I4100H03', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE015', 'TotOverd', 'I4100H05', '若“账户状态”为“21-关闭”时，“当前逾期总额”必须为0。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE015', 'OverdPrinc', 'I4100H05', '若“账户状态”为“21-关闭”时，“当前逾期本金”必须为0。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE015', 'OverdDy', 'I4100H05', '若“账户状态”为“21-关闭”时，“当前逾期天数”必须为0。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE016', 'OverdPrinc', 'I4100H06', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE017', 'LatRpyAmt', 'I4100H07', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE018', 'OverdDy', 'I4100H08', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE019', 'BalChgDate', 'I4100H09', '当“账户关闭日”不为空时，则必须不早于“余额变化日期”。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE019', 'LatRpyDate', 'I4100H09', '当“账户关闭日”不为空时，则必须不早于“最近一次实际还款款日期”。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE019', 'LatAgrrRpyDate', 'I4100H09', '当“账户关闭日”不为空时，则必须不早于“最近一次约定还款日期”。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE019', 'FiveCateAdjDate', 'I4100H09', '当“账户关闭日”不为空时，则必须不早于“五级分类认定日期”。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE020', 'NxtAgrrRpyDate', 'I4100H10', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE021', 'BalChgDate', 'I4100H11', '当“下一次约定还款日期”不为空时，必须不早于“余额变化日期”。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE021', 'LatRpyDate', 'I4100H11', '当“下一次约定还款日期”不为空时，必须不早于“最近一次实际还款款日期”。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE021', 'LatAgrrRpyDate', 'I4100H11', '当“下一次约定还款日期”不为空时，必须不早于“最近一次约定还款日期”。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE021', 'FiveCateAdjDate', 'I4100H11', '当“下一次约定还款日期”不为空时，必须不早于“五级分类认定日期”。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE031', '0000', 'I4100H12', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE022', 'DueTranMon', 'I4100I01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE023', 'CagOfTrdNm', 'I4100I02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE024', 'CloseDate', 'I4100A01', '企业借贷账户信息记录中的开户日期不晚于同一条记录中的账户关闭日期', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE024', 'BalChgDate', 'I4100A01', '企业借贷账户信息记录中的开户日期不晚于同一条记录中的余额变化日期', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE024', 'FiveCateAdjDate', 'I4100A01', '企业借贷账户信息记录中的开户日期不晚于同一条记录中的五级分类认定日期', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE024', 'LatRpyDate', 'I4100A01', '企业借贷账户信息记录中的开户日期不晚于同一条记录中的最近一次实际还款日期', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE024', 'LatAgrrRpyDate', 'I4100A01', '企业借贷账户信息记录中的开户日期不晚于同一条记录中的最近一次约定还款日期', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE024', 'NxtAgrrRpyDate', 'I4100A01', '企业借贷账户信息记录中的开户日期不晚于同一条记录中的下一次约定还款日期', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE024', 'TranDate', 'I4100A01', '企业借贷账户信息记录中的开户日期不晚于同一条记录中的交易日期。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE024', 'DueDate', 'I4100A01', '企业借贷账户信息记录中的开户日期不晚于同一条记录中的到期日期。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE025', 'BalChgDate', 'I4100A02', '账户信息记录中如果有“账户关闭日期”数据项，则“账户关闭日期”必须不早于同一条记录中余额变化日期', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE025', 'FiveCateAdjDate', 'I4100A02', '账户信息记录中如果有“账户关闭日期”数据项，则“账户关闭日期”必须不早于同一条记录中五级分类认定日期', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE025', 'LatRpyDate', 'I4100A02', '账户信息记录中如果有“账户关闭日期”数据项，则“账户关闭日期”必须不早于同一条记录中最近一次实际还款日期', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE025', 'LatAgrrRpyDate', 'I4100A02', '账户信息记录中如果有“账户关闭日期”数据项，则“账户关闭日期”必须不早于同一条记录中最近一次约定还款日期', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE025', 'NxtAgrrRpyDate', 'I4100A02', '账户信息记录中如果有“账户关闭日期”数据项，则“账户关闭日期”必须不早于同一条记录中下一次约定还款日期', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE025', 'TranDate', 'I4100A02', '账户信息记录中如果有“账户关闭日期”数据项，则“账户关闭日期”必须不早于同一条记录中交易日期', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE026', 'RptDate', 'I4100A03', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE028', 'TranAmt', 'I4100A05', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
commit;
prompt 200 records committed...
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE033', '0000', 'I4100A10', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CIR000', '0000', 'I4110B01', '企业账户标识变更信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CIR001', 'OdBnesCode', 'I4111B02', '企业账户标识变更信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CIR002', 'NwBnesCode', 'I4111B03', '企业账户标识变更信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR002', '0000', 'R4120103', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR004', '0000', 'R4120105', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR005', '0000', 'R4120106', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR007', '0000', 'R4121204', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR013', 'AcctType', 'R4121207', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR014', '0000', 'R4121208', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR015', '0000', 'R4121209', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR016', '0000', 'R4121210', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR006', '0000', 'R4121211', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR019', '0000', 'R4121212', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR008', '0000', 'R4121213', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR009', '0000', 'R4121214', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR010', '0000', 'R4121215', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR017', '0000', 'R4121217', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR018', '0000', 'R4121218', '企业借贷账户按段更正信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CTR000', 'DelRecCode', 'R4141201', '企业借贷账户整笔删除信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CSR000', '0000', 'R4131201', '企业借贷账户整笔删除信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CSE000', '0000', 'I4130B01', '企业借贷账户整笔删除信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CSE001', 'DelStartDate', 'I4130B02', '企业借贷账户整笔删除信息记录错误', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAR000', 'GuarAcctBsInfSgmt', 'R4400101', '“报告时点说明代码”为“10-开户/首次上报”时，至少应出现“基本信息段”。', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAR000', 'GuarRltRepymtInfSgmt', 'R4400101', '“报告时点说明代码”为“10-开户/首次上报”时，至少应出现“在保责任信息段”。', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAR001', 'GuarRltRepymtInfSgmt', 'R4400102', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAR002', 'GuarRltRepymtInfSgmt', 'R4400103', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAR003', 'RltRepymtInfSgmt', 'R4400104', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAR004', 'GuarAcctBsSgmt', 'R4400105', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAR008', 'GuarRltRepymtInfSgmt', 'R4400106', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAR010', 'GuarRltRepymtInfSgmt', 'R4400107', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAR005', 'FiveCateAdjDate', 'R4401201', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAR006', 'AcctStatus', 'R4401202', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAR007', 'AcctStatus', 'R4401203', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAE000', 'OpenDate', 'I4400C01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAE002', 'RepayPrd', 'I4400D02', '账户信息记录中如果“账户关闭日期”数据项不为空，账户关闭日期应不早于余额变化日期、。', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAE002', 'FiveCateAdjDate', 'I4400D02', '账户信息记录中如果“账户关闭日期”数据项不为空，账户关闭日期应不早于五级分类认定日期。', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAE003', '0000', 'I4400E01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAE009', 'WartySign', 'I4400E03', '当“还款责任人类型”为“2-反担保人”时，“联保标志”不应为空。', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAE009', 'MaxGuarMcc', 'I4400E03', '当“还款责任人类型”为“2-反担保人”时，“保证合同编号”不应为空。', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAE006', 'RepayPrd', 'I4400A01', '账户信息记录中的“开户日期”应不晚于“余额变化日期”。', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAE006', 'FiveCateAdjDate', 'I4400A01', '账户信息记录中的“开户日期”应不晚于“五级分类认定日期”。', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAE006', 'CloseDate', 'I4400A01', '账户信息记录中的“开户日期”应不晚于“账户关闭日期”。', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CIR200', '0000', 'I4410B01', '企业担保账户标识变更请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CIR201', 'OdBnesCode', 'I4411B02', '企业担保账户标识变更请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CIR202', 'NwBnesCode', 'I4411B03', '企业担保账户标识变更请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR301', 'MdfcSgmtCode', 'R4420102', '企业担保账户更正请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR302', '0000', 'R4420105', '企业担保账户更正请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR303', '0000', 'R4420106', '企业担保账户更正请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR306', '0000', 'R4421203', '企业担保账户更正请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR309', '0000', 'R4421206', '企业担保账户更正请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR313', '0000', 'R4421207', '企业担保账户更正请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR314', '0000', 'R4421208', '企业担保账户更正请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR315', '0000', 'R4421209', '企业担保账户更正请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR311', '0000', 'R4421210', '企业担保账户更正请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR312', '0000', 'R4421211', '企业担保账户更正请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR316', '0000', 'R4421212', '企业担保账户更正请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR317', '0000', 'R4421213', '企业担保账户更正请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CSR300', '0000', 'R4431201', '企业担保账户按段删除请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CSE300', '0000', 'I4430B01', '企业担保账户按段删除请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CSE301', 'DelStartDate', 'I4430B02', '企业担保账户按段删除请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CTR300', 'DelRecCode', 'R4441201', '企业担保账户整笔删除请求记录错误', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE000', 'TotalEquityAndLiabilities', 'I6100C01', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE001', 'TotalAssets', 'I6100C02', '在借款人2002版资产负债表信息中数据项“负债和所有者权益总计＝资产总计”。', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE002', 'TotalEquityAndLiabilities', 'I6100D01', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE003', 'TotalAssets', 'I6100C02', '在2007版资产负债表信息中数据项“资产总计=负债和所有者权益合计”。', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE100', 'NetCashFlowsFromOperatingActivities', 'I6300C01', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE101', 'NetCashFlowsFromInvestingActivities', 'I6300C02', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE102', 'NetCashFlowsFromFinancingActivities', 'I6300C03', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE103', 'NetIncreaseInCashAndCashEquivalents', 'I6300C04', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE104', 'NetCashFlowsFromOperatingActivities', 'I6300D01', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE105', 'NetCashFlowsFromInvestingActivities', 'I6300D02', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE106', 'NetCashFlowsFromFinancingActivities', 'I6300D03', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE107', 'NetIncreaseInCashAndCashEquivalents', 'I6300D04', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE108', 'TheFinalCashAndCashEquivalentsBalance', 'I6300D05', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE200', 'SheetType', 'I6400B01', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE201', 'TotalAssets', 'I6400C01', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE202', 'TotalLiabilities', 'I6400C02', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE203', 'TotalLiabilitiesAndNetAssets', 'I6400C03', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE204', 'TotalAssets', 'I6400C04', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE300', 'SheetType', 'I6500B01', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE301', 'CurrentFinancialSubsidyCarriedOverBalance', 'I6500C01', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE302', 'CurrentUndertakingsCarriedOverBalance', 'I6500C02', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE303', 'CurrentOperatingBalance', 'I6500C03', '财务报表信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE400', '0000', 'R6141201', '财务报表整笔删除请求信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE500', '0000', 'R6241201', '财务报表整笔删除请求信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE600', '0000', 'R6341201', '财务报表整笔删除请求信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE700', '0000', 'R6441201', '财务报表整笔删除请求信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABR002', 'AcctCode', 'R0000201', '对于正常情况下的数据报送，报送文件中的不应存在标识项相同的个人借贷账户信息记录。/对于正常情况下的数据报送，报送文件中的不应存在标识项相同的企业借贷账户信息记录。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABR004', 'AcctCode', 'R0001203', '信息记录入库时，库中不能存在与其标识项完全相同的人借贷账户信息记录。/信息记录入库时，库中不能存在与其标识项完全相同的个人授信协议信息记录。/信息记录入库时，库中不能存在与其标识项完全相同的企业借贷账户信息记录。', null);
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE002', 'AcctCode', 'I0001301', '个人借贷账户记录和个人借贷账户特殊事件说明记录中的“账户标识码”与文件头中“数据提供机构区段码”应对应同一数据提供机构。/企业借贷账户记录中的账户标识码与文件头中的数据提供机构区段码应对应同一数据提供机构。', null);
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'OpenDate', 'I0000501', '个人借贷账户信息记录的信息报告日期应不早于开户日期/个人担保账户信息记录的信息报告日期应不早于开户日期。', '个人信贷交易信息/个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'RepayPrd', 'I0000501', '个人担保账户信息记录的信息报告日期应不早于余额变化日期。', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'FiveCateAdjDate', 'I0000501', '个人借贷账户信息记录的信息报告日期应不早于五级分类认定日期/个人担保账户信息记录的信息报告日期应不早于五级分类认定日期。', '个人信贷交易信息/个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'CloseDate', 'I0000501', '个人借贷账户信息记录的信息报告日期应不早于账户关闭日期/个人担保账户信息记录的信息报告日期应不早于账户关闭日期。', '个人信贷交易信息/个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAR000', 'GuarAcctBsInfSgmt', 'R2300101', '“报告时点说明代码”为“10-新开户/首次上报”，至少应出现“基本信息段”。', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAR000', 'GuarRltRepymtInfSgmt', 'R2300101', '“报告时点说明代码”为“10-新开户/首次上报”，至少应出现“在保责任信息段”。', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAR001', 'GuarRltRepymtInfSgmt', 'R2300102', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAR002', 'GuarRltRepymtInfSgmt', 'R2300103', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAR007', 'RltRepymtInfSgmt', 'R2300105', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
commit;
prompt 300 records committed...
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAR008', 'GuarAcctBsSgmt', 'R2300106', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAR003', 'GuarRltRepymtInfSgmt', 'R2300107', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAR009', 'GuarRltRepymtInfSgmt', 'R2300108', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAR004', 'FiveCateAdjDate', 'R2301201', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAR005', 'AcctStatus', 'R2301202', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAR006', 'AcctStatus', 'R2301203', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAE002', 'CloseDate', 'I2300D01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAE003', '0000', 'I2300E01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAE007', 'WartySign', 'I2300E03', '相关还款责任人段中“还款责任人类型”为“2-反担保人”时，“联保标志”必须不能为空值。', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAE007', 'MaxGuarMcc', 'I2300E03', '相关还款责任人段中“还款责任人类型”为“2-反担保人”时，“保证合同编号”必须不能为空值。', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAE000', 'RepayPrd', 'I2300A01', '账户信息记录中的开户日期小于等于余额变化日期。', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAE000', 'FiveCateAdjDate', 'I2300A01', '账户信息记录中的开户日期小于等于五级分类认定日期。', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAE000', 'CloseDate', 'I2300A01', '账户信息记录中的开户日期小于等于账户关闭日期（若不为空）。', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BIE200', '0000', 'I2310B01', '个人担保账户标识变更请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BIE201', 'OdBnesCode', 'I2311B02', '个人担保账户标识变更请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BIE202', 'NwBnesCode', 'I2311B03', '个人担保账户标识变更请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR201', '0000', 'R2320102', '个人担保账户按段更正请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR212', '0000', 'R2320105', '个人担保账户按段更正请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR204', '0000', 'R2320106', '个人担保账户按段更正请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR203', '0000', 'R2321203', '个人担保账户按段更正请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR205', 'AcctType', 'R2321207', '个人担保账户按段更正请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR206', '0000', 'R2321208', '个人担保账户按段更正请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR207', '0000', 'R2321209', '个人担保账户按段更正请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR208', '0000', 'R2321210', '个人担保账户按段更正请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR209', '0000', 'R2321211', '个人担保账户按段更正请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR210', '0000', 'R2321212', '个人担保账户按段更正请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR211', '0000', 'R2321213', '个人担保账户按段更正请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BSR200', '0000', 'R2331101', '个人担保账户按段删除请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BSE200', '0000', 'I2330B01', '个人担保账户按段删除请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BSE201', 'DelStartDate', 'I2330B02', '个人担保账户按段删除请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BTE200', 'DelRecCode', 'R2341101', '个人担保账户整笔删除请求记录错误', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE002', 'Mcc', 'I0001301', '个人借贷账户记录中的“授信协议标识码”与文件头中“数据提供机构区段码”应对应同一数据提供机构。/企业借贷账户记录中的授信协议标识码与文件头中的数据提供机构区段码应对应同一数据提供机构。', null);
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE002', 'Ccc', 'I0001301', '个人借贷账户记录的“抵（质）押合同标识码”与文件头中“数据提供机构区段码”应对应同一数据提供机构。/企业借贷账户记录中的抵（质）押合同标识码与文件头中的数据提供机构区段码应对应同一数据提供机构。', null);
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE002', 'MaxGuarMcc', 'I0001301', '个人借贷账户记录的“保证合同编号”与文件头中“数据提供机构区段码”应对应同一数据提供机构。/企业借贷账户记录中的保证合同编号与文件头中的数据提供机构区段码应对应同一数据提供机构。', null);
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE005', 'IDNum', 'I0001402', '借款人身份标识号码为中征码时应在库中存在', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'BalChgDate', 'I0000501', '信息记录中的“信息报告日期”应不早于同一条记录中余额变化日期', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'LatAgrrRpyDate', 'I0000501', '信息记录中的信息报告日期应不早于同一条记录中最近一次约定还款日', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR005', 'MotgaCltalCtrctInfSgmt', 'R2101214', '当首次上报时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“C1”，不应包括抵质押物信息段', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLD000', '不符合 S 型出现约束的数据项标签', 'S2100101', '除A型数据项外，对于不同的账户类型S型数据项出现约束见附录《个人借贷账户出现约束表》。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE028', 'RepayFreqcy', 'I2100C02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE031', 'CreditID', 'I2100C03', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE036', '0000', 'I2100C04', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE038', 'RepayPrd', 'I2100C05', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE009', '0000', 'I2100C06', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE050', '0000', 'I2100C07', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE003', 'ArlpAmt', 'I2100D01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE032', '0000', 'I2100D02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE048', 'MaxGuarMcc', 'I2100D04', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE013', 'TotOverd', 'I2100H03', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE014', 'AcctBal', 'I2100H04', '若“账户状态”为“6-未激活”时，则“余额”必须为0。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE014', 'RpyStatus', 'I2100H04', '若“账户状态”为“6-未激活”时，则“当前还款状态”必须为“*”。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE014', 'OverdPrd', 'I2100H04', '若“账户状态”为“6-未激活”时，则“当前逾期期数”若存在则必须为0。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE014', 'TotOverd', 'I2100H04', '若“账户状态”为“6-未激活”时，则“当前逾期总额”若存在则必须为0。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE015', 'CurRpyAmt', 'I2100H05', '当账户信息记录中“当前还款状态”为“*”时，“本月应还款金额”必须为0（若此账户没有上述数据项，则不校验此数据项）。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE015', 'OverdPrd', 'I2100H05', '当账户信息记录中“当前还款状态”为“*”时，“当前逾期期数”必须为0（若此账户没有上述数据项，则不校验此数据项）。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE015', 'TotOverd', 'I2100H05', '当账户信息记录中“当前还款状态”为“*”时，“当前逾期总额”必须为0（若此账户没有上述数据项，则不校验此数据项）。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE015', 'PridAcctBal', 'I2100H05', '当账户信息记录中“当前还款状态”为“*”时，“本期账单余额”必须为0（若此账户没有上述数据项，则不校验此数据项）。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE017', 'OverdPrd', 'I2100H07', '针对月度表现段，当账户信息记录中“当前还款状态”为“N”或“M”时，“当前逾期期数”必须为0（若此账户没有上述数据项，则不校验此数据项）。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE017', 'TotOverd', 'I2100H07', '针对月度表现段，当账户信息记录中“当前还款状态”为“N”或“M”时，“当前逾期总额”必须为0（若此账户没有上述数据项，则不校验此数据项）。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE019', 'OverdPrd', 'I2100H09', '当账户信息记录中“当前还款状态”为“1-7”数字时，“当前逾期期数”必须大于0（若此账户没有上述数据项，则不校验此数据项）。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE019', 'TotOverd', 'I2100H09', '当账户信息记录中“当前还款状态”为“1-7”数字时，“当前逾期总额”必须大于0（若此账户没有上述数据项，则不校验此数据项）。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE026', 'AcctBal', 'I2100H11', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE001', 'CloseDate', 'I2100H14', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE004', 'OverdPrd', 'I2100H15', '当账户状态为“关闭”/“销户”时，“当前逾期期数”应为0。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE004', 'TotOverd', 'I2100H15', '当账户状态为“关闭”/“销户”时，“当前逾期总额”应为0。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE042', 'CloseDate', 'I2100J03', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE027', 'AcctBal', 'I2100J05', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE018', 'OverdPrd', 'I2100J06', '针对非月度表现段，若“当前还款状态”为“N”或“M”，则“当前逾期期数”必须为0（若此账户没有上述数据项，则不校验此数据项）。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE018', 'TotOverd', 'I2100J06', '针对非月度表现段，若“当前还款状态”为“N”或“M”，则“当前逾期总额”必须为0（若此账户没有上述数据项，则不校验此数据项）。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE023', 'AcctBal', 'I2100A02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE035', 'BusiLines', 'I2100A07', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE005', 'OpenDate', 'I2100A09', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE010', 'RptDate', 'I2100A12', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE041', '0000', 'I2100A15', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BCR000', 'CtrctBsSgmt', 'R2200101', '个人授信协议记录报送时，“基础段”必须出现。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BCR000', 'CreditLimSgmt', 'R2200101', '个人授信协议记录报送时，“额度信息段”必须出现。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BCR002', 'ConStatus', 'R2201202', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BCE000', 'ConEffDate', 'I2200D01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BIE000', '0000', 'I2110B01', '个人借贷账户标识变更记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BIE001', 'OdBnesCode', 'I2111B02', '个人借贷账户标识变更记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BIE002', 'NwBnesCode', 'I2111B03', '个人借贷账户标识变更记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BIE100', '0000', 'I2210B01', '个人授信协议标识变更记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BIE101', 'OdBnesCode', 'I2211B02', '个人授信协议标识变更记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BIE102', 'NwBnesCode', 'I2211B03', '个人授信协议标识变更记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR001', 'AcctCode', 'R2151201', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR002', 'AcctType', 'R2151202', '若“事件类型”为“11-信用卡因调整账单日本月不出单”且“生效标志”为“1-有效”。账户类型必须为“R2”，否则此记录不能入库。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR002', 'Month', 'R2151202', '若“事件类型”为“11-信用卡因调整账单日本月不出单”且“生效标志”为“1-有效”。“发生月份”不能存在“月度表现信息段”，否则此记录不能入库；若“发生月份”处于销户月与下一个重启月之间，则此记录不能入库。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR002', 'AcctStatus', 'R2151202', '若“事件类型”为“11-信用卡因调整账单日本月不出单”且“生效标志”为“1-有效”。该记录的信息报告日期晚于该账户的最新的信息报告日期，则最新账户状态必须不为“4-销户”，否则此记录不能入库。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR002', '0000', 'R2151202', '若“事件类型”为“11-信用卡因调整账单日本月不出单”且“生效标志”为“1-有效”。库中不能存在“账户标识码+事件类型+发生月份+生效标识”相同的特殊事件说明记录，否则此记录不能入库。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR003', 'AcctType', 'R2151203', '若“事件类型”为“12-已注销信用卡账户重启”且“生效标志”为“1-有效”。账户类型必须为“R2”，否则此记录不能入库。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR003', 'AcctStatus', 'R2151203', '若“事件类型”为“12-已注销信用卡账户重启”且“生效标志”为“1-有效”。该账户的最新的“账户状态”必须是“4-销户”，否则此记录不能入库。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR003', 'Month', 'R2151203', '若“事件类型”为“12-已注销信用卡账户重启”且“生效标志”为“1-有效”。“发生月份”必须大于账户最新的“月度表现信息段”的月份，否则此记录不能入库。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR003', '0000', 'R2151203', '若“事件类型”为“12-已注销信用卡账户重启”且“生效标志”为“1-有效”。库中不能存在“账户标识码+事件类型+发生月份+生效标识”相同的特殊事件说明记录，否则此记录不能入库。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR004', 'AcctType', 'R2151204', '若“事件类型”为“21-转出”且“生效标志”为“1-有效”。该账户的账户类型必须为“D1”，否则此记录不能入库。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR004', 'RptDate', 'R2151204', '若“事件类型”为“21-转出”且“生效标志”为“1-有效”。该记录的信息报告日期必须晚于库中最新的信息记录，否则不能入库。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR004', 'AcctStatus', 'R2151204', '若“事件类型”为“21-转出”且“生效标志”为“1-有效”。该账户的最新账户状态必须不为“3-关闭”，否则此记录不能入库。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR004', 'Month', 'R2151204', '若“事件类型”为“21-转出”且“生效标志”为“1-有效”。“发生月份”必须等于最新的“月度表现信息段”的“月份”的次月，否则此记录不能入库。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR004', '0000', 'R2151204', '若“事件类型”为“21-转出”且“生效标志”为“1-有效”。库中不能存在“账户标识码+事件类型+发生月份+生效标识”相同的特殊事件说明记录，否则此记录不能入库。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR005', '0000', 'R2151205', '若“生效标志”为“0-无效”：“账户标识码+事件类型+发生月份”对应的“生效标志”为“1-有效”的特殊事件说明记录必须库中存在，否则该记录不能入库。', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR005', 'OpetnType', 'R2151205', '若“生效标志”为“0-无效”：“事件类型”为“12-已注销信用卡账户重启”，若存在更新的月度表现信息（即“月份”大于该记录的“发生月份”），则该记录不能入库。', '个人信贷交易信息');
commit;
prompt 400 records committed...
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR006', '0000', 'R2151206', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BQR000', '0000', 'I2150B01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR001', '0000', 'R2120102', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR003', '0000', 'R2120106', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR005', '0000', 'R2120107', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR007', '0000', 'R2121206', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR008', 'RptDate', 'R2121207', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR012', 'AcctType', 'R2121211', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR014', 'RptDate', 'R2121213', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR006', '0000', 'R2121214', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR009', '0000', 'R2121216', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR013', '0000', 'R2121219', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR017', '0000', 'R2121222', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR020', '0000', 'R2121225', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR104', '0000', 'R2221203', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR106', '0000', 'R2221209', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR109', '0000', 'R2221212', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BTE000', 'DelRecCode', 'R2141101', '个人借贷账户整笔删除记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BTE100', 'DelRecCode', 'R2241101', '个人授信协议整笔删除记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BSR000', '0000', 'R2131203', '个人借贷账户按段删除记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BSR001', '0000', 'R2131201', '个人借贷账户按段删除记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BSR002', '0000', 'R2131202', '个人借贷账户按段删除记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BSE000', '0000', 'I2130B01', '个人借贷账户按段删除记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BSE001', 'DelStartDate', 'I2130B02', '个人借贷账户按段删除记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BSR100', '0000', 'R2231101', '个人授信协议按段删除记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BSE100', '0000', 'I2230B01', '个人授信协议按段删除记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BSE101', 'DelStartDate', 'I2230B02', '个人授信协议按段删除记录错误', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE011', 'CosignersNm', 'I0000702', '对于联保人信息段中一组可出现多次的数据项，当出现多次时，内容不能重复。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR000', 'AcctBsSgmt', 'R4100101', '当“报送时点说明代码”为“10-新开户/首次报送”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“D1”，必须包含基础段若“账户类型”为“D2”，必须包含基础段若“账户类型”为“R1/R4”，必须包含基础段若“账户类型”为“C1”，必须包含基础段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR000', 'AcctBsInfSgmt', 'R4100101', '当“报送时点说明代码”为“10-新开户/首次报送”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“D1”，必须包含基本信息段若“账户类型”为“D2”，必须包含基本信息段若“账户类型”为“R1/R4”，必须包含基本信息段若“账户类型”为“C1”，必须包含基本信息段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR000', 'ActLbltyInfSgmt', 'R4100101', '当“报送时点说明代码”为“10-新开户/首次报送”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“D1”，必须包含还款表现信息段若“账户类型”为“D2”，必须包含还款表现信息段若“账户类型”为“R1/R4”，必须包含还款表现信息段。若“账户类型”为“C1”，必须包含还款表现信息段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR000', 'AcctCredSgmt', 'R4100101', '当“报送时点说明代码”为“10-新开户/首次报送”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“D1”，如果基本信息段中“分次放款标识”代码表位为“1”或“2”，则还应包含授信额度信息段。若“账户类型”为“R1/R4”，必须包含授信额度信息段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR001', 'OrigCreditorInfSgmt', 'R4100102', '当“报送时点说明代码”为“10-新开户/首次报送”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，不应包含初始债权说明段若“账户类型”为“R1/R4”，不应包含初始债权说明段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR001', 'AcctCredSgmt', 'R4100102', '当“报送时点说明代码”为“10-新开户/首次报送”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，如果“分次放款标识”为“0”，则不应包含授信额度信息段。若“账户类型”为“D2”，不应包含授信额度信息段若“账户类型”为“C1”，不应包含授信额度信息段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR001', 'MotgaCltalCtrctInfSgmt', 'R4100102', '当“报送时点说明代码”为“10-新开户/首次报送”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D2”，不应包含抵质押物信息段若“账户类型”为“C1”，不应包含抵质押物信息段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR002', 'AcctBsSgmt', 'R4100103', '当“报送时点说明代码”为“20-账户关闭”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“D1”，必须包含基础段若“账户类型”为“D2”，必须包含基础段若“账户类型”为“R1/R4”，必须包含基础段若“账户类型”为“C1”，必须包含基础段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR002', 'ActLbltyInfSgmt', 'R4100103', '当“报送时点说明代码”为“20-账户关闭”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“D1”，必须包含还款表现信息段。若“账户类型”为“D2”，必须包含还款表现信息段。若“账户类型”为“R1/R4”，必须包含还款表现信息段。若“账户类型”为“C1”，必须包含还款表现信息段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR003', 'MotgaCltalCtrctInfSgmt', 'R4100104', '当“报送时点说明代码”为“20-账户关闭”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D2”，不应包含抵质押物信息段若“账户类型”为“C1”，不应包含抵质押物信息段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR003', 'AcctCredSgmt', 'R4100104', '当“报送时点说明代码”为“20-账户关闭”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，如果“分次放款标识”为“0”，则不应包含授信额度信息段。若“账户类型”为“D2”，不应包含授信额度信息段若“账户类型”为“C1”，不应包含授信额度信息段。OrigCreditorInfSgmt当“报送时点说明代码”为“20-账户关闭”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，不应包含初始债权说明段若“账户类型”为“R1/R4”，不应包含初始债权说明段。若“账户类型”为“C1”，不应包含初始债权说明段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR003', 'RltRepymtInfSgmt', 'R4100104', '当“报送时点说明代码”为“20-账户关闭”时，“账户类型”为“C1”，不应包含相关还款责任信息段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR004', 'AcctBsInfSgmt', 'R4100105', '当“报送时点说明代码”为“31-开户后放款”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“D1”，且“分次放款标识”为“2”，还应包含基本信息段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR004', 'AcctType', 'R4100105', '当“报送时点说明代码”为“31-开户后放款”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“D1”，且“分次放款标识”为“0”、“1”，则不适用放款日报送时点。若“账户类型”为“D2”，不适用放款日报送时点。若“账户类型”为“R1/R4”，不适用放款日报送时点。若“账户类型”为“C1”，不适用放款日报送时点。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR005', 'OrigCreditorInfSgmt', 'R4100106', '当“报送时点说明代码”为“31-开户后放款”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，且“分次放款标识”为“2”，不应包含初始债权说明段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR005', 'AcctType', 'R4100106', '当“报送时点说明代码”为“31-开户后放款”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，“分次放款标识”为“0”、“1”，不适用放款日报送时点。若“账户类型”为“D2”，不适用放款日报送时点。若“账户类型”为“R1/R4”，不适用放款日报送时点。若“账户类型”为“C1”，不适用放款日报送时点。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR006', 'AcctBsSgmt', 'R4100107', '当“报送时点说明代码”为“32-约定还款日结算”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“D1”，应包含基础段若“账户类型”为“D2”，应包含基础段若“账户类型”为“R4”，应包含基础段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR006', 'ActLbltyInfSgmt', 'R4100107', '当“报送时点说明代码”为“32-约定还款日结算”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“D1”，应包含还款表现信息段。若“账户类型”为“D2”，应包含还款表现信息段。若“账户类型”为“R4”，应包含还款表现信息段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR006', 'AcctType', 'R4100107', '当“报送时点说明代码”为“32-约定还款日结算”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“R1”，不适用约定还款日报送时点。若“账户类型”为“C1”，不适用约定还款日报送时点。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR007', 'OrigCreditorInfSgmt', 'R4100108', '当“报送时点说明代码”为“32-约定还款日结算”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，不应包含初始债权说明段。若“账户类型”为“R1”，不应包含初始债权说明段若“账户类型”为“R4”，不应包含初始债权说明段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR007', 'AcctCredSgmt', 'R4100108', '当“报送时点说明代码”为“32-约定还款日结算”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，如果“分次放款标识”为“0”，则不应包含授信额度信息段。若“账户类型”为“D2”，不应包含授信额度信息段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR007', 'MotgaCltalCtrctInfSgmt', 'R4100108', '当“报送时点说明代码”为“32-约定还款日结算”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D2”，不应包含抵质押物信息段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR007', 'AcctType', 'R4100108', '当“报送时点说明代码”为“32-约定还款日结算”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“C1”，不适用约定还款日报送时点。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR008', 'AcctBsSgmt', 'R4100109', '当“报送时点说明代码”为“33-实际还款”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“D1”，应包含基础段若“账户类型”为“D2”，应包含基础段若“账户类型”为“R4”，应包含基础段若“账户类型”为“C1”，应包含基础段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR008', 'ActLbltyInfSgmt', 'R4100109', '当“报送时点说明代码”为“33-实际还款”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“D1”，应包含还款表现信息段。若“账户类型”为“D2”，应包含还款表现信息段。若“账户类型”为“R4”，应包含还款表现信息段。若“账户类型”为“C1”，应包含还款表现信息段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR008', 'AcctType', 'R4100109', '当“报送时点说明代码”为“33-实际还款”时，对于不同的账户类型至少还应包含的信息段如下。对于“账户类型”为“R1”，不适用实际还款日报送时点。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR009', 'OrigCreditorInfSgmt', 'R4100110', '当“报送时点说明代码”为“33-实际还款”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，不应包含初始债权说明段。若“账户类型”为“R4”，不应包含初始债权说明段若“账户类型”为“C1”，不应包含初始债权说明段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR009', 'AcctCredSgmt', 'R4100110', '当“报送时点说明代码”为“33-实际还款”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，如果“分次放款标识”为“0”，则不应包含授信额度信息段。若“账户类型”为“D2”，不应包含授信额度信息段若“账户类型”为“C1”，不应包含授信额度信息段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR009', 'MotgaCltalCtrctInfSgmt', 'R4100110', '当“报送时点说明代码”为“33-实际还款”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D2”，不应包含抵质押物信息段若“账户类型”为“C1”，不应包含抵质押物信息段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR009', 'RltRepymtInfSgmt', 'R4100110', '当“报送时点说明代码”为“33-实际还款”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“C1”，不应包含相关还款责任人段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR009', 'AcctType', 'R4100110', '当“报送时点说明代码”为“33-实际还款”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“R1”，不适用实际还款报送时点。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR010', 'AcctBsSgmt', 'R4100111', '当“报送时点说明代码”为“41-五级分类调整”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“D1”，应包含基础段对于“账户类型”为“D2”，应包含基础段若“账户类型”为“R4”，应包含基础段若“账户类型”为“C1”，应包含基础段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR010', 'ActLbltyInfSgmt', 'R4100111', '当“报送时点说明代码”为“41-五级分类调整”时，对于不同的账户类型至少还应包含的信息段如下。若“账户类型”为“D1”，应包含还款表现信息段。对于“账户类型”为“D2”，应包含还款表现信息段。若“账户类型”为“R4”，应包含还款表现信息段。若“账户类型”为“C1”，应包含还款表现信息段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR010', 'AcctType', 'R4100111', '当“报送时点说明代码”为“41-五级分类调整”时，对于“账户类型”为“R1”，不适用该时点。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR011', 'OrigCreditorInfSgmt', 'R4100112', '当“报送时点说明代码”为“41-五级分类调整”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，不应包含初始债权说明段；若“账户类型”为“R4”，不应包含初始债权说明段；若“账户类型”为“R1”，不适用该时点；若“账户类型”为“C1”，不应包含初始债权说明段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR011', 'AcctCredSgmt', 'R4100112', '当“报送时点说明代码”为“41-五级分类调整”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，如果“分次放款标识”为“0”，则不应包含授信额度信息段。若“账户类型”为“D2”，不应包含授信额度信息段若“账户类型”为“C1”，授信额度信息段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR011', 'MotgaCltalCtrctInfSgmt', 'R4100112', '当“报送时点说明代码”为“41-五级分类调整”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D2”，不应包含抵质押物信息段若“账户类型”为“C1”，不应包含抵质押物信息段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR011', 'RltRepymtInfSgmt', 'R4100112', '当“报送时点说明代码”为“41-五级分类调整”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“C1”，不应包含相关还款责任人段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR012', 'AcctBsSgmt', 'R4100113', '当“报送时点说明代码”为“42-展期发生”时，对于不同的账户类型至少应包含的信息段如下。若“账户类型”为“D1”，应包含基础段。若“账户类型”为“R4”，应包含基础段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR012', 'ActLbltyInfSgmt', 'R4100113', '当“报送时点说明代码”为“42-展期发生”时，对于不同的账户类型至少应包含的信息段如下。若“账户类型”为“D1”，应包含还款表现信息段；若“账户类型”为“R4”，应包含还款表现信息段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR012', 'AcctSpecTrstDspnSgmt', 'R4100113', '当“报送时点说明代码”为“42-展期发生”时，对于不同的账户类型至少应包含的信息段如下。若“账户类型”为“D1”，特定交易说明段若“账户类型”为“R4”，应包含特定交易说明段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR012', 'AcctType', 'R4100113', '当“报送时点说明代码”为“42-展期发生”时，对于不同的账户类型至少应包含的信息段如下。对于“账户类型”为“D2”，不适用展期发生报送时点。若“账户类型”为“R1”，不适用展期发生报送时点。若“账户类型”为“C1”，不适用展期发生报送时点。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR013', 'OrigCreditorInfSgmt', 'R4100114', '当“报送时点说明代码”为“42-展期发生”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，不应包含初始债权说明段若“账户类型”为“R4”，不应包含初始债权说明段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR013', 'AcctCredSgmt', 'R4100114', '当“报送时点说明代码”为“42-展期发生”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，如果“分次放款标识”为“0”，则不应包含授信额度信息段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR013', 'AcctType', 'R4100114', '当“报送时点说明代码”为“42-展期发生”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D2”，不适用展期发生报送时点。若“账户类型”为“R1”，不适用展期发生报送时点。若“账户类型”为“C1”，不适用展期发生报送时点。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR014', 'AcctBsSgmt', 'R4100115', '当“报送时点说明代码”为“49-其他报送日”时，对于不同的账户类型至少应包含的信息段如下。若“账户类型”为“D1”，应包含基础段若“账户类型”为“D2”，应包含基础段若“账户类型”为“R1”，应包含基础段若“账户类型”为“R4”，应包含基础段若“账户类型”为“C1”，应包含基础段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR014', 'ActLbltyInfSgmt', 'R4100115', '当“报送时点说明代码”为“49-其他报送日”时，对于不同的账户类型至少应包含的信息段如下。若“账户类型”为“D1”，应包含还款表现信息段。若“账户类型”为“D2”，应包含段、还款表现信息段。若“账户类型”为“R1”，应包含还款表现信息段。若“账户类型”为“R4”，应包含还款表现信息段。若“账户类型”为“C1”，应包含还款表现信息段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR015', 'OrigCreditorInfSgmt', 'R4100116', '当“报送时点说明代码”为“49-其他报送日”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，不应包含初始债权说明段。若“账户类型”为“R1/R4”，不应包含初始债权说明段。若“账户类型”为“C1”，不应包含初始债权说明段。', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR015', 'AcctCredSgmt', 'R4100116', '当“报送时点说明代码”为“49-其他报送日”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D1”，如果“分次放款标识”为“0”，则不应包含授信额度信息段。若“账户类型”为“D2”，不应包含授信额度信息段。若“账户类型”为“C1”，不应包含授信额度信息段.', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR015', 'RltRepymtInfSgm', 'R4100116', '当“报送时点说明代码”为“49-其他报送日”时，对于不同的账户类型不应包含的信息段如下：若“账户类型”为“C1”，不应包含相关还款责任人段.', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR015', 'MotgaCltalCtrctInfSgmt', 'R4100116', '当“报送时点说明代码”为“49-其他报送日”时，对于不同的账户类型不应包含的信息段如下。若“账户类型”为“D2”，不应包含抵质押物信息段若“账户类型”为“C1”，不应包含抵质押物信息段', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR016', 'RltRepymtInfSgmt', 'R4100117', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR017', 'MotgaCltalCtrctInfSgmt', 'R4100118', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR018', 'AcctBsSgmt', 'R4100119', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR019', 'AcctType', 'R4101201', '待入库的企业借贷账户信息记录中的“账户类型”必须与已入库的“账户类型”一致', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR020', 'RptDate', 'R4101202', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR021', 'RptDate', 'R4101203', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR023', 'BalChgDate', 'R4101205', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR024', 'FiveCateAdjDate', 'R4101206', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR025', 'LatRpyDate', 'R4101207', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR026', 'LatAgrrRpyDate', 'R4101208', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR027', 'NxtAgrrRpyDate', 'R4101209', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR030', 'AcctBsInfSgmt', 'R4101212', '首次上报时（即库中不存在该账户）：企业借贷账户信息记录至少包含基本信息段；', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR030', 'ActLbltyInfSgmt', 'R4101212', '首次上报时（即库中不存在该账户）：若账户类型为“D1/D2/R1/R4/C1”，则企业借贷账户信息记录还应包含还款表现信息段，', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR030', 'AcctCredSgmt', 'R4101212', '首次上报时（即库中不存在该账户）：若账户类型为“D1”，基本信息段中“分次放款标志”为“1”或“2”或者若账户类型为“R1/R4”，则企业借贷账户信息记录还应包含授信额度信息段；', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAE001', 'CloseDate', 'I4400D01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAE007', '0000', 'I4400A02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAE001', 'OpenDate', 'I2300C01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAE006', '0000', 'I2300C02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAE005', 'CloseDate', 'I2300D02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BAE004', '0000', 'I2300A02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE048', 'WartySign', 'I2100D04', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
commit;
prompt 500 records committed...
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE002', 'RpyPrct', 'I2100H01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE012', 'SettDate', 'I2100H02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE020', '0000', 'I2100H10', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE030', 'RpyStatus', 'I2100H12', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE011', 'CloseDate', 'I2100H13', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE007', 'SpecEfctDate', 'I2100I01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE034', 'RpyStatus', 'I2100J02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE043', 'CloseDate', 'I2100J04', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE046', 'CagOfTrdNm', 'I2100K01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE022', 'OvedrawBaOve180', 'I2100A01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE025', 'AcctBal', 'I2100A04', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE029', 'RepayMode', 'I2100A05', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE037', 'AcctStatus', 'I2100A08', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE006', 'CloseDate', 'I2100A10', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE008', 'RptDate', 'I2100A11', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE039', 'RptDate', 'I2100A13', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE040', 'LatRpyDate', 'I2100A14', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLE016', '0000', 'I2100A16', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BCR001', 'ConStatus', 'R2201201', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BCE002', '0000', 'I2200C01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BCE004', '0000', 'I2200D02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BCE003', '0000', 'I2200A01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR021', '0000', 'R2121215', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR010', '0000', 'R2121217', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR011', '0000', 'R2121218', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR015', '0000', 'R2121220', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR016', '0000', 'R2121221', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR018', '0000', 'R2121223', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR019', '0000', 'R2121224', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR101', '0000', 'R2220102', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR105', '0000', 'R2220103', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR103', '0000', 'R2221207', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD000', 'Occupation', 'S1100101', '当“就业状况”为“11-国家公务员”、“13-专业技术人员”、“17-职员”、“21-企业管理人员”、“24-工人”或“91-在职”时，“职业”必须出现。“就业状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD000', 'Title', 'S1100101', '当“就业状况”为“11-国家公务员”、“13-专业技术人员”、“17-职员”、“21-企业管理人员”、“24-工人”或“91-在职”时，“职务”必须出现。“就业状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD000', 'TechTitle', 'S1100101', '当“就业状况”为“11-国家公务员”、“13-专业技术人员”、“17-职员”、“21-企业管理人员”、“24-工人”或“91-在职”时，“职称”必须出现。“就业状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD000', 'WorkStartDate', 'S1100101', '当“就业状况”为“11-国家公务员”、“13-专业技术人员”、“17-职员”、“21-企业管理人员”、“24-工人”或“91-在职”时，“本单位工作起始年份”必须出现。“就业状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD001', 'SpoName', 'S1100102', '当“婚姻状况”为“20-已婚”、“21-初婚”、“22-再婚”、“23-复婚”时，“配偶姓名”必须出现。“婚姻状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD001', 'SpoIDType', 'S1100102', '当“婚姻状况”为“20-已婚”、“21-初婚”、“22-再婚”、“23-复婚”时，“配偶证件类型”必须出现。“婚姻状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD001', 'SpoIDNum', 'S1100102', '当“婚姻状况”为“20-已婚”、“21-初婚”、“22-再婚”、“23-复婚”时，“配偶证件号码”必须出现。“婚姻状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD001', 'SpoTel', 'S1100102', '当“婚姻状况”为“20-已婚”、“21-初婚”、“22-再婚”、“23-复婚”时，“配偶联系电话”必须出现。“婚姻状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD001', 'SpsCmpyNm', 'S1100102', '当“婚姻状况”为“20-已婚”、“21-初婚”、“22-再婚”、“23-复婚”时，“配偶工作单位”必须出现。“婚姻状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBE004', 'AcaDegree', 'I1100F03', '未定义', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBE005', 'Occupation', 'I1100G04', '未定义', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD002', '0000', 'I1100A01', '未定义', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD003', '0000', 'I1100A02', '未定义', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BFR000', 'RptDate', 'R1201201', '家族关系信息记录错误', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BFE000', '0000', 'I1200B01', '家族关系信息记录错误', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BOR000', 'RptDate', 'R1301201', '个人证件有效期信息记录错误', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BPR000', 'RptDate', 'R1401202', '个人证件整合信息记录错误', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BDE000', 'InfSurcCode', 'R1141201', '个人基本信息整笔删除请求记录错误', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BDE001', 'InfSurcCode', 'R1341101', '个人证件有效期整笔删除请求记录错误', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CRE800', '0000', 'R6541201', '财务报表整笔删除请求信息记录错误', '企业财务报表信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CCR000', 'CtrctBsSgmt', 'R4200101', '企业授信协议记录报送时，“基础段”必须出现。', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CCR000', 'CreditLimSgmt', 'R4200101', '企业授信协议记录报送时，“额度信息段”必须出现。', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CCR001', 'ConStatus', 'R4201201', '企业授信协议信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CCR002', 'ConStatus', 'R4201202', '企业授信协议信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CCE000', '0000', 'I4200C01', '企业授信协议信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CCE002', 'ConEffDate', 'I4200D01', '企业授信协议信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CCE004', '0000', 'I4200D02', '企业授信协议信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CCE003', '0000', 'I4200A01', '企业授信协议信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CIR100', '0000', 'I4210B01', '企业授信协议标识变更信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CIR101', 'OdBnesCode', 'I4211B02', '企业授信协议标识变更信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CIR102', 'NwBnesCode', 'I4211B03', '企业授信协议标识变更信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR101', 'MdfcSgmtCode', 'R4220102', '企业授信协议按段更正信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR106', '0000', 'R4220103', '企业授信协议按段更正信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR104', '0000', 'R4221203', '企业授信协议按段更正信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR107', '0000', 'R4221206', '企业授信协议按段更正信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR108', '0000', 'R4221207', '企业授信协议按段更正信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR109', '0000', 'R4221208', '企业授信协议按段更正信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR110', '0000', 'R4221209', '企业授信协议按段更正信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR111', '0000', 'R4221210', '企业授信协议按段更正信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CMR112', '0000', 'R4221211', '企业授信协议按段更正信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CTR100', 'DelRecCode', 'R4241201', '企业授信协议整笔删除信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CSR100', '0000', 'R4231201', '企业授信协议按段删除信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CSE100', '0000', 'I4230B01', '企业授信协议按段删除信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CSE101', 'DelStartDate', 'I4230B02', '企业授信协议按段删除信息记录错误', '企业授信协议信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BPR000', 'MotgaCltalCtrctBsSgmt', 'R5100101', '当抵（质）押合同信息记录上报时，基础段必须出现。', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BPR000', 'MotgaCltalBsInfSgmt', 'R5100101', '当抵（质）押合同信息记录上报时，合同基本信息段必须出现。', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BPR001', 'MotgaProptInfSgmt', 'R5100102', '当抵（质）押合同信息记录中“合同类型”为“1-抵押合同”、时，记录中必须有抵押物信息段且不能包含质押物信息段。', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BPR001', 'CltalInfSgmt', 'R5100102', '当抵（质）押合同信息记录中“合同类型”为“2-质押合同”时，记录中必须有质押信息段且不能包含抵押信息段。', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BPR002', 'RptDate', 'R5101201', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BPR003', 'CcStatus', 'R5101202', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BPE000', '0000', 'I1400B01/I5100B01', '（个人）个人证件整合信息记录错误/（抵（质）押物信息）人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BPE001', '0000', 'I5100C01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BPE002', '0000', 'I5100D01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BPE003', 'GrtdNm', 'I5100D02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BPE005', 'PleNm', 'I5100E02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BPE007', 'ImpNm', 'I5100F02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BPE008', '0000', 'I5100A01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BIE300', '0000', 'I5110B01', '抵（质）押合同标识变更请求记录错误', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BIE301', 'OdBnesCode', 'I5111B02', '抵（质）押合同标识变更请求记录错误', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BIE302', 'NwBnesCode', 'I5111B03', '抵（质）押合同标识变更请求记录错误', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BTE300', 'DelRecCode', 'R5141101', '抵（质）押合同整笔删除请求记录错误', '抵（质）押物信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR110', '0000', 'R2221208', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR107', '0000', 'R2221210', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BMR108', '0000', 'R2221211', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR028', '0000', 'R4101210', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLR029', 'AcctBal', 'R4101211', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR000', 'BsSgmt', 'R1100102', '个人基本信息记录应包含基础段。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR000', 'FcsInfSgmt', 'R1100101', '当报告时点说明代码为“10-新增客户/首次上报”时，记录必须至少包含基本概况信息段。', '个人基本信息');
commit;
prompt 600 records committed...
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR000', 'SpsInfSgmt', 'R1100101', '当报告时点说明代码为“10-新增客户/首次上报”时，记录必须至少包含婚姻信息段。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR000', 'EduInfSgmt', 'R1100101', '当报告时点说明代码为“10-新增客户/首次上报”时，记录必须至少包含教育信息段。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR000', 'OctpnInfSgmt', 'R1100101', '当报告时点说明代码为“10-新增客户/首次上报”时，记录必须至少包含职业信息段。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR000', 'RedncInfSgmt', 'R1100101', '当报告时点说明代码为“10-新增客户/首次上报”时，记录必须至少包含居住地址段。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR000', 'MlgInfSgmt', 'R1100101', '当报告时点说明代码为“10-新增客户/首次上报”时，记录必须至少包含通讯地址段。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR001', 'FcsInfSgmt', 'R1101201', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中不存在，该记录至少包含基本概况段。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR002', 'SpsInfSgmt', 'R1101201', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中不存在，该记录至少包含婚姻信息段。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR003', 'EduInfSgmt', 'R1101201', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中不存在，该记录至少包含教育信息段。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR004', 'OctpnInfSgmt', 'R1101201', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中不存在，该记录至少包含职业信息段。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR005', 'RedncInfSgmt', 'R1101201', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中不存在，该记录至少包含居住地址段。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR006', 'MlgInfSgmt', 'R1101201', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中不存在，该记录至少包含通讯地址段。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR002', 'RptDate', 'R1101202', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中已存在，若其信息报告日期早于库中信息记录最新的信息报告日期，则此记录不能入库。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR002', 'IDInfoUpDate', 'R1101202', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中已存在，若其他标识信息段信息更新日期早于库中其他标识信息段信息更新日期，则此记录不能入库。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR002', 'FcsInfoUpDate', 'R1101202', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中已存在，若基本概况段信息更新日期早于库中基本概况信息段信息更新日期，则此记录不能入库。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR002', 'SpsInfoUpDate', 'R1101202', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中已存在，若婚姻信息段信息更新日期早于库中婚姻信息段信息更新日期，则此记录不能入库。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR002', 'EduInfoUpDate', 'R1101202', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中已存在，若教育信息段信息更新日期早于库中教育信息段信息更新日期，则此记录不能入库。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR002', 'OctpnInfoUpDa-te', 'R1101202', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中已存在，若职业信息段信息更新日期早于库中职业信息段信息更新日期，则此记录不能入库。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR002', 'ResiInfoUpDate', 'R1101202', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中已存在，若居住地址段信息更新日期早于库中居住地址段信息更新日期，则此记录不能入库。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR002', 'MlgInfoUpDate', 'R1101202', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中已存在，若通讯信息段信息更新日期早于库中通讯信息段信息更新日期，则此记录不能入库。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBR002', 'IncInfoUpDate', 'R1101202', '对于待入库的个人基本信息记录，若“两标/三标”+“信息来源编码”在库中已存在，若收入信息段信息更新日期早于库中收入信息段信息更新日期，则此记录不能入库。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD000', 'CpnName', 'S1100101', '当“就业状况”为“11-国家公务员”、“13-专业技术人员”、“17-职员”、“21-企业管理人员”、“24-工人”或“91-在职”时，“单位名称”必须出现。“就业状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD000', 'CpnType', 'S1100101', '当“就业状况”为“11-国家公务员”、“13-专业技术人员”、“17-职员”、“21-企业管理人员”、“24-工人”或“91-在职”时，“单位性质”必须出现。“就业状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD000', 'Industry', 'S1100101', '当“就业状况”为“11-国家公务员”、“13-专业技术人员”、“17-职员”、“21-企业管理人员”、“24-工人”或“91-在职”时，“单位所属行业”必须出现。“就业状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD000', 'CpnAddr', 'S1100101', '当“就业状况”为“11-国家公务员”、“13-专业技术人员”、“17-职员”、“21-企业管理人员”、“24-工人”或“91-在职”时，“单位详细地址”必须出现。“就业状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD000', 'CpnPc', 'S1100101', '当“就业状况”为“11-国家公务员”、“13-专业技术人员”、“17-职员”、“21-企业管理人员”、“24-工人”或“91-在职”时，“单位所在地邮编”必须出现。“就业状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD000', 'CpnDist', 'S1100101', '当“就业状况”为“11-国家公务员”、“13-专业技术人员”、“17-职员”、“21-企业管理人员”、“24-工人”或“91-在职”时，“单位所在地行政区划”必须出现。“就业状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BBD000', 'CpnTEL', 'S1100101', '当“就业状况”为“11-国家公务员”、“13-专业技术人员”、“17-职员”、“21-企业管理人员”、“24-工人”或“91-在职”时，“单位电话”必须出现。“就业状况”若为上述以外的代码，上述数据项不能出现。', '个人基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABR004', 'InfSurcCode', 'R0001203', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABD001', '空信息段的信息段标签', 'S0000102', '信息段不能为空段（信息段为空指两个信息段的XML标签中没有任何数据项）。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE005', 'OthEntCertNum', 'I0001402', '其他标识段企业身份标识号码为中征码时应在库中存在/企业身份标识整合信息记录中企业身份标识号码为中征码时应在库中存在', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE007', 'SupOrgInfoUpDate', 'I0000501', '个人/企业基本信息记录的“信息报告日期”应不早于上级机构段信息更新日期', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE010', 'MnSharHodNm', 'I0000701', '对于一组可出现多次的数据项：主要出资人信息，其出现次数必须与其个数相匹配。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR000', 'FcsInfSgmt', 'R3100101', '当报告时点说明代码为“报告时新增客户/首次上报”时，记录必须至少包含“基本概况段”。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR003', 'IDInfoUpDate', 'R3101202', '待入库的企业基本信息记录（“两标/三标”+“信息来源编码”在库中存在），其他标识信息段信息更新日期早于最新的其他标识信息段信息更新日期，该记录不能入库。', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABH005', '0000', 'F0000301', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABF007', '0000', 'F0000401', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABF009', '0000', 'F0000601', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABF008', '0000', 'F0000501', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABR001', 'RptDate', 'R0000102', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABR002', 'InfSurcCode', 'R0000201', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('ABE003', 'Cimoc', 'I0001302', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBR001', 'MnShaHodInfSgmt', 'R3100102', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE000', '0000', 'I3100E01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE002', '0000', 'I3100E03', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE014', '0000', 'I3100E04', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE004', 'InvRatio', 'I3100F02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE015', '0000', 'I3100H01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE006', 'OthEntCertType', 'I3100A01', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE008', 'OthEntCertType', 'I3100A03', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CBE010', 'OthEntCertType', 'I3100A05', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人基本信息/企业基本信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR029', 'AcctBsSgmt', 'R2100117', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR019', 'AcctType', 'R2101204', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR021', 'RptDate', 'R2101206', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR022', 'FiveCateAdjDate', 'R2101207', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR024', '0000', 'R2101209', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR026', 'RptDate', 'R2101211', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('BLR027', 'RptDate', 'R2101212', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '个人信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE014', 'TotOverd', 'I4100H04', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE027', 'AcctBal', 'I4100A04', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE029', 'RepayMode', 'I4100A06', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CLE030', '0000', 'I4100A07', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业信贷交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAR009', 'AcctType', 'R4401204', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
insert into MBT_FEEDBACK_INFO (fb_code, fb_msg, role_code, remark, belong)
values ('CAE008', '0000', 'I4400C02', '人行在发文中未定义相应的错误描述，具体信息请查看人行错误反馈描述文档', '企业担保交易信息');
commit;
prompt 663 records loaded

set feedback on
set define on
prompt Done
