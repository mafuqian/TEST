_DATA_FORMAT_="YYYYMMDD";
_TIME_FORMAT_="HHmmSS";
ALERT_POSITION="TOP";
_SHOW_TAB_LOADING=false;//是否显示TAB加载框
_AUTO_TALBE_MODE="FULL";//自适应表格父表格未设置宽度时,FULL:撑满,其它:计算
_EDIT_TABLE_HEAD_ICON=null;//这个参数表示可编辑表格表头图标的位置. 可选值: left,center,right
_DATAGRID_ROW_FOCUS_ON_CLICK_TAG_A=true;//点击单元格超链，光标是否自动移动到该行，默认true
_ALERT_AUTO_CLOSE={info:3000,warn:3000,correct:3000};//配置弹出框自动关闭的等待时间，单位ms。支持种类:info,warn,correct,error,confirm.不写则是表示不自动关闭
