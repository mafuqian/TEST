package freemarker.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class Test {
	
	public static void main(String[] args) {
		recursiveTraversalFolder("C:\\514");
	}

	public static void recursiveTraversalFolder(String path) {
        File folder = new File(path);
        if (folder.exists()) {
            File[] fileArr = folder.listFiles();
            if (null == fileArr || fileArr.length == 0) {
                System.out.println("文件夹是空的!");
                return;
            } else {
                File newDir = null;//文件所在文件夹路径+新文件名
                String newName = "";//新文件名
                String fileName = null;//旧文件名
                File parentPath = new File("");//文件所在父级路径
                for (File file : fileArr) {
                    if (file.isDirectory()) {//是文件夹，继续递归，如果需要重命名文件夹，这里可以做处理
                        System.out.println("文件夹:" + file.getAbsolutePath() + "，继续递归！");
                        recursiveTraversalFolder(file.getAbsolutePath());
                    } else {//是文件，判断是否需要重命名
                        fileName = file.getName();
                        parentPath = file.getParentFile();
                        if (fileName.contains("Mbt514")) {//文件名包含需要被替换的字符串
                            newName = fileName.replaceAll("Mbt514", "Mbt514_P_");//新名字
                            newDir = new File(parentPath + "/" + newName);//文件所在文件夹路径+新文件名
                            file.renameTo(newDir);//重命名
                            System.out.println("修改后：" + newDir);
                        }
                    }
                }
            }
        } else {
            System.out.println("文件不存在!");
        }
    }
	
	public static void init (String s,String s1) {
		try {
			BufferedReader bufReader = new BufferedReader(new InputStreamReader(new FileInputStream(new File("D:/EntNatureDistributionDAO.txt"))));//数据流读取文件

			StringBuffer strBuffer = new StringBuffer();
			String empty = "";
			String tihuan = "";
			for (String temp = null; (temp = bufReader.readLine()) != null; temp = null) {
				if(temp.indexOf(s) != -1 && temp.indexOf(s) != -1){ //判断当前行是否存在想要替换掉的字符 -1表示存在
					temp = temp.replace(s, s1);//替换为你想要的东东
				}
				strBuffer.append(temp);
				strBuffer.append(System.getProperty("line.separator"));//行与行之间的分割
			}
			bufReader.close();
			PrintWriter printWriter = new PrintWriter("E:/EntNatureDistributionDAO.txt");//替换后输出的文件位置
			printWriter.write(strBuffer.toString().toCharArray());
			printWriter.flush();
			printWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}

