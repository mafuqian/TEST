package com.gingkoo.gf4j2.framework.entity;
import com.google.common.base.MoreObjects;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gingkoo.gf4j2.framework.entity.base.RootEntity;
import com.gingkoo.gf4j2.framework.entity.base.WithDataDate;
import com.gingkoo.gf4j2.framework.entity.base.WithDataHolder;
import com.gingkoo.gf4j2.framework.entity.base.WithDataId;
import com.gingkoo.gf4j2.framework.entity.base.WithDataTracker;
import com.gingkoo.gf4j2.framework.entity.base.WithDataVersion;
import com.gingkoo.gf4j2.framework.entity.base.WithSingleKey;

@Entity
@Table(name = "EAST_WGT_CFG")
public class EastWgtCfg extends RootEntity implements WithDataId, WithDataHolder, WithDataVersion, WithDataDate, WithSingleKey, WithDataTracker {
    @Id
    @Column(name = "DATA_ID")
    private String dataId;

    @Column(name = "DATA_DATE")
    private String dataDate;

    @Column(name = "CORP_ID")
    private String corpId;

    @Column(name = "ORG_ID")
    private String orgId;

    @Column(name = "GROUP_ID")
    private String groupId;

    @Column(name = "INQ_ORG_ID")
    private String inqOrgId;

    @Column(name = "INQ_GROUP_ID")
    private String inqGroupId;

    @Column(name = "FUNCID")
    private String funcid;

    @Column(name = "FUNCNAMELIST")
    private String funcnamelist;

    @Column(name = "DEPART")
    private String depart;

    @Column(name = "USERNAMELIST")
    private String usernamelist;

    @Column(name = "FIELDNAME")
    private String fieldname;

    @Column(name = "FIELDNAMEDESC")
    private String fieldnamedesc;

    @Column(name = "TYPE")
    private String type;

    @Column(name = "BUTTONID")
    private String buttonid;

    @Column(name = "BUTTONNAME")
    private String buttonname;

    @Column(name = "BUTTONTYPE")
    private String buttontype;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "CHECK_FLAG")
    private String checkFlag;

    @Column(name = "CHECK_DESC")
    private String checkDesc;

    @Column(name = "CHECK_ERR_TYPE")
    private String checkErrType;

    @Column(name = "NEXT_ACTION")
    private String nextAction;

    @Column(name = "DATA_STATUS")
    private String dataStatus;

    @Column(name = "DATA_FLAG")
    private String dataFlag;

    @Column(name = "DATA_SOURCE")
    private String dataSource;

    @Column(name = "DATA_VERSION")
    private Integer dataVersion;

    @Column(name = "DATA_REJ_DESC")
    private String dataRejDesc;

    @Column(name = "DATA_DEL_DESC")
    private String dataDelDesc;

    @Column(name = "DATA_CRT_USER")
    private String dataCrtUser;

    @Column(name = "DATA_CRT_DATE")
    private String dataCrtDate;

    @Column(name = "DATA_CRT_TIME")
    private String dataCrtTime;

    @Column(name = "DATA_CHG_USER")
    private String dataChgUser;

    @Column(name = "DATA_CHG_DATE")
    private String dataChgDate;

    @Column(name = "DATA_CHG_TIME")
    private String dataChgTime;

    @Column(name = "DATA_APV_USER")
    private String dataApvUser;

    @Column(name = "DATA_APV_DATE")
    private String dataApvDate;

    @Column(name = "DATA_APV_TIME")
    private String dataApvTime;

    @Column(name = "RSV1")
    private String rsv1;

    @Column(name = "RSV2")
    private String rsv2;

    @Column(name = "RSV3")
    private String rsv3;

    @Column(name = "RSV4")
    private String rsv4;

    @Column(name = "RSV5")
    private String rsv5;

    @Column(name = "FIELDPART")
    private String fieldpart;

    @Column(name = "BUTTONPART")
    private String buttonpart;

    @Column(name = "FIELDPARTNAMELIST")
    private String fieldpartnamelist;

    @Column(name = "BUTTONPARTNAMELIST")
    private String buttonpartnamelist;

    private static final long serialVersionUID = 1L;

    @Override
    public String getDataId() {
        return dataId;
    }

    @Override
    public void setDataId(String dataId) {
        this.dataId = dataId == null ? null : dataId.trim();
    }

    @Override
    public String getDataDate() {
        return dataDate;
    }

    @Override
    public void setDataDate(String dataDate) {
        this.dataDate = dataDate == null ? null : dataDate.trim();
    }

    @Override
    public String getCorpId() {
        return corpId;
    }

    @Override
    public void setCorpId(String corpId) {
        this.corpId = corpId == null ? null : corpId.trim();
    }

    @Override
    public String getOrgId() {
        return orgId;
    }

    @Override
    public void setOrgId(String orgId) {
        this.orgId = orgId == null ? null : orgId.trim();
    }

    @Override
    public String getGroupId() {
        return groupId;
    }

    @Override
    public void setGroupId(String groupId) {
        this.groupId = groupId == null ? null : groupId.trim();
    }

    public String getInqOrgId() {
        return inqOrgId;
    }

    public void setInqOrgId(String inqOrgId) {
        this.inqOrgId = inqOrgId == null ? null : inqOrgId.trim();
    }

    public String getInqGroupId() {
        return inqGroupId;
    }

    public void setInqGroupId(String inqGroupId) {
        this.inqGroupId = inqGroupId == null ? null : inqGroupId.trim();
    }

    public String getFuncid() {
        return funcid;
    }

    public void setFuncid(String funcid) {
        this.funcid = funcid == null ? null : funcid.trim();
    }

    public String getFuncnamelist() {
        return funcnamelist;
    }

    public void setFuncnamelist(String funcnamelist) {
        this.funcnamelist = funcnamelist == null ? null : funcnamelist.trim();
    }

    public String getDepart() {
        return depart;
    }

    public void setDepart(String depart) {
        this.depart = depart == null ? null : depart.trim();
    }

    public String getUsernamelist() {
        return usernamelist;
    }

    public void setUsernamelist(String usernamelist) {
        this.usernamelist = usernamelist == null ? null : usernamelist.trim();
    }

    public String getFieldname() {
        return fieldname;
    }

    public void setFieldname(String fieldname) {
        this.fieldname = fieldname == null ? null : fieldname.trim();
    }

    public String getFieldnamedesc() {
        return fieldnamedesc;
    }

    public void setFieldnamedesc(String fieldnamedesc) {
        this.fieldnamedesc = fieldnamedesc == null ? null : fieldnamedesc.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getButtonid() {
        return buttonid;
    }

    public void setButtonid(String buttonid) {
        this.buttonid = buttonid == null ? null : buttonid.trim();
    }

    public String getButtonname() {
        return buttonname;
    }

    public void setButtonname(String buttonname) {
        this.buttonname = buttonname == null ? null : buttonname.trim();
    }

    public String getButtontype() {
        return buttontype;
    }

    public void setButtontype(String buttontype) {
        this.buttontype = buttontype == null ? null : buttontype.trim();
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks == null ? null : remarks.trim();
    }

    public String getCheckFlag() {
        return checkFlag;
    }

    public void setCheckFlag(String checkFlag) {
        this.checkFlag = checkFlag == null ? null : checkFlag.trim();
    }

    public String getCheckDesc() {
        return checkDesc;
    }

    public void setCheckDesc(String checkDesc) {
        this.checkDesc = checkDesc == null ? null : checkDesc.trim();
    }

    public String getCheckErrType() {
        return checkErrType;
    }

    public void setCheckErrType(String checkErrType) {
        this.checkErrType = checkErrType == null ? null : checkErrType.trim();
    }

    public String getNextAction() {
        return nextAction;
    }

    public void setNextAction(String nextAction) {
        this.nextAction = nextAction == null ? null : nextAction.trim();
    }

    public String getDataStatus() {
        return dataStatus;
    }

    public void setDataStatus(String dataStatus) {
        this.dataStatus = dataStatus == null ? null : dataStatus.trim();
    }

    public String getDataFlag() {
        return dataFlag;
    }

    public void setDataFlag(String dataFlag) {
        this.dataFlag = dataFlag == null ? null : dataFlag.trim();
    }

    public String getDataSource() {
        return dataSource;
    }

    public void setDataSource(String dataSource) {
        this.dataSource = dataSource == null ? null : dataSource.trim();
    }

    @Override
    public Integer getDataVersion() {
        return dataVersion;
    }

    @Override
    public void setDataVersion(Integer dataVersion) {
        this.dataVersion = dataVersion;
    }

    public String getDataRejDesc() {
        return dataRejDesc;
    }

    public void setDataRejDesc(String dataRejDesc) {
        this.dataRejDesc = dataRejDesc == null ? null : dataRejDesc.trim();
    }

    public String getDataDelDesc() {
        return dataDelDesc;
    }

    public void setDataDelDesc(String dataDelDesc) {
        this.dataDelDesc = dataDelDesc == null ? null : dataDelDesc.trim();
    }

    @Override
    public String getDataCrtUser() {
        return dataCrtUser;
    }

    @Override
    public void setDataCrtUser(String dataCrtUser) {
        this.dataCrtUser = dataCrtUser == null ? null : dataCrtUser.trim();
    }

    @Override
    public String getDataCrtDate() {
        return dataCrtDate;
    }

    @Override
    public void setDataCrtDate(String dataCrtDate) {
        this.dataCrtDate = dataCrtDate == null ? null : dataCrtDate.trim();
    }

    @Override
    public String getDataCrtTime() {
        return dataCrtTime;
    }

    @Override
    public void setDataCrtTime(String dataCrtTime) {
        this.dataCrtTime = dataCrtTime == null ? null : dataCrtTime.trim();
    }

    @Override
    public String getDataChgUser() {
        return dataChgUser;
    }

    @Override
    public void setDataChgUser(String dataChgUser) {
        this.dataChgUser = dataChgUser == null ? null : dataChgUser.trim();
    }

    @Override
    public String getDataChgDate() {
        return dataChgDate;
    }

    @Override
    public void setDataChgDate(String dataChgDate) {
        this.dataChgDate = dataChgDate == null ? null : dataChgDate.trim();
    }

    @Override
    public String getDataChgTime() {
        return dataChgTime;
    }

    @Override
    public void setDataChgTime(String dataChgTime) {
        this.dataChgTime = dataChgTime == null ? null : dataChgTime.trim();
    }

    @Override
    public String getDataApvUser() {
        return dataApvUser;
    }

    @Override
    public void setDataApvUser(String dataApvUser) {
        this.dataApvUser = dataApvUser == null ? null : dataApvUser.trim();
    }

    @Override
    public String getDataApvDate() {
        return dataApvDate;
    }

    @Override
    public void setDataApvDate(String dataApvDate) {
        this.dataApvDate = dataApvDate == null ? null : dataApvDate.trim();
    }

    @Override
    public String getDataApvTime() {
        return dataApvTime;
    }

    @Override
    public void setDataApvTime(String dataApvTime) {
        this.dataApvTime = dataApvTime == null ? null : dataApvTime.trim();
    }

    public String getRsv1() {
        return rsv1;
    }

    public void setRsv1(String rsv1) {
        this.rsv1 = rsv1 == null ? null : rsv1.trim();
    }

    public String getRsv2() {
        return rsv2;
    }

    public void setRsv2(String rsv2) {
        this.rsv2 = rsv2 == null ? null : rsv2.trim();
    }

    public String getRsv3() {
        return rsv3;
    }

    public void setRsv3(String rsv3) {
        this.rsv3 = rsv3 == null ? null : rsv3.trim();
    }

    public String getRsv4() {
        return rsv4;
    }

    public void setRsv4(String rsv4) {
        this.rsv4 = rsv4 == null ? null : rsv4.trim();
    }

    public String getRsv5() {
        return rsv5;
    }

    public void setRsv5(String rsv5) {
        this.rsv5 = rsv5 == null ? null : rsv5.trim();
    }

    public String getFieldpart() {
        return fieldpart;
    }

    public void setFieldpart(String fieldpart) {
        this.fieldpart = fieldpart == null ? null : fieldpart.trim();
    }

    public String getButtonpart() {
        return buttonpart;
    }

    public void setButtonpart(String buttonpart) {
        this.buttonpart = buttonpart == null ? null : buttonpart.trim();
    }

    public String getFieldpartnamelist() {
        return fieldpartnamelist;
    }

    public void setFieldpartnamelist(String fieldpartnamelist) {
        this.fieldpartnamelist = fieldpartnamelist == null ? null : fieldpartnamelist.trim();
    }

    public String getButtonpartnamelist() {
        return buttonpartnamelist;
    }

    public void setButtonpartnamelist(String buttonpartnamelist) {
        this.buttonpartnamelist = buttonpartnamelist == null ? null : buttonpartnamelist.trim();
    }

    @Override
    public String getPrimaryKey() {
        return get(Columns.DATA_ID);
    }

    @Override
    public void setPrimaryKey(String key) {
        set(Columns.DATA_ID, key);
    }

    @Override
    public boolean contains(String column) {
        return Columns.parse(column) != null;
    }

    public String get(Columns column) {
        Object value;
        if (column == null) return null;
        switch (column) {
        case DATA_ID: {
            return getDataId();
        }
        case DATA_DATE: {
            return getDataDate();
        }
        case CORP_ID: {
            return getCorpId();
        }
        case ORG_ID: {
            return getOrgId();
        }
        case GROUP_ID: {
            return getGroupId();
        }
        case INQ_ORG_ID: {
            return getInqOrgId();
        }
        case INQ_GROUP_ID: {
            return getInqGroupId();
        }
        case FUNCID: {
            return getFuncid();
        }
        case FUNCNAMELIST: {
            return getFuncnamelist();
        }
        case DEPART: {
            return getDepart();
        }
        case USERNAMELIST: {
            return getUsernamelist();
        }
        case FIELDNAME: {
            return getFieldname();
        }
        case FIELDNAMEDESC: {
            return getFieldnamedesc();
        }
        case TYPE: {
            return getType();
        }
        case BUTTONID: {
            return getButtonid();
        }
        case BUTTONNAME: {
            return getButtonname();
        }
        case BUTTONTYPE: {
            return getButtontype();
        }
        case REMARKS: {
            return getRemarks();
        }
        case CHECK_FLAG: {
            return getCheckFlag();
        }
        case CHECK_DESC: {
            return getCheckDesc();
        }
        case CHECK_ERR_TYPE: {
            return getCheckErrType();
        }
        case NEXT_ACTION: {
            return getNextAction();
        }
        case DATA_STATUS: {
            return getDataStatus();
        }
        case DATA_FLAG: {
            return getDataFlag();
        }
        case DATA_SOURCE: {
            return getDataSource();
        }
        case DATA_VERSION: {
            return (value = getDataVersion()) == null ? null : value.toString();
        }
        case DATA_REJ_DESC: {
            return getDataRejDesc();
        }
        case DATA_DEL_DESC: {
            return getDataDelDesc();
        }
        case DATA_CRT_USER: {
            return getDataCrtUser();
        }
        case DATA_CRT_DATE: {
            return getDataCrtDate();
        }
        case DATA_CRT_TIME: {
            return getDataCrtTime();
        }
        case DATA_CHG_USER: {
            return getDataChgUser();
        }
        case DATA_CHG_DATE: {
            return getDataChgDate();
        }
        case DATA_CHG_TIME: {
            return getDataChgTime();
        }
        case DATA_APV_USER: {
            return getDataApvUser();
        }
        case DATA_APV_DATE: {
            return getDataApvDate();
        }
        case DATA_APV_TIME: {
            return getDataApvTime();
        }
        case RSV1: {
            return getRsv1();
        }
        case RSV2: {
            return getRsv2();
        }
        case RSV3: {
            return getRsv3();
        }
        case RSV4: {
            return getRsv4();
        }
        case RSV5: {
            return getRsv5();
        }
        case FIELDPART: {
            return getFieldpart();
        }
        case BUTTONPART: {
            return getButtonpart();
        }
        case FIELDPARTNAMELIST: {
            return getFieldpartnamelist();
        }
        case BUTTONPARTNAMELIST: {
            return getButtonpartnamelist();
        }
        default: {
            return null;
        }}
    }

    @Override
    public String get(String column) {
        return get(Columns.parse(column));
    }

    @Override
    public Map<String, String> get(Map<String, String> map) {
        for (Columns c: Columns.values()) {
            map.put(c.toString(), get(c));
        }
        return map;
    }

    public EastWgtCfg set(Columns column, String value) {
        if (column == null) return this;
        switch (column) {
        case DATA_ID: {
            setDataId(value);
            break;
        }
        case DATA_DATE: {
            setDataDate(value);
            break;
        }
        case CORP_ID: {
            setCorpId(value);
            break;
        }
        case ORG_ID: {
            setOrgId(value);
            break;
        }
        case GROUP_ID: {
            setGroupId(value);
            break;
        }
        case INQ_ORG_ID: {
            setInqOrgId(value);
            break;
        }
        case INQ_GROUP_ID: {
            setInqGroupId(value);
            break;
        }
        case FUNCID: {
            setFuncid(value);
            break;
        }
        case FUNCNAMELIST: {
            setFuncnamelist(value);
            break;
        }
        case DEPART: {
            setDepart(value);
            break;
        }
        case USERNAMELIST: {
            setUsernamelist(value);
            break;
        }
        case FIELDNAME: {
            setFieldname(value);
            break;
        }
        case FIELDNAMEDESC: {
            setFieldnamedesc(value);
            break;
        }
        case TYPE: {
            setType(value);
            break;
        }
        case BUTTONID: {
            setButtonid(value);
            break;
        }
        case BUTTONNAME: {
            setButtonname(value);
            break;
        }
        case BUTTONTYPE: {
            setButtontype(value);
            break;
        }
        case REMARKS: {
            setRemarks(value);
            break;
        }
        case CHECK_FLAG: {
            setCheckFlag(value);
            break;
        }
        case CHECK_DESC: {
            setCheckDesc(value);
            break;
        }
        case CHECK_ERR_TYPE: {
            setCheckErrType(value);
            break;
        }
        case NEXT_ACTION: {
            setNextAction(value);
            break;
        }
        case DATA_STATUS: {
            setDataStatus(value);
            break;
        }
        case DATA_FLAG: {
            setDataFlag(value);
            break;
        }
        case DATA_SOURCE: {
            setDataSource(value);
            break;
        }
        case DATA_VERSION: {
            value = trimToNull(value);
            setDataVersion(value == null ? null : new Integer(value));
            break;
        }
        case DATA_REJ_DESC: {
            setDataRejDesc(value);
            break;
        }
        case DATA_DEL_DESC: {
            setDataDelDesc(value);
            break;
        }
        case DATA_CRT_USER: {
            setDataCrtUser(value);
            break;
        }
        case DATA_CRT_DATE: {
            setDataCrtDate(value);
            break;
        }
        case DATA_CRT_TIME: {
            setDataCrtTime(value);
            break;
        }
        case DATA_CHG_USER: {
            setDataChgUser(value);
            break;
        }
        case DATA_CHG_DATE: {
            setDataChgDate(value);
            break;
        }
        case DATA_CHG_TIME: {
            setDataChgTime(value);
            break;
        }
        case DATA_APV_USER: {
            setDataApvUser(value);
            break;
        }
        case DATA_APV_DATE: {
            setDataApvDate(value);
            break;
        }
        case DATA_APV_TIME: {
            setDataApvTime(value);
            break;
        }
        case RSV1: {
            setRsv1(value);
            break;
        }
        case RSV2: {
            setRsv2(value);
            break;
        }
        case RSV3: {
            setRsv3(value);
            break;
        }
        case RSV4: {
            setRsv4(value);
            break;
        }
        case RSV5: {
            setRsv5(value);
            break;
        }
        case FIELDPART: {
            setFieldpart(value);
            break;
        }
        case BUTTONPART: {
            setButtonpart(value);
            break;
        }
        case FIELDPARTNAMELIST: {
            setFieldpartnamelist(value);
            break;
        }
        case BUTTONPARTNAMELIST: {
            setButtonpartnamelist(value);
            break;
        }
        default: {
            break;
        }}
        return this;
    }

    @Override
    public EastWgtCfg set(String column, String value) {
        return set(Columns.parse(column), value);
    }

    @Override
    public EastWgtCfg set(Map<String, ?> map) {
        for (Columns c: Columns.values()) {
            if (map.containsKey(c.toString())) {
                Object v = map.get(c.toString());
                set(c, v == null ? null : v.toString());
            }
        }
        return this;
    }

    @Override
    public EastWgtCfg set(RootEntity table) {
        return set(table.get());
    }

    @Override
    public List<RootEntity.Columns> getColumns() {
        return Arrays.<RootEntity.Columns>asList(Columns.values());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EastWgtCfg that = (EastWgtCfg) o;
        return Objects.equals(getDataId(), that.getDataId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                getDataId()
        );
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this).omitNullValues()
                .add("dataId", getDataId())
                .add("dataDate", getDataDate())
                .add("corpId", getCorpId())
                .add("orgId", getOrgId())
                .add("groupId", getGroupId())
                .add("inqOrgId", getInqOrgId())
                .add("inqGroupId", getInqGroupId())
                .add("funcid", getFuncid())
                .add("funcnamelist", getFuncnamelist())
                .add("depart", getDepart())
                .add("usernamelist", getUsernamelist())
                .add("fieldname", getFieldname())
                .add("fieldnamedesc", getFieldnamedesc())
                .add("type", getType())
                .add("buttonid", getButtonid())
                .add("buttonname", getButtonname())
                .add("buttontype", getButtontype())
                .add("remarks", getRemarks())
                .add("checkFlag", getCheckFlag())
                .add("checkDesc", getCheckDesc())
                .add("checkErrType", getCheckErrType())
                .add("nextAction", getNextAction())
                .add("dataStatus", getDataStatus())
                .add("dataFlag", getDataFlag())
                .add("dataSource", getDataSource())
                .add("dataVersion", getDataVersion())
                .add("dataRejDesc", getDataRejDesc())
                .add("dataDelDesc", getDataDelDesc())
                .add("dataCrtUser", getDataCrtUser())
                .add("dataCrtDate", getDataCrtDate())
                .add("dataCrtTime", getDataCrtTime())
                .add("dataChgUser", getDataChgUser())
                .add("dataChgDate", getDataChgDate())
                .add("dataChgTime", getDataChgTime())
                .add("dataApvUser", getDataApvUser())
                .add("dataApvDate", getDataApvDate())
                .add("dataApvTime", getDataApvTime())
                .add("rsv1", getRsv1())
                .add("rsv2", getRsv2())
                .add("rsv3", getRsv3())
                .add("rsv4", getRsv4())
                .add("rsv5", getRsv5())
                .add("fieldpart", getFieldpart())
                .add("buttonpart", getButtonpart())
                .add("fieldpartnamelist", getFieldpartnamelist())
                .add("buttonpartnamelist", getButtonpartnamelist())
                .toString();
    }

    public static EastWgtCfg of(Map<String, ?> map) {
        EastWgtCfg entity = new EastWgtCfg();
        return entity.set(map);
    }

    public static EastWgtCfg of(RootEntity object) {
        EastWgtCfg entity = new EastWgtCfg();
        return entity.set(object);
    }

    public static EastWgtCfg of(String dataId) {
        EastWgtCfg entity = new EastWgtCfg();
        entity.setDataId(dataId);
        return entity;
    }

    public enum Columns implements RootEntity.Columns {
        DATA_ID("dataId", true),
        DATA_DATE("dataDate", false),
        CORP_ID("corpId", false),
        ORG_ID("orgId", false),
        GROUP_ID("groupId", false),
        INQ_ORG_ID("inqOrgId", false),
        INQ_GROUP_ID("inqGroupId", false),
        FUNCID("funcid", false),
        FUNCNAMELIST("funcnamelist", false),
        DEPART("depart", false),
        USERNAMELIST("usernamelist", false),
        FIELDNAME("fieldname", false),
        FIELDNAMEDESC("fieldnamedesc", false),
        TYPE("type", false),
        BUTTONID("buttonid", false),
        BUTTONNAME("buttonname", false),
        BUTTONTYPE("buttontype", false),
        REMARKS("remarks", false),
        CHECK_FLAG("checkFlag", false),
        CHECK_DESC("checkDesc", false),
        CHECK_ERR_TYPE("checkErrType", false),
        NEXT_ACTION("nextAction", false),
        DATA_STATUS("dataStatus", false),
        DATA_FLAG("dataFlag", false),
        DATA_SOURCE("dataSource", false),
        DATA_VERSION("dataVersion", false),
        DATA_REJ_DESC("dataRejDesc", false),
        DATA_DEL_DESC("dataDelDesc", false),
        DATA_CRT_USER("dataCrtUser", false),
        DATA_CRT_DATE("dataCrtDate", false),
        DATA_CRT_TIME("dataCrtTime", false),
        DATA_CHG_USER("dataChgUser", false),
        DATA_CHG_DATE("dataChgDate", false),
        DATA_CHG_TIME("dataChgTime", false),
        DATA_APV_USER("dataApvUser", false),
        DATA_APV_DATE("dataApvDate", false),
        DATA_APV_TIME("dataApvTime", false),
        RSV1("rsv1", false),
        RSV2("rsv2", false),
        RSV3("rsv3", false),
        RSV4("rsv4", false),
        RSV5("rsv5", false),
        FIELDPART("fieldpart", false),
        BUTTONPART("buttonpart", false),
        FIELDPARTNAMELIST("fieldpartnamelist", false),
        BUTTONPARTNAMELIST("buttonpartnamelist", false);

        private final String property;

        private final boolean isKey;

        Columns(String property, boolean isKey) {
            this.property = property;
            this.isKey = isKey;
        }

        @Override
        public String getProperty() {
            return property;
        }

        @Override
        public boolean isKey() {
            return isKey;
        }

        public static Columns parse(String column) {
            return RootEntity.parse(Columns.class, column);
        }
    }
}
