package com.gingkoo.gf4j2.framework.config.database;

import static com.gingkoo.gf4j2.framework.util.IteratorHelper.nullToEmpty;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.config.Config;
import com.gingkoo.gf4j2.framework.config.database.DatabaseProcedure.Parameter;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

@Component
public class DatabaseProcedureHelper {

    public static final int INDEX_COLUMN_NAME = 4;
    public static final int INDEX_COLUMN_TYPE = 5;
    public static final int INDEX_DATA_TYPE = 6;
    public static final int INDEX_ORDINAL_POSITION = 18;

    private final Log logger = LogFactory.getLogger(getClass());

    @Autowired
    private Config config;

    private Map<String, DatabaseProcedure> cache = new HashMap<String, DatabaseProcedure>();

    public <T> Map<String, T> callProcedure(Connection connection, String name)
            throws SQLException {
        return callProcedure(connection, name, null);
    }

    public <T> Map<String, T> callProcedure(Connection connection,
                                            String name, Map<String, ?> parameters)
            throws SQLException {
        DatabaseProcedure procedure = getProcedure(connection, name);
        return callProcedure(connection, procedure, parameters);
    }

    public <T> Map<String, T> callProcedure(Connection connection,
                                            DatabaseProcedure procedure)
            throws SQLException {
        return callProcedure(connection, procedure, null);
    }

    public <T> Map<String, T> callProcedure(Connection connection,
                                            DatabaseProcedure procedure, Map<String, ?> parameters)
            throws SQLException {

        String sql = getSql(procedure.getName(), procedure.getParameters().size());
        logger.info("-- SQL = [{"+sql+"}]");

        try (CallableStatement statement = connection.prepareCall(sql)) {

            for (Entry<String, ?> entry : nullToEmpty(parameters.entrySet())) {
                String name = entry.getKey();
                Parameter parameter = procedure.getParameter(name);
                if (parameter != null && parameter.isIn()) {
                    statement.setObject(parameter.getPosition(), entry.getValue(), parameter.getDataType());
                    logger.info("-- Set parameter [{"+parameter.getPosition()+"}] to [{"+parameter.getDataType()+"}][{"+entry.getValue()+"}]");
                }
            }

            Collection<Parameter> out = procedure.getOut();
            for (Parameter parameter : out) {
                statement.registerOutParameter(parameter.getPosition(), parameter.getDataType());
                logger.info("-- Register out parameter [{"+parameter.getPosition()+"}] as [{"+parameter.getDataType()+"}]");
            }

            statement.execute();

            Map<String, T> results = new LinkedHashMap<>();
            for (Parameter parameter : out) {
                @SuppressWarnings("unchecked")
                T value = (T) statement.getObject(parameter.getPosition());
                results.put(parameter.getName(), value);
            }

            return results;
        }
    }

    public String getSql(DatabaseProcedure procedure) {
        String sql = procedure.getSql();

        if (sql == null) {
            StringBuilder sb = new StringBuilder();
            sb.append("{CALL ").append(procedure.getName()).append("(");
            boolean first = true;
            for (String parameter : procedure.getParameters().keySet()) {
                if (first) {
                    first = false;
                } else {
                    sb.append(",");
                }
                sb.append(":").append(parameter);
            }
            sb.append(")}");
            sql = sb.toString();
            procedure.setSql(sql);
        }

        return sql;
    }

    public String getSql(String name, int count) {
        StringBuilder sb = new StringBuilder();
        sb.append("{CALL ").append(name).append("(");
        for (int i = 0; i < count; i++) {
            if (i > 0) {
                sb.append(",");
            }
            sb.append("?");
        }
        sb.append(")}");
        return sb.toString();
    }

    public DatabaseProcedure getProcedure(final Connection conn, String name)
            throws SQLException {
        if (config.isDebug()) {
            return analyzeProcedure(conn, name);
        }

        DatabaseProcedure result = cache.get(name);
        if (result == null) {
            try {
                result = analyzeProcedure(conn, name);
            } catch (SQLException e) {
                throw (SQLException) e.getCause();
            }
        }
        return result;
    }

    private DatabaseProcedure analyzeProcedure(Connection connection, String name)
            throws SQLException {
        DatabaseProcedure procedure = new DatabaseProcedure();
        procedure.setName(name);

        DatabaseMetaData metaData = connection.getMetaData();
        ResultSet resultSet = metaData.getProcedureColumns(
                connection.getCatalog(), null, name, null);

        List<Parameter> parameters = new ArrayList<>();
        boolean zero = false;
        while (resultSet.next()) {
            Parameter parameter = new Parameter();

            parameter.setType(resultSet.getShort(INDEX_COLUMN_TYPE));
            if (!parameter.isInOrOut()) {
                continue;
            }

            int position = resultSet.getInt(INDEX_ORDINAL_POSITION);
            if (position == 0) {
                if (zero) {
                    continue;
                }
                zero = true;
            }
            parameter.setPosition(position);

            parameter.setName(resultSet.getString(INDEX_COLUMN_NAME));
            parameter.setDataType(resultSet.getInt(INDEX_DATA_TYPE));

            boolean find = false;
            for (Parameter p : parameters) {
                if (p.getName().equals(parameter.getName())) {
                    find = true;
                    break;
                }
            }
            if (find) {
                continue;
            }
            parameters.add(parameter);
        }

        Collections.sort(parameters, new Comparator<Parameter>() {
            @Override
            public int compare(Parameter o1, Parameter o2) {
                return o1.getPosition() - o2.getPosition();
            }
        });

        procedure.setParameters(parameters);

        return procedure;
    }
}
