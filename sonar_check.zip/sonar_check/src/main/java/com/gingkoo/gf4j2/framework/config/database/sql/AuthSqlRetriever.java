package com.gingkoo.gf4j2.framework.config.database.sql;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.dao.impl.AuthDAO;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.EastAuthCfg;
import com.gingkoo.gf4j2.framework.entity.GpBmBranch;
import com.gingkoo.gf4j2.framework.entity.GpBmPrivGrant;
import com.gingkoo.gf4j2.framework.entity.bean.DataPrivilegeTree;
import com.gingkoo.gf4j2.framework.entity.bean.DataPrivilegeVO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;

/**
 *
 * <截取权限控制串> <拼装权限控制>
 *
 * @author junjunxia
 * @version [版本号, 2016-10-17]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
@Component
public class AuthSqlRetriever extends SqlRetrieverImpl {

    private static final Log logger = LogFactory
            .getLogger(AuthSqlRetriever.class);

    @Autowired
    private AuthDAO authDao;
    @Autowired
    private ROOTDAO rootDao;

    /**
     * 根据sqlId和 参数进行组装。
     * @param sqlId
     * @param parameters
     * @return
     */
    @Override
    public String getSql(String sqlId, Map<String, ?> parameters) {
        String sql = super.getSql(sqlId, parameters);

        logger.info(sqlId);

        if (sql == null) {
            return null;
        }

        return this.getSqlBySqlString(sql,parameters);
    }

    /**
     * 根据sql语句和参数进行组装
     * @param sql
     * @param parameters
     * @return
     */
    public String getSqlBySqlString(String sql, Map<String, ?> parameters) {
        logger.info(sql);
        if (sql == null) {
            return null;
        }
        try {
            if(!("".equals(GlobalInfo.getCurrentInstance().getGroupId()) || GlobalInfo.getCurrentInstance().getGroupId() == null)){
                Map<String,String> map = (Map<String, String>) parameters;
                map.put("v_depart", GlobalInfo.getCurrentInstance().getGroupId());
                map.put("v_user", GlobalInfo.getCurrentInstance().getTlrno());
                map.put("v_brno", GlobalInfo.getCurrentInstance().getBrno());
                map.put("v_corpid", GlobalInfo.getCurrentInstance().getCorpId());
            }

        } catch (CommonException e1) {
            logger.error(e1.getMessage());
        }
        /*
         * EAST 添加
         */
        if (sql.contains("@{EAST}")) {
            try {
                GlobalInfo globalInfo = GlobalInfo.getCurrentInstance();
                String funcid = globalInfo.getFuncId();
                String depart = globalInfo.getGroupId();

                String query = "from EastAuthCfg where funcid = ? and depart = ?";

                List<EastAuthCfg> list = (List<EastAuthCfg>)rootDao.getHibernateTemplate().find(query, funcid, depart);
                if(null != list && list.size() > 0){
                    sql = sql.replace("@{EAST}", list.get(0).getSqlString());
                }else{
                    sql = sql.replace("@{EAST}", "");
                }

            } catch (CommonException e) {
                sql = sql.replace("@{EAST}", "");
            }

        }
        if (sql.contains("@{_PRIV_COND")) {
            try {
                sql = givePrivilege(sql, parameters);
            } catch (CommonException e) {
                // TODO Auto-generated catch block
                logger.error(e.getMessage());
            }
        }
        return sql;
    }

    @SuppressWarnings({ "unchecked", "null" })
    public String givePrivilege(final String sql,
                                final Map<String, ?> parameters) throws CommonException {
        logger.info("=============================权限Begin=============================");
        GlobalInfo gi = GlobalInfo.getCurrentInstance();
        String sql_l = "";
        String upBrcode = gi.getBrno();
        String menuId = gi.funcId;
        int privCunt = 0;
        boolean isAllFlag = false;

        String orgId = gi.getBrno();
        String userId = gi.getTlrno();
        String groupId = gi.getGroupId();
        String sqlFromCommonQuery = sql;

        Map<String, String> tableMap = new HashMap<String, String>();
        Pattern p = Pattern.compile("\\@\\{_PRIV_COND");
        Matcher m = p.matcher(sqlFromCommonQuery);

        int num = 0;
        while (m.find()) {
            String tableName = "";
            num++;
            int start = m.start();
            String flag = sqlFromCommonQuery.charAt(start + 12) + "";
            if (":".equals(flag)) {
                tableName = sqlFromCommonQuery.substring(start + 13,
                        sqlFromCommonQuery.indexOf("}", start + 13));
            } else {
                tableName = "";
            }
            tableMap.put("tableName" + num, tableName);
        }
        Map<String, Object> dataMap = new HashMap<String, Object>();

        //查找GP_BM_CODE_SCHEMA和GP_BM_PRIV_F_DEFINE关联的权限方案
        List<Object> codeSchemaList = authDao.selectCodeSchemaMap(menuId);

        Map<String, String> codeSchemaMap = new HashMap<String, String>();
        if (codeSchemaList == null || codeSchemaList.size() == 0) {
            logger.info("当前菜单没有配置数据权限");
            for (int i = 1; i <= num; i++) {
                String tableNameTemp = tableMap.get("tableName" + i);
                if (StringUtils.isNotBlank(tableNameTemp)) {
                    sqlFromCommonQuery = sqlFromCommonQuery.replace(
                            "@{_PRIV_COND:" + tableNameTemp + "}", "");
                } else {
                    sqlFromCommonQuery = sqlFromCommonQuery.replace(
                            "@{_PRIV_COND}", "");
                }
            }
            logger.info("=============================权限End=============================");
            return sqlFromCommonQuery;
        }

        for (int i = 0; i < codeSchemaList.size(); i++) {
            Object[] codeList = (Object[]) codeSchemaList.get(i);
            codeSchemaMap.put("CODESCHEMA",codeList[0] ==null?"":codeList[0].toString());
            codeSchemaMap.put("SCHEMATYPE",codeList[2] ==null?"":codeList[2].toString());
            if(codeList[3] != null) {
            	 String sqlString = codeList[3].toString();
            	 sqlString = sqlString.replace("&", "||");
            	 codeSchemaMap.put("sqlString",sqlString);
            }
           
          //  codeSchemaMap.put("sqlString",codeList[3] ==null?"":codeList[3].toString());
            
          //  and ({TABLE}ORG_ID=:\"v_brno\" or {TABLE}ORG_ID in ({CHILDS})) and {TABLE}GROUP_ID like '%' :\"v_depart\" '%' and {TABLE}CORP_ID=:\"v_corpid\"
        }
        String codeSchema = codeSchemaMap.get("CODESCHEMA");
        String schemaType = codeSchemaMap.get("SCHEMATYPE");
        if ("2".equals(schemaType)) {
            String sqlString = codeSchemaMap.get("sqlString");// 当选简单模式的时候，sqlString为必输项
            if (sqlString.contains("{ORG_ID}")) {
                sqlString = sqlString.replace("{ORG_ID}", "'" + upBrcode + "'");
            }

            if (sqlString.contains("{CHILDS}")) {
                List<Object> selectBctlList = authDao.selectBctlData(upBrcode);
                if (selectBctlList.size() <= 0) {
                    logger.info(upBrcode + "没有下属机构数据");
                    sqlString = sqlString.replace("{CHILDS}", "null");
                }
                String orgIds = "";
                for (int i = 0; i < selectBctlList.size(); i++) {
                    Object[] resList =  (Object[]) selectBctlList.get(i);
                    GpBmBranch bctl = new GpBmBranch();
                    bctl.setBrcode(resList[0] ==null?"":resList[0].toString());
                    bctl.setBlnUpBrcode(resList[1] ==null?"":resList[1].toString());
                    bctl.setBrname(resList[2] ==null?"":resList[2].toString());
                    if (i < selectBctlList.size() - 1) {
                        orgIds = orgIds.concat("'").concat(bctl.getBrcode())
                                .concat("',");
                    } else {
                        orgIds = orgIds.concat("'").concat(bctl.getBrcode())
                                .concat("'");
                    }
                }
                sqlString = sqlString.replace("{CHILDS}", orgIds);
            }

            for (int i = 1; i <= num; i++) {
                String sqlString1 = sqlString;// 每次重新取一下sqlString,每次循环会替换掉
                String tableNameTemp = tableMap.get("tableName" + i);
                if (StringUtils.isNotBlank(tableNameTemp)) {
                    String tableName1 = tableNameTemp + ".";
                    sqlString1 = sqlString1.replaceAll("\\{TABLE\\}",
                            tableName1);
                    sqlFromCommonQuery = sqlFromCommonQuery.replaceFirst(
                            "\\@\\{_PRIV_COND:" + tableNameTemp + "\\}",
                            sqlString1);
                } else {
                    sqlString1 = sqlString1.replaceAll("\\{TABLE\\}", "");
                    sqlFromCommonQuery = sqlFromCommonQuery.replaceFirst(
                            "\\@\\{_PRIV_COND\\}", sqlString1);
                }
            }
            logger.info("=============================权限End=============================");
            return sqlFromCommonQuery;
        }

        dataMap.put("userId", userId);
        String roleId = authDao.getRoleId(userId);
        String userDataId = authDao.getUserDataId(userId);
        dataMap.put("ENT_ID_U", userDataId);
        dataMap.put("ENT_ID_R", roleId);
        dataMap.put("ENT_ID_D", groupId);
        dataMap.put("ORG_ID", orgId);
        dataMap.put("CODE_SCHEMA", codeSchema);
        //查询GpBmPrivGrant表的dataOrgId
        List<Object> selectDataorgidList = authDao.selectDataorgidList(dataMap);
        if (selectDataorgidList.size() <= 0) {
            logger.info("GP_BM_PRIV_GRANT表为空");
            for (int i = 1; i <= num; i++) {
                String tableNameTemp = tableMap.get("tableName" + i);
                if (StringUtils.isNotBlank(tableNameTemp)) {
                    sqlFromCommonQuery = sqlFromCommonQuery.replace(
                            "@{_PRIV_COND:" + tableNameTemp + "}", "and 0=1");
                } else {
                    sqlFromCommonQuery = sqlFromCommonQuery.replace(
                            "@{_PRIV_COND}", "and 0=1");
                }
            }
            logger.info("=============================权限End=============================");
            return sqlFromCommonQuery;
        }
        int allsize = selectDataorgidList.size();
        for (int nnn = 0; nnn < allsize; nnn++) {
            List<DataPrivilegeVO> selectDataPrivilegeVOAllList1 = new ArrayList<DataPrivilegeVO>();
            String data_org_id = (String) selectDataorgidList.get(nnn);
            dataMap.put("DATA_ORG_ID", data_org_id);
            //查询GpBmPrivGrant表的数据
            List<Object> selectgpBmPrivGrantList = authDao
                    .selectgpBmPrivGrantList(dataMap);
            if (selectgpBmPrivGrantList.size() == 0) {
                continue;
            } else {
                GpBmPrivGrant gpBmPrivGrantTmp = new GpBmPrivGrant();
                for (int i = 0; i < selectgpBmPrivGrantList.size(); i++) {
                    Object[] fieldMapList = (Object[]) selectgpBmPrivGrantList.get(i);
                    //System.out.println(fieldMapList[0].toString());
                    gpBmPrivGrantTmp.setOrgId(fieldMapList[0]== null?"":fieldMapList[0].toString());
                    gpBmPrivGrantTmp.setCodeSchema(fieldMapList[1]== null?"":fieldMapList[1].toString());
                    gpBmPrivGrantTmp.setCodeItem(fieldMapList[2]== null?"":fieldMapList[2].toString());
                    gpBmPrivGrantTmp.setCodeValue(fieldMapList[3]== null?"":fieldMapList[3].toString());
                    gpBmPrivGrantTmp.setDataOrgId(fieldMapList[4]== null?"":fieldMapList[4].toString());
                    gpBmPrivGrantTmp.setEntType(fieldMapList[5]== null?"":fieldMapList[5].toString());
                    gpBmPrivGrantTmp.setEntId(fieldMapList[6]== null?"":fieldMapList[6].toString());
                    gpBmPrivGrantTmp.setPrivAllow(fieldMapList[7]== null?"":fieldMapList[7].toString());
                    gpBmPrivGrantTmp.setGrantFlag(fieldMapList[8]== null?"":fieldMapList[8].toString());
                    isAllFlag = false;
//				if ("all".equals(gpBmPrivGrantTmp.getCodeValue())) {
//					isAllFlag = true;
//					break;
//				} else {
//					isAllFlag = false;
//				}
                }

                List<DataPrivilegeVO> selectDataPrivilegeVOAllList = new ArrayList<DataPrivilegeVO>();
                for (int ii = 0; ii < selectgpBmPrivGrantList.size(); ii++) {
                    Object[] fieldMapList = (Object[]) selectgpBmPrivGrantList.get(ii);
                    gpBmPrivGrantTmp.setOrgId(fieldMapList[0]== null?"":fieldMapList[0].toString());
                    gpBmPrivGrantTmp.setCodeSchema(fieldMapList[1]== null?"":fieldMapList[1].toString());
                    gpBmPrivGrantTmp.setCodeItem(fieldMapList[2]== null?"":fieldMapList[2].toString());
                    gpBmPrivGrantTmp.setCodeValue(fieldMapList[3]== null?"":fieldMapList[3].toString());
                    gpBmPrivGrantTmp.setDataOrgId(fieldMapList[4]== null?"":fieldMapList[4].toString());
                    gpBmPrivGrantTmp.setEntType(fieldMapList[5]== null?"":fieldMapList[5].toString());
                    gpBmPrivGrantTmp.setEntId(fieldMapList[6]== null?"":fieldMapList[6].toString());
                    gpBmPrivGrantTmp.setPrivAllow(fieldMapList[7]== null?"":fieldMapList[7].toString());
                    gpBmPrivGrantTmp.setGrantFlag(fieldMapList[8]== null?"":fieldMapList[8].toString());
                    dataMap.put("CODE_VALUE", gpBmPrivGrantTmp.getCodeValue());
                    dataMap.put("CODE_SCHEMA", gpBmPrivGrantTmp.getCodeSchema());
                    //获取权限树
                    List<Object> selectDataPrivilegeVOList = authDao.selectDataPrivilegeVOData(dataMap);

                    if (selectDataPrivilegeVOList.size() <= 0) {
                        logger.info("DataPrivilegeVO为空");
                        int start = 0;
                        while (m.find()) {
                            String tableName = "";
                            start = m.start();

                        }
                        return sql.substring(0,start);
                    }


                    for (int iiii = 0; iiii < selectDataPrivilegeVOList.size(); iiii++) {
                        Object[] privilegeVOList =  (Object[]) selectDataPrivilegeVOList.get(iiii);
                        DataPrivilegeVO dataPrivilegeVO = new DataPrivilegeVO();
                        dataPrivilegeVO.setOrgId(privilegeVOList[0]==null?"":privilegeVOList[0].toString());
                        dataPrivilegeVO.setCodeSchema(privilegeVOList[1]==null?"":privilegeVOList[1].toString());
                        dataPrivilegeVO.setCodeItem(privilegeVOList[2]==null?"":privilegeVOList[2].toString());
                        dataPrivilegeVO.setCodeValue(privilegeVOList[3]==null?"":privilegeVOList[3].toString());
                        dataPrivilegeVO.setpCodeValue(privilegeVOList[4]==null?"":privilegeVOList[4].toString());
                        dataPrivilegeVO.setFieldId(privilegeVOList[5]==null?"":privilegeVOList[5].toString());
                        dataPrivilegeVO.setDataOrgId(privilegeVOList[6]==null?"":privilegeVOList[6].toString());
                        dataPrivilegeVO.setGrantFlag(privilegeVOList[7]==null?"":privilegeVOList[7].toString());
                        if (!selectDataPrivilegeVOAllList.contains(dataPrivilegeVO)) {

                            if (!"all".equals(dataPrivilegeVO.getCodeValue())) {
                                selectDataPrivilegeVOAllList.add(dataPrivilegeVO);
                            }
                        }
                    }

                }
                List<DataPrivilegeVO> parentList = new ArrayList<DataPrivilegeVO>();
                List<DataPrivilegeVO> childList = new ArrayList<DataPrivilegeVO>();
                for (DataPrivilegeVO dataPrivilegeVO : selectDataPrivilegeVOAllList) {
                    if (StringUtils.isBlank(dataPrivilegeVO.getpCodeValue())) {
                        selectDataPrivilegeVOAllList1.add(dataPrivilegeVO);
                    }
                    if ("all".equals(dataPrivilegeVO.getpCodeValue()) && !"".equals(dataPrivilegeVO.getpCodeValue())) {
                        parentList.add(dataPrivilegeVO);
                    } else if(!"all".equals(dataPrivilegeVO.getpCodeValue()) && !"".equals(dataPrivilegeVO.getpCodeValue())){
                        childList.add(dataPrivilegeVO);
                    }
                }
                selectDataPrivilegeVOAllList1.addAll(parentList);
                selectDataPrivilegeVOAllList1.addAll(childList);

                DataPrivilegeTree dataPrivilegeTree = recursiveTree("all",
                        null, selectDataPrivilegeVOAllList1);
                String tableNames = "$tableName.";
                String privSql = "";
                String orgSql = "";
                if (isAllFlag) {
                    isAllFlag = false;
                    orgSql = getOrgSql(data_org_id, orgId, tableNames).replace(
                            " and ", "");
                } else {
                    privSql = generateTreeSql(dataPrivilegeTree, tableNames,orgId).substring(5);
                    //privSql = privSql.substring(5);
                    orgSql = getOrgSql(data_org_id, orgId, tableNames);
                }
                privSql = ("(") + orgSql + privSql + (")");
                if (privCunt == 0) {
                    sql_l = privSql;
                    privCunt++;
                } else {
                    sql_l = sql_l + " or " + privSql;
                }
            }
        }
        if (StringUtils.isNotBlank(sql_l)) {
            sql_l = "and (" + sql_l + ")";
        } else {
            isAllFlag = true;
        }
        if (isAllFlag) {
            for (int j = 1; j <= num; j++) {
                String tableNameTemp = tableMap.get("tableName" + j);
                if (StringUtils.isNotBlank(tableNameTemp)) {
                    sqlFromCommonQuery = sqlFromCommonQuery.replace(
                            "@{_PRIV_COND:" + tableNameTemp + "}", "");
                } else {
                    sqlFromCommonQuery = sqlFromCommonQuery.replace(
                            "@{_PRIV_COND}", "");
                }
            }
            logger.info("=============================权限End=============================");
            return sqlFromCommonQuery;
        }
        Pattern p1 = Pattern.compile("\\@\\{_PRIV_COND");
        Matcher m1 = p1.matcher(sqlFromCommonQuery);
        int num1 = 0;
        while (m1.find()) {
            num1++;
            String sqlStringTmp = "";
            String tableName = tableMap.get("tableName" + num1);
            if (StringUtils.isNotBlank(tableName)) {
                sqlStringTmp = sql_l.replace("$tableName.",
                        tableMap.get("tableName" + num1) + ".");
                sqlFromCommonQuery = sqlFromCommonQuery.replace("@{_PRIV_COND:"
                        + tableName + "}", sqlStringTmp);
            } else {
                sqlStringTmp = sql_l.replace("$tableName.", "");
                sqlFromCommonQuery = sqlFromCommonQuery.replace(
                        "@{_PRIV_COND}", sqlStringTmp);
            }

        }
        //System.out.println("PPPPPPPPPPPPPPPPPPPPPPPPPP: " + sql_l);
        logger.info("=============================权限End=============================");
        return sqlFromCommonQuery;
    }

    /**
     * 生成多叉树
     *
     * @param DataPrivilegeTree
     *            多叉树节点
     * @return
     */
    @SuppressWarnings("unchecked")
    public DataPrivilegeTree recursiveTree(String codeValue, String pCodeValue,
                                           List<DataPrivilegeVO> selectDataPrivilegeVOAllList) {

        DataPrivilegeTree node = new DataPrivilegeTree();
        DataPrivilegeVO dataPrivilegeVOTmp = new DataPrivilegeVO();
        // 根据codeValue获取节点对象
        for (int i = 0; i < selectDataPrivilegeVOAllList.size(); i++) {
            dataPrivilegeVOTmp = selectDataPrivilegeVOAllList.get(i);
            if (StringUtils.isBlank(pCodeValue)) {
                if (codeValue.equals(dataPrivilegeVOTmp.getCodeValue())) {
                    node.setCodeValue(dataPrivilegeVOTmp.getCodeValue());
                    node.setFieldId(dataPrivilegeVOTmp.getFieldId());
                    node.setpCodeValue(dataPrivilegeVOTmp.getpCodeValue());
                    selectDataPrivilegeVOAllList.remove(i);
                    if (StringUtils.isNotBlank(dataPrivilegeVOTmp
                            .getDataOrgId())) {
                        node.setDataOrgId(dataPrivilegeVOTmp.getDataOrgId());
                    }
                    break;
                }
            } else {
                if (codeValue.equals(dataPrivilegeVOTmp.getCodeValue())
                        && pCodeValue
                        .equals(dataPrivilegeVOTmp.getpCodeValue())) {
                    node.setCodeValue(dataPrivilegeVOTmp.getCodeValue());
                    node.setFieldId(dataPrivilegeVOTmp.getFieldId());
                    node.setpCodeValue(dataPrivilegeVOTmp.getpCodeValue());
                    if (StringUtils.isNotBlank(dataPrivilegeVOTmp
                            .getDataOrgId())) {
                        node.setDataOrgId(dataPrivilegeVOTmp.getDataOrgId());
                    }
                    selectDataPrivilegeVOAllList.remove(i);
                    break;
                }
            }
        }
        // 查询codeValue下的所有子节点
        List<DataPrivilegeTree> childTreeNodes = new ArrayList<DataPrivilegeTree>();
        // DataPrivilegeTree dataPrivilegeTree = new DataPrivilegeTree();
        // childTreeNodes v1_0 没有v1_1
        for (DataPrivilegeVO dataPrivilegeVO : selectDataPrivilegeVOAllList) {
            DataPrivilegeTree dataPrivilegeTree = new DataPrivilegeTree();
            if (codeValue.equals(dataPrivilegeVO.getpCodeValue())) {
                dataPrivilegeTree.setCodeValue(dataPrivilegeVO.getCodeValue());
                dataPrivilegeTree.setFieldId(dataPrivilegeVO.getFieldId());
                dataPrivilegeTree
                        .setpCodeValue(dataPrivilegeVO.getpCodeValue());
                if (StringUtils.isNotBlank(dataPrivilegeVO.getDataOrgId())) {
                    dataPrivilegeTree.setDataOrgId(dataPrivilegeVO
                            .getDataOrgId());
                }
                childTreeNodes.add(dataPrivilegeTree);
            }
        }

        // 遍历子节点
        for (DataPrivilegeTree child : childTreeNodes) {
            DataPrivilegeTree n = recursiveTree(child.getCodeValue(),
                    child.getpCodeValue(), selectDataPrivilegeVOAllList); // 递归
            node.getNodes().add(n);
        }

        return node;
    }

    /**
     * 获取机构sql
     *
     * @return
     */
    public String getOrgSql(String dataOrgId, String orgId, String tableName) {
        String orgSql = null;
        if (StringUtils.isBlank(dataOrgId)) {
            orgSql = "";
        } else if ("THIS".equals(dataOrgId) || "CHILD".equals(dataOrgId)) {
            orgSql = getOrg(dataOrgId, orgId, tableName);
        } else {
            orgSql = getOrg(dataOrgId, dataOrgId, tableName);
        }
        return orgSql;
    }

    private String getOrg(String dataOrgId, String orgId, String tableName) {
        String sql = "";
        if ("CHILD".equals(dataOrgId)) {
            Map<String, Object> dataMap = new HashMap<String, Object>();
            dataMap.put("ORG_ID", orgId);
            List<Object> selectGpBmBranchList = authDao
                    .selectgpBmBranchData(dataMap);
            if (selectGpBmBranchList.size() <= 0) {
                logger.info(orgId + "没有下属机构数据");
                return sql = "ORG_ID ='" + orgId + "'";
            }
            String orgIds = "(";
            GpBmBranch gpBmBranch = new GpBmBranch();
            for (int i = 0; i < selectGpBmBranchList.size(); i++) {
                Object[] rtMap =  (Object[]) selectGpBmBranchList.get(i);
                if (rtMap != null) {
                    String brno = rtMap[0].toString();
                    String blnUpBrcode = rtMap[1].toString();
                    String brcode = rtMap[2].toString();
                    String brname = rtMap[3].toString();
                    gpBmBranch.setBrno(brno);
                    gpBmBranch.setBlnUpBrcode(blnUpBrcode);
                    gpBmBranch.setBrcode(brcode);
                    gpBmBranch.setBrname(brname);
                }
                if (i < selectGpBmBranchList.size() - 1) {
                    orgIds = orgIds.concat("'").concat(gpBmBranch.getBrno())
                            .concat("',");
                } else {
                    orgIds = orgIds.concat("'").concat(gpBmBranch.getBrno())
                            .concat("')");
                }
            }
            sql = sql.concat("ORG_ID").concat(" in").concat(orgIds);
        } else {
            sql = "ORG_ID ='" + orgId + "'";
        }
        // return tableName+sql;
        return tableName + sql + " and ";
    }

    /**
     * 递归遍历树形成sql
     *
     * @param DataPrivilegeTree
     *            多叉树节点
     * @return
     */
    private String generateTreeSql(DataPrivilegeTree dpt, String tableName,
                                   String orgId) {
        StringBuilder sb = new StringBuilder();
        if (dpt != null) {
            int size = dpt.getNodes().size();
            //System.out.println("size=============" + size);
            if (size <= 0) {
                // return sb.toString();
            } else {
                DataPrivilegeTree dpt1 = (DataPrivilegeTree) dpt.getNodes()
                        .get(0);
                sb.append(" and (");
                // int size1 = dpt1.getNodes().size();
                if (size == 0) {
                    sb.append(tableName + dpt1.getFieldId() + "='"
                            + dpt1.getCodeValue() + "'");
                } else if (size == 1) {
                    sb.append(
                            "(" + tableName + dpt1.getFieldId() + "='"
                                    + dpt1.getCodeValue() + "'")
                            .append(generateTreeSql(dpt1, tableName, orgId))
                            .append(")");
                } else {
                    sb.append(
                            "(" + tableName + dpt1.getFieldId() + "='"
                                    + dpt1.getCodeValue() + "'")
                            .append(generateTreeSql(dpt1, tableName, orgId))
                            .append(")");
                    for (int i = 1; i < size; i++) {
                        sb.append(
                                " or ("
                                        + tableName
                                        + ((DataPrivilegeTree) dpt.getNodes()
                                        .get(i)).getFieldId()
                                        + "='"
                                        + ((DataPrivilegeTree) dpt.getNodes()
                                        .get(i)).getCodeValue() + "'")
                                .append(generateTreeSql((DataPrivilegeTree) dpt
                                        .getNodes().get(i), tableName, orgId))
                                .append(")");
                    }
                }
                sb.append(")");
            }
        }
        return sb.toString();
    }

}