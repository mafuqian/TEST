/**
 *
 */
package com.gingkoo.gf4j2.framework.entity.result;

import java.util.HashMap;
import java.util.Map;

/**
 * 
* <p>Description: </p>  
* <p>Copyright: Copyright (c) 2019</p>  
* <p>Company: GINGKOO</p>
* @date 2019年6月5日
* @version 1.0
 */
public class UpdateReturnBean extends ResCdMsg {

	/**
	 * 
	 */
	private static final long serialVersionUID = -729387373822402941L;
	
	public Map<String,Object> paramMap;

	public UpdateReturnBean() {
		super();
		this.paramMap = new HashMap<String,Object>();
	}

	public UpdateReturnBean(String resCd, String resMsg) {
		super(resCd, resMsg);
		this.paramMap = new HashMap<String,Object>();
	}

	public Map<String,Object> getParamMap() {
		return this.paramMap;
	}

	public void setParamMap(Map<String,Object> paramMap) {
		this.paramMap = paramMap;
	}

	public void setParameter(String string, Object value) {

		this.getParamMap().put(string, value);
	}
	
	public void setParameter(String string, String value) {
		this.getParamMap().put(string, value);
	}

	public Object getParameter(String string) {

		return this.getParamMap().get(string);
	}
}
