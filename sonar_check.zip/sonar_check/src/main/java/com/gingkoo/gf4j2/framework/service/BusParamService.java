package com.gingkoo.gf4j2.framework.service;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.config.database.base.MyHibernateTemplate;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.gf4j2.framework.util.FileUploadUtil;
import com.gingkoo.gf4j2.framework.util.ParamMap;
import com.gingkoo.orm.entity.GpBmBusinessParam;

/**
 * 系统参数
 * 
 * @author yyh
 * @version [2.0, 2016-10-11]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
@Component
public class BusParamService {
	private static final Log logger = LogFactory.getLogger(BusParamService.class);
	@Autowired
	private ROOTDAO rootDao;
	
	public static Map<String, GpBmBusinessParam> busParamMap = null;
	public static ParamMap<String, Map<String, String>> busPmMap = null;
	private static String appRoot;
	private static String appHome;
	
	public String impStatus;
	
	
	/**
	 * 
	 * @Title: init
	 * @Description: TODO(初始化一份系统参数)
	 * @param 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	@PostConstruct
	private void init() {
		if(busParamMap == null || busPmMap == null){
			busParamMap = new HashMap<String, GpBmBusinessParam>();
			busPmMap = new ParamMap<String, Map<String, String>>();
			appHome = FileUploadUtil.getServerfile();
			List<GpBmBusinessParam> list = null;
			try {
				Iterator it = rootDao.queryByQL(
						"select tt FROM GpBmBusinessParam tt");
				while (it.hasNext()) {
					GpBmBusinessParam bean = (GpBmBusinessParam) it.next();
					busParamMap.put(
							bean.getParamGroupId() + "|" + bean.getParamId(),
							bean);
				}
			} catch (Exception e) {
				logger.error("SysParamService.init():"+e);
			}
		}
	}
	
	public static String getSysParamDef(String paramGroupId,String paramId,String defaultVal){
		String value = getSysParamValue(paramGroupId,paramId);
		if(value.trim().length() == 0){
			return defaultVal;
		}else{
			return value;
		}
	}
	
	public static String getSysParamValue(String paramGroupId, String paramId) {		
		GpBmBusinessParam bean = busParamMap.get(paramGroupId+"|"+paramId);
		if(bean != null && bean.getLoadType() != null && "I".equals(bean.getLoadType())){
			return bean.getParamValue();
		}	
		try {
			StringBuilder hql = new StringBuilder();
			hql.append("FROM GpBmBusinessParam tt where 1=1");
			if (paramGroupId != null && !"".equals(paramGroupId)) {
				hql.append(" and tt.paramGroupId = ? ");
			}
			if(paramId != null && !"".equals(paramId)){
				hql.append(" and tt.paramId = ? ");
			}
			List<GpBmBusinessParam> list =  ApplicationContextUtil.getBean(
					MyHibernateTemplate.class).find(hql.toString(), paramGroupId,paramId);
			Iterator<GpBmBusinessParam> iter = list.iterator();
			while (iter.hasNext()) {
				bean = (GpBmBusinessParam) iter.next();
				busParamMap.put(
						bean.getParamGroupId() + "|" + bean.getParamId(),
						bean);
			}
		} catch (Exception e) {
			logger.error("BusParamService.getSysParamValue():"+e);
		}
		
		if(bean != null){
			return bean.getParamValue();
		}else{
			return "";
		}
	}

	/**
	 * 获取已经配置的路径参数
	 * 
	 * @param inputParam
	 *            格式：PARAM_GROUP_ID|PARAM_NAME
	 * @return
	 * 
	 */
	public static String getSysParamDir(String path, String inputParam) {
		String rtnParam = "";
		try {
			GpBmBusinessParam bean = busParamMap.get(inputParam);
			if(bean != null){
				rtnParam = bean.getParamValue();
				rtnParam = rtnParam.replace("${APP_HOME}", path);
				rtnParam = rtnParam.replace("\\", File.separator);
				rtnParam = rtnParam.replace("/", File.separator);
			}

		} catch (Exception e) {
			logger.error("SysParamService.getSysParamDir():"+e);
		}

		return rtnParam;
	}
	
	/**
	 * 获取已经配置的路径参数
	 * @param inputParam 格式：paramgroupID|paramId
	 * @return
	 * 
	 */
	public static String getSysParamDir(String inputParam){
		String rtnParam ;
		try {
			rtnParam = busPmMap.get(inputParam).get("PARAM_VAL");
			rtnParam = rtnParam.replace("${APP_HOME}", appHome);
			rtnParam = rtnParam.replace("${APP_ROOT}", appRoot);
			rtnParam = rtnParam.replace("\\", File.separator);
			rtnParam = rtnParam.replace("/", File.separator);
			
		} catch (Exception e) {
			
			return "";
		}
		
		return rtnParam;
	}
	
	/**
	 * @throws CommonException 
	 * 
	 * @Title: setSysParam
	 * @Description: TODO(膝盖系统参数的方法，建议调完后调用refresh)
	 * @param @param sysParamMap
	 * @param @return 设定文件
	 * @return Boolean 返回类型
	 * @throws
	 */
	public Boolean setSysParam(Map<String, String> sysParamMap) throws CommonException {
        @SuppressWarnings("unchecked")
        ROOTDAO rootDao = (ROOTDAO) ApplicationContextUtil.getBean("ROOTDAO");
        List<GpBmBusinessParam> list = (List<GpBmBusinessParam>) rootDao.getHibernateTemplate().find("from GpBmBusinessParam where paramGroupId ='" +sysParamMap.get("paramgroup_id") +"' and paramId ='" +sysParamMap.get("param_id")+"'");
        if(list !=null && list.size() >0){
			GpBmBusinessParam bean  = list.get(0);
			bean.setParamValue(sysParamMap.get("param_val"));
			
			bean = rootDao.getHibernateTemplate().merge(bean);
			init();
			
			return true;
		}
		return false;
	}

	public String getImpStatus() {
		return impStatus;
	}

	public void setImpStatus(String impStatus) {
		this.impStatus = impStatus;
	}

	public ROOTDAO getRootDao() {
		return rootDao;
	}

	public void setRootDao(ROOTDAO rootDao) {
		this.rootDao = rootDao;
	}

	public Log getLogger() {
		return logger;
	}

}
