/*
 * 文 件 名:  SysParamsMaintAlterAction.java
 * 版    权:  Shanghai Gingkoo Co., Ltd. Copyright YYYY-YYYY,  All rights reserved
 * 描    述:  <描述>
 * 修 改 人:  Lisa
 * 修改时间:  2016年9月29日
 * 跟踪单号:  <跟踪单号>
 * 修改单号:  <修改单号>
 * 修改内容:  <修改内容>
 */
package com.gingkoo.gf4j2.framework.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.common.gpms.system.service.BusParamsMaintService;
import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.service.base.OPCaller;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.orm.entity.GpBmBusinessParam;

/**
 * <一句话功能简述>
 * <功能详细描述>
 * 
 * @author  Lizh
 * @version  [2.0, 2016年9月29日]
 * @see  [相关类/方法]
 * @since  [产品/模块版本]
 */
public class BusParamsMaintAlterAction extends WebAlterAction {
	private static final String DATASET_ID = "BusParamsMaint";

	@Override
	public UpdateReturnBean saveOrUpdate(
			MultiUpdateResultBean multiUpdateResultBean,
			HttpServletRequest request, HttpServletResponse respone)
			throws AppException {
		UpdateReturnBean updateReturnBean = new UpdateReturnBean();
		// 结果集对象
		UpdateResultBean updateResultBean = multiUpdateResultBean 
				.getUpdateResultBeanByID(DATASET_ID);
		ServiceContext oc = new ServiceContext();
		GpBmBusinessParam GpBmBusinessParam = new GpBmBusinessParam();
		while (updateResultBean.hasNext()) {
			Map<String, String> map = updateResultBean.next();
			String opr = map.get("opr");
			if ("add".equals(opr)) {
				oc.setAttribute(BusParamsMaintService.CMD, BusParamsMaintService.CMD_ADD);
			} else if ("mod".equals(opr)) {
				oc.setAttribute(BusParamsMaintService.CMD, BusParamsMaintService.CMD_MOD);
			} else if ("del".equals(opr)) {
				oc.setAttribute(BusParamsMaintService.CMD, BusParamsMaintService.CMD_DEL);
			}
			mapToObject(GpBmBusinessParam, map);
			oc.setAttribute(BusParamsMaintService.IN_PARAM, GpBmBusinessParam);
			
		}
		
		OPCaller.call(BusParamsMaintService.ID, oc);
		GlobalInfo.getCurrentInstance().appendBizLog("系统参数维护操作");
		return updateReturnBean;
	}
}