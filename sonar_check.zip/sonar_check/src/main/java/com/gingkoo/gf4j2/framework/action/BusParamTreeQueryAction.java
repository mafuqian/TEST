/*
 * 文 件 名:  SysParamTreeQueryAction.java
 * 版    权:  Shanghai Gingkoo Co., Ltd. Copyright YYYY-YYYY,  All rights reserved
 * 描    述:  <描述>
 * 修 改 人:  Wendy
 * 修改时间:  2016-11-23
 * 跟踪单号:  <跟踪单号>
 * 修改单号:  <修改单号>
 * 修改内容:  <修改内容>
 */
package com.gingkoo.gf4j2.framework.action;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.query.result.ResultMng;
import com.gingkoo.common.query.web.action.base.WebQueryAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.bean.TreeNode;
import com.gingkoo.gf4j2.framework.entity.result.Result;
import com.gingkoo.orm.entity.GpBmBusinessParam;

/**
 * <一句话功能简述>
 * <功能详细描述>
 * 
 * @author  Wendy
 * @version  [版本号, 2016-11-23]
 * @see  [相关类/方法]
 * @since  [产品/模块版本]
 */
public class BusParamTreeQueryAction extends WebQueryAction {

	@Override
	public Result call() throws AppException {
		List<TreeNode> list = new ArrayList<TreeNode>();

		StringBuffer hql = new StringBuffer();
		hql.append("select distinct(catalog) from GpBmBusinessParam po where 1=1");
		
		List<String> paramList = ROOTDAOUtils.getROOTDAO().queryByQL2List(
				hql.toString());
		GpBmBusinessParam bean = new GpBmBusinessParam();
		for (int i = 0; i < paramList.size(); i++) {
			String beanInfo =  paramList.get(i);
			if (beanInfo != null) {
//				String paramId = beanInfo[0].toString();
//				String paramName = beanInfo[1].toString();
//				String paramGroupId = beanInfo;
				bean.setCatalog(beanInfo);
//				bean.setParamName(paramName);
//				bean.setParamGroupId(paramGroupId);
				TreeNode n = this.convert(bean);
				if (StringUtils.isNotBlank(bean.getParamId())) {
					n.setHasChild(false);
				}
				list.add(n);
			}
		}


		ResultMng.fillResultByList(getCommonQueryBean(), getCommQueryServletRequest(), list, getResult());
		getResult().setContent(list);
		getResult().getPage().setTotalPage(1);
		getResult().init();
		return getResult();
	}

	private List<TreeNode> getNodes(TreeNode node) {
		List<TreeNode> t = new ArrayList<TreeNode>();
		t.add(node);
		for(TreeNode n : node.getChildren()) {
			t.addAll(getNodes(n));
		}
		return t;
	}

	private TreeNode convert(final GpBmBusinessParam obj) {
		TreeNode node = new TreeNode();
		node.setCanSelected(true);
//		node.setPid(StringUtils.strip(obj.getParamGroupId()));
//		node.setId(StringUtils.strip(obj.getParamId()));
		node.setId(StringUtils.strip(obj.getCatalog()));
//		if (StringUtils.equalsIgnoreCase(node.getId(), node.getPid())) {
//			node.setPid(null);
//		}
		node.setText(obj.getCatalog());
		node.setHasChild(false);
		return node;
	}

}
