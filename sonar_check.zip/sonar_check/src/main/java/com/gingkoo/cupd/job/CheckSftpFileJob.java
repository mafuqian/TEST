package com.gingkoo.cupd.job;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.cupd.service.ObjectInsertToTableService;

@Component("checkSftpFileJob")
public class CheckSftpFileJob {

    private static final Log logger = LogFactory.getLog(CheckSftpFileJob.class);

    @Autowired
    ObjectInsertToTableService objectInsertToTableService;
    
    JobResult jr = new JobResult();

    public Map<String, String> execute() {
        logger.info("===============++++++++++Exec CheckSftpFileJob begin++++++++++=============");
        jr.setErrCode("00");
        jr.setErrMsg("OK");
        try {
        	boolean falg = objectInsertToTableService.check();
        	if(falg) {
        		jr.setErrCode("00");
                jr.setErrMsg("OK");
                logger.info("未获取CUPD文件");
        	}else {
        		jr.setErrCode("E");
                jr.setErrMsg("已获取CUPD文件");
                logger.info("已获取CUPD文件");
        	}
        } catch (Exception arg6) {
            arg6.printStackTrace();
            logger.info("操作失败，错误信息：" + arg6.getMessage());
            jr.setErrCode("E");
            jr.setErrMsg("操作失败，错误信息：" + arg6.getMessage());
            return jr.getMap();
        }

        logger.info("===============++++++++++Exec CheckSftpFileJob end++++++++++=============");
        return jr.getMap();
    }

}
