package com.gingkoo.cupd.sftp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.common.email.excp.MailException;
import com.gingkoo.common.email.excp.MailMessageException;
import com.gingkoo.common.email.excp.MailServerException;
import com.gingkoo.common.message.entity.bean.GpBmGnoMsgBean;
import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.cupd.service.MailServices;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.GpBmSysStat;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;

public class SftpUtil {
	private static final Log logger = LogFactory.getLog(SftpUtil.class);
	public static final String SFTP_REQ_HOST = "host";
	public static final String SFTP_REQ_PORT = "port";
	public static final String SFTP_REQ_USERNAME = "username";
	public static final String SFTP_REQ_PRIVATE_KEY_PATH = "path";
	public static final String SFTP_REQ_PASSWORD = "password";
	public static final String SFTP_REQ_KEY_PASSWORD = "password";
	public static final int SFTP_DEFAULT_PORT = 22;
	public static final String SFTP_REQ_LOC = "location";
	public static final String SFTP_ERROR_FLAG = "error.ok";

	private Session session = null;
	private Channel channel = null;
	private ChannelSftp chSftp;
	
	@Autowired
	private MailServices mailServices;

	public ChannelSftp getChSftp() {
		return chSftp;
	}

	/**
	 * 
	 * <默认构造函数>
	 */
	public SftpUtil(Map<String, String> sftpDetails) {
		try {
			chSftp = getChannel(sftpDetails, 60000);
		} catch (JSchException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * <默认构造函数>
	 */
	public SftpUtil(String ip, String userName, String pwd, String port) {
		Map<String, String> sftpDetails = new HashMap<String, String>();
		// 设置主机ip，端口，用户名，密码
		sftpDetails.put(SftpUtil.SFTP_REQ_HOST, ip);
		sftpDetails.put(SftpUtil.SFTP_REQ_USERNAME, userName);
		sftpDetails.put(SftpUtil.SFTP_REQ_PASSWORD, pwd);
		sftpDetails.put(SftpUtil.SFTP_REQ_PORT, port);
		try {
			chSftp = getChannel(sftpDetails, 60000);
		} catch (JSchException e) {
			e.printStackTrace();
		}
	}

	public SftpUtil(String userName, String ip, String port, String privateKeyPath, String passphrase) throws Exception {
		Map<String, String> sftpDetails = new HashMap<String, String>();
		// 设置主机ip，端口，用户名，密码
		sftpDetails.put(SftpUtil.SFTP_REQ_HOST, ip);
		sftpDetails.put(SftpUtil.SFTP_REQ_USERNAME, userName);
		sftpDetails.put(SftpUtil.SFTP_REQ_PRIVATE_KEY_PATH, privateKeyPath);
		sftpDetails.put(SftpUtil.SFTP_REQ_KEY_PASSWORD, passphrase);
		sftpDetails.put(SftpUtil.SFTP_REQ_PORT, port);
		//sftpDetails.put(SftpUtil.SFTP_ERROR_FLAG, error);
		chSftp = getChannelByPrivateKey(sftpDetails, 60000);
	}

	/**
	 * 上传文件，支持文件夹上传 <一句话功能简述> <功能详细描述>
	 * 
	 * @param sPath
	 *            源文件目录
	 * @param dPath
	 *            目标文件夹
	 * @throws SftpException
	 * @see [类、类#方法、类#成员]
	 */
	public void put(String sPath, String dPath) throws SftpException {

		try {
			chSftp.cd(dPath);
		} catch (SftpException e) {
			chSftp.mkdir(dPath);
			chSftp.cd(dPath);
		}
		File file = new File(sPath);
		copyFile(file, chSftp.pwd());

	}

	/**
	 * 删除文件
	 * 
	 * @param directory
	 *            要删除文件所在目录
	 * @param deleteFile
	 *            要删除的文件
	 * @throws SftpException
	 * @throws Exception
	 */
	public void delete(String directory, String deleteFile) throws SftpException {
		chSftp.cd(directory);
		chSftp.rm(deleteFile);
	}

	public void delete(String directory) throws SftpException {
		// chSftp.cd(directory);
		// chSftp.rmdir(directory);
		chSftp.cd(directory);
		Vector vector = chSftp.ls(directory);
		for (Object obj : vector) {
			if (obj instanceof com.jcraft.jsch.ChannelSftp.LsEntry) {
				String fileName = ((com.jcraft.jsch.ChannelSftp.LsEntry) obj).getFilename();
				boolean SftpATTRS = ((com.jcraft.jsch.ChannelSftp.LsEntry) obj).getAttrs().isDir();

				if (".".equals(fileName) || "..".equals(fileName)) {
					continue;
				}
				if (SftpATTRS == true) {
					delete(directory + "/" + fileName);
					chSftp.rmdir(directory + "/" + fileName);

				} else {
					chSftp.rm(directory + "/" + fileName);

				}
			}
		}
		chSftp.rmdir(directory);
	}

	/**
	 * 关闭连接 <一句话功能简述> <功能详细描述>
	 * 
	 * @see [类、类#方法、类#成员]
	 */

	public void close() {
		chSftp.quit();
		try {
			closeChannel();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 拷贝文件递归方法 <一句话功能简述> <功能详细描述>
	 * 
	 * @param file
	 * @param pwd
	 * @see [类、类#方法、类#成员]
	 */
	private void copyFile(File file, String pwd) {

		if (file.isDirectory()) {
			File[] list = file.listFiles();
			try {
				try {
					String fileName = file.getName();
					chSftp.cd(pwd);
					logger.info("正在创建目录:" + chSftp.pwd() + "/" + fileName);
					chSftp.mkdir(fileName);
					logger.info("目录创建成功:" + chSftp.pwd() + "/" + fileName);
				} catch (Exception e) {
				}
				pwd = pwd + "/" + file.getName();
				try {
					chSftp.cd(file.getName());
				} catch (SftpException e) {
					e.printStackTrace();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			for (int i = 0; i < list.length; i++) {
				copyFile(list[i], pwd);
			}
		} else {
			try {
				chSftp.cd(pwd);
			} catch (SftpException e1) {
				e1.printStackTrace();
			}
			logger.info("正在复制文件:" + file.getAbsolutePath());
			InputStream instream = null;
			OutputStream outstream = null;
			try {
				outstream = chSftp.put(file.getName());
				instream = new FileInputStream(file);
				logger.info("11111111");
				byte b[] = new byte[1024];
				int n;
				try {
					while ((n = instream.read(b)) != -1) {
						outstream.write(b, 0, n);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			} catch (SftpException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					outstream.flush();
					outstream.close();
					instream.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}
	}

	/**
	 * 获取ChannelSftp <一句话功能简述> <功能详细描述>
	 * 
	 * @param sftpDetails
	 * @param timeout
	 * @return
	 * @throws JSchException
	 * @see [类、类#方法、类#成员]
	 */
	private ChannelSftp getChannel(Map<String, String> sftpDetails, int timeout) throws JSchException {

		String ftpHost = sftpDetails.get(SftpUtil.SFTP_REQ_HOST);
		String port = sftpDetails.get(SftpUtil.SFTP_REQ_PORT);
		String ftpUserName = sftpDetails.get(SftpUtil.SFTP_REQ_USERNAME);
		String ftpPassword = sftpDetails.get(SftpUtil.SFTP_REQ_PASSWORD);

		int ftpPort = SftpUtil.SFTP_DEFAULT_PORT;
		if (port != null && !port.equals("")) {
			ftpPort = Integer.valueOf(port);
		}

		JSch jsch = new JSch(); // 创建JSch对象
		session = jsch.getSession(ftpUserName, ftpHost, ftpPort); // 根据用户名，主机ip，端口获取一个Session对象
		logger.info("Session created.");
		if (ftpPassword != null) {
			session.setPassword(ftpPassword); // 设置密码
		}
		Properties config = new Properties();
		config.put("StrictHostKeyChecking", "no");
		session.setConfig(config); // 为Session对象设置properties
		session.setTimeout(timeout); // 设置timeout时间
		session.connect(); // 通过Session建立链接
		logger.info("Session connected.");

		logger.info("Opening Channel.");
		channel = session.openChannel("sftp"); // 打开SFTP通道
		channel.connect(); // 建立SFTP通道的连接
		logger.info("Connected successfully to ftpHost = " + ftpHost + ",as ftpUserName = " + ftpUserName
				+ ", returning: " + channel);
		return (ChannelSftp) channel;
	}

	private ChannelSftp getChannelByPrivateKey(Map<String, String> sftpDetails, int timeout) throws JSchException {

		String ftpHost = sftpDetails.get(SftpUtil.SFTP_REQ_HOST);
		String port = sftpDetails.get(SftpUtil.SFTP_REQ_PORT);
		String ftpUserName = sftpDetails.get(SftpUtil.SFTP_REQ_USERNAME);
		String ftpPrivatePath = sftpDetails.get(SftpUtil.SFTP_REQ_PRIVATE_KEY_PATH);
		String ftpPasswordKey = sftpDetails.get(SftpUtil.SFTP_REQ_KEY_PASSWORD);
		
		int ftpPort = SftpUtil.SFTP_DEFAULT_PORT;
		if (port != null && !port.equals("")) {
			ftpPort = Integer.valueOf(port);
		}

		JSch jsch = new JSch(); // 创建JSch对象
		if (ftpPrivatePath != null) {
			if (ftpPasswordKey != null) {
				jsch.addIdentity(ftpPrivatePath, ftpPasswordKey);// 设置私钥
			} else {
				jsch.addIdentity(ftpPrivatePath);// 设置私钥
			}
		}

		session = jsch.getSession(ftpUserName, ftpHost, ftpPort); // 根据用户名，主机ip，端口获取一个Session对象
		logger.info("Session created.");

		Properties config = new Properties();
		config.put("StrictHostKeyChecking", "no");
		session.setConfig(config); // 为Session对象设置properties
		session.setTimeout(timeout); // 设置timeout时间
		session.connect(); // 通过Session建立链接
		logger.info("Session connected.");

		logger.info("Opening Channel.");
		channel = session.openChannel("sftp"); // 打开SFTP通道
		channel.connect(); // 建立SFTP通道的连接
		logger.info("Connected successfully to ftpHost = " + ftpHost + ",as ftpUserName = " + ftpUserName
				+ ", returning: " + channel);
		return (ChannelSftp) channel;
	}

	/**
	 * 关闭 <一句话功能简述> <功能详细描述>
	 * 
	 * @throws Exception
	 * @see [类、类#方法、类#成员]
	 */

	private void closeChannel() throws Exception {
		if (channel != null) {
			channel.disconnect();
		}
		if (session != null) {
			session.disconnect();
		}
	}

	public String get8Date() throws CommonException {

		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String sqlDate = "from GpBmSysStat";
		List<GpBmSysStat> workDateList = rootdao.queryByQL2List(sqlDate);
		if (workDateList.size() > 0) {
			String workDate = ((GpBmSysStat) workDateList.get(0)).getWorkDate();
			return workDate;
		}

		Calendar calendar = Calendar.getInstance();
		return String.format("%1$4tY%1$2tm%1$td", calendar);

		// return "20190101";
	}

	public void listDicTory(File[] files) throws IllegalAccessException, IOException, CommonException {
		System.out.println("-->文件备份开始");
		logger.info("<-->文件备份开始");
		String locationpath = null;
		File locationFilePath = null;
		for (int i = 0; i < files.length; i++) {

			if (null == locationpath) {
				locationpath = files[i].getAbsolutePath().replace(files[i].getName(), "");
				locationpath = locationpath.substring(0, locationpath.length() - 1) + "-" + get8Date();
				locationFilePath = new File(locationpath);
				if (!locationFilePath.exists()) {
					System.out.println("-->文件备份目录:" + locationFilePath.getAbsolutePath());
					logger.info("-->文件备份目录:" + locationFilePath.getAbsolutePath());
					locationFilePath.mkdir();
				}
			}
			String filepath = locationpath + File.separator + files[i].getName();
			File file = new File(filepath);
			if (!file.exists()) {
				file.createNewFile();
			}
			System.out.println("-->文件备份名称:" + file.getAbsolutePath());
			logger.info("-->文件备份名称:" + file.getAbsolutePath());
			FileReader fr = new FileReader(files[i]);
			FileWriter fw = new FileWriter(file, false);// true:不覆盖原来内容,false:覆盖原来内容
			int c;
			while ((c = fr.read()) != -1) {
				fw.write((char) c);
				fw.flush();
			}
			fr.close();
			fw.close();

			System.out.println("-->文件备份结束");
			logger.info("-->文件备份结束");
		}

	}

	public void upload(String basePath, String directory, File[] files) throws SftpException, IOException {
		try {
			System.out.println("-->基础目录:" + basePath);
			logger.info("-->基础目录" + basePath);

			// sftp.cd(basePath);
			chSftp.cd(basePath);
			chSftp.cd(directory);
			System.out.println("-->存放目录:" + directory);
			logger.info("-->存放目录:" + directory);
		} catch (SftpException e) {
			System.out.println("-->存放目录:" + directory + "不存在");
			// e.printStackTrace();
			// 目录不存在，则创建文件夹
			String[] dirs = directory.split("/");
			String tempPath = basePath;
			for (String dir : dirs) {
				if (null == dir || "".equals(dir))
					continue;
				tempPath += "/" + dir;
				try {
					chSftp.cd(tempPath);
				} catch (SftpException ex) {
					chSftp.mkdir(tempPath);
					System.out.println("-->创建存放目录:" + tempPath);
					logger.info("-->创建存放目录:" + tempPath);

					chSftp.cd(tempPath);
				}
			}
		}
		System.out.println("-->文件传送开始");
		logger.info("-->文件传送开始");
		for (int i = 0; i < files.length; i++) {
			if (files[i].isFile() && files[i].getName().toUpperCase().endsWith(".TXT")) {
				System.out.println("-->文件名称:" + files[i].getName());
				logger.info("-->文件名称:" + files[i].getName());

				InputStream is = new FileInputStream(files[i]);

				// this.upload(".",get8Date(), files[i].getName(), is);
				chSftp.put(is, files[i].getName()); // 上传文件
				is.close();
			}
		}

		System.out.println("-->文件传送结束");
		logger.info("-->文件传送结束");

	}

	public Map<String, String> bacthUploadFile(String basePath, String localPath) {
		JobResult jr = new JobResult();
		try {
			File file = new File(localPath);
			File[] files = file.listFiles();

			this.upload(basePath, get8Date(), files);

			this.close();

			this.listDicTory(files);

			for (int i = 0; i < files.length; i++) {
				boolean flag = files[i].delete();
				System.out.println(flag);
			}
		} catch (Exception e) {
			e.printStackTrace();

			jr.setcCode("01");
			jr.setErrMsg("文件上传错误" + e.getMessage());
			return jr.getMap();
		}
		return jr.getMap();
	}

	/**
	 * 
	 * 列出目录下的文件
	 * 
	 * 
	 * 
	 * @param directory
	 * 
	 *            要列出的目录
	 * 
	 * @param sftp
	 * 
	 * @return
	 * 
	 * @throws SftpException
	 * 
	 */

	public Vector listFiles(String directory) throws SftpException {

		return chSftp.ls(directory);

	}

	/**
	 * 
	 * 如果目录不存在就创建目录
	 * 
	 * 
	 * 
	 * @param path
	 * 
	 */

	public void mkdirs(String path) {
		File f = new File(path);
		String fs = f.getParent();
		f = new File(fs);
		if (!f.exists()) {
			f.mkdirs();
		}

	}

	public boolean downloadFile(String remotePath, String remoteFileName, String localPath, String localFileName) {

		try {

			chSftp.cd(remotePath);

			File file = new File(localPath + localFileName);

			mkdirs(localPath + localFileName);

			chSftp.get(remoteFileName, new FileOutputStream(file));

			return true;

		} catch (FileNotFoundException e) {

			e.printStackTrace();

		} catch (SftpException e) {

			e.printStackTrace();

		}

		return false;

	}

	public void deleteSFTP(String directory, String deleteFile) {

		try {

			chSftp.cd(directory);

			chSftp.rm(deleteFile);

		} catch (Exception e) {

			e.printStackTrace();

		}

	}

	/**
	 * 
	 * 批量下载文件
	 * 
	 * 
	 * 
	 * @param remotPath
	 * 
	 *            远程下载目录(以路径符号结束)
	 * 
	 * @param localPath
	 * 
	 *            本地保存目录(以路径符号结束)
	 * 
	 * @param fileFormat
	 * 
	 *            下载文件格式(以特定字符开头,为空不做检验)
	 * 
	 * @param del
	 * 
	 *            下载后是否删除sftp文件
	 * 
	 * @return
	 * 
	 */
	
	public boolean checkPathIsExists(String remotPath,String localPath,String lpwd) {
		String MMDD = DateUtil.get8Date().substring(4,8);
		String YYMMDD = DateUtil.get8Date();
		String mm = File.separator+YYMMDD;
		try {
			chSftp.cd(remotPath);
			//chSftp.cd(MMDD);
			if(!"".equals(lpwd)) {
				chSftp.cd(lpwd);
			}else {
				chSftp.cd(YYMMDD);
			}
			return true;
		} catch (SftpException e) {
			logger.error("文件目录不存在:" + remotPath+mm);
			this.close();
			
			File file = new File(localPath+YYMMDD+File.separator);
			
			if(!file.exists()) {
				file.mkdirs();
				try {
					File file2 = new File(localPath+YYMMDD+File.separator+"ERROR-NO-PATH.OK");
					file2.createNewFile();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					return false;
				}
			}
			return false;
			
		}
	}
	
	/**
	 * 迭代删除文件夹
	 * @param dirPath 文件夹路径
	 */
	public static void deleteDir(String dirPath)
	{
		File file = new File(dirPath);
		if(file.isFile())
		{
			file.delete();
		}else
		{
			File[] files = file.listFiles();
			if(files == null)
			{
				file.delete();
			}else
			{
				for (int i = 0; i < files.length; i++) 
				{
					deleteDir(files[i].getAbsolutePath());
				}
				file.delete();
			}
		}
	}
	public boolean batchDownloadFile(String remotPath, String localPath, String fileFormat,
			boolean del,String error,String mail,String lpwd) throws Exception {
		deleteDir(localPath+DateUtil.get8Date()+File.separator);
		boolean checkFlag = checkPathIsExists(remotPath, localPath,lpwd);
		
		if(checkFlag) {
			
			error = "0321-nofile-"+DateUtil.get8Date();
			List<String> lPath = new ArrayList<String>();
			String path = DateUtil.get8Date();
			Vector v =  null;
			boolean flag = false;
			boolean mainflag = false;
			logger.info("文件目录:" + chSftp.pwd());
			v = listFiles(chSftp.pwd());
			
			if (v.size() > 0) {
				Iterator it = v.iterator();
				while (it.hasNext()) {
					LsEntry entry = (LsEntry) it.next();
					String filename = entry.getFilename();
					SftpATTRS attrs = entry.getAttrs();
					if (!attrs.isDir()) {
						if (fileFormat != null && !"".equals(fileFormat.trim())) {
							if (filename.toUpperCase().endsWith(fileFormat) || filename.startsWith("0321-nofile-")) {
								lPath.add(filename);
							}
							
							if(filename.toUpperCase().equals("PBOC.OK")) {
								flag = true;
								lPath.add(filename);
							}
							
						}
					}
				}

			}
			
			if(flag) {
				logger.info("开始获取目录文件开始");
				for(int i=0;i<lPath.size();i++) {
					this.downloadFile(chSftp.pwd(), lPath.get(i), localPath+File.separator+DateUtil.get8Date()+File.separator, lPath.get(i));
					logger.info("获取文件名称："+lPath.get(i));
				}
				this.close();
				logger.info("开始获取目录文件结束");
				return true;
			}else {
				logger.info("标志文件pboc.ok文件不存，等待下次获取"+path);
				
				File file = new File(localPath+DateUtil.get8Date()+File.separator);
				
				if(!file.exists()) {
					file.mkdirs();
					try {
						File file2 = new File(localPath+DateUtil.get8Date()+File.separator+"ERROR-NO-PBOC.OK");
						file2.createNewFile();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						return true;
					}
				}
				
				this.close();
				return true;
			}
		}else {
			return true;
		}
	}

	public static void main(String[] args) {
		
		try {
			SftpUtil sftpUtil = new SftpUtil("gingkoo", "127.0.0.1", "120",
					"C:\\Users\\young\\Desktop\\11.ppk", "111111");
			
			
			//sftpUtil.checkPathIsExists(".","D:\\sftp\\");
			//sftpUtil.batchDownloadFile(".", "D:\\sftp\\", "TXT", false,"","");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
