package com.gingkoo.cupd.job;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.cupd.service.ObjectInsertToTableService;

@Component("xmlDataToTableJob")
public class XmlDataToTableJob {

    private static final Log logger = LogFactory.getLog(XmlDataToTableJob.class);

    @Autowired
    ObjectInsertToTableService objectInsertToTableService;
    
    
    JobResult jr = new JobResult();

    public Map<String, String> execute(String type) {
        logger.info("===============++++++++++Exec XmlDataToTableJob begin++++++++++=============");
        jr.setErrCode("00");
        jr.setErrMsg("OK");
        try {
        	objectInsertToTableService.insert(type);
        } catch (Exception arg6) {
            arg6.printStackTrace();
            logger.info("操作失败，错误信息：" + arg6.getMessage());
            jr.setErrCode("E");
            jr.setErrMsg("操作失败，错误信息：" + arg6.getMessage());
            return jr.getMap();
        }

        logger.info("===============++++++++++Exec XmlDataToTableJob end++++++++++=============");
        return jr.getMap();
    }
    
    public Map<String, String> execute1(String type) {
        logger.info("===============++++++++++Exec XmlDataToTableJob begin++++++++++=============");
        jr.setErrCode("00");
        jr.setErrMsg("OK");
        try {
        	objectInsertToTableService.insert1(type);
        } catch (Exception arg6) {
            arg6.printStackTrace();
            logger.info("操作失败，错误信息：" + arg6.getMessage());
            jr.setErrCode("E");
            jr.setErrMsg("操作失败，错误信息：" + arg6.getMessage());
            return jr.getMap();
        }

        logger.info("===============++++++++++Exec XmlDataToTableJob end++++++++++=============");
        return jr.getMap();
    }

}
