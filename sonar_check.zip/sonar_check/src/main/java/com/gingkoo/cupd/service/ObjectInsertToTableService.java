package com.gingkoo.cupd.service;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.orm.entity.MbtHsbcCupdFileLog;

@Service
public class ObjectInsertToTableService {

	 private static final Log logger = LogFactory.getLog(ObjectInsertToTableService.class);
	 
	 @Autowired
	 ParseTemplateTmpService parseTemplateService;
	 
	 @Autowired
	 ParseTemplateService parseTemplateService1;
	 
	 @Autowired
	 ROOTDAO dao;
	 
	 public boolean insert(String type) throws Exception {
		 	
			String hql = "from MbtHsbcCupdFileLog where isAnalysis = '1' and type = ? ";
			List<MbtHsbcCupdFileLog> resultList = dao.queryByQL2List(hql,new Object[] {type},null);
			if(!resultList.isEmpty()) {
				for (MbtHsbcCupdFileLog mbtHsbcCupdFileLog : resultList) {
					String filePath = mbtHsbcCupdFileLog.getFilePath();
					String fileBakPath = mbtHsbcCupdFileLog.getFileBakPath();

					type = mbtHsbcCupdFileLog.getType();
					String file_from = mbtHsbcCupdFileLog.getFileType();
					/*l= parseTemplateService.paserXmlObjectDataList(filePath,type,file_from);
					for (Object object : l) {
						dao.save(object);
					}*/
/*					ParseTemplateService parseTemplateService = new ParseTemplateService();
*/					String date = DateUtil.get14Date();
					parseTemplateService.saveObjs(filePath, type, file_from,fileBakPath);
					mbtHsbcCupdFileLog.setIsAnalysis("2");
					mbtHsbcCupdFileLog.setAnalsisStartTime(date);
					mbtHsbcCupdFileLog.setAnalsisEndTime(DateUtil.get14Date());
					mbtHsbcCupdFileLog.setXmlDataCount(String.valueOf(parseTemplateService.getDataCount()));
					dao.update(mbtHsbcCupdFileLog);
				}
			}
		 return true;
				 
	 }
	 
	 public boolean insert1(String type) throws Exception {
		 	
			String hql = "from MbtHsbcCupdFileLog where isAnalysis = '1' and type = ? ";
			List<MbtHsbcCupdFileLog> resultList = dao.queryByQL2List(hql,new Object[] {type},null);
			if(!resultList.isEmpty()) {
				for (MbtHsbcCupdFileLog mbtHsbcCupdFileLog : resultList) {
					String filePath = mbtHsbcCupdFileLog.getFilePath();
					String fileBakPath = mbtHsbcCupdFileLog.getFileBakPath();

					type = mbtHsbcCupdFileLog.getType();
					String file_from = mbtHsbcCupdFileLog.getFileType();
					/*l= parseTemplateService.paserXmlObjectDataList(filePath,type,file_from);
					for (Object object : l) {
						dao.save(object);
					}*/
/*					ParseTemplateService parseTemplateService = new ParseTemplateService();
*/					String date = DateUtil.get14Date();
					parseTemplateService1.saveObjs(filePath, type, file_from,fileBakPath);
					mbtHsbcCupdFileLog.setIsAnalysis("2");
					mbtHsbcCupdFileLog.setAnalsisStartTime(date);
					mbtHsbcCupdFileLog.setAnalsisEndTime(DateUtil.get14Date());
					mbtHsbcCupdFileLog.setXmlDataCount(String.valueOf(parseTemplateService.getDataCount()));
					dao.update(mbtHsbcCupdFileLog);
				}
			}
		 return true;
				 
	 }

	 public boolean check() throws Exception {
		 	
			String hql = "from MbtHsbcCupdFileLog where dataDate = ? ";
			List<MbtHsbcCupdFileLog> resultList = dao.queryByQL2List(hql,new Object[] {DateUtil.get8Date()},null);
			if(resultList.isEmpty()) {
				return true;
			}
		 return false;
				 
	 }
	    
}
