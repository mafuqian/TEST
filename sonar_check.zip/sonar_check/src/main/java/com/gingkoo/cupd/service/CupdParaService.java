package com.gingkoo.cupd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.GpBmSysParam;
import com.gingkoo.gf4j2.framework.excp.CommonException;

@Service
public class CupdParaService {

	@Autowired
	ROOTDAO dao;
	public String getParamValue(String id,String groupId) throws CommonException {
		String hql = "from GpBmSysParam where paramId = ? and paramGroupId = ? ";
		List<GpBmSysParam> l =  dao.queryByQL2List(hql, new Object[] {id,groupId}, null);
		if(!l.isEmpty()) {
			GpBmSysParam bmSysParam= l.get(0);
			return bmSysParam.getParamValue();
		}
		return null;
		
	}
	
	public static void main(String[] args) {
		String name = "D10052900H00022019090611001020.txt";
		System.out.println(name.indexOf("pboc") );
	}
}
