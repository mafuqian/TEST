package com.gingkoo.cupd.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gingkoo.common.email.service.impl.UGnoChlEmailImpl;
import com.gingkoo.common.message.entity.bean.GpBmGnoMsgBean;

@Service
public class MailServices {
	private static final Log logger = LogFactory.getLog(MailServices.class);

	@Autowired
	private UGnoChlEmailImpl uGnoChlEmailImpl;
	
	public boolean send(String title,String mail,String msg) {

		//需发送邮件
		logger.info("今日未收到文件，开始发送邮件：");
		//String title = String.valueOf("未收到CUPD文件邮件提醒");
		StringBuilder sb = new StringBuilder();
		sb.append("Dear ").append("" + ",<br/>")
				.append(msg).append("<br/>")
				.append("------------------------------------------------------------------------------------------<br/>")
				.append("<br/>").append("此邮件由CRMS系统发送");

		String mess = String.valueOf(sb.toString());
		GpBmGnoMsgBean msgInfo = new GpBmGnoMsgBean();
		msgInfo.setMsgTitle(title);
		msgInfo.setMsgContent(mess);
		msgInfo.setToList(mail);
		try {
			// UGnoChlEmailImpl uGnoChlEmailImpl = new UGnoChlEmailImpl();
			uGnoChlEmailImpl.sendMessage(msgInfo);
			
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e.getStackTrace(),e);
			//e.printStackTrace();
			return false;
		}
	
	}
}
