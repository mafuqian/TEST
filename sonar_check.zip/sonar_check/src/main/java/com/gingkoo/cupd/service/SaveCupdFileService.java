package com.gingkoo.cupd.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.orm.entity.MbtHsbcCupdFileLog;

@Service
public class SaveCupdFileService {

    private static final Log logger = LogFactory.getLog(SaveCupdFileService.class);

	@Autowired
	ROOTDAO dao;
	@Autowired
	MailServices mailServices;
	//D10052900H00022019090611001020
	public boolean saveFile(String path,String errorname,String mail,int num) throws Exception {
		
		String path_err_1 = path + File.separator +"ERROR-NO-PATH.OK";
		File file_err_1 = new File(path_err_1);
		String path_err_2 = path + File.separator +"ERROR-NO-PBOC.OK";
		File file_err_2 = new File(path_err_2);
		if(file_err_1.exists() || file_err_2.exists()) {
			MbtHsbcCupdFileLog log = new MbtHsbcCupdFileLog();
			log.setDataDate(DateUtil.get8Date());
			log.setDataId(UUID.randomUUID().toString().replace("-", ""));
			log.setCorpId("HSBC");
			log.setGroupId("CUPD(CRD)");
			log.setFileType("CARD");
			log.setOrgId("CNQ");
			log.setArriveTime(DateUtil.get14Date());
			if(file_err_1.exists()) {
				log.setFilePath(path_err_1);
			}else {
				log.setFilePath(path_err_2);
			}
			dao.save(log);
			
			mailServices.send("未收到CUPD文件邮件提醒", mail, "未收到银联文件！");
			
			return false;
		}else {
			String path_err_4 = path + File.separator +"PBOC.OK";
			File file_err_4 = new File(path_err_4);
			errorname = "0321-nofile-"+DateUtil.get8Date();
			if(file_err_4.exists()) {
				String path_err_3 = path + File.separator +errorname;
				File file_err_3 = new File(path_err_3);
				if(file_err_3.exists()) {
					MbtHsbcCupdFileLog log = new MbtHsbcCupdFileLog();
					log.setDataDate(DateUtil.get8Date());
					log.setDataId(UUID.randomUUID().toString().replace("-", ""));
					log.setCorpId("HSBC");
					log.setGroupId("CUPD(CRD)");
					log.setFileType("CARD");
					log.setOrgId("CNQ");
					log.setArriveTime(DateUtil.get14Date());
					log.setFilePath(path + File.separator+"ERROR-NO-DATA.OK");
					dao.save(log);
					return false;
				}else {
					File file = new File(path);
					File[] lfile = file.listFiles();
					List<MbtHsbcCupdFileLog> l = new ArrayList<MbtHsbcCupdFileLog>();
					for(int i = 0;i<lfile.length;i++) {
						File f = lfile[i];
						MbtHsbcCupdFileLog log = new MbtHsbcCupdFileLog();
						String name = f.getName();
						String filePath = f.getAbsolutePath();
						if(!errorname.equals(name)) {
							if(!name.equals("PBOC.OK")) {
								List<String> lpath = separateFile(filePath, num);
								for(int k =0;k<lpath.size();k++) {
									log = new MbtHsbcCupdFileLog();
									log.setType(name.substring(22, 25));
									log.setIsAnalysis("1");
									log.setDataDate(DateUtil.get8Date());
									log.setCorpId("HSBC");
									log.setGroupId("CUPD(CRD)");
									log.setFileType("CARD");
									log.setOrgId("CNQ");
									log.setArriveTime(DateUtil.get14Date());
									log.setDataId(UUID.randomUUID().toString().replace("-", ""));
									log.setFilePath(lpath.get(k));
									log.setFileBakPath(filePath);
									//l.add(log);
									dao.save(log);
								}
							}else {
								log.setDataDate(DateUtil.get8Date());
								log.setDataId(UUID.randomUUID().toString().replace("-", ""));
								log.setFilePath(filePath);
								log.setCorpId("HSBC");
								log.setGroupId("CUPD(CRD)");
								log.setFileType("CARD");
								log.setOrgId("CNQ");
								log.setArriveTime(DateUtil.get14Date());
								//dao.save(log);
								//l.add(log);
								dao.save(log);
							
							}
						}
					}
					
					return true;
				}
			}
		}
		return true;
	}
	
	
	public List<String> separateFile(String xmlDataPath,int num) throws Exception {
		
		List<String> l = new ArrayList<String>();
		FileInputStream inputStream = null;
		StringBuilder body = new StringBuilder();
		String line = "";
		inputStream = new FileInputStream(xmlDataPath);
		Scanner sc  = new Scanner(inputStream, "UTF-8");
		 int i = 0;
		 int id = 0;
		 int count = 0;
		 while (sc.hasNextLine()) {
		         line = sc.nextLine();
		        if(i==0) {
	        		//header = line;
		        	count = Integer.parseInt(line.substring(44,50));
		        	logger.info("总读取行数--->"+count);
		        	if(count < num) {
		        		l.add(xmlDataPath);
		        		break;
		        	}
		        	i++;
	        	}else {
	        		if(line.indexOf("Document") == -1 && !line.equals("")) {
	        			body = body.append(line).append("\r\n");
	        			//logger.info("读取行数--->"+i);
	        			//logger.info("读取行数--->"+line);

	        			if(count > num) {
	    		        	if(i == num) {
	    		        		String msg  = "<Document>\r\n"+body.toString()+"</Document>";
	    		        		id = id + 1;
	    		        		String path = xmlDataPath.replace(".txt", "-"+String.valueOf(id)+"-"+String.valueOf(i)+".xml");
	    		        		writer(path, msg);
	    		        		l.add(path);
	    		        		i =0;
	    		        		body = new StringBuilder();
	    		        	}
	    		        	int all = num * id + i;
	    		        	if(all == count) {
	    		        		id = id + 1;
	    		        		String msg  = "<Document>\r\n"+body.toString()+"</Document>";
	    		        		String path = xmlDataPath.replace(".txt", "-"+String.valueOf(id)+"-"+String.valueOf(i)+".xml");
	    		        		writer(path, msg);
	    		        		l.add(path);
	    		        	}
	    		        }
	      	        	i++;
	        		}
	        		
	        	}
		    }
		 
		if (sc.ioException() != null) {
			throw sc.ioException();
		 }
		
		 if (inputStream != null) {
		        inputStream.close();
		    }
		 if (sc != null) {
			 sc.close();
		 }
        
		return l;
	}
	
	
	public Integer getDocument(String xmlDataPath,int num) throws Exception {
		int count = 0;
		FileInputStream inputStream = null;
		StringBuilder body = new StringBuilder();
		String line = "";
		inputStream = new FileInputStream(xmlDataPath);
		Scanner sc  = new Scanner(inputStream, "UTF-8");
		String header = "";
		 int i = 0;
		 while (sc.hasNextLine()) {
		         line = sc.nextLine();
		        if(i==0) {
	        		header = line;
	        		break;
	        	}
		    }
		if (sc.ioException() != null) {
			throw sc.ioException();
		 }
		
		 if (inputStream != null) {
		        inputStream.close();
		    }
		 if (sc != null) {
			 sc.close();
		 }
		String len = header.substring(44,50);
		
		int cnt = Integer.parseInt(len);
		int j = cnt/num;
		if(j > 0) {
			int k = cnt%num;
			if(k >0) {
				count = j +1;
			}
		}
		
		for(int m = count;m>0;m++) {
			
		}
		
		return count;
	}
	
	public void writer(String path,String msg) throws Exception {
		File file = new File(path);
		if(!file.exists()) {
			file.createNewFile();
		}
		PrintWriter out = new PrintWriter(file,"UTF-8");
		out.println(msg);
		out.close();
		logger.info("生成文件--->"+path);
	}
	
	
	
	
	public static void main(String[] args) throws Exception {
		SaveCupdFileService cupdFileService = new SaveCupdFileService();
		
		List<String> l = cupdFileService.separateFile("D:\\sftp\\20200306\\D10052900H00022020090611002020.txt", 10);

		for(int i=0;i<l.size();i++) {
			System.out.println(l.get(i));
		}
		
	
		/*String str = "0015038";
		int i = Integer.parseInt(str);
		int j = i/10000;
		int k = i%10000;
		System.out.println(j);
		System.out.println(k);*/

	}
}
