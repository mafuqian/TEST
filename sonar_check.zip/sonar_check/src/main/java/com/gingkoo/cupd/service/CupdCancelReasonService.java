package com.gingkoo.cupd.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gingkoo.exception.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.mbt.dao.MbtRootDao;

@SuppressWarnings("ALL")
@Service
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class CupdCancelReasonService  {

    protected static final Log logger = LogFactory.getLogger(CupdCancelReasonService.class);

    @Autowired
    protected MbtRootDao dao;

   
    @Transactional(rollbackFor = Exception.class)
    public void process(Map<String, String> recordMap) throws Exception {
    	String tableName = recordMap.get("tableName");
    	String cancelReason = recordMap.get("cancelReason");
    	
    	String dataId= recordMap.get("dataId");
    	dataId = dataId.replace(",", "','") ;
    	StringBuffer buffer = new StringBuffer("UPDATE ");
    	buffer.append(tableName).append(" SET DATA_STATUS = '30' , DATA_CHG_USER='")
    	.append(GlobalInfo.getCurrentInstance().getTlrno()).append("',RSV5= '")
    	.append(cancelReason).append("' ,DATA_CHG_DATE ='")
    	.append(DateUtil.get8Date()).append("', DATA_CHG_TIME='").append(DateUtil.get14Date())
    	.append("' WHERE DATA_STATUS='24' AND DATA_ID IN ('").append(dataId).append("')");
    	
    	int i = dao.executeSql(buffer.toString());
    	if(i < 1) {
    		throw new AppException("操作失败！");
    	}
    }
    
    @Transactional(rollbackFor = Exception.class)
    public void processCallBack(List<Map<String, String>> records,String tableName) throws Exception {
    	String dataIdArr = "222";
    	for(int i = 0;i<records.size();i++) {
    		Map<String, String> map = records.get(i);
    		String dataId= map.get("dataId");
    		dataIdArr = dataIdArr + "','"+dataId;
    	}
    	StringBuffer buffer = new StringBuffer("UPDATE ");
    	buffer.append(tableName).append(" SET DATA_STATUS = '24' , DATA_CHG_USER='")
    	.append(GlobalInfo.getCurrentInstance().getTlrno()).append("' ,DATA_CHG_DATE ='")
    	.append(DateUtil.get8Date()).append("', DATA_CHG_TIME='").append(DateUtil.get14Date())
    	.append("' WHERE DATA_STATUS='30' AND DATA_ID IN ('").append(dataIdArr).append("')");
    	
    	int i = dao.executeSql(buffer.toString());
    	if(i < 1) {
    		throw new AppException("操作失败！");
    	}
    }
}
