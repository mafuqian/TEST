package com.gingkoo.cupd.job;

import java.io.File;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.cupd.service.CupdParaService;
import com.gingkoo.cupd.service.SaveCupdFileService;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.excp.CommonException;

/**
 * 
 * East报文生成 <功能详细描述>
 * 
 * 1、使用线程(后改，优化)
 * 2、使用循环调用起线程完成报文生成
 * 
 * 
 * @author kane
 * @version [版本号, 2017年1月7日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
@Component("saveCupdFileJob")
public class SaveCupdFileJob {
	private static final Log logger = LogFactory.getLog(SaveCupdFileJob.class);
	@Autowired
	SaveCupdFileService saveCupdFileService;
	@Autowired
	private CupdParaService cupdParaService;
	public Map<String, String> execute(String num){
        logger.info("===============++++++++++Exec SaveCupdFileJob begin++++++++++=============");

 		JobResult jr = new JobResult(); 
 		
 		try {
			String l_path = cupdParaService.getParamValue("SFTP_DB_CONNECT", "SFTP_LOCATION_PATH");

			String arr =cupdParaService.getParamValue("SFTP_DB_CONNECT", "SFTP");

			String[] obj = arr.split("\\|");
			
			l_path = l_path + File.separator+ DateUtil.get8Date();
			
			boolean falg = saveCupdFileService.saveFile(l_path,obj[5],obj[6],Integer.parseInt(num));
			if(falg) {
				jr.setErrCode("00");
				jr.setErrMsg("保存成功");
			}else {
				jr.setErrCode("E");
				jr.setErrMsg("未收到CUPD文件");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			jr.setErrCode("E");
			jr.setErrMsg(e.getMessage());
		}
        logger.info("===============++++++++++Exec SaveCupdFileJob end++++++++++=============");

        return jr.getMap();
	}
	
}

