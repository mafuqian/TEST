package com.gingkoo.mbt.util;

import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 日期工具类
 *
 */
public class DateConvertUtils {
    /**
     * 获取当前时间
     *
     * @return
     */
    public static Date getNowDate() {

        Date currentTime = new Date();

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

        String dateString = formatter.format(currentTime);

        return strToDate(dateString);

    }

    /**
     * 时间从string类型转成date类型
     *
     * @param strDate
     * @return
     */
    public static Date strToDate(String strDate) {

        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");

        ParsePosition pos = new ParsePosition(0);

        Date strtodate = formatter.parse(strDate, pos);

        return strtodate;
    }

    /**
     * 提取一个月中的最后一天
     *
     * @return
     */
    public static String getLastDate() {

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

        Calendar ca = Calendar.getInstance();

        ca.set(Calendar.DAY_OF_MONTH, ca.getActualMaximum(Calendar.DAY_OF_MONTH));

        String last = format.format(ca.getTime());

        return last;

    }
    /**
     * 获取月份+n的时间
     */
    public static String subMonth(String date, int month) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Date dt = null;
        try {
            dt = sdf.parse(date);

        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar rightNow = Calendar.getInstance();
        rightNow.setTime(dt);
        rightNow.add(Calendar.MONTH, month);
        Date dt1 = rightNow.getTime();
        String reStr = sdf.format(dt1);
        return reStr;
    }

}
