package com.gingkoo.mbt.action;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.service.base.OPCaller;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.mbt.service.PersonalTagAlterService;
import com.gingkoo.mbt.service.PersonalObjService;
import com.gingkoo.orm.entity.TagInf;
import com.gingkoo.orm.entity.ToCheckInf;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

public class PersonalTagPzSendAlterAction extends WebAlterAction {

    private static final String DATASET_ID = "PersonalTag_ds";
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse respone) throws AppException {
        UpdateReturnBean updateReturnBean = new UpdateReturnBean();
        UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
        ServiceContext oc = new ServiceContext();
        TagInf tagInf = new TagInf();

        Map<String, String> map = updateResultBean.next();
        String correctState= map.get("correctState");
        String objCheckId= map.get("objCheckId");
        String dataProviderOrgCode= map.get("dataProviderOrgCode");
        PersonalObjService personalObjService=new PersonalObjService();
        Map<String,String> fileStr= personalObjService.shengchengfiles(map,tagInf,"G107.ftl");

        boolean result=personalObjService.psObjCorrectResultQueryReq("");
        if (result){
            map.put("dataState","4");
            oc.setAttribute(PersonalTagAlterService.CMD, PersonalTagAlterService.CMD_MOD);
            mapToObject(tagInf, map);
            oc.setAttribute(PersonalTagAlterService.IN_PARAM, tagInf);
            OPCaller.call(PersonalTagAlterService.ID , oc);
            updateReturnBean.setParameter("isOptSucc", "true");


        }else {
            map.put("dataState","5");
            oc.setAttribute(PersonalTagAlterService.CMD, PersonalTagAlterService.CMD_MOD);
            mapToObject(tagInf, map);
            oc.setAttribute(PersonalTagAlterService.IN_PARAM, tagInf);
            OPCaller.call(PersonalTagAlterService.ID , oc);
            updateReturnBean.setParameter("isOptSucc", "true");
        }
        return updateReturnBean;
    }
}
