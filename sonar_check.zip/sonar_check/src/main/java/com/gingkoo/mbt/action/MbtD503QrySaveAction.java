package com.gingkoo.mbt.action;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.GpBmSysParam;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.orm.entity.MbtD503Qry;

public class MbtD503QrySaveAction extends MbtEditTableMultRecordAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("D503_Qry_ds");
        UpdateResultBean MbtD503ResultBean = multiUpdateResultBean.getUpdateResultBeanByID("D503_ds");
        String pdataId = resultBean.getParameter("pdataId");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
        Map<String,String> paramMap = resultBean.getParamMap();

        paramMap.put("originateUserCode", GlobalInfo.getCurrentInstance().getTlrno());
        ROOTDAO dao = ROOTDAOUtils.getROOTDAO();
        String sql = "from GpBmSysParam where param_id='ORIGINATE_ORG_CODE'";
        List<GpBmSysParam> list = dao.queryByQL2List(sql);
        paramMap.put("originateOrgCode",list.get(0).getParamValue());


        new MbtD503SaveAction(MbtD503ResultBean,pdataId,paramMap.get("originateOrgCode")).saveOrUpdate(multiUpdateResultBean,request,response);



        resultBean.getParamMap().put("pdataId",MbtD503ResultBean.getTotalList().get(0).get("dataId"));

        process(resultBean, MbtD503Qry.class);
        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("pdataId",MbtD503ResultBean.getTotalList().get(0).get("dataId"));
        return returnBean;
    }
}
