package com.gingkoo.mbt.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtD101AndD103ApplyDownloadManageService;

/**
 * @Author: li.jy
 * @Date: 2019/1/17
 */
public class MbtApplyDownloadManageAction extends WebAlterAction {

    private Log logger = LogFactory.getLogger(MbtApplyDownloadManageAction.class);

    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request,
                                         HttpServletResponse respone) throws AppException {
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("MbtApplyDownloadManage_Bas_ds");
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtD101AndD103ApplyDownloadManageService manageService =
                (MbtD101AndD103ApplyDownloadManageService) context.getBean("mbtD101AndD103ApplyDownloadManageService");
        UpdateReturnBean returnBean = manageService.applyDownloadManage(resultBean);
        return returnBean;
    }
}
