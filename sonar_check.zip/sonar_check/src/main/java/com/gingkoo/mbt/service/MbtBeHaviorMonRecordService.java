package com.gingkoo.mbt.service;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.util.DataObjectUtils;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.mbt.dao.MbtRootDao;
import com.gingkoo.mbt.service.base.MbtCommonBaseService;
import com.gingkoo.orm.entity.MbtArchiveManage;
import com.gingkoo.orm.entity.MbtBehaviourMonitor;
import com.gingkoo.orm.entity.MbtSendUserManage;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.lang.reflect.InvocationTargetException;
import java.util.*;

/**
 *
 * 处理前台提交的单条记录的通用 Action
 *
 * @author fuxiang.luo@gingkoo.com
 *
 *
 */
@SuppressWarnings("ALL")
@Service
public class MbtBeHaviorMonRecordService {

    protected static final Logger logger = LogManager.getLogger(MbtBeHaviorMonRecordService.class);

    @Autowired
    protected MbtRootDao dao;

    private String dataId;

    @Autowired
    private MbtCommonBaseService mbtCommonBaseService;


    public String getDataId(){
        return dataId;
    }

    /**
     *
     * @param resultBean 包含记录数据的 resultBean
     * @param clazz 实体类
     * @throws AppException app异常
     */
    @Transactional(rollbackFor = Exception.class)
    public void process(UpdateResultBean resultBean, Class<?> clazz) throws AppException {
        Map<String, String> recordMap = resultBean.next();
        resultBean.getParamMap().forEach((k, v) ->{
            if(!StringUtils.isEmpty(v)){
                recordMap.put(k, v);
            }
        });

        Object bean;
        recordMap.put("dataChgUser", GlobalInfo.getCurrentInstance().getTlrno());
        recordMap.put("dataChgTime", DateUtil.get14Date());
        recordMap.put("dataChgDate", DateUtil.get8Date());

        Map<String,String> map = new HashMap<String,String>();
        try {
            bean = clazz.newInstance();
        } catch (InstantiationException | IllegalAccessException e) {
            logger.error(e);
            throw new AppException("系统错误，创建类" + clazz.getName() + "实例时出错。");
        }

        if(null != recordMap.get("dataCrtTime")) {
       	 recordMap.put("dataCrtTime",trim(recordMap.get("dataCrtTime")));
       }

       if(null != recordMap.get("dataApvTime")) {
      	 recordMap.put("dataApvTime",trim(recordMap.get("dataApvTime")));
      }
        if (StringUtils.isEmpty(recordMap.get("dataId"))) {
            dataId = UUID.randomUUID().toString().replace("-", "");
            //根据当前登陆用户的用户名+用户号查询出征信表中的东东
            String hql = " from MbtSendUserManage where  sysTlrno=? and sysTlrname=? ";
            ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
            List<MbtSendUserManage> mbtSendUserManageList = dao.queryByQL2List(hql, new Object[]{GlobalInfo.getCurrentInstance().getTlrno(), resultBean.getParamMap().get("tlrName")}, null);
            if (mbtSendUserManageList.size() > 0) {
                //查询机构代码+查询用户代码+查询用户密码 指的是当前登录用户在表中对应的接入机构代码 接口用户代码 接口用户密码
                recordMap.put("qryOrgCode", mbtSendUserManageList.get(0).getAssociatedOrgNo());
                recordMap.put("userCode", mbtSendUserManageList.get(0).getAssociatedUserId());
                recordMap.put("passWord", mbtSendUserManageList.get(0).getAssociatedUserPassword());
                //发起机构代码 +发起用户代码
                recordMap.put("ognOrgCode", GlobalInfo.getCurrentInstance().getGroupId());
                recordMap.put("ognUserCode", GlobalInfo.getCurrentInstance().getTlrno());
                recordMap.put("originateOrgCode", GlobalInfo.getCurrentInstance().getGroupId());
                recordMap.put("originateUserCode", GlobalInfo.getCurrentInstance().getTlrno());
                recordMap.put("dataId", dataId);
                recordMap.put("dataCrtUser", GlobalInfo.getCurrentInstance().getTlrno());
                recordMap.put("dataCrtTime", DateUtil.get14Date());
                recordMap.put("dataDate", DateUtil.get8Date());
                recordMap.put("dataCrtDate", DateUtil.get8Date());
                recordMap.put("corpId", GlobalInfo.getCurrentInstance().getCorpId());
                recordMap.put("orgId", GlobalInfo.getCurrentInstance().getBrno());
                recordMap.put("groupId", GlobalInfo.getCurrentInstance().getGroupId());
                recordMap.put("inqOrgID", "");
                recordMap.put("dataSource", "1");
                recordMap.put("iptStatus", "21");
                recordMap.put("qryTlrno", GlobalInfo.getCurrentInstance().getTlrno());
                recordMap.put("qryTlrname", resultBean.getParamMap().get("tlrName"));
                recordMap.put("subjectType", resultBean.getParamMap().get("subjectType"));
                map.put("actionId", "add");
            }
            mapToObject(bean, recordMap);
            dao.save(bean);
            record(resultBean,recordMap, MbtBehaviourMonitor.class);
        }
    }

    public String trim(String str) {
    	if(!"".equals(str) && null != str) {
    		str = str.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
    	}

    	return str;
    }

    /**
     * 生成行为监控记录
     * @param resultBean
     * @param recordMap
     * @param clazz
     * @throws AppException
     */
    @Transactional(rollbackFor = Exception.class)
    private void record(UpdateResultBean resultBean,Map<String,String> recordMap,Class<?> clazz) throws  AppException{
        //行为监控记录保存
        Object clazz1;
        Map<String,String> beRecordMap = new HashMap<String,String>();
        try {
            clazz1 =Class.forName("com.gingkoo.orm.entity.MbtBehaviourMonitor").newInstance();
            dataId = UUID.randomUUID().toString().replace("-", "");
            beRecordMap.put("dataId", dataId);
            beRecordMap.put("dataCrtUser",GlobalInfo.getCurrentInstance().getTlrno());
            beRecordMap.put("dataCrtTime", DateUtil.get14Date());
            beRecordMap.put("dataDate", DateUtil.get8Date());
            beRecordMap.put("dataCrtDate", DateUtil.get8Date());
            beRecordMap.put("corpId", GlobalInfo.getCurrentInstance().getCorpId());
            beRecordMap.put("orgId", GlobalInfo.getCurrentInstance().getBrno());
            beRecordMap.put("groupId", GlobalInfo.getCurrentInstance().getGroupId());
            beRecordMap.put("inqOrgID","");
            beRecordMap.put("dataSource","1");
            beRecordMap.put("oprCorpId", GlobalInfo.getCurrentInstance().getCorpId());
            beRecordMap.put("oprOrgId", GlobalInfo.getCurrentInstance().getBrno());
            beRecordMap.put("oprDepartId", GlobalInfo.getCurrentInstance().getGroupId());
            beRecordMap.put("oprTlrno",GlobalInfo.getCurrentInstance().getTlrno());
            beRecordMap.put("oprTlrname",resultBean.getParamMap().get("tlrName"));
            beRecordMap.put("oprDate", DateUtil.get8Date());
            beRecordMap.put("oprTime", DateUtil.get14Date());
            beRecordMap.put("exceptionLevel", "警告");
            //TODO start
            beRecordMap.put("exceptionDesc", "在工作日/正常查询时间之外查询");
            //TODO end
            String hql = "from MbtArchiveManage  where authorizationId =?  ";
            List<MbtArchiveManage> archiveManageList ;
            archiveManageList = dao.queryByQL2List(hql,new Object[]{recordMap.get("authorizationId")},null);
            // 根据主体姓名 主体类型 主体证件号
            if (!CollectionUtils.isEmpty(archiveManageList)){
                beRecordMap.put("clientId", archiveManageList.get(0).getClientId());
                beRecordMap.put("identifyName", archiveManageList.get(0).getIdentifyName());
                beRecordMap.put("authorizationId", recordMap.get("authorizationId"));
                beRecordMap.put("subjectType", archiveManageList.get(0).getSubjectType());
            }
            //fucid+opr
            beRecordMap.put("oprCode", resultBean.getParamMap().get("funcId")+resultBean.getParamMap().get("opr"));
            try {
                BeanUtils.copyProperties(clazz1,beRecordMap);
            } catch (IllegalAccessException e) {
                logger.error(e);
            } catch (InvocationTargetException e) {
                logger.error(e);
            }
            dao.save(clazz1);

        } catch (InstantiationException | IllegalAccessException |ClassNotFoundException e) {
            logger.error(e);
            throw new AppException("系统错误，创建类" + clazz.getName() + "实例时出错。");
        }
    }
    public static Set<String> mapToObject(Object object, Map map) throws AppException {
        HashMap candidates = new HashMap();
        Iterator var4 = map.keySet().iterator();

        while(var4.hasNext()) {
            Object e = var4.next();
            char[] chars = ((String)e).toCharArray();
            if(Character.isUpperCase(chars[1])) {
                chars[0] = (char)(chars[0] - 32);
                candidates.put(String.valueOf(chars), map.get(e));
            }
        }

        map.putAll(candidates);

        try {
            return DataObjectUtils.mapToObject(object, map);
        } catch (Exception var6) {
            throw new AppException("SY", "9999", "属性拷贝出错", var6);
        }
    }
}
