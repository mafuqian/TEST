package com.gingkoo.mbt.action;


import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.mbt.util.ExpCommUtils;
import com.gingkoo.orm.entity.Mbt650;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

public class Mbt650SaveAction extends WebAlterAction {

	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
			throws AppException {
		// TODO Auto-generated method stub
		UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResult().containsKey("Mat_650_Bas_ds")?multiUpdateResultBean.getUpdateResultBeanByID("Mat_650_Bas_ds"):multiUpdateResultBean.getUpdateResultBeanByID("Mat_650_Bas_2007_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
/*        if("failed".equals(validateFields(resultBean, returnBean))){
            return returnBean;
        }*/
        if(StringUtils.isEmpty(recordMap.get("dataId")) || StringUtils.isEmpty(recordMap.get("bInfRecType"))){
            recordMap.put("bInfRecType", "650");
        }
    //    process(resultBean, Mbt650.class);
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");
//        mbtCommSaveService.process(resultBean,Mbt650.class);
        ExpCommUtils.process(resultBean,Mbt650.class,mbtCommSaveService);

        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("dataId", mbtCommSaveService.getDataId());
        return returnBean;
	}

}
