package com.gingkoo.mbt.service.init;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.mbt.util.DateConvertUtils;
import com.gingkoo.mbt.util.MapToObject;
import com.gingkoo.orm.entity.Mbt210;
import org.apache.commons.lang.StringUtils;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.sys.log.Log;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InitMbt210 {

    protected static final Log logger = LogFactory.getLogger(InitMbt210.class);

    protected ROOTDAO dao = ROOTDAOUtils.getROOTDAO();

    private String bRptDateCode;

    private String monthDate;


    /**
     * 给Mbt210赋值报告时点
     * author:wuxy
     * time:2018年11月15日18:26:44
     *
     * @throws Exception
     */
    public Mbt210 initMbt210(Mbt210 mbt210) throws AppException {
        monthDate = "";
        bRptDateCode = !("").equals(mbt210.getBRptDateCode()) ? mbt210.getBRptDateCode() : "10";
        String dataId = "";
        dataId = mbt210.getDataId();
        //1.查询历史表是否存在数据
        String sql_his_table = "from  Mbt210His where odsDataId= ?  order by hisDate desc";
        List hisTableData = dao.queryByQL2List(sql_his_table, new Object[]{dataId}, null);
        if (null != hisTableData && hisTableData.size() > 0) {
            Map<String, String> map_his = new HashMap<String, String>();
            Object his_data_obj = hisTableData.get(0);
            try {
                map_his = MapToObject.objectToMap(his_data_obj);
                String sql_rpt_table = "from  Mbt210Rpt where odsDataId= ? and dataStatus='27' order by rptDate desc";
                dataId = map_his.get("dataId");
                List rptTableData = dao.queryByQL2List(sql_rpt_table, new Object[]{dataId}, null);
                if (null != rptTableData && rptTableData.size() > 0) {
                    Map<String, String> map_rpt = new HashMap<String, String>();
                    Object rpt_data_obj = hisTableData.get(0);
                    map_rpt = MapToObject.objectToMap(rpt_data_obj);
                    assignment(mbt210);
                    if (map_rpt.get("COpenDate").equals(map_his.get("COpenDate"))) {
                        //说明历史数据中的开户日期与上报数据中的一致 继续比较其他字段
                        assignmentOthScsb(mbt210);
                    }
                } else {
                    //走月结日首次上报存量账户方法
                    assignmentScsb(mbt210);
                }

            } catch (Exception e) {
                logger.error(e.getLocalizedMessage());
            }
        }

        mbt210.setBRptDateCode(bRptDateCode);
        return mbt210;
    }

    /**
     * 先取到月结日
     *
     * @param mbt210
     * @return
     */
    private void assignment(Mbt210 mbt210) {
        String oldRptDateCode = mbt210.getBRptDateCode();
        String bAcctType = mbt210.getBAcctType();
        if (!"C1".equals(bAcctType)) {
            if ("R2".equals(bAcctType) || "R3".equals(bAcctType)) {
                //R2/R3的月结日取账单日  hSettDate
                monthDate = mbt210.getHSettDate();
            } else {
                //cRepayFreqcy 还款频率
                String cRepayFreqcy = mbt210.getCRepayFreqcy();
                if ("R4".equals(bAcctType)) {
                    if ("3".equals(cRepayFreqcy)) {
                        //如果到期了
                        String cDueDate = mbt210.getCDueDate();
                        Date ncDueDate = DateConvertUtils.strToDate(cDueDate);
                        Date nowDate = DateConvertUtils.getNowDate();
                        //到期 取月底最后一天
                        if (nowDate.compareTo(ncDueDate) > 0) {
                            monthDate = DateConvertUtils.getLastDate();
                        } else {
                            //查看是否有特殊交易说明段信息  MBT_210_K

                            // 没有--->约定还款日
                            monthDate = mbt210.getHSettDate();
                            assignmenthK(mbt210);
                            //有的话取约定还款日+延长期数 延长后的日期
                        }
                    } else {
                        monthDate = DateConvertUtils.getLastDate();
                    }
                } else if ("R1".equals(bAcctType) || "D1".equals(bAcctType)) {
                    //各借据还款计划不同:还款方式填写“90-汇总报送，不区分还款方式”。 还款计划 03-按月
                    if ("3".equals(mbt210.getCRepayFreqcy()) || "90".equals(mbt210.getCRepayMode())) {
                        monthDate = DateConvertUtils.getLastDate();
                    } else {
                        String cDueDate = mbt210.getCDueDate();
                        Date ncDueDate = DateConvertUtils.strToDate(cDueDate);
                        Date nowDate = DateConvertUtils.getNowDate();
                        if (nowDate.compareTo(ncDueDate) > 0) {
                            monthDate = DateConvertUtils.getLastDate();
                        } else {
                            monthDate = mbt210.getHSettDate();
                            assignmenthK(mbt210);
                        }
                    }
                }
            }
        }
    }


    /**
     * 月结日首次上报存量账户  未上报过且借款金额不等于余额
     */
    private void assignmentScsb(Mbt210 mbt210) {
        if (mbt210.getCLoanAmt().compareTo(mbt210.getJAcctBal()) != 0) {
            bRptDateCode = "31";
        }
    }

    /**
     * 其他月度结算日&月结日账户关闭
     * 其他月度结算日  上报过且借款金额不等于余额 并且月结日不等于账户关闭日期
     * 月结日账户关闭  上报过且借款金额不等于余额 并且月结日等于账户关闭日期
     */
    private void assignmentOthScsb(Mbt210 mbt210) {
        Date monthDate1 = DateConvertUtils.strToDate(monthDate);
        Date hCloseDate = DateConvertUtils.strToDate(mbt210.getHCloseDate());

        if ((mbt210.getCLoanAmt().compareTo(mbt210.getJAcctBal()) != 0) && (monthDate1.compareTo(hCloseDate) != 0)) {
            bRptDateCode = "30";
        } else if ((mbt210.getCLoanAmt().compareTo(mbt210.getJAcctBal()) != 0) && (monthDate1.compareTo(hCloseDate) == 0)) {
            bRptDateCode = "32";
        } else {
            assignmentjRpyStatus(mbt210);
        }
    }

    /**
     * 收回逾期款项  结清
     * 对于 D1/R1/R2/R4 类账户，指收回全部逾期款项的日期(不包括月结日和账户关闭日).
     * 对于 C1 账户，指收回欠款的日期。
     */
    private void assignmentjRpyStatus(Mbt210 mbt210) {
        if ("C".equals(mbt210.getJRpyStatus())) {
            bRptDateCode = "40";
        } else {
            assignmenthCloseDate(mbt210);
        }
    }

    /**
     * 账户关闭  有账户关闭日期的hCloseDate
     *
     * @param mbt210
     * @return
     */
    private void assignmenthCloseDate(Mbt210 mbt210) {
        if (!StringUtils.isEmpty(mbt210.getHCloseDate())) {
            bRptDateCode = "20";
        }
    }

    /**
     * 特殊交易说明段
     */
    private void assignmenthK(Mbt210 mbt210) {
        //MBT_210_K
        Map<String, String> mbt210kMap = new HashMap<>();
        try {
            String sql_rpt_table = "from  Mbt210K where pdataId= ?";
            List mbt210KTableData = dao.queryByQL2List(sql_rpt_table, new Object[]{mbt210.getDataId()}, null);
            if (null != mbt210KTableData && mbt210KTableData.size() > 0) {
                for (int i = 0; i < mbt210KTableData.size(); i++) {
                    Object mbt210K_data_obj = mbt210KTableData.get(i);
                    mbt210kMap = MapToObject.objectToMap(mbt210K_data_obj);
                    String kChanTranType = mbt210kMap.get("KChanTranType");
                    if ("1".equals(kChanTranType) || "14".equals(kChanTranType) || "16".equals(kChanTranType)) {
                        //取kDueTranMon的值+原来的月结日
                        monthDate = DateConvertUtils.subMonth(monthDate,Integer.valueOf(mbt210kMap.get("KDueTranMon")).intValue());
                    }
                }
            }
        } catch (Exception e) {
            logger.error(e.getLocalizedMessage());
        }
    }
}