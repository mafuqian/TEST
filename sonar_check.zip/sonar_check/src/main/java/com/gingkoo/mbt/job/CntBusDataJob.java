package com.gingkoo.mbt.job;


import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.config.database.sql.ParamSql;
import com.gingkoo.gf4j2.framework.config.database.sql.SqlParserImpl;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.orm.entity.MbtDataSyncInfoCfg;
import com.gingkoo.orm.entity.MbtDataSyncInfoCnt;



@Component("cntBusDataJob")
public class CntBusDataJob {
	private static final Log logger = LogFactory.getLog(CntBusDataJob.class);
	
	JobResult jr = new JobResult();
	
	public Map<String, String> execute() {
		logger.info("===============++++++++++Exec cntBusDataJob begin++++++++++=============");
		jr.setErrCode("0");
		jr.setErrMsg("OK");
		try {
			ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
			//GlobalInfo GI = GlobalInfo.getCurrentInstance();
			Date date = new Date();
			String dataDate = (new SimpleDateFormat("yyyyMMdd")).format(date);
			String hql = "";
			Object[] obj = new Object[2] ;
			hql = "from MbtDataSyncInfoCnt where dataDate=?";
			
			List<MbtDataSyncInfoCnt> list = rootdao.queryByQL2List(hql,new Object[]{dataDate}, null);
			if(list.size() > 0) {
				String  sql = " from MbtDataSyncInfoCnt where dataDate = '"+ dataDate +"'";
				
				ROOTDAOUtils.getROOTDAO().delete(sql);
			}
			
			
			Map<String,String> map = new HashMap<String,String>();
			String hqlcfg = "";
			hqlcfg = "from MbtDataSyncInfoCfg ";
			List<MbtDataSyncInfoCfg> listcfg = rootdao.queryByQL2List(hqlcfg, null, null);
			if(listcfg.size() > 0) {
				for(int i=0;i<listcfg.size();i++) {
					MbtDataSyncInfoCnt cnt = new MbtDataSyncInfoCnt();
					cnt.setDataId(UuidHelper.getCleanUuid());
					cnt.setDataDate(dataDate);
					cnt.setInfoType(listcfg.get(i).getInfoType());
					cnt.setCorpId("TESTCORP");
					//cnt.setOrgId(GI.getBrcode());
					cnt.setGroupId("");
					cnt.setCntTime((new SimpleDateFormat("yyyyMMddHHmmss")).format(date));
				//	cnt.setDataCrtUser(GI.getTlrno());
					cnt.setDataCrtDate((new SimpleDateFormat("yyyyMMdd")).format(date));
					cnt.setDataCrtTime((new SimpleDateFormat("yyyyMMddHHmmss")).format(date));
				//	cnt.setDataChgUser(GI.getTlrno());
					cnt.setDataChgDate((new SimpleDateFormat("yyyyMMdd")).format(date));
					cnt.setDataChgTime((new SimpleDateFormat("yyyyMMddHHmmss")).format(date));
					String sqlApv = listcfg.get(i).getApvDataSql();
					String sqlUnApv = listcfg.get(i).getUnapvDataSql();
					String sqlApvAll = listcfg.get(i).getDataSql();
					SqlParserImpl parser = new SqlParserImpl();
					BigDecimal cnt1 = new BigDecimal("0");
					BigDecimal cnt2 = new BigDecimal("0");
					BigDecimal cnt3 = new BigDecimal("0");
					if(null != sqlApv && !"".equals(sqlApvAll)) {
						ParamSql parse = parser.parse(sqlApv, map);
						String query = parse.getSql();
						Iterator it = rootdao.queryBySQL(query);
						while(it.hasNext()){
							cnt1 = (BigDecimal) it.next();
							
						}
					}
					
					if(null != sqlUnApv && !"".equals(sqlUnApv)) {
						ParamSql parse = parser.parse(sqlUnApv, map);
						String query = parse.getSql();
						Iterator it = rootdao.queryBySQL(query);
						while(it.hasNext()){
							cnt2 = (BigDecimal) it.next();
							cnt.setUnapvDataCnt(cnt2.toString());
						}
					}
					
					if(null != sqlApvAll && !"".equals(sqlApvAll)) {
						ParamSql parse = parser.parse(sqlApvAll, map);
						String query = parse.getSql();
						Iterator it = rootdao.queryBySQL(query);
						while(it.hasNext()){
							cnt3 = (BigDecimal) it.next();
						}
					}else {
						cnt3 = cnt1.add(cnt2);
					}
					cnt.setApvDataCnt(cnt1.toString());
					cnt.setUnapvDataCnt(cnt2.toString());
					cnt.setDataCnt(cnt3.toString());
					ROOTDAOUtils.getROOTDAO().save(cnt);
				}
			}
		
		} catch (Exception arg6) {
			arg6.printStackTrace();
			logger.info("操作失败，错误信息：" + arg6.getMessage());
			jr.setErrCode("E");
			jr.setErrMsg("操作失败，错误信息：" + arg6.getMessage());
			return jr.getMap();
		}

		logger.info("===============++++++++++Exec cntBusDataJob end++++++++++=============");
		return jr.getMap();
	}
	
	


	
	
	


	

	
	
}