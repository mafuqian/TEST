package com.gingkoo.mbt.dao;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.connection.ConnectionProvider;
import org.hibernate.engine.SessionFactoryImplementor;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.SystemConstant;
import com.gingkoo.gf4j2.framework.dao.base.HQLDAO;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.dao.range.PageQueryCondition;
import com.gingkoo.gf4j2.framework.dao.range.PageQueryResult;
import com.gingkoo.gf4j2.framework.entity.base.EntityProxy;
import com.gingkoo.gf4j2.framework.err.ErrorCode;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.util.DateHelper;
import com.gingkoo.gf4j2.framework.util.ExceptionUtil;
import com.gingkoo.mbt.util.CompareUtils;
import com.gingkoo.orm.entity.MbtDataChangeLog;
import com.gingkoo.orm.entity.MbtDataCheckField;

@Repository("mbtRootDao")
public class MbtRootDao extends HQLDAO {

	private static final Log log = LogFactory.getLogger(ROOTDAO.class);

	public MbtRootDao() {
		super();
	}

	/**
	 * @title 通过键值查询
	 * @Description 通过键值查询，返回数据库实体对象
	 * @param id
	 * @return Object
	 * @throws CommonException
	 */
	public <T> T query(Class<T> cls, Serializable id) throws CommonException {
		this.getHibernateTemplate().setCacheQueries(true);
		if (log.isDebugEnabled()) {
			log.debug("query(Class,String) - start"); //$NON-NLS-1$
		}
		try {

			Object reObj = this.getHibernateTemplate().get(cls, id);
			if (log.isDebugEnabled()) {
				log.debug("query(Class,String) - end"); //$NON-NLS-1$
			}
			return (T)reObj;
		} catch (Exception e) {
			log.error("query(String)", e); //$NON-NLS-1$

			ExceptionUtil.throwCommonException(e.getMessage(),
					ErrorCode.ERROR_CODE_DAO, e);
		}

		if (log.isDebugEnabled()) {
			log.debug("query(Class,String) - end"); //$NON-NLS-1$
		}
		return null;
	}

	/**
	 * @title 保存数据实体
	 * @Description 保存数据实体，返回吃久态实体
	 * @param obj
	 * @return
	 * @throws CommonException
	 */
	public Object save(Object obj) throws CommonException {
		this.getHibernateTemplate().setCacheQueries(false);
		if (log.isDebugEnabled()) {
			log.debug("save(Object) - start"); //$NON-NLS-1$
		}
		Object reObj = null;

		try {
			if (obj != null) {
				reObj = this.getHibernateTemplate().save(obj);
			}
		} catch (Exception e) {
			log.error("save(Object)", e); //$NON-NLS-1$
			ExceptionUtil.throwCommonException(e.getMessage(),
					ErrorCode.ERROR_CODE_DAO, e);
		}
		if (log.isDebugEnabled()) {
			log.debug("save(Object) - end"); //$NON-NLS-1$
		}
		return reObj;
	}

	/**
	 * @title 更新数据库实体
	 * @Description 更新数据库实体
	 * @param obj
	 * @throws CommonException
	 */
	public void update(Object obj) throws CommonException {
		this.getHibernateTemplate().setCacheQueries(false);
		if (log.isDebugEnabled()) {
			log.debug("update(Object) - start"); //$NON-NLS-1$
		}

		try {
			this.getHibernateTemplate().update(obj);
		} catch (Exception e) {
			log.error("update(Object)", e); //$NON-NLS-1$

			ExceptionUtil.throwCommonException(e.getMessage(),
					ErrorCode.ERROR_CODE_DAO, e);
		}

		if (log.isDebugEnabled()) {
			log.debug("update(Object) - end"); //$NON-NLS-1$
		}
	}

	public void audit(Object obj) throws CommonException {
		this.getHibernateTemplate().setCacheQueries(false);
		if (log.isDebugEnabled()) {
			log.debug("update(Object) - start"); //$NON-NLS-1$
		}

		try {
			this.getHibernateTemplate().update(obj);

			EntityProxy<Object> ep = EntityProxy.of(obj);
			String dataId = ep.getDataId();
			String sql = " from MbtDataChangeLog where pdataId='" + dataId +"'";
			ROOTDAOUtils.getROOTDAO().delete(sql);

		} catch (Exception e) {
			log.error("update(Object)", e); //$NON-NLS-1$

			ExceptionUtil.throwCommonException(e.getMessage(),
					ErrorCode.ERROR_CODE_DAO, e);
		}

		if (log.isDebugEnabled()) {
			log.debug("update(Object) - end"); //$NON-NLS-1$
		}
	}

	/**
	 * @title 插入或更新数据库实体
	 * @Description 插入或更新数据库实体，不推荐使用
	 * @deprecated
	 * @param obj
	 * @return
	 * @throws CommonException
	 */
	public Object saveOrUpdate(Object obj) throws CommonException {
		this.getHibernateTemplate().setCacheQueries(false);

		if (log.isDebugEnabled()) {
			log.debug("saveOrUpdate(Object) - start"); //$NON-NLS-1$
		}
		Object reObj = null;
		try {
			ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
			Class testTypeClass=obj.getClass();
			String tableName = testTypeClass.getSimpleName();
			if(!"".equals(tableName) && null != tableName) {
				MbtDataCheckField a = new MbtDataCheckField();
				String hql = "from MbtDataCheckField where tableName = ? ";
				List<MbtDataCheckField> list = rootdao.queryByQL2List(hql, new Object[] {tableName}, null);
				boolean flag = false;
				String pTableName = "";
				if(list.size() > 0) {
					String headTable = "";
					Map<String,MbtDataCheckField> map = new HashMap<String,MbtDataCheckField>();
					Map<String,List<Object>> map1 = new HashMap<String,List<Object>>();
					for(int i = 0;i<list.size();i++) {
						map.put(list.get(i).getField(),list.get(i));

						if(!flag){
							pTableName = list.get(i).getPartTableName();
							flag = true;
						}
					}

					String hqltable = "from "+ tableName + " where dataId=?";
					String data_id = BeanUtils.getProperty(obj,"dataId");
					List dataList = rootdao.queryByQL2List(hqltable, new Object[] {data_id}, null);

					String tableNameTmp = tableName +"Tmp";
					String hql1 = "from " + tableNameTmp +" where odsDataId=? order by odsDataMarkTime desc";
					List tmpDataList = rootdao.queryByQL2List(hql1, new Object[] {data_id}, null);

					if(dataList.size() > 0 && tmpDataList.size() > 0) {
						Object objTmp = testTypeClass.newInstance();
						BeanUtils.copyProperties(objTmp, tmpDataList.get(0));
						map1 = CompareUtils.getModifyContentListValue(obj,objTmp , map);
					}else {
//						Object objTmp = testTypeClass.newInstance();
//						map1 = CompareUtils.getModifyContentListValue(obj,objTmp , map);
					}


					String hql311 = " from MbtDataChangeLog where pdataId= ? and part = ?";
					List list31 = rootdao.queryByQL2List(hql311, new Object[] {data_id,list.get(0).getPart()}, null);

					if(list31.size() > 0) {
						for(int i = 0;i<list31.size();i++) {
							MbtDataChangeLog log = (MbtDataChangeLog) list31.get(i);
							this.delete(log);
						}
					}

					String bakSql = "from " + tableName + "TodayBak where dataId= ?";
					List bakSqlList = rootdao.queryByQL2List(bakSql, new Object[]{data_id}, null);

					if (!CollectionUtils.isEmpty(bakSqlList)) {
						for (int i = 0; i < bakSqlList.size(); i++) {
							this.delete(bakSqlList.get(i));
						}
					}

					String pDataId = "";
					if(pTableName.equals(tableName)){
						pDataId = data_id;
					}else{
						pDataId = BeanUtils.getProperty(obj,"pdataId");
					}

					for (String in : map1.keySet()) {
						MbtDataChangeLog changeLog = new MbtDataChangeLog();
						changeLog.setDataId(UuidHelper.getCleanUuid());
						changeLog.setPdataId(pDataId);
						changeLog.setDtlDataId(data_id);
						changeLog.setPart(list.get(0).getPart());
						changeLog.setField(in);
						changeLog.setDataCrtDate(DateHelper.today());
						changeLog.setDataCrtTime(DateHelper.now());
						changeLog.setRsv1("界面修改");
						List<Object> l = new ArrayList<Object>();
						l = map1.get(in);//得到每个key多对用value的值
						if(l.size() >0){
							Object value = l.get(0);
							if(null == value) {
								changeLog.setFieldValue("");
							}else {
								changeLog.setFieldValue(l.get(0).toString());
							}
							
						}

						if(l.size() >1){
							if (null==l.get(1)){
								changeLog.setFieldValueOld("");

							} else{
                                changeLog.setFieldValueOld(l.get(1).toString());

                            }
						}

						this.getHibernateTemplate().merge(changeLog);
					}
				}
			}

			reObj = this.getHibernateTemplate().merge(obj);


		} catch (Exception e) {
			log.error("saveOrUpdate(Object)", e); //$NON-NLS-1$

			ExceptionUtil.throwCommonException(e.getMessage(),
					ErrorCode.ERROR_CODE_DAO, e);
		}

		if (log.isDebugEnabled()) {
			log.debug("saveOrUpdate(Object) - end"); //$NON-NLS-1$
		}

		return reObj;
	}





	public Map<String, String> objectToMap(Object obj) throws Exception {
		if (obj == null)
			return null;

		Map<String, String> map = new HashMap<String, String>();

		BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
		PropertyDescriptor[] propertyDescriptors = beanInfo
				.getPropertyDescriptors();
		for (PropertyDescriptor property : propertyDescriptors) {
			String key = property.getName();


			if (key.compareToIgnoreCase("class") == 0) {
				continue;
			}
			Method getter = property.getReadMethod();
			String value = getter != null ? getter.invoke(obj) + "" : null;

			if(null == value || "".equals(value)) {
				String name = key.substring(0, 1).toLowerCase()+key.substring(1,key.length());
				property.setName(name);
				getter = property.getReadMethod();
				value = getter != null ? getter.invoke(obj) + "" : null;
			}

			map.put(key, value);
		}

		return map;
	}


	/**
	 * @title 删除数据库实体
	 * @Description 删除数据库实体
	 * @param obj
	 * @throws CommonException
	 */
	public void delete(Object obj) throws CommonException {
		this.getHibernateTemplate().setCacheQueries(false);
		if (log.isDebugEnabled()) {
			log.debug("delete(Object) - start"); //$NON-NLS-1$
		}
		try {
			if (obj != null) {
				this.getHibernateTemplate().delete(obj);
			}
		} catch (Exception e) {
			log.error("save(Object)", e); //$NON-NLS-1$
			ExceptionUtil.throwCommonException(e.getMessage(),
					ErrorCode.ERROR_CODE_DAO, e);
		}
		if (log.isDebugEnabled()) {
			log.debug("save(Object) - end"); //$NON-NLS-1$
		}

	}

	/**
	 * @title 删除数据库实体，依据对象键值
	 * @Description 删除数据库实体，依据对象键值
	 * @param id
	 * @throws CommonException
	 */
	public void delete(Class cls, String id) throws CommonException {
		this.getHibernateTemplate().setCacheQueries(false);
		if (log.isDebugEnabled()) {
			log.debug("delete(Class,String) - start"); //$NON-NLS-1$
		}

		try {
			this.getHibernateTemplate().delete(query(cls, id));
		} catch (Exception e) {
			log.error("delete(Class,String)", e); //$NON-NLS-1$

			ExceptionUtil.throwCommonException(e.getMessage(),
					ErrorCode.ERROR_CODE_DAO, e);
		}

		if (log.isDebugEnabled()) {
			log.debug("delete(Class,String) - end"); //$NON-NLS-1$
		}
	}

	/**
	 * @title 依据HQL进行分页查询
	 * @Description 依据HQL进行分页查询，只返回数据LIST，不提供统计信息
	 * @param hql
	 * @param startPage
	 * @param maxRows
	 * @return
	 * @throws CommonException
	 */
	public List pageQueryByHql(String hql, int startPage, int maxRows)
			throws CommonException {
		this.getHibernateTemplate().setCacheQueries(true);
		if (log.isDebugEnabled()) {
			log.debug("pageQueryByHql(String, int, int) - start"); //$NON-NLS-1$
		}

		List returnValue = new ArrayList();
		startPage = startPage >= 1 ? startPage : 1;
		int firstResult = (startPage - 1)
				* (maxRows > 0 ? maxRows : SystemConstant.MAX_ROWS);
		int rows = maxRows;
		rows = (rows == 0 ? SystemConstant.MAX_ROWS : rows);

		try {
			Query query = this.getSession().createQuery(hql);
			query.setFirstResult(firstResult);
			if (rows != -1) {
				query.setMaxResults(rows + 1);
			}
			returnValue = query.list();

		} catch (HibernateException e) {
			log.error("queryByCondition(String, int, int)", e); //$NON-NLS-1$
			ExceptionUtil.throwCommonException(e.getMessage(),
					ErrorCode.ERROR_CODE_DAO, e);
		}

		if (log.isDebugEnabled()) {
			log.debug("queryByCondition(String, int, int) - end"); //$NON-NLS-1$
		}
		return returnValue;
	}

	/**
	 * 分页查询（每次获取行数）
	 * @param pageIndex 第几页
	 * @param pageSize 每页显示行数
	 * @param hql
	 * @return
	 * @throws CommonException
	 */
	public PageQueryResult pageQueryByHql(int pageIndex, int pageSize, String hql) throws CommonException {
		PageQueryCondition queryCondition = new PageQueryCondition();
		queryCondition.setQueryString(hql);
		queryCondition.setPageIndex(pageIndex);
		queryCondition.setPageSize(pageSize);
		queryCondition.setCacheCount(false);
		return pageQueryByQL(queryCondition);
	}

	/**
	 * 分页查询
	 * @param pageIndex 第几页
	 * @param pageSize 每页显示行数
	 * @param hql
	 * @param cacheCount （前台传入是否缓存了总页数，ture表示不查询总页数，false表示查询，默认为false）
	 * @return
	 * @throws CommonException
	 */
	public PageQueryResult pageQueryByHql(int pageIndex, int pageSize, String hql,boolean cacheCount) throws CommonException {
		PageQueryCondition queryCondition = new PageQueryCondition();
		queryCondition.setQueryString(hql);
		queryCondition.setPageIndex(pageIndex);
		queryCondition.setPageSize(pageSize);
		queryCondition.setCacheCount(cacheCount);
		return pageQueryByQL(queryCondition);
	}

	/**
	 * ����hql��ѯ����
	 * @param hql
	 * @return
	 * @throws CommonException
	 */
	public Integer queryByHqlToCount(String hql) throws CommonException{
		return  Integer.parseInt(this.queryByQL(hql).next().toString());
	}

	public Object queryByHqlMax(String hql)  throws CommonException{
		final String tempHql = hql;
		Object max = null;
		try {
			max = (Object) getHibernateTemplate().execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					return session.createQuery(tempHql).uniqueResult();
				}
			});
		} catch (Exception e) {
			throw new CommonException(e.getMessage());
		}
		return max;
	}


	public List queryByCondition(String whereString) throws CommonException {
		try {
			List list = this.getHibernateTemplate().find(whereString);
			return list;
		} catch (Exception e) {
			ExceptionUtil.throwCommonException(e.getMessage(),
					ErrorCode.ERROR_CODE_GLOBALINFO_SELECT, e);
		}
		return null;
	}

	public int executeSql(String sql) throws CommonException{
		final String tempSql = sql;
		Integer row = null;
		try {
			row = getHibernateTemplate().execute(new HibernateCallback<Integer>() {
				public Integer doInHibernate(Session session) throws HibernateException {
					SQLQuery sqlQuery = session.createSQLQuery(tempSql);
					return sqlQuery.executeUpdate();
				}
			});
		} catch (Exception e) {
			ExceptionUtil.throwCommonException(e.getMessage(),ErrorCode.ERROR_CODE_GLOBALINFO_SELECT, e);
		}
		if (row==null) {
			row = 0;
		}
		return row;
	}

	public List executeSql(String sql, Class clazz) throws CommonException{
		final String tempSql = sql;
		final Class<?> tempclazz = clazz;
		List retList = null;
		try {
			retList = getHibernateTemplate().execute(new HibernateCallback<List>() {
				public List doInHibernate(Session session) throws HibernateException {
					SQLQuery sqlQuery = session.createSQLQuery(tempSql);
					if(tempclazz!=null){
						sqlQuery.addEntity(tempclazz);
					}
					return sqlQuery.list();
				}
			});
		} catch (Exception e) {
			ExceptionUtil.throwCommonException(e.getMessage(),ErrorCode.ERROR_CODE_GLOBALINFO_SELECT, e);
		}
		return retList;
	}

	/**
	 * 获取ConnectionProvider
	 * @return
	 */
	public ConnectionProvider getConnectionProvider(){
		SessionFactory sf = this.getSessionFactory();
		ConnectionProvider cp = ((SessionFactoryImplementor) sf).getConnectionProvider();
		return cp;
	}

	public Connection getConnection(ConnectionProvider connProvider) throws SQLException{
		return connProvider.getConnection();
	}

	public void closeConnection(ConnectionProvider connProvider,Connection conn) throws SQLException{
		connProvider.closeConnection(conn);
	}



}
