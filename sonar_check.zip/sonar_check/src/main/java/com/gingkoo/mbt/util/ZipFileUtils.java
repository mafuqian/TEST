package com.gingkoo.mbt.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * Zip工具类
 * 可在此类中对文件进行压缩解压等操作
 * 
 * @author  kane
 * @version  [版本号, 2016年10月18日]
 * @see  [相关类/方法]
 * @since  [产品/模块版本]
 */
public class ZipFileUtils {
	private static final int BUFFER = 1024;
	private static final Log logger = LogFactory.getLog(ZipFileUtils.class);

	public ZipFileUtils() {
	}
	
	/**
	 * 创建目录
	 * 
	 * @param dir 目录名称
	 * @return 成功/失败
	 * @see [类、类#方法、类#成员]
	 */
	public static boolean createDir(String dir) {
		try {
			File e = new File(dir);
			e.mkdirs();
			return true;
		} catch (Exception var2) {
			var2.printStackTrace();
			return false;
		}
	}
	
	/**
	 * 级联创建多级目录
	 * 
	 * @param dirFile 目录名称
	 * @see [类、类#方法、类#成员]
	 */
	private static void fileProber(File dirFile) {
		File parentFile = dirFile.getParentFile();
		if (!parentFile.exists()) {
			fileProber(parentFile);
			parentFile.mkdir();
		}

	}
	
	/**
	 * 将Zip压缩包读取到流中
	 * 
	 * @param destFile Zip压缩文件
	 * @param zis 流对象
	 * @throws Exception
	 * @see [类、类#方法、类#成员]
	 */
	private static void decompressFile(File destFile, ZipInputStream zis) throws Exception {
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(destFile));
		byte[] data = new byte[1024];

		int count;
		while ((count = zis.read(data, 0, 1024)) != -1) {
			bos.write(data, 0, count);
		}

		bos.close();
	}
	
	/**
	 * 压缩文件
	 * 
	 * @param list 文件列表
	 * @param zipFileName zip压缩包名称
	 * @throws Exception
	 * @see [类、类#方法、类#成员]
	 */
	public static File zipFile(List<String> list, String zipFileName) throws Exception {
		File zipFile = new File(zipFileName);
		FileOutputStream os = new FileOutputStream(zipFile);
		BufferedOutputStream bos = new BufferedOutputStream(os);
		ZipOutputStream zos = new ZipOutputStream(bos);

		for (int i = 0; i < list.size(); ++i) {
			File inFile = new File((String) list.get(i));
			FileInputStream fis = new FileInputStream(inFile);
			BufferedInputStream bis = new BufferedInputStream(fis);
			zos.putNextEntry(new ZipEntry(inFile.getName()));
			boolean length = false;
			byte[] buf = new byte[1024];

			int var12;
			while ((var12 = bis.read(buf)) > 0) {
				zos.write(buf, 0, var12);
			}
			fis.close();
			bis.close();
			zos.closeEntry();
		}
		
		os.close();
		bos.close();
		zos.close();
		return zipFile;
	}
	
	/**
	 * 解压文件
	 * 
	 * @param fileName 解压到的目录
	 * @param destDir zip压缩包名称
	 * @return 解压后的文件列表对象
	 * @see [类、类#方法、类#成员]
	 */
	public static List<String> unzipFile(String fileName, String destDir) {
		ArrayList list = new ArrayList();

		try {
			File e = new File(destDir);
			FileInputStream fis = new FileInputStream(fileName);
			ZipInputStream zis = new ZipInputStream(fis);

			for (ZipEntry entry = null; (entry = zis.getNextEntry()) != null; zis.closeEntry()) {
				String dir = e.getPath() + File.separator + entry.getName();
				File dirFile = new File(dir);
				fileProber(dirFile);
				if (entry.isDirectory()) {
					dirFile.mkdirs();
				} else {
					decompressFile(dirFile, zis);
					list.add(dir);
				}
			}

			zis.close();
			fis.close();
			return list;
		} catch (Exception var9) {
			var9.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 复制文件
	 * 
	 * @param f1 源文件
	 * @param f2 目标文件
	 * @return 成功/失败
	 * @throws Exception
	 * @see [类、类#方法、类#成员]
	 */
	public static boolean copyTwoFile(String f1, String f2) throws Exception {
		logger.info("copy file from " + f1 + " to " + f2);
		int length = 2097152;
		FileInputStream in = new FileInputStream(f1);
		FileOutputStream out = new FileOutputStream(f2);
		byte[] buffer = new byte[length];

		while (true) {
			int ins = in.read(buffer);
			if (ins == -1) {
				in.close();
				out.flush();
				out.close();
				return true;
			}

			out.write(buffer, 0, ins);
		}
	}
	
	/**
	 * 赋值一个文件到指定目录
	 * 
	 * @param fileName 源文件
	 * @param destDir 目标文件夹
	 * @return 成功/失败
	 * @see [类、类#方法、类#成员]
	 */
	public static boolean copyFile(String fileName, String destDir) {
		try {
			File e = new File(fileName);
			copyTwoFile(fileName, destDir + File.separator + e.getName());
			return true;
		} catch (Exception var3) {
			var3.printStackTrace();
			return false;
		}
	}

	public static void main(String[] args) {
		System.out.println(2147483647);
		List list = unzipFile(
				"/Users/YiSiliang/Desktop/CICS/download/CXQQ31029000001300001123456789012345678901234567890.ZIP",
				"/Users/YiSiliang/Desktop/CICS/upload");
		System.out.println(list.size());

		for (int e = 0; e < list.size(); ++e) {
			System.out.println((String) list.get(e));
		}

		try {
			zipFile(list, "/Users/YiSiliang/Desktop/CICS/download/11111.ZIP");
		} catch (Exception var3) {
			var3.printStackTrace();
		}

	}
}
