package com.gingkoo.mbt.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.mbt.service.MbtLocaCommitToApvService;
import com.gingkoo.orm.entity.LocateInf;
import com.gingkoo.orm.entity.PerTagInf;

public class EntTagTabAlterAction extends WebAlterAction {
    private static final String DATASET_ID = "EntTag_TabPageList_ds";
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse respone) throws AppException {
        UpdateReturnBean updateReturnBean = new UpdateReturnBean();
        UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
        Map<String,String> map = new HashMap<>();
        UpdateReturnBean returnBean = new UpdateReturnBean();

        String objTagId=updateResultBean.getParamMap().get("objTagId");
        int size=deleteSheetData(objTagId);
        if (size>0){
            WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
            MbtLocaCommitToApvService mbtCommCommitToApvService = (MbtLocaCommitToApvService) context.getBean("mbtLocaCommitToApvService");
            mbtCommCommitToApvService.commitToApprove(updateResultBean, PerTagInf.class,returnBean);
            if("".equals(returnBean.getParameter("E_CODE"))) {
            	updateReturnBean.setParameter("isOptSucc", "true");
            }else {
            	updateReturnBean.setParameter("isOptSucc", "false");
            }
        }else {
            updateReturnBean.setParameter("isOptSucc", "false");

        }


        return updateReturnBean;
    }
    private  int  deleteSheetData(String objTagId) throws CommonException {
    	ROOTDAO dao = ROOTDAOUtils.getROOTDAO();

        String hql = "from PerLocateInf where 1=1 and objTagId = '"+objTagId.trim()+"'";
        List<LocateInf> list = dao.queryByQL2List(hql);;
        return  list.size();
    }
}
