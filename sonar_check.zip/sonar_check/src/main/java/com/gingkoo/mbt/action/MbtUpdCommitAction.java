package com.gingkoo.mbt.action;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import com.gingkoo.mbt.dao.MbtRootDao;
import com.gingkoo.mbt.util.MapToObject;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import org.springframework.beans.factory.annotation.Autowired;

import javax.swing.text.html.HTMLDocument;

public abstract class MbtUpdCommitAction extends WebAlterAction {
    protected static final Log logger = LogFactory.getLogger(MbtSingleRecordAction.class);

    protected ROOTDAO dao = ROOTDAOUtils.getROOTDAO();

    private String dataId;

    protected String getDataId() {
        return dataId;
    }

    /**
     * @param resultBean 包含记录数据的 resultBean
     * @param clazz      实体类
     * @throws AppException app异常
     */
    public void process(UpdateResultBean resultBean, Class<?> clazz) throws AppException {

        Map<String, String> recordMap = resultBean.next();
        resultBean.getParamMap().forEach((k, v) -> {
            if (!StringUtils.isEmpty(v)) {
                recordMap.put(k, v);
            }
        });

        Object bean;

        Map<String,String> oldMap = new HashMap<>();
        this.dataId = recordMap.get("pdataId");
//        if (null == dataId || "".equals(dataId)){
//            dataId = recordMap.get("dataId");
//        }
        //查到RPT表对应的数据
        String hql = "from "+recordMap.get("tableName")+" where dataId=?";
        Iterator iterator = ROOTDAOUtils.getROOTDAO().queryByQL(hql,new Object[]{dataId},null);
        Object tmp = null;
        if(iterator.hasNext()){
            tmp = iterator.next();
            if (null==tmp){
                throw new AppException("找不到RPT表对应的数据");
            }else{
                try {
                    oldMap =  MapToObject.objectToMap(tmp);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        recordMap.put("dataChgUser", GlobalInfo.getCurrentInstance().getTlrno());
        recordMap.put("dataChgTime", DateUtil.get14Date());
        recordMap.put("dataChgDate", DateUtil.get8Date());
        recordMap.put("dataStatus", "11");
        recordMap.put("orgId",oldMap.get("orgId"));
        recordMap.put("corpId",oldMap.get("corpId"));
        recordMap.put("groupId",oldMap.get("groupId"));

        // 不含dataId，新增数据
            try {
                bean = clazz.newInstance();
            } catch (InstantiationException | IllegalAccessException e) {
                logger.error(e.getLocalizedMessage());
                throw new AppException("系统错误，创建类" + clazz.getName() + "实例时出错。");
            }

            dataId = UUID.randomUUID().toString().replace("-", "");
            recordMap.put("dataId", dataId);
            recordMap.put("dataCrtUser", GlobalInfo.getCurrentInstance().getTlrno());
            recordMap.put("dataCrtTime", DateUtil.get14Date());
            recordMap.put("dataCrtDate", DateUtil.get8Date());
            recordMap.put("dataDate", DateUtil.get8Date());
        if (null != recordMap.get("dataCrtTime")) {
            recordMap.put("dataCrtTime", trim(recordMap.get("dataCrtTime")));
        }

        if (null != recordMap.get("dataApvTime")) {
            recordMap.put("dataApvTime", trim(recordMap.get("dataApvTime")));
        }
        try {
            BeanUtils.copyProperties(bean,recordMap);
            dao.saveOrUpdate(bean);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getLocalizedMessage());
        }
//        mapToObject(bean, recordMap);
    }

    public String trim(String str) {
        if(!"".equals(str) && null != str) {
            str = str.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
        }

        return str;
    }
//    public Map<String, String> objectToMap(Object obj) throws Exception {
//        if (obj == null)
//            return null;
//
//        Map<String, String> map = new HashMap<String, String>();
//
//        BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
//        PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
//        for (PropertyDescriptor property : propertyDescriptors) {
//            String key = property.getName();
//            if (key.compareToIgnoreCase("class") == 0) {
//                continue;
//            }
//            Method getter = property.getReadMethod();
//            String value = getter != null ? getter.invoke(obj) + "" : null;
//            map.put(key, value);
//        }
//
//        return map;
//    }
}
