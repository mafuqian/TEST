package com.gingkoo.mbt.action;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.orm.entity.MbtUnusalList;

public class Mbt212CommitAction extends MbtUpdCommitAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mbt212Upd_Opt_ds");
        List<Map<String, String>> records = resultBean.getTotalList();
        StringBuffer partName = new StringBuffer("");
        StringBuffer partType = new StringBuffer("");
        for(Map<String, String> one:records){
            if (!(one.get("partName")==null || "".equals(one.get("partName")))){
                partName.append(one.get("partName")).append(",");
            }
            if (!(one.get("partType")==null || "".equals(one.get("partType")))){
                partType.append(one.get("partType")).append(",");
            }
        }
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
//        if(StringUtils.isEmpty(recordMap.get("dataId"))){
        String opr = resultBean.getParamMap().get("opr");

        if (opr.equals("upd")){
                recordMap.put("infRecType", "212");
                recordMap.put("optType", "01");
                recordMap.put("partName",partName.substring(0,partName.length()-1));
                recordMap.put("partType",partType.substring(0,partType.length()-1));
            }else if (opr.equals("del")){
                recordMap.put("infRecType", "213");
                recordMap.put("optType", "02");
                recordMap.put("partName",partName.substring(0,partName.length()-1));
                recordMap.put("partType",partType.substring(0,partType.length()-1));
            }
//        }
//        resultBean.getParamMap().put("optType",recordMap.get("optType"));
        /** startDate和endDate不为空则转换*/
        if (!StringUtils.isEmpty(resultBean.getParamMap().get("startDate"))){
            resultBean.getParamMap().put("startDate",new SimpleDateFormat("YYYYMMdd").format(Long.valueOf(resultBean.getParamMap().get("startDate"))));
        }
        if (!StringUtils.isEmpty(resultBean.getParamMap().get("endDate"))){
            resultBean.getParamMap().put("endDate",new SimpleDateFormat("YYYYMMdd").format(Long.valueOf(resultBean.getParamMap().get("endDate"))));
        }
        recordMap.put("tableName","Mbt210Rpt");

        process(resultBean, MbtUnusalList.class);
        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("dataId", getDataId());
        return returnBean;
    }
}
