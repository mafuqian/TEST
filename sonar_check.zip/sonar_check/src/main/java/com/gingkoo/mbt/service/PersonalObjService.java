package com.gingkoo.mbt.service;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.util.DataObjectUtils;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.GpBmSysParam;
import com.gingkoo.mbt.webservice.ConnectWebservices;
import com.gingkoo.orm.entity.ToCheckInf;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.awt.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

@Component
public class PersonalObjService {
    @Autowired
    ConnectWebservices connectWebservices;



    public boolean psObjCorrectResultQueryReq(String querymessage){
        return true;

    }
    public static String getRandomFileName() {

        SimpleDateFormat simpleDateFormat;

        simpleDateFormat = new SimpleDateFormat("yyyyMMdd");

        Date date = new Date();

        String str = simpleDateFormat.format(date);

        Random random = new Random();

        int rannum = (int) (random.nextDouble() * (99999 - 10000 + 1)) + 10000;// 获取5位随机数

        return rannum + str;// 当前时间
    }
    public static Set<String> mapToObject(Object object, Map map) throws AppException {
        Map<Object, Object> candidates = new HashMap();
        Iterator var4 = map.keySet().iterator();

        while(var4.hasNext()) {
            Object key = var4.next();
            char[] chars = ((String)key).toCharArray();
            if (Character.isUpperCase(chars[1])) {
                chars[0] = (char)(chars[0] - 32);
                candidates.put(String.valueOf(chars), map.get(key));
            }
        }

        map.putAll(candidates);

        try {
            return DataObjectUtils.mapToObject(object, map);
        } catch (Exception var6) {
            throw new AppException("SY", "9999", "属性拷贝出错", var6);
        }
    }

    public  Map<String,String> shengchengfiles(Map<String,String> map, Object bean, String ftlName)  throws AppException {
        ToCheckInf toCheckInf;
        Map<String,String> fileStr = new HashMap<>();
        try {

            String filePath = "C:/Users/N/Desktop/gg" +"/"+ DateUtil.get14Date()+"/";
            File file = new File(filePath);
            if (!file.exists()) {
                file.mkdirs();
            }

            String fileName =getRandomFileName()+".txt";
            File f = new File(filePath);
            //创建一个freemarker.template.Configuration实例，它是存储 FreeMarker 应用级设置的核心部分
            //指定版本号
            Configuration cfg = new Configuration(Configuration.VERSION_2_3_22);
            ROOTDAO dao = ROOTDAOUtils.getROOTDAO();
            String sql = "from GpBmSysParam where param_id='TEMPPATH' and PARAM_GROUP_ID='MBT'";
            List<GpBmSysParam> gpBmSysParamList = dao.queryByQL2List(sql);
            if (gpBmSysParamList.size()>0){
                /**设置模板目录*/
                cfg.setDirectoryForTemplateLoading(new File(gpBmSysParamList.get(0).getParamValue()));
                /**设置默认编码格式*/
                cfg.setDefaultEncoding("UTF-8");
                /**获取数据*/
//                List<Object> d101List = new ArrayList<>();
                Map<String,Object> Gmap=new HashMap<>();
                if (map.size()>0) {
                    mapToObject(bean,map);

/*                    BeanUtils.copyProperties(bean,map);*/
                }
                    Gmap.put("toCheckInf",bean);
                Gmap.put("user",map.get("userCode"));
                Gmap.put("pass",map.get("passWord"));

                //从设置的目录中获得模板
                Template temp = cfg.getTemplate(ftlName);
                //合并模板和数据模型
                PrintWriter pw = new PrintWriter(new File(f, fileName));
                temp.process(Gmap, pw);
                //关闭
                pw.flush();
                pw.close();
                //生成字符串并调用接口
                fileStr.put(filePath+fileName,fileToStr(filePath+fileName));
            }else{
                throw new AppException("模板文件不存在");
            }
        }catch (Exception e){
            throw new AppException("生成个人异议字符串/打包文件失败");
        }
        return fileStr;
    }
    private String fileToStr(String fileName) throws AppException{
        String fileStr = "";
        try {
            FileInputStream fis = new FileInputStream(fileName);
            InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
            //将file文件内容转成字符串
            BufferedReader bf = new BufferedReader(isr);
            String content = "";
            StringBuilder sb = new StringBuilder();
            while (content != null) {
                content = bf.readLine();
                if (content == null) {
                    break;
                }
                sb.append(content.trim());
            }
            bf.close();
            fileStr = sb.toString();
        }catch (Exception e){
            e.printStackTrace();
        }
        return fileStr;
    }


}
