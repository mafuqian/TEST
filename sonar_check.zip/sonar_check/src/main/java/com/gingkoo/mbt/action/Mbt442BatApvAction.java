package com.gingkoo.mbt.action;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommExBatApvService;
import com.gingkoo.orm.entity.MbtUnusalList;

public class Mbt442BatApvAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
            throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        List<Map<String, String>> records = multiUpdateResultBean.getUpdateResultBeanByID("Mbt442Apv_ds").getTotalList();
        new MbtCommExBatApvService(MbtUnusalList.class, records).approve();
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }
}
