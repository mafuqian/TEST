package com.gingkoo.mbt.service.init;

import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.sys.log.Log;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.orm.entity.Mbt110;
import com.gingkoo.orm.entity.Mbt210;
import com.gingkoo.orm.entity.Mbt220;
import com.gingkoo.orm.entity.Mbt230;
import com.gingkoo.orm.entity.Mbt310;
import com.gingkoo.orm.entity.Mbt410;
import com.gingkoo.orm.entity.Mbt420;
import com.gingkoo.orm.entity.Mbt440;

public class InitController {
    protected static final Log logger = LogFactory.getLogger(InitController.class);

    protected ROOTDAO dao = ROOTDAOUtils.getROOTDAO();
	/**
     * 给Mbt110赋值报告时点
     * @throws Exception 
     */
    
    public  Object init(Object mbt) throws Exception {
    	if(mbt instanceof Mbt110) {
    		mbt = new InitMbt110().initMbt110((Mbt110) mbt);
    	}else if (mbt instanceof Mbt210) {
		mbt = new InitMbt210().initMbt210((Mbt210) mbt);
		}
    	else if (mbt instanceof Mbt220) {
    		mbt = new InitMbt220().initMbt220((Mbt220) mbt);
    	}else if (mbt instanceof Mbt230) {
    		mbt = new InitMbt230().initMbt230((Mbt230) mbt);
    	}else if (mbt instanceof Mbt310) {
			mbt = new InitMbt310().initMbt310((Mbt310) mbt);
		}else if (mbt instanceof Mbt410) {
    		mbt = new InitMbt410().initMbt410((Mbt410) mbt);
    	}else if (mbt instanceof Mbt420) {
    		mbt = new InitMbt420().initMbt420((Mbt420) mbt);
    	}else if (mbt instanceof Mbt440) {
			mbt = new InitMbt440().initMbt440((Mbt440) mbt);
		}
    	
		return mbt;
    }
}
