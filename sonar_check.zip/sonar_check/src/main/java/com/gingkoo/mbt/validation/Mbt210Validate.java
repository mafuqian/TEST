package com.gingkoo.mbt.validation;

import org.apache.commons.collections.map.HashedMap;

import java.util.Map;

/**
 * Created by young on 2018/11/15.
 */
public class Mbt210Validate {

    public Map<String,String> R2100101 (){

        return new HashedMap();
    }

    public Map<String,String> R2100102 (){

        return new HashedMap();
    }



}
