package com.gingkoo.mbt.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommCommitToApvService;
import com.gingkoo.orm.entity.MbtD103Add;
import com.gingkoo.orm.entity.MbtD103Qry;

public class MbtD103AddCommitAction extends MbtSingleRecordAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        String dsId = multiUpdateResultBean.getUpdateResult().containsKey("D103BodyAdd_Bas_ds") ? "D103BodyAdd_Bas_ds" : "D103BodyAdd_ds";
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID(dsId);
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
        if("failed".equals(validateFields(resultBean, returnBean))){
            return returnBean;
        }
//        if(StringUtils.isEmpty(recordMap.get("dataId")) || StringUtils.isEmpty(recordMap.get("infRecType"))){
//            recordMap.put("infRecType", "230");
//        }
        process(resultBean, MbtD103Add.class);
        returnBean.setParameter("dataId", getDataId());
        resultBean.setRecodeIndex(0);
/*
        new MbtCommCommitToApvService(resultBean, MbtD103Add.class).commitToApprove();
*/

        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommCommitToApvService mbtCommCommitToApvService = (MbtCommCommitToApvService) context.getBean("mbtCommCommitToApvService");
        mbtCommCommitToApvService.commitToApprove(resultBean, MbtD103Add.class,returnBean);
        if("".equals(returnBean.getParameter("E_CODE"))) {
        	returnBean.setParameter("isOptSucc", "true");
        }else {
        	returnBean.setParameter("isOptSucc", "false");
        }
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }
}
