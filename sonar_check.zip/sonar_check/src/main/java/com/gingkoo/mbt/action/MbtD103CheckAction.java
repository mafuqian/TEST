package com.gingkoo.mbt.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtD101AndD103Service;

public class MbtD103CheckAction extends WebAlterAction {

    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtD101AndD103Service mbtD101AndD103Service = (MbtD101AndD103Service) context.getBean("mbtD101AndD103Service");
        UpdateReturnBean returnBean = mbtD101AndD103Service.getTodaySendTimes("MBT_D103_QRY", "TODAY_RESULT_SEND_TIMES", GlobalInfo.getCurrentInstance().getTlrno(), "10");
        return returnBean;
    }
}
