package com.gingkoo.mbt.action;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.orm.entity.MbtIdentifyManage;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Iterator;
import java.util.Map;

public class MbtIdentifyManage_EntrySaveAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("MbtIdentifyManage_Entry_Bas_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);

        ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
        Iterator iterator = rootdao.queryByQL("from " + MbtIdentifyManage.class.getTypeName() + " where clientId=? or (identifyType=? and identifyNo=?) ", new String[]{recordMap.get("clientId"),recordMap.get("identifyType"),recordMap.get("identifyNo")}, null);
       if(iterator.hasNext()){
//            returnBean.setParameter("isOptSucc", "false");
            return returnBean;

        }else {
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");
        mbtCommSaveService.process(resultBean,MbtIdentifyManage.class);

        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("dataId", mbtCommSaveService.getDataId());
        }
        return returnBean;
    }
}
