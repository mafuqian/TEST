package com.gingkoo.mbt.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.mbt.util.ExpCommUtils;
import com.gingkoo.orm.entity.Mbt610Ex;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.orm.entity.Mbt110C;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Mbt110SaveCAction extends WebAlterAction {

	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
			throws AppException {
		UpdateReturnBean returnBean = new UpdateReturnBean();
		UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mat_110_Oth_C_ds");
		List<Map<String,String>> recordMap = resultBean.getTotalList().stream().filter(s->!s.get("opr").equals("del")).collect(Collectors.toList());
		for (Map<String,String> tmp:
				recordMap) {
				//1.看证件类型是不是和主表冲突
				//个人基本信息记录的标识项为“证件类型”。
				ROOTDAO dao = ROOTDAOUtils.getROOTDAO();
				String sql ="select count(1) from MBT_110  where  B_ID_TYPE='"+tmp.get("othIdType")+"' and DATA_ID='"+resultBean.getParamMap().get("pdataId")+"'";
				Iterator it= dao.queryBySQL(sql);
				if (it.hasNext()){
					BigDecimal str = (BigDecimal)it.next();
					System.out.println(str);
					if (str.compareTo(new BigDecimal(0))>0)
						throw new AppException("保存失败，当前其他标识段的证件类型已在基础段中存在，请重新输入后提交！");
				}

		}

			//2.看新录入进来的证件类型是不是在子表中已存在
			List<String> recordMap1 = resultBean.getTotalList().stream().filter(s->!s.get("opr").equals("del")).map(i->i.get("othIdType")).distinct().collect(Collectors.toList());
			if (recordMap.size() != recordMap1.size()){
				throw new AppException("保存失败，当前其他标识段的证件类型存在重复的，请重新输入后提交！");
			}

		WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
		MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");
//		mbtCommSaveService.batchprocess(resultBean, Mbt110C.class);
		ExpCommUtils.batchProcess(resultBean,Mbt110C.class,mbtCommSaveService);

		returnBean.setParameter("isOptSucc", "true");
		return returnBean;
	}

}
