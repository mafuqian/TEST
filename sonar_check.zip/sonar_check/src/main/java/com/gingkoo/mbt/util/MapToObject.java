package com.gingkoo.mbt.util;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

public class MapToObject {
	private static final String DATE_NUMBER_PATTERN = "yyyy-MM-dd";
	private static final String DATE_NUMBER_PATTERN_YYYYMMDD = "yyyyMMdd";
	
	public static Set<String> mapToObject(Object object, Map map)
			throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
		Iterator iterator = map.keySet().iterator();
		Set<String> nullSet = new HashSet<>();
		while (iterator.hasNext()) {
			String fieldName = (String) iterator.next();
			Object o = getNestedProperty(object, fieldName);
			PropertyDescriptor desc = PropertyUtils.getPropertyDescriptor(o, fieldName);
			if (desc == null)
				continue;
			Class cl = desc.getPropertyType();

			Object value = map.get(fieldName);
			if (value == null || (!String.class.isAssignableFrom(cl) && value instanceof String
					&& StringUtils.isEmpty((String) value))) {
				nullSet.add(fieldName);
				PropertyUtils.setProperty(o, fieldName, "null");
				continue;
			}

			if (Date.class.isAssignableFrom(cl)) {
				Long time = convert(value);
				if (time != null)
					BeanUtils.setProperty(o, fieldName, new Date(time));
				else {
					/*
					 * BeanUtils.setProperty(o, propertyName, new java.util.Date(0L));
					 */
					/*
					 * modify by shen_antonio 20080918 BeanUtils.setProperty(o, fieldName,
					 * defaultDate); .
					 */
				}
			} else if (Calendar.class.isAssignableFrom(cl)) {
				Long time = convert(value);
				Calendar calendar = Calendar.getInstance();
				if (time != null) {
					calendar.setTimeInMillis(time);
					BeanUtils.setProperty(o, fieldName, calendar);
				} else {
					// calendar.setTimeInMillis(0L);
					/*
					 * modify by shen_antonio 20080918
					 * calendar.setTimeInMillis(defaultDate.getTime()); BeanUtils.setProperty(o,
					 * fieldName, calendar); .
					 */
				}
			} else if (BigDecimal.class.isAssignableFrom(cl)) {
				String v = (String) value;
				if(v.indexOf(".") ==-1) {
					v = v+".00";
				}
				if (!StringUtils.isEmpty(v)) {
					BeanUtils.setProperty(o, fieldName, v);
				}
			} else {
				String v = (String) value;
				// 杩囨护"|"浠ュ強鍥炶溅鎹㈣绗﹀彿銆�
				v = v.replace('|', ' ');
				v = v.replaceAll("\n|\r\n|\r|\u0085|\u2028|\u2029", "^p");
				if ("null".equals(v)) {
					v = "";
				}
				BeanUtils.setProperty(o, fieldName, v);
			}

		}
		return nullSet;
	}

	public static Set<String> mapToObject(Object object, Map map, String str)
			throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
		Iterator iterator = map.keySet().iterator();
		Set<String> nullSet = new HashSet<>();
		while (iterator.hasNext()) {
			String fieldName = (String) iterator.next();
			Object o = getNestedProperty(object, fieldName);
			PropertyDescriptor desc = PropertyUtils.getPropertyDescriptor(o, fieldName);
			if (desc == null)
				continue;
			Class cl = desc.getPropertyType();

			Object value = map.get(fieldName);
			if (value == null || (!String.class.isAssignableFrom(cl) && value instanceof String
					&& StringUtils.isEmpty((String) value))) {
				nullSet.add(fieldName);
				PropertyUtils.setProperty(o, fieldName, "null");
				continue;
			}

			if (Date.class.isAssignableFrom(cl)) {
				Long time = convert(value);
				if (time != null)
					BeanUtils.setProperty(o, fieldName, new Date(time));
				else {
					/*
					 * BeanUtils.setProperty(o, propertyName, new java.util.Date(0L));
					 */
					/*
					 * modify by shen_antonio 20080918 BeanUtils.setProperty(o, fieldName,
					 * defaultDate); .
					 */
				}
			} else if (Calendar.class.isAssignableFrom(cl)) {
				Long time = convert(value);
				Calendar calendar = Calendar.getInstance();
				if (time != null) {
					calendar.setTimeInMillis(time);
					BeanUtils.setProperty(o, fieldName, calendar);
				} else {
					// calendar.setTimeInMillis(0L);
					/*
					 * modify by shen_antonio 20080918
					 * calendar.setTimeInMillis(defaultDate.getTime()); BeanUtils.setProperty(o,
					 * fieldName, calendar); .
					 */
				}
			} else if (BigDecimal.class.isAssignableFrom(cl)) {
				String v = (String) value;
				if (!StringUtils.isEmpty(v)) {
					BeanUtils.setProperty(o, fieldName, v);
				}
			} else {
				String v = (String) value;
				// 杩囨护"|"浠ュ強鍥炶溅鎹㈣绗﹀彿銆�
				v = v.replace('|', ' ');
				v = v.replaceAll("\n|\r\n|\r|\u0085|\u2028|\u2029", "^p");
				if ("null".equals(v)) {
					v = "";
				}
				BeanUtils.setProperty(o, fieldName, v);
			}

		}
		return nullSet;
	}
	public static Long convert(Object arg1) {

		String p = (String) arg1;
		if (p == null || p.trim().length() == 0) {
			return null;
		}
		SimpleDateFormat df = null;
		try {
			if (p.indexOf("-") > 0) {
				df = new SimpleDateFormat(DATE_NUMBER_PATTERN);
			} else {
				df = new SimpleDateFormat(DATE_NUMBER_PATTERN_YYYYMMDD);
			}
			return new Long(df.parse(p.trim()).getTime());
		} catch (Exception e) {
			return null;
		}
	}

	private static Object getNestedProperty(Object o, String propertyDesc)
			throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
		Object value = o;
		String properties[] = StringUtils.split(propertyDesc, ".");
		for (int i = 0; i < properties.length; i++) {
			if (properties.length == 1)
				break;
			String property = properties[i];
			value = PropertyUtils.getProperty(value, property);
			if (i + 2 == properties.length)
				break;
		}

		return value;
	}

	public static Map<String, String> objectToMap(Object obj) throws Exception {
		if (obj == null)
			return null;

		Map<String, String> map = new HashMap<String, String>();

		BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
		PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
		for (PropertyDescriptor property : propertyDescriptors) {
			String key = property.getName();
			if (key.compareToIgnoreCase("class") == 0) {
				continue;
			}
			Method getter = property.getReadMethod();
			String value = getter !=null? (getter.invoke(obj)!=null?getter.invoke(obj):"") + "" : "";
			map.put(toLowerCaseFirstOne(key), value);
		}

		return map;
	}

	public static String toLowerCaseFirstOne(String s) {
		if (Character.isLowerCase(s.charAt(0)))
			return s;
		else
			return (new StringBuilder()).append(Character.toLowerCase(s.charAt(0))).append(s.substring(1)).toString();
	}
}
