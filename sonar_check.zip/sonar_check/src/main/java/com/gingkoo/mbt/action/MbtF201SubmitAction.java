package com.gingkoo.mbt.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommCommitToApvService;
import com.gingkoo.mbt.util.MapToObject;
import com.gingkoo.orm.entity.MbtF201;
import com.gingkoo.orm.entity.MbtF501;

public class MbtF201SubmitAction extends MbtSingleRecordAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
            throws AppException {
        // TODO Auto-generated method stub
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResult().containsKey("MbtF201_Send_ds") ?
                multiUpdateResultBean.getUpdateResultBeanByID("MbtF201_Send_ds") : multiUpdateResultBean.getUpdateResultBeanByID("MbtF201_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
        if(!resultBean.getParameter("opr").equals("del")){
            ROOTDAO dao = ROOTDAOUtils.getROOTDAO();
            String sql = "from MbtF501 where FILE_NAME = '"+recordMap.get("fileName")+"'";
            List list = dao.queryByQL2List(sql);
            MbtF501 mbtF501 = new MbtF501();
            if(!list.isEmpty()) {
                Object l = list.get(0);
                Map<String, String> map = new HashMap<>();

                try {
                    map = MapToObject.objectToMap(l);
                    mapToObject(mbtF501,map);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
            recordMap.put("fileName",mbtF501.getFileName());
            if(resultBean.getParameter("opr").equals("add")){
                recordMap.put("sendStatus","00");
            }
            process(resultBean, MbtF201.class);
        }
        resultBean.setRecodeIndex(0);
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommCommitToApvService mbtCommCommitToApvService = (MbtCommCommitToApvService) context.getBean("mbtCommCommitToApvService");
        mbtCommCommitToApvService.commitToApprove(resultBean, MbtF201.class,returnBean);
        if("".equals(returnBean.getParameter("E_CODE"))) {
        	returnBean.setParameter("isOptSucc", "true");
        }else {
        	returnBean.setParameter("isOptSucc", "false");
        }
        return returnBean;
    }
}
