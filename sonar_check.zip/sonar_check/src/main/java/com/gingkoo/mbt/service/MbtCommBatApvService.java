package com.gingkoo.mbt.service;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.util.DateUtil;
import com.gingkoo.mbt.service.base.MbtCommonBaseService;
import com.gingkoo.mbt.util.MapToObject;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 通用批量审核 service
 * 待审核的记录以 List<Map<String, String>> 的形式传入。
 * @author fuxiang.luo@gingkoo.com
 */
@Service
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class MbtCommBatApvService {



    private List<Map<String, String>> toBeApproveRecords;

    private String entityName;
    
    private Log logger = LogFactory.getLogger(MbtCommBatApvService.class);

    @Autowired
    private ROOTDAO rootdao;

    @Autowired
    private MbtCommonBaseService mbtCommonBaseService;

    @Autowired
    private MbtBakTablesServive mbtBakTablesServive;
    @Autowired
    private MbtCommApvService mbtCommApvService;

    public List<Map<String, String>> getToBeApproveRecords() {
        return toBeApproveRecords;
    }

    public void setToBeApproveRecords(List<Map<String, String>> toBeApproveRecords) {
        this.toBeApproveRecords = toBeApproveRecords;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }
    /**
     * 构造方法
     * @param clazz 待审核的实体
     * @param records 待审核的记录，必须包含 dataId字段
     */
    public MbtCommBatApvService(Class clazz, List<Map<String, String>> records){
       /* entityName = clazz.getTypeName();
        toBeApproveRecords = records;
        this.mbtCommonBaseService = new MbtCommonBaseService();*/
    }

    public MbtCommBatApvService(){

    }

    /**
     * 执行审核
     * @throws AppException 审核时抛出的审核异常，提示用户异常原因
     */
    @Transactional(rollbackFor = Exception.class)
    public void approve() throws AppException {

    //    ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();

        List instances;

        StringBuilder ids = new StringBuilder();
        for(Map record : toBeApproveRecords){
            ids.append("'");
            ids.append(record.get("dataId"));
            ids.append("',");
        }
        ids.deleteCharAt(ids.length()-1);
        String hql = "from " + entityName + " where dataId in(" + ids + ")";
        try {
            instances = rootdao.queryByQL2List(hql);
        } catch (CommonException e) {
            logger.error(e.getLocalizedMessage());
            throw new AppException("审核失败！系统错误");
        }

        String currentDataStatus; //当前状态
        String targetDataStatus="";    // 目标状态

        // 检查待审核的记录是否都合法
        for (Object e : instances){
            try {

                currentDataStatus = BeanUtils.getProperty(e, "dataStatus");//当前状态
                Map<String,String> map = new HashMap<String,String>();
                map.put("currDataStatus", currentDataStatus);
                if("11".equals(currentDataStatus) || "12".equals(currentDataStatus)){//已补录待审核
                    map.put("actionId", "apv");         
                }else {
                    logger.error("数据(dataId=" + BeanUtils.getProperty(e, "dataId") + ")处于不需要审核状态。");
                    throw new AppException("提交的数据中存在不需要审核的记录。");
                }
                Map<String,String> resultMap = mbtCommonBaseService.RedataStatus(map);
                if(null==resultMap.get("errMsg") ||"".equals(resultMap.get("errMsg"))) {
                    targetDataStatus = resultMap.get("dataStatus");
                }else {
                    throw new AppException(resultMap.get("errMsg"));
                }
                BeanUtils.setProperty(e, "dataStatus", targetDataStatus);
                BeanUtils.setProperty(e, "dataApvUser", GlobalInfo.getCurrentInstance().getTlrno());
                BeanUtils.setProperty(e, "dataApvTime", DateUtil.get14Date());
               
                rootdao.update(e);
                
                Map map1 = new HashMap();
                map1 = MapToObject.objectToMap(e);
                
                String dataId = (String) map1.get("dataId");
    			String sql = " from MbtDataChangeLog where pdataId='" + dataId +"'";
    			ROOTDAOUtils.getROOTDAO().delete(sql);

                mbtBakTablesServive.bakTables(e);
    			
            } catch (Exception e1) {
                e1.printStackTrace();
                logger.error(e1.getLocalizedMessage());
            }
            //执行更新
          
        }
    }

    /**
     * 执行审核
     * @throws AppException 审核时抛出的审核异常，提示用户异常原因
     */
    @Transactional(rollbackFor = Exception.class)
    public void approve810() throws AppException {

        //    ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();

        List instances;

        StringBuilder ids = new StringBuilder();
        for(Map record : toBeApproveRecords){
            ids.append("'");
            ids.append(record.get("dataId"));
            ids.append("',");
        }
        ids.deleteCharAt(ids.length()-1);
        String hql = "from " + entityName + " where dataId in(" + ids + ")";
        try {
            instances = rootdao.queryByQL2List(hql);
        } catch (CommonException e) {
            logger.error(e.getLocalizedMessage());
            throw new AppException("审核失败！系统错误");
        }

        String currentDataStatus; //当前状态
        String targetDataStatus="";    // 目标状态

        // 检查待审核的记录是否都合法
        for (Object e : instances){
            try {

                currentDataStatus = BeanUtils.getProperty(e, "dataStatus");//当前状态
                Map<String,String> map = new HashMap<String,String>();
                map.put("currDataStatus", currentDataStatus);
                if("11".equals(currentDataStatus) || "12".equals(currentDataStatus)){//已补录待审核
                    map.put("actionId", "apv");
                }else {
                    logger.error("数据(dataId=" + BeanUtils.getProperty(e, "dataId") + ")处于不需要审核状态。");
                    throw new AppException("提交的数据中存在不需要审核的记录。");
                }
                Map<String,String> resultMap = mbtCommonBaseService.RedataStatus(map);
                if(null==resultMap.get("errMsg") ||"".equals(resultMap.get("errMsg"))) {
                    targetDataStatus = resultMap.get("dataStatus");
                }else {
                    throw new AppException(resultMap.get("errMsg"));
                }
                BeanUtils.setProperty(e, "dataStatus", targetDataStatus);
                BeanUtils.setProperty(e, "dataApvUser", GlobalInfo.getCurrentInstance().getTlrno());
                BeanUtils.setProperty(e, "dataApvTime", DateUtil.get14Date());

                rootdao.update(e);

                mbtCommApvService.saveLog(e,"审核通过授权书");

            } catch (Exception e1) {
                e1.printStackTrace();
                logger.error(e1.getLocalizedMessage());
            }
            //执行更新

        }
    }
}
