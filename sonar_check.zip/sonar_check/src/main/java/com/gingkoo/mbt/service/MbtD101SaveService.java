package com.gingkoo.mbt.service;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.platform.entity.GpBmHoliday;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.DataObjectUtils;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.config.database.base.MyHibernateTemplate;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.mbt.dao.MbtRootDao;
import com.gingkoo.mbt.service.base.MbtCommonBaseService;
import com.gingkoo.orm.entity.*;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 *
 * 处理前台提交的单条记录的通用 Action
 *
 */
@SuppressWarnings("ALL")
@Service
public class MbtD101SaveService {

    protected static final Log logger = LogFactory.getLogger(MbtD101SaveService.class);
    @Autowired
    private MyHibernateTemplate template;
    @Autowired
    protected MbtRootDao dao;

    private String dataId;

    @Autowired
    private MbtCommonBaseService mbtCommonBaseService;

    private String currentDataStatus;
    private String targetDataStatus;

    public String getDataId(){
        return dataId;
    }

    /**
     *
     * @param resultBean 包含记录数据的 resultBean
     * @param clazz 实体类
     * @throws AppException app异常
     */
    @Transactional(rollbackFor = Exception.class)
    public void process(UpdateResultBean resultBean, Class<?> clazz) throws AppException {
        Map<String, String> recordMap = resultBean.next();
        resultBean.getParamMap().forEach((k, v) ->{
            if(!StringUtils.isEmpty(v)){
                recordMap.put(k, v);
            }
        });

        Object bean;
        recordMap.put("dataChgUser", GlobalInfo.getCurrentInstance().getTlrno());
        recordMap.put("dataChgTime", DateUtil.get14Date());
        recordMap.put("dataChgDate", DateUtil.get8Date());

        Map<String,String> map = new HashMap<String,String>();
        try {
            bean = clazz.newInstance();
        } catch (InstantiationException | IllegalAccessException e) {
            logger.error(e.getLocalizedMessage());
            throw new AppException("系统错误，创建类" + clazz.getName() + "实例时出错。");
        }
        //a
        if (clazz.getName().contains("MbtD101")){
            isEffDay(recordMap);
        }else{
            isEffDay1(recordMap);

        }

        //d
        isWorkDate(resultBean);
       //e
        isEffQryDate(resultBean);

        if(null != recordMap.get("dataCrtTime")) {
       	 recordMap.put("dataCrtTime",trim(recordMap.get("dataCrtTime")));
       }

       if(null != recordMap.get("dataApvTime")) {
      	 recordMap.put("dataApvTime",trim(recordMap.get("dataApvTime")));
      }
        if ( "".equals(recordMap.get("dataId"))&& null==resultBean.getResMsg()){
            dataId = UUID.randomUUID().toString().replace("-", "");
            //根据当前登陆用户的用户名+用户号查询出征信表中的东东
            String hql =" from MbtSendUserManage where  sysTlrno=? and sysTlrname=? ";
            ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
             List<MbtSendUserManage> mbtSendUserManageList = dao.queryByQL2List(hql,new Object[]{GlobalInfo.getCurrentInstance().getTlrno(),resultBean.getParamMap().get("tlrName")},null);
            if (mbtSendUserManageList.size()>0){
                //查询机构代码+查询用户代码+查询用户密码 指的是当前登录用户在表中对应的接入机构代码 接口用户代码 接口用户密码
                recordMap.put("qryOrgCode",mbtSendUserManageList.get(0).getAssociatedOrgNo());
                recordMap.put("userCode",mbtSendUserManageList.get(0).getAssociatedUserId());
                recordMap.put("passWord",mbtSendUserManageList.get(0).getAssociatedUserPassword());
                //发起机构代码 +发起用户代码
                recordMap.put("ognOrgCode",GlobalInfo.getCurrentInstance().getGroupId());
                recordMap.put("ognUserCode",GlobalInfo.getCurrentInstance().getTlrno());
                recordMap.put("originateOrgCode",GlobalInfo.getCurrentInstance().getGroupId());
                recordMap.put("originateUserCode",GlobalInfo.getCurrentInstance().getTlrno());
                recordMap.put("dataId", dataId);
                recordMap.put("dataCrtUser",GlobalInfo.getCurrentInstance().getTlrno());
                recordMap.put("dataCrtTime", DateUtil.get14Date());
                recordMap.put("dataDate", DateUtil.get8Date());
                recordMap.put("dataCrtDate", DateUtil.get8Date());
                recordMap.put("corpId", GlobalInfo.getCurrentInstance().getCorpId());
                recordMap.put("orgId", GlobalInfo.getCurrentInstance().getBrno());
                recordMap.put("groupId", GlobalInfo.getCurrentInstance().getGroupId());
                recordMap.put("inqOrgID","");
                recordMap.put("dataSource","1");
                recordMap.put("iptStatus","21");
                recordMap.put("qryTlrno",GlobalInfo.getCurrentInstance().getTlrno());
                recordMap.put("qryTlrname",resultBean.getParamMap().get("tlrName"));
                recordMap.put("subjectType",resultBean.getParamMap().get("subjectType"));
                map.put("actionId", "add");
                try {
                    mapToObject(bean, recordMap);
                } catch (Exception e) {
                  throw new AppException("对象转换失败");
                }
//                    BeanUtils.copyProperties(bean,recordMap);
                dao.save(bean);
            }else{
                throw new AppException("未找到当前用户对应的信息");
            }

        }// 含dataId, 表示修改
        else  if (!"".equals(recordMap.get("dataId")) && null==resultBean.getResMsg()){
            Iterator iterator = dao.queryByQL("from " + clazz.getName() + " where dataId='" + dataId + "'");
            if(iterator.hasNext()){
                bean = iterator.next();
                try {
                    currentDataStatus = BeanUtils.getProperty(bean, "iptStatus");
                    map.put("actionId", "mod");
                } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                    logger.error(e.getLocalizedMessage());
                }
            }else {//标识根据 dataId没有检索出数据，说明提交的dataId有问题
                logger.error("前端提交的dataId数据库不存在。");
                throw new AppException("提交的数据不合法。");
            }

            map.put("currDataStatus", currentDataStatus);

            Map<String,String> resultMap = mbtCommonBaseService.RedataStatus(map);
            if(null==resultMap.get("errMsg") ||"".equals(resultMap.get("errMsg"))) {
                targetDataStatus = resultMap.get("iptStatus");
            }else {
                throw new AppException(resultMap.get("errMsg"));
            }
            recordMap.put("iptStatus", targetDataStatus);

            try {
                mapToObject(bean, recordMap);
            } catch (Exception e) {
                throw new AppException("对象转换失败");
            }
            try {
                dao.saveOrUpdate(bean);
//       } catch (CommonException e) {
//           logger.error(e.getLocalizedMessage());
//           throw new AppException("系统错误，保存失败"+e.getMessage());
            }
            catch (Exception e) {
                logger.error(e.getLocalizedMessage());
                throw new AppException("系统错误，保存失败"+e.getMessage());
            }
        }

    }
    public String trim(String str) {
    	if(!"".equals(str) && null != str) {
    		str = str.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
    	}

    	return str;
    }

    /**
     * a.根据主体信息查询最近一次申请记录的记录，
     * 计算该记录的日期到当前日的天数，未超过系统业务参数：“有效天数”的，
     * 提示：“该主体已存在有效的查询结果，请申请调阅（链接到查询管理页面查看信息）
     * @throws AppException
     */
    public void isEffDay(Map<String,String> recordMap) throws AppException{
        String hql = " from MbtD101 where  name=? and idType=? and idNum=?  order by dataCrtDate DESC";

        List<MbtD101> listExMap;

        listExMap = dao.queryByQL2List(hql, new Object[] {recordMap.get("name"),recordMap.get("idType"),recordMap.get("idNum")}, null);
        if (!CollectionUtils.isEmpty(listExMap)){
            String oldTime = listExMap.get(0).getDataCrtTime();
            String hql1 = " from GpBmBusinessParam where paramId=? and paramGroupId=?";
            List<GpBmBusinessParam> listExMap1;

            listExMap1 = dao.queryByQL2List(hql1, new Object[] {"RESULT_VALID_DAYS","MBT_CR_REPORT_QRY"}, null);
            String effDay = listExMap1.get(0).getParamValue();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            try{
                if (daysBetween(new Date(),sdf.parse(oldTime))<Integer.valueOf(effDay)){
                    throw new AppException("该主体已存在有效的查询结果，请申请调阅");
                }
            }catch(ParseException e){
                throw new AppException("比较有效天数出错");
            }
        }else{
            checkArchiveInfo(recordMap);
        }

    }
    /**
     * a.根据主体信息查询最近一次申请记录的记录，
     * 计算该记录的日期到当前日的天数，未超过系统业务参数：“有效天数”的，
     * 提示：“该主体已存在有效的查询结果，请申请调阅（链接到查询管理页面查看信息）
     * @throws AppException
     */
    public void isEffDay1(Map<String,String> recordMap) throws AppException{
        String hql = " from MbtD103Qry where  entName=? and entCertType=? and entCertNum=?  order by dataCrtDate DESC";
        List<MbtD103Qry> listExMap;

        listExMap = dao.queryByQL2List(hql, new Object[] {recordMap.get("entName"),recordMap.get("entCertType"),recordMap.get("entCertNum")}, null);
        if (!CollectionUtils.isEmpty(listExMap)){
            String oldTime = listExMap.get(0).getDataCrtTime();
            String hql1 = " from GpBmBusinessParam where paramId=? and paramGroupId=?";
            List<GpBmBusinessParam> listExMap1;

            listExMap1 = dao.queryByQL2List(hql1, new Object[] {"RESULT_VALID_DAYS","MBT_CR_REPORT_QRY"}, null);
            String effDay = listExMap1.get(0).getParamValue();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            try{
                if (daysBetween(new Date(),sdf.parse(oldTime))<Integer.valueOf(effDay)){
                    throw new AppException("该主体已存在有效的查询结果，请申请调阅");
                }
            }catch(ParseException e){
                throw new AppException("比较有效天数出错");
            }
        }else{
            checkArchiveInfo1(recordMap);
        }

    }

    private static long daysBetween(Date one, Date two) {
        long difference =  (one.getTime()-two.getTime())/86400000;
        return Math.abs(difference);
    }

    /**
     * b.检查档案信息：当前日期是否在档案的使用期限内，
     * 否则提示：“授权书已过期”，申请失败
     * c、检查档案信息：共享情况，若不为3-全行共享，
     * 则检查查询人的所属机构是档案信息的所属机构或是上级机构，
     * 否则提示：“所属分行没有授权书使用权限”；
     * @throws AppException
     */
    private  void checkArchiveInfo(Map<String,String> recordMap) throws AppException{
        //档案管理
        String hql = " from MbtArchiveManage where  identifyName=? and identifyType=? and identifyNo=?  order by dataCrtDate DESC";
        List<MbtArchiveManage> listMbtArchiveManageMap;
        listMbtArchiveManageMap = dao.queryByQL2List(hql, new Object[] {recordMap.get("name"),recordMap.get("idType"),recordMap.get("idNum")}, null);

//        listMbtArchiveManageMap = dao.queryByQL2List(hql, new Object[] {recordMap.get("entName"),recordMap.get("entCertType"),recordMap.get("entCertNum")}, null);
        //不为空的情况
        if (!CollectionUtils.isEmpty(listMbtArchiveManageMap)){
            //生效日期
            String startDate = listMbtArchiveManageMap.get(0).getAuthorizationEffectDate();
            //失效日期
            String endDate = listMbtArchiveManageMap.get(0).getAuthorizationValidityDate();

            SimpleDateFormat formatter  = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat formatter2  = new SimpleDateFormat("yyyyMMdd");
            String nowDate =null;
            try {
                if (!StringUtils.isEmpty(startDate)){
                    Date  date = formatter2.parse(startDate);
                    startDate   = formatter.format(date);
                }

                nowDate = formatter.format(new Date());
                if (!StringUtils.isEmpty(endDate)){
                    Date  date = formatter2.parse(endDate);
                    endDate   = formatter.format(date);
                }
            } catch (ParseException e) {
                logger.error(e.getLocalizedMessage());
            }
            if (!(null ==startDate) &&!(compareDate(nowDate,startDate)>=0 )){
                throw new AppException("授权书已过期，申请失败");
            }else if(!(null ==endDate) &&compareDate(endDate,nowDate)<0){
                throw new AppException("授权书已过期，申请失败");
            }
            //仅本行
            GlobalInfo gi = GlobalInfo.getCurrentInstance();
            String v_corpid = gi.getCorpId();
            String v_depart = gi.getGroupId();
            String v_orgId = gi.getBrno();
            if(listMbtArchiveManageMap.get(0).getShareFlag().equals("1") && !(v_orgId.equals(listMbtArchiveManageMap.get(0).getOrgId()))){
                throw new AppException("所属机构没有授权书使用权限");
            }//仅本行以及上报行
            else if (listMbtArchiveManageMap.get(0).getShareFlag().equals("2")){
                //TODO
                //检查人的机构是啥 是否为本行/上报行
                if (!(v_orgId.equals(listMbtArchiveManageMap.get(0).getOrgId()))){
                   boolean flag = isSHigheruthorities(listMbtArchiveManageMap.get(0).getOrgId(),v_orgId);
                   if (false == flag){
                       throw new AppException("所属机构没有授权书使用权限");
                   }
                }
            }
        }

     }

    /**
     * b.检查档案信息：当前日期是否在档案的使用期限内，
     * 否则提示：“授权书已过期”，申请失败
     * c、检查档案信息：共享情况，若不为3-全行共享，
     * 则检查查询人的所属机构是档案信息的所属机构或是上级机构，
     * 否则提示：“所属分行没有授权书使用权限”；
     * @throws AppException
     */
    private  void checkArchiveInfo1(Map<String,String> recordMap) throws AppException{
        //档案管理
        String hql = " from MbtArchiveManage where  identifyName=? and identifyType=? and identifyNo=?  order by dataCrtDate DESC";
        List<MbtArchiveManage> listMbtArchiveManageMap;
        listMbtArchiveManageMap = dao.queryByQL2List(hql, new Object[] {recordMap.get("entName"),recordMap.get("entCertType"),recordMap.get("entCertNum")}, null);
        //不为空的情况
        if (!CollectionUtils.isEmpty(listMbtArchiveManageMap)){
            //生效日期
            String startDate = listMbtArchiveManageMap.get(0).getAuthorizationEffectDate();
            //失效日期
            String endDate = listMbtArchiveManageMap.get(0).getAuthorizationValidityDate();

            SimpleDateFormat formatter  = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat formatter2  = new SimpleDateFormat("yyyyMMdd");
            String nowDate =null;
            try {
                if (!StringUtils.isEmpty(startDate)){
                    Date  date = formatter2.parse(startDate);
                    startDate   = formatter.format(date);
                }

                nowDate = formatter.format(new Date());
                if (!StringUtils.isEmpty(endDate)){
                    Date  date = formatter2.parse(endDate);
                    endDate   = formatter.format(date);
                }
            } catch (ParseException e) {
                logger.error(e.getLocalizedMessage());
            }
            if (!(null ==startDate) &&!(compareDate(nowDate,startDate)>=0 )){
                throw new AppException("授权书已过期，申请失败");
            }else if(!(null ==endDate) &&compareDate(endDate,nowDate)<0){
                throw new AppException("授权书已过期，申请失败");
            }
            //仅本行
            GlobalInfo gi = GlobalInfo.getCurrentInstance();
            String v_corpid = gi.getCorpId();
            String v_depart = gi.getGroupId();
            String v_orgId = gi.getBrno();
            if(listMbtArchiveManageMap.get(0).getShareFlag().equals("1") && !(v_orgId.equals(listMbtArchiveManageMap.get(0).getOrgId()))){
                throw new AppException("所属机构没有授权书使用权限");
            }//仅本行以及上报行
            else if (listMbtArchiveManageMap.get(0).getShareFlag().equals("2")){
                //TODO
                //检查人的机构是啥 是否为本行/上报行
                if (!(v_orgId.equals(listMbtArchiveManageMap.get(0).getOrgId()))){
                    boolean flag = isSHigheruthorities(listMbtArchiveManageMap.get(0).getOrgId(),v_orgId);
                    if (false == flag){
                        throw new AppException("所属机构没有授权书使用权限");
                    }
                }
            }
        }

    }
     private boolean isSHigheruthorities(String isCheckOrgId,String orgId){
        boolean result = false;
         //select * from  gp_bm_branch
         String hql = " select brno from GP_BM_BRANCH where bln_up_brcode=( select bln_up_brcode from GP_BM_BRANCH where org_id=? )";
         List list = null;
         list = template.findBySql(hql, isCheckOrgId);
         if (list.size()>0){
             for (int i = 0; i < list.size(); i++) {
                 if (orgId.equals(list.get(i))){
                     result = true;
                     break;
                 }
             }
         }

         return result;
     }
     private int compareDate(String dbtime1,String dbtime2) {

       //算两个日期间隔多少天
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date date1 = null;
        int a = 0;
        try {
            date1 = format.parse(dbtime1);
            Date date2 = format.parse(dbtime2);
             a = (int) ((date1.getTime() - date2.getTime()) / (1000*3600*24));
        } catch (ParseException e) {
            logger.error(e.getLocalizedMessage());
        }
         return a;
     }

    /**
     * d.检查当前日是否是工作日
     * @throws AppException
     */
    private void isWorkDate(UpdateResultBean resultBean) throws AppException{
        Calendar ca = Calendar.getInstance();
        ca.setTime(new Date());
        //第几天
        int day =ca.get(Calendar.DAY_OF_YEAR);
        int year = ca.get(Calendar.YEAR);

        String hql = " from GpBmHoliday where   year=?";
        List<GpBmHoliday> listExMap;
        listExMap = dao.queryByQL2List(hql, new Object[] {year}, null);
        if (!CollectionUtils.isEmpty(listExMap) &&listExMap.get(0).getHolidayDef().substring(day-1,day).equals("0")){
//                throw new AppException("zzz","200","查询发起时间在工作时间之外，继续查询将会被记录行为，是否继续？");
            resultBean.setResMsg("查询发起时间在工作时间之外，继续查询将会被记录行为，是否继续？");

        }

    }

    /**
     * e.检查当前时间是否是正常查询时间
     */
    private void isEffQryDate(UpdateResultBean resultBean) throws AppException{
        String hql = " from GpBmBusinessParam where paramId=? and paramGroupId=?";
        List<GpBmBusinessParam> listExMap;
        listExMap = dao.queryByQL2List(hql, new Object[] {"RES_EFFECTIVE_TIME","MBT_CR_REPORT_QRY"}, null);
        if (!CollectionUtils.isEmpty(listExMap) ) {
            isInTime(resultBean,listExMap);
        }
    }

    private void isInTime(UpdateResultBean resultBean,List<GpBmBusinessParam> listExMap) throws AppException{
        //取当前时间并判断是否在这个时间区间内
        String businessTime=listExMap.get(0).getParamValue();
        String []strs=businessTime.split("-");
        String []strs1=strs[0].split(":");
        String []strs2=strs[1].split(":");
        Calendar currentDate = Calendar.getInstance();
        currentDate.setTime(new Date());
        Calendar min=Calendar.getInstance();
        //min=currentDate;
        min.set(Calendar.YEAR, currentDate.get(Calendar.YEAR));
        min.set(Calendar.MONTH, currentDate.get(Calendar.MONTH));
        min.set(Calendar.HOUR_OF_DAY, Integer.parseInt(strs1[0]));
        min.set(Calendar.MINUTE, Integer.parseInt(strs1[1]));
        min.set(Calendar.SECOND, 0);
        min.set(Calendar.MILLISECOND, 0);

        Calendar max=Calendar.getInstance();
        // max=currentDate;
        max.set(Calendar.YEAR, currentDate.get(Calendar.YEAR));
        max.set(Calendar.MONTH, currentDate.get(Calendar.MONTH));
        max.set(Calendar.HOUR_OF_DAY,Integer.parseInt(strs2[0]));
        max.set(Calendar.MINUTE, Integer.parseInt(strs2[1]));
        min.set(Calendar.SECOND, 0);
        min.set(Calendar.MILLISECOND, 0);
        if(!(currentDate.getTimeInMillis()>=min.getTimeInMillis() && currentDate.getTimeInMillis()<=max.getTimeInMillis())){
            resultBean.setResMsg("查询发起时间为非正常查询时间，继续查询将会被记录行为，是否继续？");
//            throw new AppException("zzz","200","查询发起时间为非正常查询时间，继续查询将会被记录行为，是否继续？");
        }
    }

    public static Set<String> mapToObject(Object object, Map map) throws AppException {
        HashMap candidates = new HashMap();
        Iterator var4 = map.keySet().iterator();

        while(var4.hasNext()) {
            Object e = var4.next();
            char[] chars = ((String)e).toCharArray();
            if(Character.isUpperCase(chars[1])) {
                chars[0] = (char)(chars[0] - 32);
                candidates.put(String.valueOf(chars), map.get(e));
            }
        }

        map.putAll(candidates);

        try {
            return DataObjectUtils.mapToObject(object, map);
        } catch (Exception var6) {
            throw new AppException("SY", "9999", "属性拷贝出错", var6);
        }
    }
}
