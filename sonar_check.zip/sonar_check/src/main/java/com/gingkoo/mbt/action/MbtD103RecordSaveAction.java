package com.gingkoo.mbt.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtBeHaviorMonRecordService;
import com.gingkoo.orm.entity.MbtD103Qry;


public class MbtD103RecordSaveAction extends MbtSingleRecordAction{
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
            throws AppException {
        // TODO Auto-generated method stub
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResult().containsKey("MbtD103Apply_Dtl_ds") ?
                multiUpdateResultBean.getUpdateResultBeanByID("MbtD103Apply_Dtl_ds") : multiUpdateResultBean.getUpdateResultBeanByID("MbtD103Apply_ds");
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtBeHaviorMonRecordService monRecordService = (MbtBeHaviorMonRecordService) context.getBean("mbtBeHaviorMonRecordService");
        resultBean.getParamMap().put("funcId",multiUpdateResultBean.getFuncId());
        monRecordService.process(resultBean, MbtD103Qry.class);
        if (null ==resultBean.getResMsg()){
            returnBean.setParameter("isOptSucc", "true");
        }else{
            returnBean.setParameter("errCode", "200");
            returnBean.setParameter("errMsg", resultBean.getResMsg());
        }
        return returnBean;
    }
}
