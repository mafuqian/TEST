package com.gingkoo.mbt.service;

import java.lang.reflect.InvocationTargetException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gingkoo.common.validate.service.CommonValidteServeice;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.DataObjectUtils;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.mbt.dao.MbtRootDao;
import com.gingkoo.mbt.service.base.MbtCommonBaseService;

/**
 *
 * 处理前台提交的单条记录的通用 Action
 *
 * @author fuxiang.luo@gingkoo.com
 *
 *
 */
@SuppressWarnings("ALL")
@Service
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class MbtCommSaveService  {

    protected static final Log logger = LogFactory.getLogger(MbtCommSaveService.class);

    @Autowired
    protected MbtRootDao dao;

    private String dataId;

    private boolean falg;

    @Autowired
    private MbtCommonBaseService mbtCommonBaseService;

    @Autowired
    private MbtCommApvService mbtCommApvService;


    private String currentDataStatus;

    private String targetDataStatus;

    private  Object bean;

    @Value("${application.home}")
    public String uploadPath;

    public String getUploadPath() {
        return uploadPath;
    }

    public String getDataId(){
        return dataId;
    }


    public boolean isBeforeDay(String bRptDate) {
    	DateFormat df = new SimpleDateFormat("yyyyMMdd");

        try {
			Date dt1 = df.parse(bRptDate);
			 Date dt2 = df.parse(DateUtil.get8Date());
			 if (dt1.getTime() > dt2.getTime()) {
				return false;
			 }

		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        return true;
    }

    /**
     *
     * @param resultBean 包含记录数据的 resultBean
     * @param clazz 实体类
     * @throws AppException app异常
     */
    @Transactional(rollbackFor = Exception.class)
    public void process(UpdateResultBean resultBean, Class<?> clazz) throws AppException {

        Map<String, String> recordMap = resultBean.next();

        String bRptDate = recordMap.get("bRptDate") != null ? recordMap.get("bRptDate") : recordMap.get("rptDate");
        if (StringUtils.isNotEmpty(bRptDate) && !isBeforeDay(bRptDate)) {
            throw new AppException("信息报告日期不能大于当前系统日期");
        }


//        resultBean.getParamMap().forEach((k, v) ->{
//            if(!StringUtils.isEmpty(k)){
//                recordMap.put(k, v);
//            }
//        });


        this.dataId = recordMap.get("dataId");
        recordMap.put("dataChgUser", GlobalInfo.getCurrentInstance().getTlrno());
        recordMap.put("dataChgTime", DateUtil.get14Date());
        recordMap.put("dataChgDate", DateUtil.get8Date());

        Map<String,String> map = new HashMap<String,String>();
        // 不含dataId，新增数据
        if(StringUtils.isEmpty(dataId)){
            falg = true;
            try {
                bean = clazz.newInstance();
            } catch (InstantiationException | IllegalAccessException e) {
                logger.error(e.getLocalizedMessage());
                throw new AppException("系统错误，创建类" + clazz.getName() + "实例时出错。");
            }

            dataId = UUID.randomUUID().toString().replace("-", "");
            recordMap.put("dataId", dataId);
            recordMap.put("dataCrtUser",GlobalInfo.getCurrentInstance().getTlrno());
            recordMap.put("dataCrtTime", DateUtil.get14Date());
            recordMap.put("dataDate", DateUtil.get8Date());
            recordMap.put("dataCrtDate", DateUtil.get8Date());
            recordMap.put("corpId", GlobalInfo.getCurrentInstance().getCorpId());
            recordMap.put("orgId", GlobalInfo.getCurrentInstance().getBrno());
            recordMap.put("groupId", GlobalInfo.getCurrentInstance().getGroupId());
            recordMap.put("inqOrgID","");
            recordMap.put("dataSource","1");
            recordMap.put("dataSoure","1");
            recordMap.put("checkFlag","N");
            recordMap.put("fbStatus","0");
            currentDataStatus = "00";
            map.put("actionId", "add");

        }
        // 含dataId, 表示修改
        else {
            falg = false;
            Iterator iterator = dao.queryByQL("from " + clazz.getName() + " where dataId='" + dataId + "'");
            if(iterator.hasNext()){
                bean = iterator.next();
                try {
					currentDataStatus = BeanUtils.getProperty(bean, "dataStatus");
	                map.put("actionId", "mod");
	                recordMap.put("dataCrtTime", BeanUtils.getProperty(bean, "dataCrtTime"));
	                recordMap.put("dataCrtUser", BeanUtils.getProperty(bean, "dataCrtUser"));
	                recordMap.put("dataSource", BeanUtils.getProperty(bean, "dataSource"));
	                recordMap.put("checkFlag", BeanUtils.getProperty(bean, "checkFlag"));
	                recordMap.put("fbStatus", BeanUtils.getProperty(bean, "fbStatus"));

				} catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
	                logger.error(e.getLocalizedMessage());
	            }
            }else {//标识根据 dataId没有检索出数据，说明提交的dataId有问题
                logger.error("前端提交的dataId数据库不存在。");
                throw new AppException("提交的数据不合法。");
            }
        }
        if(null != recordMap.get("dataCrtTime")) {
       	 recordMap.put("dataCrtTime",trim(recordMap.get("dataCrtTime")));
       }

       if(null != recordMap.get("dataApvTime")) {
      	 recordMap.put("dataApvTime",trim(recordMap.get("dataApvTime")));
       }
        if(null != recordMap.get("fbTime")) {
            recordMap.put("fbTime",trim(recordMap.get("fbTime")));
        }
       map.put("currDataStatus", currentDataStatus);

       Map<String,String> resultMap = mbtCommonBaseService.RedataStatus(map);
       if(null==resultMap.get("errMsg") ||"".equals(resultMap.get("errMsg"))) {
           targetDataStatus = resultMap.get("dataStatus");
       }else {
           throw new AppException(resultMap.get("errMsg"));
       }
       recordMap.put("dataStatus", targetDataStatus);
       recordMap.put("dataRejDesc", "");
       mapToObject(bean, recordMap);
       try {
    	   dao.saveOrUpdate(bean);
//       } catch (CommonException e) {
//           logger.error(e.getLocalizedMessage());
//           throw new AppException("系统错误，保存失败"+e.getMessage());
       }
       catch (Exception e) {
           logger.error(e.getMessage());
           throw new AppException("系统错误，保存失败"+e.getMessage());
       }
    }
    public String trim(String str) {
    	if(!"".equals(str) && null != str) {
    		str = str.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
    	}

    	return str;
    }

    public static Set<String> mapToObject(Object object, Map map) throws AppException {
        HashMap candidates = new HashMap();
        Iterator var4 = map.keySet().iterator();

        while(var4.hasNext()) {
            Object e = var4.next();
            char[] chars = ((String)e).toCharArray();
            if(Character.isUpperCase(chars[1])) {
                chars[0] = (char)(chars[0] - 32);
                candidates.put(String.valueOf(chars), map.get(e));
            }
        }

        map.putAll(candidates);

        try {
            return DataObjectUtils.mapToObject(object, map);
        } catch (Exception var6) {
            throw new AppException("SY", "9999", "属性拷贝出错", var6);
        }
    }

    /**
     * 校验字段
     * @param resultBean 待更新的结果集
     * @param returnBean 处理之后，返回给前端的结果集
     * @return pass - 校验通过; failed - 校验失败
     * @throws CommonException 通用异常
     */
    protected String validateFields(UpdateResultBean resultBean, UpdateReturnBean returnBean) throws CommonException {
        CommonValidteServeice validateService = new CommonValidteServeice();
        String validateResult = validateService.execute(resultBean.getTotalList().get(0), GlobalInfo.getCurrentInstanceWithoutException().getFuncId(),true);
        if(!StringUtils.isEmpty(validateResult)){
            String[] result = validateResult.split("\\|");
            returnBean.setParameter("desc", result[1]);
            returnBean.setParameter("resId", result[0]);
            return "failed";
        }else {
            return "pass";
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public void batchprocess(UpdateResultBean resultBean, Class<?> clazz) throws AppException {
        while (resultBean.hasNext()){
            Map<String, String> recordMap = resultBean.next();
            resultBean.getParamMap().forEach((k, v)->{
                if(!StringUtils.isEmpty(v) && !k.equals("dataId")){
                    recordMap.put(k,v);
                }
            });

            Object bean = null;
            try {
                bean = clazz.newInstance();
            } catch (InstantiationException | IllegalAccessException e) {
                logger.error(e.getLocalizedMessage());
                throw new AppException("实例化类" + clazz.getName() + "时出错。");
            }

            String recordState = recordMap.get("opr");
            if(StringUtils.isEmpty(recordMap.get("dataId"))){
                recordMap.put("dataId", UUID.randomUUID().toString().replace("-", ""));
            }

            mapToObject(bean, recordMap);
            try {
            	if("insert".equals(recordState) || "new".equals(recordState)){//新增加的记录
                    dao.save(bean);
                }else if ("modify".equals(recordState)){//修改
                    dao.update(bean);
                }else if ("delete".equals(recordState) || "discard".equals(recordState)){//被删除或者被舍弃的
                    dao.delete(bean);
                }


            	//更新附表状态
            	String pdataId =recordMap.get("pdataId");


            	String name = clazz.getSimpleName();

            	//PerLocateInf
            	if(name.equals("LocateInf")) {
            		String objTagId = recordMap.get("objTagId");
            		name = "Tag_Inf";

            		String sql  = "update " + name + " set data_status ='00',data_State='0' where OBJ_TAG_ID ='"+objTagId+"'";
                	dao.executeSql(sql);
            	}else if(name.equals("PerLocateInf")) {
            		String objTagId = recordMap.get("objTagId");
            		name = "Per_Tag_Inf";

            		String sql  = "update " + name + " set data_status ='00',data_State='0' where OBJ_TAG_ID ='"+objTagId+"'";
                	dao.executeSql(sql);
            	}else {
            		if(name.indexOf("Ex") ==-1 ) {
                		name = name.substring(0, 3)+"_"+name.substring(3, 6);
                	}else {
                		name = name.substring(0, 3)+"_"+name.substring(3, 6)+"_EX";
                	}

            		String sql  = "update " + name + " set data_status ='00' where data_id='"+pdataId+"'";
                	dao.executeSql(sql);
            	}

            }catch(Exception e) {
            	e.printStackTrace();
            	logger.error("同步数据库出错。",e);
            	new AppException("同步数据库出错。",e);
			}
        }

    }


    public void process810(UpdateResultBean resultBean, Class<?> clazz) throws AppException {

        process(resultBean,clazz);

        String opt = "";
        if(falg){
            opt = "01";
        }else{
            opt = "02";
        }

        mbtCommApvService.saveLog(bean,opt);
    }


//    public static void main(String[] args) {
//DateFormat df = new SimpleDateFormat("yyyyMMdd");
//
//        try {
//			Date dt1 = df.parse("20180101");
//			 Date dt2 = df.parse(DateUtil.get8Date());
//			 if (dt1.getTime() > dt2.getTime()) {
//				System.out.println("111");
//			 }
//
//		} catch (ParseException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//
//	}

}
