package com.gingkoo.mbt.action;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.mbt.service.MbtCrossTableService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;


public class CMbtCrossTableValidateAction extends WebAlterAction {

    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
            throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("CMbtCrossTableValidate_ds");
        String opr = resultBean.getParameter("opr");
        String busClass = resultBean.getParameter("busClass");
        String rptDate = resultBean.getParameter("rptDate");
        String rptDataType = resultBean.getParameter("rptDataType");
        rptDate = new SimpleDateFormat("yyyyMMdd").format(Long.valueOf(rptDate));
        if (opr == null || "".equals(opr.trim())) {
            returnBean.setParameter("ERR_CODE", "99");
            returnBean.setParameter("ERR_MSG", "操作参数错误。");
            return returnBean;
        }
        if ( "batch".equals(opr) && (busClass == null || "".equals(busClass.trim()) || rptDate == null || "".equals(rptDate.trim()) )) {
            returnBean.setParameter("ERR_CODE", "99");
            returnBean.setParameter("ERR_MSG", "批量操作参数错误。");
        }

        if ("single".equals(opr) && (busClass == null || "".equals(busClass.trim()) || rptDate == null || "".equals(rptDate.trim()) || rptDataType == null || "".equals(rptDataType.trim()))) {
            returnBean.setParameter("ERR_CODE", "99");
            returnBean.setParameter("ERR_MSG", "单笔操作参数错误。");
        }
        MbtCrossTableService mbtCrossTableService = (MbtCrossTableService) ApplicationContextUtil.getBean("mbtCrossTableService");
        JobResult jobResult = new JobResult();
        if("batch".equals(opr)){
            jobResult = mbtCrossTableService.batchValidate(busClass,rptDate);
        }
        if("single".equals(opr)){
            jobResult = mbtCrossTableService.singleValidate(busClass,rptDate,rptDataType);
        }
        returnBean.setParameter("ERR_CODE", jobResult.getErrCode());
        returnBean.setParameter("ERR_MSG", jobResult.getErrMsg());
        return returnBean;
    }

}
