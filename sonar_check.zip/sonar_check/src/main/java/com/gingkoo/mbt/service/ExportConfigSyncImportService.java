package com.gingkoo.mbt.service;

import com.gingkoo.common.batch.entity.GpBmIdFielddata;
import com.gingkoo.common.batch.entity.GpBmIdFiledata;
import com.gingkoo.common.batch.entity.GpBmIdSheetdata;
import com.gingkoo.common.dataimport.service.base.BaseDataImportService;
import com.gingkoo.common.query.entity.GpBmExportField;
import com.gingkoo.common.query.entity.GpBmExportFunction;
import com.gingkoo.common.query.entity.GpBmExportSheet;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class ExportConfigSyncImportService {

	private static final Log logger = LogFactory.getLogger(ExportConfigSyncImportService.class);

	public static final String ID = "exportConfigSyncImportService";
	public static final String FILE = "FILE";
	public static final String SHEET = "SHEET";
	public static final String FIELD = "FIELD";

	@Autowired
	@Qualifier("ROOTDAO")
	private ROOTDAO rootdao;

	@Autowired
	private GpBmIdImportSettingService importSettingService;

	@Autowired
	private ExportSettingService exportSettingService;

	@Autowired
	@Qualifier("baseDataImportService")
	private BaseDataImportService baseDataImportService;
	
	/**
	 * 根据导出配置同步导入配置。
	 * @param type
	 * @param dataId
	 * @throws CommonException
	 */
	public void execute(String type ,String dataId) throws CommonException {
		switch(type) {
		case FILE :
			exportConfigSyncGpBmIdFiledata(dataId);
			break;
		case SHEET:
			exportSheetConfigSyncGpBmIdSheetdata(dataId);
			break;
		case FIELD :
			exportFieldConfigSyncGpBmIdFielddata(dataId);
			break;
		}
		baseDataImportService.init();
	}
	

	
	/**
	 * 同步更新导入配置文件层配置
	 * 
	 * @throws CommonException
	 */
	public void exportConfigSyncGpBmIdFiledata(String dataId) throws CommonException {
		GlobalInfo glo = GlobalInfo.getCurrentInstance();
		String guid = dataId;
		GpBmIdFiledata gpBmIdFiledata = importSettingService.getFileData(guid);
		GpBmExportFunction gpBmExportFunction = exportSettingService.getGpBmExportFunctionByDataId(dataId);
		if (gpBmExportFunction == null) {// 说明删除
			if (gpBmIdFiledata != null) {
				importSettingService.deleteFileData(guid);
			}
		} else {// 说明新增或修改
			if (gpBmIdFiledata == null) {// 新增
				String exportStrategyType = gpBmExportFunction.getExportStrategyType();
				if ("exportAndImport".equals(exportStrategyType)) {// 批量编辑
					GpBmIdFiledata filedata = new GpBmIdFiledata();
					filedata.setGuid(gpBmExportFunction.getGuid());
					filedata.setFuncid(gpBmExportFunction.getFunctionId());
					filedata.setFuncName(gpBmExportFunction.getFunctionName());
					filedata.setFileName(gpBmExportFunction.getFileName());
					filedata.setDepartId(glo.getBrno());
					filedata.setImportType("1");// 批量编辑
					filedata.setBatchNo("1");// 导入批号
					filedata.setMainFlag("01");// 主文件标志
					filedata.setImportTime("10");// 导入时机：每日
					filedata.setKeyFlag("8");// 只更新
					filedata.setFileOwner("01");// 文件所属all
					filedata.setSequenceNo("1");// 顺序号
					filedata.setFilenameFormat("*");
					filedata.setComments(gpBmExportFunction.getFunctionName() + "批量编辑");
					filedata.setAutoImportFlag("N");// 不自动导入
					filedata.setJobType("0");
					filedata.setArgs("");
					rootdao.save(filedata);
				}
			} else {//修改
				String exportStrategyType = gpBmExportFunction.getExportStrategyType();
				if ("exportAndImport".equals(exportStrategyType)) {// 批量编辑
					gpBmIdFiledata.setFileName(gpBmExportFunction.getFileName());
					gpBmIdFiledata.setComments(gpBmExportFunction.getFunctionName() + "批量编辑");
					rootdao.update(gpBmIdFiledata);
				}else {//批量编辑改成只导出。
					importSettingService.deleteFileData(guid);
				}
			}
		}

	}

	/**
	 * 同步更新导入配置sheet层配置
	 * (先删除，再导入。)
	 * @param pDataId
	 * @throws CommonException
	 */
	public void exportSheetConfigSyncGpBmIdSheetdata(String pDataId) throws CommonException {
		GpBmExportFunction bmExportFunction = exportSettingService.getGpBmExportFunctionByDataId(pDataId);
		String  exportStrategyType = bmExportFunction.getExportStrategyType();//导出策略类型
		if ("exportAndImport".equals(exportStrategyType)) {// 批量编辑
			importSettingService.deleteSheetData(pDataId);
			List<GpBmExportSheet> exportSheetList = exportSettingService.getGpBmExportSheetList(pDataId);
			for(GpBmExportSheet exportSheet : exportSheetList) {
				List<GpBmExportField> fieldList = exportSettingService.getGpBmExportFieldList(exportSheet.getDataId());
				GpBmIdSheetdata sheetData = new GpBmIdSheetdata();
				sheetData.setGuid(exportSheet.getDataId());
				sheetData.setPguid(exportSheet.getPDataId());
				sheetData.setTableName(exportSheet.getTableName());
				sheetData.setTableComments(exportSheet.getTableComments());
				sheetData.setFormatType("4");
				sheetData.setSheetNum(exportSheet.getSheetNum()+"");
				sheetData.setSheetName(exportSheet.getSheetName());
				sheetData.setSequenceNo(exportSheet.getSheetNum()+"");
				sheetData.setStartRow("2");//起始行
				sheetData.setStartColumn("1");
				sheetData.setEndrowFlag("1");
				sheetData.setEndColumn(fieldList.size()+"");
				sheetData.setComments(exportSheet.getTableComments());
				rootdao.save(sheetData);
			}
			
		}
		
		
		
		
	}

	/**
	 * 同步更新导入配置字段层配置
	 * @throws CommonException 
	 */
	public void exportFieldConfigSyncGpBmIdFielddata(String pDataId) throws CommonException {
		GpBmIdSheetdata bmIdSheetdata = importSettingService.getSheetDataByGuid(pDataId);
		if(bmIdSheetdata==null) {
			return;
		}
		List<GpBmIdFielddata> importFieldlist = importSettingService.getFieldDataList(pDataId);
		if(importFieldlist.size()>0) {
			importSettingService.deleteFieldDataWithspecificField(pDataId);
		}

		setidFieldSysColumn(bmIdSheetdata.getGuid(), bmIdSheetdata.getTableName());
		List<GpBmExportField> exportFieldList = exportSettingService.getGpBmExportFieldListWithExportOrderBySeqNo(pDataId);
		for(GpBmExportField exportField : exportFieldList) {//根据字段进行保存。
			GpBmIdFielddata fieldData = new GpBmIdFielddata();
			fieldData.setGuid(exportField.getDataId());
			fieldData.setPguid(exportField.getPDataId());
			fieldData.setFieldName(exportField.getColumnName());
			fieldData.setFieldComments(exportField.getColumnComments());
			fieldData.setUmwExpression("specificField(${value},"+exportField.getExportNum()+")");
			String datatype = getDataTypeByUSER_TAB_COLS(bmIdSheetdata.getTableName(), exportField.getColumnName());
			fieldData.setUDatatype(datatype);//字段类型 1-数字，2-字符
			String keyFlag = getUniquekeyFlag(exportField.getColumnName());
			fieldData.setUniquekeyFlag(keyFlag);//主键标志 1-是，0-否
			fieldData.setUpdateWay("1");//字段修改方式：1-覆盖
			fieldData.setUpdateFlag("1");//修改标志 1-是 0 -否
			String readOnlyFlag = exportField.getReadonlyFlag();
			if("Y".equals(readOnlyFlag)){//对于只读的字段，过滤掉，不更新。
				fieldData.setFilterFlag("1");//过滤标志1-是 0 -否
			}else {
				fieldData.setFilterFlag("0");//过滤标志1-是 0 -否
			}
			rootdao.save(fieldData);
		}
		int endColumn = exportFieldList.size();
		bmIdSheetdata.setEndColumn(endColumn+"");
		rootdao.update(bmIdSheetdata);
	}
	

	/**
	 * 获取主键。//主键标志 1-是，0-否
	 * @param columnNmae
	 * @return
	 */
	private String getUniquekeyFlag(String columnNmae) {
		String result = "0";
		if("DATA_ID".equals(columnNmae)||"GUID".equals(columnNmae)) {
			result = "1";
		}
		return result;
	}
	
	/**
	 * 根据表名和字段名获取判断字段类型。
	 * @param tableName
	 * @param columnName
	 * @return
	 */
	public String getDataTypeByUSER_TAB_COLS(String tableName ,String columnName) {
		String result = "2";//字段类型 1-数字，2-字符
		String sql = "select DATA_TYPE from GP_BM_USER_TAB_COLS where table_name = '"+tableName+"' and COLUMN_NAME = '"+columnName+"'";  
		List<Map<String, Object>> list = rootdao.findBySql(sql);
		String dataType = (String) list.get(0).get("DATA_TYPE");
		if("NUMBER".equals(dataType)||"INTEGER".equals(dataType)||"BINARY_FLOAT".equals(dataType)||"BINARY_DOUBLE".equals(dataType)||"FLOAT".equals(dataType)) {
			result = "1";
		}
		return result;
	}
	
	/**
	 * 根据表名 从USER_TAB_COLS 获取字段
	 * @param tableName
	 * @return
	 */
	public List<String> getColumnNameBytableNameInUSER_TAB_COLS(String tableName ) {
		List<String> strList = new ArrayList<>();
		String sql = "select COLUMN_NAME from GP_BM_USER_TAB_COLS where table_name = '"+tableName+"' ";  
		List<Map<String, Object>> list = rootdao.findBySql(sql);
		for(Map<String, Object> map : list) {
			String columnName = (String) map.get("COLUMN_NAME");
			strList.add(columnName);
		}
		return strList;
	}
	
	/**
	 * 添加系统字段。
	 * @param pguid
	 * @param tableName
	 * @throws CommonException
	 */
	public void setidFieldSysColumn(String pguid,String tableName) throws CommonException {
		List<String> columnList = getColumnNameBytableNameInUSER_TAB_COLS(tableName);
		if(columnList.contains("DATA_CHG_USER")){
            saveDataChgUserField(pguid);
        }
	
	}

    /**
     * 保存DATA_DATE
     * @param pguid
     * @return
     */
	private void saveDatadateField(String pguid) throws CommonException{
        GpBmIdFielddata fieldData = new GpBmIdFielddata();
        fieldData.setGuid(UuidHelper.getCleanUuid());
        fieldData.setPguid(pguid);
        fieldData.setFieldName("DATA_DATE");
        fieldData.setFieldComments("数据日期");
        fieldData.setUmwExpression("getSysDate(${value})");
        fieldData.setUDatatype("2");//字段类型 1-数字，2-字符
        fieldData.setUniquekeyFlag("0");//主键标志 1-是，0-否
        fieldData.setUpdateWay("1");//字段修改方式：1-覆盖
        fieldData.setUpdateFlag("1");//修改标志 1-是 0 -否
        fieldData.setFilterFlag("1");//过滤标志1-是 0 -否
        rootdao.save(fieldData);
    }



    /**
     * 保存 DATA_CHG_USER
     * @param pguid
     * @return
     */
    private void saveDataChgUserField(String pguid) throws CommonException{
        GpBmIdFielddata fieldData = new GpBmIdFielddata();
        fieldData.setGuid(UuidHelper.getCleanUuid());
        fieldData.setPguid(pguid);
        fieldData.setFieldName("DATA_CHG_USER");
        fieldData.setFieldComments("修改日期");
        fieldData.setUmwExpression("fixedValue(${value},\"sys_Import\")\t");//批量编辑默认将修改人的名字改为sys_Import,后续校验的话会变更过来。
        fieldData.setUDatatype("2");//字段类型 1-数字，2-字符
        fieldData.setUniquekeyFlag("0");//主键标志 1-是，0-否
        fieldData.setUpdateWay("1");//字段修改方式：1-覆盖
        fieldData.setUpdateFlag("1");//修改标志 1-是 0 -否
        fieldData.setFilterFlag("0");//过滤标志1-是 0 -否
        rootdao.save(fieldData);
    }




}
