package com.gingkoo.mbt.action;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommBatDelService;
import com.gingkoo.orm.entity.Mbt620;

public class Mbt620BatDelAction extends WebAlterAction {

	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean updateReturnBean = new UpdateReturnBean();
            UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResult().containsKey("Mat_620_ds") ?
                    multiUpdateResultBean.getUpdateResultBeanByID("Mat_620_ds") : multiUpdateResultBean.getUpdateResultBeanByID("Mat_620_2007_ds");
            List<Map<String, String>> records = resultBean.getTotalList();
//        List<Map<String, String>> records = multiUpdateResultBean.getUpdateResultBeanByID("Mat_620_ds").getTotalList();
//        new MbtCommBatApvService(Mbt610.class, records).approve();
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommBatDelService mbtCommBatDelService = (MbtCommBatDelService) context.getBean("mbtCommBatDelService");
        mbtCommBatDelService.setEntityName(Mbt620.class.getName());
        mbtCommBatDelService.setToBeApproveRecords(records);
        mbtCommBatDelService.batchDelete();
        updateReturnBean.setParameter("isOptSucc", "true");
        return updateReturnBean;
    }

}
