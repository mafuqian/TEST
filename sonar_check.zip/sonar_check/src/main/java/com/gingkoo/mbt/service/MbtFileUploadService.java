package com.gingkoo.mbt.service;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.mbt.service.base.MbtCommonBaseService;
import com.gingkoo.mbt.util.MbtDateUtils;

/**
 * @Author: li.jy
 * @Date: 2019/4/9
 */
@Component
public class MbtFileUploadService {
    private static final Log logger = LogFactory.getLogger(MbtFileUploadService.class);

    @Autowired
    MbtCommonBaseService mbtCommonBaseService;

    public void execute(List<Map<String, String>> list) throws AppException {
        Map<String, String> recordMap = list.get(0);
        if (recordMap.get("opt").equals("countData")) {
            for (Map<String, String> mapTmp : list) {
                String fileType = mapTmp.get("fileType");
                String countSql = mbtCommonBaseService.getParamValue("MBT_FILE_UPLOAD_COUNT_SQL");
                countSql = countSql.replace("type", fileType);
                Iterator iterator = ROOTDAOUtils.getROOTDAO().queryBySQL(countSql);
                BigDecimal count = BigDecimal.ZERO;
                while (iterator.hasNext()) {
                    count = (BigDecimal) iterator.next();
                }
                String sql = "update MBT_FILE_UPLOAD_INFO set DATA_COUNT=" + count + MbtDateUtils.updateTime() + " where FILE_TYPE=" + fileType;
                ROOTDAOUtils.getROOTDAO().executeSql(sql);
            }
        } else if (recordMap.get("opt").equals("geneMessage")) {
            MbtXmlConvertService xmlConvertService = ApplicationContextUtil.getBean(MbtXmlConvertService.class);
            for (Map<String, String> mapTmp : list) {
                String fileType = mapTmp.get("fileType");
                Map<String, String> xmlMap = xmlConvertService.buildMbtT1Data2XML(fileType);
                logger.info(fileType + "生成报文结果：" + xmlMap.toString());
            }
        }
    }
}
