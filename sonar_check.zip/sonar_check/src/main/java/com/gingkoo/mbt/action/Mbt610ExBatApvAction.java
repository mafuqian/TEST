package com.gingkoo.mbt.action;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommApvService;
import com.gingkoo.orm.entity.Mbt610Ex;
import com.gingkoo.orm.entity.Mbt620Ex;
import com.gingkoo.orm.entity.Mbt630Ex;
import com.gingkoo.orm.entity.Mbt640Ex;
import com.gingkoo.orm.entity.Mbt650Ex;

public class Mbt610ExBatApvAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean updateReturnBean = new UpdateReturnBean();
        List<Map<String,String>> records = multiUpdateResultBean.getUpdateResultBeanByID("Mat_610_Ex_ds").getTotalList();
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommApvService mbtCommApvService = (MbtCommApvService) context.getBean("mbtCommApvService");
       for(int i=0;i<records.size();i++){
           Map<String,String> map= (HashMap) records.get(i);
           map.put("apvResult","pass");
           if (map.get("bInfRecType").equals("614")){
               mbtCommApvService.setEntityName(Mbt610Ex.class.getName());
           }else if(map.get("bInfRecType").equals("624")){
               mbtCommApvService.setEntityName(Mbt620Ex.class.getName());
           }else if(map.get("bInfRecType").equals("634")){
               mbtCommApvService.setEntityName(Mbt630Ex.class.getName());
           }else if(map.get("bInfRecType").equals("644")){
               mbtCommApvService.setEntityName(Mbt640Ex.class.getName());
           }else if(map.get("bInfRecType").equals("654")){
               mbtCommApvService.setEntityName(Mbt650Ex.class.getName());
           }
           UpdateResultBean a = new UpdateResultBean();
           a.setParamMap(map);
           List list = new ArrayList();
//           Iterator iter = map.entrySet().iterator(); // 获得map的Iterator
//           while (iter.hasNext()) {
//               Map.Entry entry = (Map.Entry) iter.next();
//               list.add(entry.getKey());
//               list.add(entry.getValue());
//           }
           list.add(0,map);
           a.setTotalList(list);
           mbtCommApvService.setUpdateResultBean(a);
           mbtCommApvService.approve();
       }
        updateReturnBean.setParameter("isOptSucc", "true");
        return updateReturnBean;
    }
}
