package com.gingkoo.mbt.action;

import com.gingkoo.common.batch.entity.GpBmIdUploadlog;
import com.gingkoo.common.dataimport.component.DataImportComponent;
import com.gingkoo.common.dataimport.service.FileExistService;
import com.gingkoo.common.platform.util.FileUtil;
import com.gingkoo.common.validator.component.ValidatorComponent;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.SysParamService;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.gf4j2.framework.util.DateHelper;
import com.gingkoo.mbt.service.ExportSettingService;
import com.gingkoo.orm.entity.MbtFileUploadInfo;

import net.sf.json.JSONObject;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;


/**
 * ExcelTemplateFile 批量编辑文件从前台页面上传。自动抓取文件，并自动执行导入流程。
 *
 */
@Controller
public class FbFileUploadController {

	private static Log logger = LogFactory.getLogger(FbFileUploadController.class);

	
	@Value("${mbt.output.path}")
	public String output;

	@Autowired
	@Qualifier("ROOTDAO")
	ROOTDAO rootdao;
	
	@Autowired
	ExportSettingService exportSettingService;

	@ResponseBody
	@RequestMapping(value = { "/do/FbFile/upload" }, method = { RequestMethod.POST } ,produces = "text/html; charset=utf-8")
	public void upload(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.reset();
		response.setCharacterEncoding("UTF-8");
		response.setHeader("Content-type", "application/json; charset=utf-8");
		PrintWriter out = response.getWriter();
		JSONObject json = new JSONObject();
		InetAddress addr = null;
		String ip = null;
		String guid = "";
		try {
			addr = InetAddress.getLocalHost();
		} catch (UnknownHostException var34) {
			var34.printStackTrace();
		}

		ip = addr.getHostAddress();
		String senIp = request.getRemoteAddr();
		Date date = new Date();
		DiskFileItemFactory factory = new DiskFileItemFactory();
		String path = this.output +File.separator +"mbtfile"+ File.separator+"feedback" + File.separator + DateHelper.today();

		File file = new File(path);
		if (!file.exists()) {
			file.mkdirs();
		}

		factory.setRepository(file);
		factory.setSizeThreshold(1048576);
		ServletFileUpload upload = new ServletFileUpload(factory);
		upload.setHeaderEncoding("utf-8");
		GlobalInfo globalInfo = null;

		try {
			globalInfo = GlobalInfo.getFromRequest(request);
			String brno = null;
			String tlrno = null;
			String groupId = "";
			//String filler3 = "";
			String funcid = "";
			if (globalInfo != null) {
				tlrno = globalInfo.getTlrno();
				brno = globalInfo.getBrno();
				groupId = globalInfo.getGroupId();
				funcid = globalInfo.getFuncId();
				//filler3 = " and filler3=\'" + brno + "\'";
				globalInfo.appendBizLog("文件上传");
			}
		
			List<FileItem> items = upload.parseRequest(request);
			for (int i = 0; i < items.size(); ++i) {
				FileItem item = items.get(i);
				String[] realNameArray = item.getName().split("\\\\");
				String fileName = item.getName();
				if (fileName != null && !"".equals(fileName.trim())) {
					fileName = fileName.substring(fileName.lastIndexOf("\\") + 1, fileName.length());
					fileName = fileName.replace("%2F", "/");
					String realName = realNameArray[realNameArray.length - 1];
					String md5Name = FileUtil.getMD5FInputStream(item.getInputStream()) + "."
							+ realName.substring(realName.lastIndexOf(".") + 1);

					File dir = new File(path);
					if (!dir.exists()) {
						dir.mkdirs();
					}
						File targetFile = new File(dir, realName);
						
						item.write(targetFile);
						/*if (!targetFile.exists()) {
							item.write(targetFile);
						}*/
					if (!".DS_Store".equals(fileName)) {
						GpBmIdUploadlog uploadLog = new GpBmIdUploadlog();
						guid = UuidHelper.getCleanUuid();
						uploadLog.setUploadGuid(guid);
						uploadLog.setStoreName(md5Name);
						uploadLog.setFileName(realName);
						uploadLog.setTargetPath(targetFile.getPath());
						uploadLog.setWorkDate(new SimpleDateFormat("yyyyMMdd").format(date));
						uploadLog.setSndIp(senIp);
						uploadLog.setRecIp(ip);
						uploadLog.setFiller1("未导入");
						uploadLog.setUploadTime(new SimpleDateFormat("yyyyMMddHHmmss").format(date));
						uploadLog.setFiller3(brno);
						uploadLog.setUploader(tlrno);
						
						rootdao.save(uploadLog);
					}

					/**
					 * 文件上传完毕后，自动调用文件查询列表，找到当前文件的map，并调用导入方法进行导入。
					 */
					
					String fbName = realName.substring(0, realName.indexOf(".")-1)+"0.txt";
					
					StringBuffer hql = new StringBuffer();
					hql.append("from MbtFileUploadInfo where  1=1 ");
					hql.append(" and fileName='").append(fbName).append("'");
					List<MbtFileUploadInfo> list = new ArrayList<MbtFileUploadInfo>();
					MbtFileUploadInfo mbtFileUploadInfo = null;
					
					list = rootdao.queryByQL2List(hql.toString());
					
					if(list.size() == 0 || list.isEmpty()) {
						json.put("success", false);
						json.put("fileName", realName);
						json.put("message", "反馈文件导入失败，未找到上报文件");
					}else {
						mbtFileUploadInfo = list.get(0);
						mbtFileUploadInfo.setFbFileIsLoad("02");
						mbtFileUploadInfo.setFbFileName(realName);
						mbtFileUploadInfo.setFbFileInportDate(DateHelper.today());
						mbtFileUploadInfo.setFbFileInportTime(DateHelper.now());
						mbtFileUploadInfo.setFbFilePath(path+File.separator+realName);
						rootdao.update(mbtFileUploadInfo);
						json.put("success", true);
						json.put("fileName", realName);
						json.put("message", "反馈文件导入成功");
					}
					
					
				}

			}

		} catch (Exception e) {
			json.put("success", false);
			json.put("message", "文件上传失败！【" + e.getMessage() + "】");
			e.printStackTrace();
		} finally {
			out.write(json.toString());
			if (out != null) {
				out.close();
			}
		}
	}

	/**
	 * 根据 上传路径，真实的文件名进行查询，过滤，找到相应的配置信息。
	 * 
	 * @param filePath
	 * @param realName
	 * @return
	 */
	@SuppressWarnings({ "unused", "rawtypes", "unchecked" })
	private List<Map<String, String>> excelTemplateFileQuery(String filePath, String realName)throws CommonException {
		List existList = new ArrayList<>();
		GlobalInfo globalInfo = GlobalInfo.getCurrentInstance();
		Map<String, String> fileMap = new HashMap<String, String>();
		List<Map<String, String>> retList = new ArrayList<>();
		Map<String, String> mapFile = new HashMap<String, String>();
		String crtDate = new SimpleDateFormat("yyyyMMdd").format(new Date());
		mapFile.put("cacheCount", "false");
		mapFile.put("beginDate", crtDate);
		mapFile.put("endDate", crtDate);
		mapFile.put("nextPage", "1");
		mapFile.put("filePath", filePath);
		mapFile.put("departId", globalInfo.getBrno());
		mapFile.put("everyPage", "10000");
		mapFile.put("fileName", "");
		mapFile.put("filler2", "");
		mapFile.put("filePath", filePath);
		FileExistService fileExistService = (FileExistService) ApplicationContextUtil.getBean("fileExistService");
		// 查询文件列表
		List fileTemp = fileExistService.selectFileList(mapFile);
		// 查询文件是否存在
		for (int j = 0; j < fileTemp.size(); j++) {
			Map<String, String> fileListStatus = (Map<String, String>) fileTemp.get(j);
			String fileStatus = fileListStatus.get("fileStatus");
			// 判断文件是否存在
			if ("1".equals(fileStatus)) {
				String realFileName = fileListStatus.get("realFileName");
				// 判断该文件是否是自动导入的。
				if (realName.equals(realFileName)) {
					// 重新分配空间
					fileMap = new HashMap<String, String>();
					fileMap.put("guid", fileListStatus.get("guid"));
					fileMap.put("departId", fileListStatus.get("departId"));
					fileMap.put("fileName", fileListStatus.get("fileName"));
					fileMap.put("keyFlag", fileListStatus.get("keyFlag"));
					fileMap.put("selectFlag", fileListStatus.get("selectFlag"));
					fileMap.put("comments", fileListStatus.get("comments"));
					fileMap.put("filenameFormat", fileListStatus.get("filenameFormat"));
					fileMap.put("fileOwner", fileListStatus.get("fileOwner"));
					fileMap.put("WORK_DATE", fileListStatus.get("workDate"));
					fileMap.put("fileStatus", fileListStatus.get("fileStatus"));
					fileMap.put("realFileName", fileListStatus.get("realFileName"));
					fileMap.put("filler1", fileListStatus.get("filler1"));
					fileMap.put("importType", fileListStatus.get("importType"));
					fileMap.put("checkTable", fileListStatus.get("checkTable"));
					fileMap.put("jobType", fileListStatus.get("jobType"));
					fileMap.put("args", fileListStatus.get("args"));
					fileMap.put("funcid", fileListStatus.get("funcid"));
					fileMap.put("funcName", fileListStatus.get("funcName"));
					fileMap.put("autoImportFlag", fileListStatus.get("autoImportFlag"));
					fileMap.put("fuid", fileListStatus.get("fuid"));
					fileMap.put("mainFlag", fileListStatus.get("mainFlag"));
					retList.add(fileMap);
				}
			}
		}
		return retList;
	}

	
	/**
	 * 根据 uploadGUId 获取当前导入结果信息
	 * @throws CommonException 
	 */
	@SuppressWarnings("unchecked")
	private String  getGpBmIdUploadlogByguid(String guid) throws CommonException {
		String result = "";
		String hql = " from GpBmIdUploadlog where uploadGuid = '"+guid+"'";
		Iterator<GpBmIdUploadlog> it = rootdao.queryByQL(hql);
		if(it.hasNext()) {
			result = it.next().getFiller1();
		}
		return result;
	}
	
}