package com.gingkoo.mbt.action;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.GpBmSysParam;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommCommitToApvService;
import com.gingkoo.orm.entity.MbtD101;

public class MbtD101SubmitAction extends MbtSingleRecordAction{
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
            throws AppException {
        // TODO Auto-generated method stub
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResult().containsKey("MbtD101_Send_ds") ?
                multiUpdateResultBean.getUpdateResultBeanByID("MbtD101_Send_ds") : multiUpdateResultBean.getUpdateResultBeanByID("MbtD101_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
        if(!(resultBean.getParameter("opr").equals("del") && "del" == resultBean.getParameter("opr"))){
            recordMap.put("ognUserCode", GlobalInfo.getCurrentInstance().getTlrno());
            ROOTDAO dao = ROOTDAOUtils.getROOTDAO();
            String sql = "from GpBmSysParam where param_id='OGN_ORG_CODE'";
            List<GpBmSysParam> list = dao.queryByQL2List(sql);
            recordMap.put("ognOrgCode",list.get(0).getParamValue());
            process(resultBean, MbtD101.class);
        }
        resultBean.setRecodeIndex(0);
/*
        new MbtCommCommitToApvService(resultBean, MbtD101.class).commitToApprove();
*/

        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommCommitToApvService mbtCommCommitToApvService = (MbtCommCommitToApvService) context.getBean("mbtCommCommitToApvService");
        mbtCommCommitToApvService.commitToApprove(resultBean, MbtD101.class,returnBean);
        if("".equals(returnBean.getParameter("E_CODE"))) {
        	returnBean.setParameter("isOptSucc", "true");
        }else {
        	returnBean.setParameter("isOptSucc", "false");
        }

        return returnBean;
    }
}
