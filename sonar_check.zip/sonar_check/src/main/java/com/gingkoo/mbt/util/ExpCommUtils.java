package com.gingkoo.mbt.util;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.orm.entity.Mbt610;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataIntegrityViolationException;

import java.sql.BatchUpdateException;

/**
 * Created by liufangliang on 2020/2/6.
 */
public class ExpCommUtils {

    public static void process(UpdateResultBean resultBean, Class<?> clazz, MbtCommSaveService mbtCommSaveService) throws AppException{
        try{
            mbtCommSaveService.process(resultBean,clazz);
        }catch (Exception e){
            Throwable cause = e.getCause();
            if(cause instanceof BatchUpdateException || cause instanceof ConstraintViolationException) {
                String msg =  ((DataIntegrityViolationException) e).getRootCause().getMessage();
                throw new AppException("当前数据已存在，错误信息："+msg);
            }else {
                throw new AppException(e.getMessage());

            }
//            if (e instanceof DataIntegrityViolationException){
//                String msg =  ((DataIntegrityViolationException) e).getRootCause().getMessage();
//                throw new AppException("当前数据已存在，错误信息："+msg);
//
//            }else{
//                throw new AppException(e.getMessage());
//
//            }


        }
    }

    public static void batchProcess(UpdateResultBean resultBean, Class<?> clazz, MbtCommSaveService mbtCommSaveService) throws AppException{
        try{
            mbtCommSaveService.batchprocess(resultBean,clazz);
        }catch (Exception e){
            if (e instanceof DataIntegrityViolationException){
                String msg =  ((DataIntegrityViolationException) e).getRootCause().getMessage();
                throw new AppException("当前数据已存在，错误信息："+msg);

            }else{
                throw new AppException(e.getMessage());

            }


        }
    }
}
