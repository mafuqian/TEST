package com.gingkoo.mbt.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.common.query.entity.GpBmExportField;
import com.gingkoo.common.query.entity.GpBmExportSheet;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.config.database.base.MyHibernateTemplate;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.GpBmInqCfg;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.gf4j2.framework.util.ExceptionUtil;

@Service
public class GpBmInqCfgQueryService {


	private Logger logger = LoggerFactory.getLogger(GpBmInqCfgQueryService.class);

	@Resource
	private ROOTDAO rootDao;
	
	@Value("${datasource.url}")
	private String sqlDiverurl;
	
	
	/**
	 * 根据sqlId 确认在sql配置表中 是否存在
	 * 
	 * @param sqlId
	 * @return
	 * @throws CommonException
	 */
	public JobResult checkSqlIdisExists(String sqlId) throws CommonException {
		JobResult jr = new JobResult();
		jr.setErrCode("00");
		jr.setErrMsg("OK");
		String sql = "SELECT SQL_ID,SQL_STRING FROM GP_BM_INQ_CFG WHERE SQL_ID = '" + sqlId + "'";
		List<Map<String,Object>> list = rootDao.findBySql(sql);
		if (list.size()>0) {
			Map<String,Object> sqlMap = list.get(0);
			String sqlString = (String) sqlMap.get("SQL_STRING");
			if (StringUtils.isBlank(sqlString)) {
				jr.setErrCode("08");
				jr.setErrMsg("sqlId对应的sql语句为空，请确认是否已经添加好sql语句配置。");
			}
		}else {
				jr.setErrCode("07");
				jr.setErrMsg("sqlId对应的sql语句不存在，请输入已存在的sqlId。");

			}
		return jr;
	}
	



	/**
	 * 检查手工填写的sql是否符合规则。 规则制定： 1. from 后面必须是当前tableName , 2. tableName 后面必须存在 a 作为简称
	 * 3. 字段必须有 a. 前缀   4. where 后面必须有 1=1 5. 除了关联条件，没有其他查询条件。
	 * 
	 * @param sqlString
	 * @return
	 */
	public JobResult checkSqlStringMatchRule(String tableName, String sqlString) {
		JobResult jr = new JobResult();
		jr.setErrCode("00");
		jr.setErrMsg("成功。");
		tableName = tableName.toUpperCase();
		sqlString = sqlString.toUpperCase();

		// 如果sql语句中没有当前表名，不符合
		if (!sqlString.contains(tableName)) {
			jr.setErrCode("01");
			jr.setErrMsg("当前sql语句中没有查询" + tableName + "表。");
		}
		// 检查当前sql语句中查询的主表是tableName.
		String[] sql = sqlString.toUpperCase().split("FROM", -1);
		if (!sql[sql.length-1].trim().startsWith(tableName)) {
			jr.setErrCode("02");
			jr.setErrMsg("当前sql语句中,查询的主表不是" + tableName + "表。");
		}
		// 检查当前sql语句中查询的 主表是否 有简称 a
		sql = sqlString.split(tableName, 2);
		if (!sql[1].trim().toUpperCase().startsWith("A")) {
			jr.setErrCode("03");
			jr.setErrMsg("当前sql语句中,查询的主表" + tableName + "后面没有简称 “ A ”。");
		}
		// 检查当前sql语句中查询的字段是否有主表的字段
		if (!sqlString.toUpperCase().contains("A.")) {
			jr.setErrCode("04");
			jr.setErrMsg("当前sql语句中没有查询" + tableName + "表的字段。");
		}
		// 检查当前sql语句中 ,where 后 必须是1=1
		sql = sqlString.toUpperCase().trim().split("WHERE", 2);
		if (!sql[1].trim().startsWith("1=1")) {
			jr.setErrCode("05");
			jr.setErrMsg("当前sql语句中,where 后面必须是\" 1=1 \"。");
		}
		if (!sqlString.trim().endsWith("1=1")) {
			jr.setErrCode("06");
			jr.setErrMsg("当前sql语句中,不能存在查询条件。");
		}
		try {
			rootDao.queryBySQL(sqlString);
		} catch (CommonException e) {
			e.printStackTrace();
			jr.setErrCode("07");
			jr.setErrMsg("当前sql语句有误,不能正确执行。");
		}

		return jr;
	}

	
	

	
	
	

	/**
	 * 根据表名，从数据库底层视图中获取字段列表，并生成sql语句。
	 * @param tableName
	 * @return
	 */
	public String getSqlStringByTabelName(String tableName) {
		String queryColumnListByTableNameSql = "";
		if(StringUtils.isBlank(sqlDiverurl)) {
			return null;
		}else {
			if(sqlDiverurl.contains("oracle")) {
				//user_tab_cols / user_tab_columns 查看当前用户下的表及视图结构
				queryColumnListByTableNameSql = "select COLUMN_NAME from user_col_comments where 1=1 and TABLE_NAME='"+tableName+"' ";
			}else if(sqlDiverurl.contains("sqlserver")) {
//				 获取所有的表名
//				SELECT NAME FROM SYSOBJECTS WHERE XTYPE='U' ORDER BY NAME  --XTYPE='U':表示所有用户表;--XTYPE='S':表示所有系统表;
//				获取所有字段名
//				SELECT NAME FROM SYSCOLUMNS WHERE ID=OBJECT_ID('BCUSTOMER');
				queryColumnListByTableNameSql = "SELECT NAME as COLUMN_NAME FROM SYSCOLUMNS WHERE ID=OBJECT_ID('"+tableName+"')";
			}else if(sqlDiverurl.contains("mysql")) {
//				information_schema.COLUMNS 
				queryColumnListByTableNameSql = "select COLUMN_NAME from information_schema.COLUMNS where table_name = '"+tableName+"'";
			}
		}
		List<Map<String,Object>> columnList = rootDao.findBySql(queryColumnListByTableNameSql);
		
		StringBuilder sqlBuilder = new StringBuilder("SELECT ");
		for (Map<String,Object> columnMap : columnList) {
			sqlBuilder.append((String)columnMap.get("COLUMN_NAME")).append(",");
		}
		String sqlString = sqlBuilder.toString();
		sqlString = sqlString.trim().substring(0, sqlString.length() - 1);
		sqlString = sqlString + " from " + tableName + " A where 1=1 ";
		return sqlString;
	}
	
	
	
	
	/**
	 * 根据sqlid获取sqlstring
	 * @param sqlId
	 */
	public String getSqlStringBySqlId(String sqlId) {
		String sql = "SELECT SQL_ID,SQL_STRING FROM GP_BM_INQ_CFG WHERE SQL_ID = '" + sqlId + "'";
		List<Map<String,Object>> list = rootDao.findBySql(sql);
		if (list.size()>0) {
			return (String) list.get(0).get("SQL_STRING");
		}
		return "";
	}
	
	/**
	 * 根据sqlid获取sql信息
	 * @param sqlId
	 */
	public Map getSqlInfoBySqlId(String sqlId) {
		String sql = "SELECT DATA_ID,SQL_ID,SQL_STRING FROM GP_BM_INQ_CFG WHERE SQL_ID = '" + sqlId + "'";
		List<Map<String,Object>> list = rootDao.findBySql(sql);
		if (list.size()>0) {
			return  list.get(0);
		}
		return null;
	}
	

	/**
	 * 根据sqlid获取sql信息
	 * @param sqlId
	 * @throws CommonException 
	 */
	public GpBmInqCfg getGpBmInqCfgBySqlId(String sqlId) throws CommonException {
		String hql = " from GpBmInqCfg where sqlId = ?";
		Iterator<GpBmInqCfg> it = rootDao.queryByQL(hql);
		if (it.hasNext()) {
			return it.next();
		}
		return null;
	}
	
	
	
	/**
	 * 根据sqlId 检查sql语句是否已经被占用或已存在。
	 * @param sqlId
	 * @return
	 * @throws CommonException
	 */
	@SuppressWarnings("rawtypes")
	public boolean sqlIdIsExists(String sqlId) throws CommonException {
		String sql = "SELECT count(1) as COUNT FROM GP_BM_INQ_CFG WHERE SQL_ID = '" + sqlId + "'";
		List<Map<String, Object>> list = rootDao.findBySql(sql);
		BigDecimal count = (BigDecimal) list.get(0).get("COUNT");
		int j =count.compareTo(new BigDecimal(0));
		if(j>0) {
			return true;
		}
		return false;
	}
	
	
	/**
	 * 根据sqlId查询sql配置
	 * @param sqlId
	 * @return
	 * @throws CommonException
	 */
	public GpBmInqCfg queryGpBmInqCfgBySqlId(String sqlId) throws CommonException {
		List<GpBmInqCfg> sqlList = new ArrayList<GpBmInqCfg>();
		String hql = "from GpBmInqCfg where 1=1 and sqlId = ? ";
		try {
			sqlList = ((MyHibernateTemplate) ApplicationContextUtil.getBean(MyHibernateTemplate.class)).find(hql,
					new Object[] { sqlId });
		} catch (Exception var6) {
			var6.printStackTrace();
			ExceptionUtil.throwCommonException("查询失败！");
		}
		if(sqlList.size()>0) {			
			return sqlList.get(0);
		}
		return null;
	}
	
	
	/**
	 * 根据dataId查询sql配置
	 * @param dataId
	 * @return
	 * @throws CommonException
	 */
	public GpBmInqCfg queryGpBmInqCfgByDataId(String dataId) throws CommonException {
		List<GpBmInqCfg> sqlList = new ArrayList<GpBmInqCfg>();
		String hql = "from GpBmInqCfg where 1=1 and dataId = ? ";
		try {
			sqlList = ((MyHibernateTemplate) ApplicationContextUtil.getBean(MyHibernateTemplate.class)).find(hql,
					new Object[] { dataId });
		} catch (Exception var6) {
			var6.printStackTrace();
			ExceptionUtil.throwCommonException("查询失败！");
		}
		if(sqlList.size()>0) {			
			return sqlList.get(0);
		}
		return null;
	}
	
	/**
	 * 保存sql 配置。
	 * @param gpBmExportSheet
	 * @throws CommonException 
	 */
	public void saveGpBmInqCfg(String sqlId,String sqlString) throws CommonException {
		GpBmInqCfg inqCfg = new GpBmInqCfg();
		boolean sqlExists = sqlIdIsExists(sqlId.trim());
		if(sqlExists) {//存在就更新
			inqCfg = queryGpBmInqCfgBySqlId(sqlId);
			inqCfg.setSqlString(sqlString);
			rootDao.update(inqCfg);
		}else {//不存在就新增。
			inqCfg.setDataId(UuidHelper.getCleanUuid());
			inqCfg.setSqlId(sqlId);
			inqCfg.setSqlString(sqlString);
			rootDao.save(inqCfg);
		}
	}
	
	/**
	 * 保存sql 配置。
	 * @param gpBmExportSheet
	 * @throws CommonException 
	 */
	public void saveGpBmInqCfg(String dataId, String sqlId,String sqlString) throws CommonException {
		GpBmInqCfg inqCfg = null;
		inqCfg = queryGpBmInqCfgByDataId(dataId.trim());
		
		if(inqCfg!=null) {//存在就更新
			inqCfg.setSqlId(sqlId);
			inqCfg.setSqlString(sqlString);
			rootDao.update(inqCfg);
		}else {//不存在就新增。
			inqCfg = new GpBmInqCfg();
			inqCfg.setDataId(dataId);
			inqCfg.setSqlId(sqlId);
			inqCfg.setSqlString(sqlString);
			rootDao.save(inqCfg);
		}
	}
	
	
	/**
	 * 保存sql 配置。
	 * @param 
	 * @throws CommonException 
	 */
	public void saveGpBmInqCfg(GpBmInqCfg inqCfg) throws CommonException {
		String dataId = inqCfg.getDataId();
		if(dataId.trim().length()==32) {
			rootDao.saveOrUpdate(inqCfg);
		}
	}
	
	
	
	/**
	 * 根据sqlId 删除sql配置
	 * @param sqlId
	 * @throws CommonException
	 */
	public void deleteGpBmInqCfg(String sqlId) throws CommonException {
		boolean sqlExists = sqlIdIsExists(sqlId.trim());
		if(sqlExists) {
			GpBmInqCfg cfg = queryGpBmInqCfgBySqlId(sqlId.trim());
			rootDao.delete(cfg);
		}
	}
	
	
	/**
	 * 根据dataId 删除sql配置
	 * @param dataId
	 * @throws CommonException
	 */
	public void deleteGpBmInqCfgByDataId(String dataId) throws CommonException {
		GpBmInqCfg inq = queryGpBmInqCfgByDataId(dataId);
		if(inq==null) {
			return;
		}
		rootDao.delete(inq);
	}
	
}
