package com.gingkoo.mbt.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.gingkoo.common.query.entity.GpBmExportPkFk;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.BaseService;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;

@Component
public class ExportTablePkAlterService extends BaseService {
	
    @Resource
    private ROOTDAO rootDao;
    
    public static final String ID = "exportTablePkAlterService";
    public static final String CMD = "CMD";
    public static final String CMD_ADD = "CMD_ADD";
    public static final String CMD_MOD = "CMD_MOD";
    public static final String CMD_DEL = "CMD_DEL";
    public static final String IN_PARAM = "IN_PARAM";


    public void beforeProc(ServiceContext context) throws CommonException {
    }

    public void execute(ServiceContext context) throws CommonException {
        String cmd = (String)context.getAttribute(CMD);
        GpBmExportPkFk gpBmExportPkFk = (GpBmExportPkFk)context.getAttribute(IN_PARAM);
        if (CMD_ADD.equals(cmd)) {
            gpBmExportPkFk.setDataId(UuidHelper.getCleanUuid());
            this.rootDao.save(gpBmExportPkFk);
        } else if (CMD_MOD.equals(cmd)) {
            this.rootDao.update(gpBmExportPkFk);
        } else if (CMD_DEL.equals(cmd)) {
            String dataId = gpBmExportPkFk.getDataId();
            this.rootDao.delete(GpBmExportPkFk.class,dataId);
        }

    }

    public void afterProc(ServiceContext context) throws CommonException {
    }

   
}
