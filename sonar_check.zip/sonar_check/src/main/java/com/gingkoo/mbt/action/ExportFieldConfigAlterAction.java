package com.gingkoo.mbt.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.common.query.entity.GpBmExportField;
import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.OPCaller;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.mbt.service.ExportConfigSyncImportService;
import com.gingkoo.mbt.service.ExportFieldConfigAlterService;
import com.gingkoo.mbt.service.ExportFieldConfigSortService;

public class ExportFieldConfigAlterAction extends WebAlterAction {
	private static final String DATASET_ID = "Export_FieldBas_ds";

	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request,
			HttpServletResponse respone) throws AppException {
		UpdateReturnBean updateReturnBean = new UpdateReturnBean();
		UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
		ServiceContext oc = new ServiceContext();
		try {
			GpBmExportField gpBmExportField = new GpBmExportField();
			String str = "";
			if (updateResultBean.hasNext()) {
				Map<String, String> map = updateResultBean.next();
				String opr = map.get("opr");
				if ("add".equals(opr)) {
					oc.setAttribute(ExportFieldConfigAlterService.CMD, ExportFieldConfigAlterService.CMD_ADD);
					str = "新增";
				} else if ("mod".equals(opr)) {
					oc.setAttribute(ExportFieldConfigAlterService.CMD, ExportFieldConfigAlterService.CMD_MOD);
					str = "修改";
				}else if("batchAdd".equals(opr)) {
					oc.setAttribute(ExportFieldConfigAlterService.CMD, ExportFieldConfigAlterService.CMD_BATCH_ADD);
					str = "批量新增";
				}else if("del".equals(opr)) {
					oc.setAttribute(ExportFieldConfigAlterService.CMD, ExportFieldConfigAlterService.CMD_DEL);
					str = "删除";
				}
				mapToObject(gpBmExportField, map);
				oc.setAttribute(ExportFieldConfigAlterService.IN_PARAM, gpBmExportField);
				oc.setAttribute(ExportFieldConfigAlterService.IN_MAP, map);
				OPCaller.call(ExportFieldConfigAlterService.ID, oc);
				OPCaller.call(ExportFieldConfigSortService.ID, oc);
				ExportConfigSyncImportService exportConfigSyncImportService = ApplicationContextUtil.getBean(ExportConfigSyncImportService.class);
				exportConfigSyncImportService.execute(exportConfigSyncImportService.FIELD, gpBmExportField.getPDataId());
			}

			GlobalInfo.getCurrentInstance().appendBizLog("文件导出配置文件菜单关联  -- " + str + "功能");
			updateReturnBean.setParameter("code", "00");
			updateReturnBean.setParameter("desc", "");
		} catch (CommonException e) {
			e.printStackTrace();
			updateReturnBean.setParameter("code", "99");
			updateReturnBean.setParameter("desc", e.getErrMessage());
		}

		return updateReturnBean;
	}
}

