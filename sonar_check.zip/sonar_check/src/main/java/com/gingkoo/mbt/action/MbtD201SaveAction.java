package com.gingkoo.mbt.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.util.MapToObject;
import com.gingkoo.orm.entity.MbtD201;
import com.gingkoo.orm.entity.MbtD202;
import com.gingkoo.orm.entity.MbtD501;

public class MbtD201SaveAction  extends MbtSingleRecordAction {

    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
            throws AppException {
        // TODO Auto-generated method stub
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("MbtD201Add_Dtl_ds");
        UpdateResultBean dtlResultBean = multiUpdateResultBean.getUpdateResultBeanByID("MbtD201Add_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
        Map<String ,String> dtlRecord;
        ROOTDAO dao = ROOTDAOUtils.getROOTDAO();
        String sql = "from MbtD501 where FILE_NAME = '"+recordMap.get("fileName")+"'";
        List list = dao.queryByQL2List(sql);
        MbtD501 mbtD501 = new MbtD501();
        if(!list.isEmpty()) {
            Object l = list.get(0);
            Map<String, String> map = new HashMap<>();

            try {
                map = MapToObject.objectToMap(l);
                mapToObject(mbtD501,map);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        recordMap.put("sendStatus",mbtD501.getSendStatus());

        process(resultBean, MbtD201.class);

        if("mod" .equals( recordMap.get("opr"))){
            dtlRecord = dtlResultBean.getTotalList().get(0);
        }else{
            dtlRecord = new HashMap<>();
            dtlResultBean.getTotalList().add(dtlRecord);
        }

        dtlRecord.put("pdataId",recordMap.get("dataId"));
        dtlRecord.put("sendStatus",mbtD501.getSendStatus());
        dtlRecord.put("fileName",mbtD501.getFileName());
        process(dtlResultBean, MbtD202.class);
        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("dataId", getDataId());
        return returnBean;
    }





}
