package com.gingkoo.mbt.service;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.util.DateUtil;
import com.gingkoo.mbt.service.base.MbtCommonBaseService;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 通用单笔审核 Service, 一般单笔审核可调用此类 Service
 *
 * 调用此审核 Service 的前提条件是 updateResultBean 的记录中必须包含
 * 被审核的记录的唯一标识 dataId 和审核结果apvResult(pass|reject),
 * 若目标状态是审核拒绝(reject)，还需要包含拒绝理由字段dataRejDesc。
 *
 * 在审核过程中，此 Service 会先验证数据的当前状态是否能够被更新为目标状态，
 * 验证通过方能完成审核。合法的状态：
 * 审核通过： 补录待审核 11 -> 补录已审核 21
 * 审核拒绝： 补录待审核 11 -> 待补录 00
 * 审核拒绝： 补录已审核 21 -> 待补录 00
 * @author fuxiang.luo@gingkoo.com
 *
 */

//@Component
@Service
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class MbtCommCreditReportBatchApvService {

    private UpdateResultBean updateResultBean;

    private Log logger = LogFactory.getLogger(MbtCommCreditReportBatchApvService.class);

    private String entityName;

    private String currentDataStatus;
    private String associatedUserStatus;

    private String targetDataStatus;

    private String dataRejDesc;

    private String dataId;

 //   private ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
    @Autowired
    private ROOTDAO rootdao;
    private List<Map<String, String>> toBeApproveRecords;
//    @Autowired
//    private MbtBakTablesServive mbtBakTablesServive;


    private String userStatusChangeUser;
    private String userStatusChangeUserName;

    @Autowired
    private MbtCommonBaseService mbtCommonBaseService;

    public UpdateResultBean getUpdateResultBean() {
        return updateResultBean;
    }

    public void setUpdateResultBean(UpdateResultBean updateResultBean) {
        this.updateResultBean = updateResultBean;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }
    public List<Map<String, String>> getToBeApproveRecords() {
        return toBeApproveRecords;
    }

    public void setToBeApproveRecords(List<Map<String, String>> toBeApproveRecords) {
        this.toBeApproveRecords = toBeApproveRecords;
    }
//    /**
//     * 构造方法
//     * @param clazz 实体类
//     * @param updateResultBean 前端提交过来的 updateResultBean
//     */
    public MbtCommCreditReportBatchApvService(UpdateResultBean updateResultBean, Class clazz){
        this.entityName = clazz.getTypeName();
        this.updateResultBean = updateResultBean;
        this.mbtCommonBaseService = new MbtCommonBaseService();
    }

    public MbtCommCreditReportBatchApvService(){

    }

    /**
     * 执行审核
     * @throws AppException 审核时抛出的审核异常，提示用户异常原因
     */
    @Transactional(rollbackFor = Exception.class)
    public void approve() throws AppException {

        List instances;

        StringBuilder ids = new StringBuilder();
        for(Map record : toBeApproveRecords){
            ids.append("'");
            ids.append(record.get("dataId"));
            ids.append("',");
        }
        ids.deleteCharAt(ids.length()-1);
        String hql = "from " + entityName + " where dataId in(" + ids + ")";
        try {
            instances = rootdao.queryByQL2List(hql);
        } catch (CommonException e) {
            logger.error(e.getLocalizedMessage());
            throw new AppException("审核失败！系统错误");
        }

        String currentDataStatus; //当前状态
        String targetDataStatus="";    // 目标状态

        // 检查待审核的记录是否都合法
        for (Object e : instances){
            try {
                String dataCrtUser = BeanUtils.getProperty(e, "dataCrtUser");
                if (!StringUtils.isEmpty(dataCrtUser) &&dataCrtUser.equals(GlobalInfo.getCurrentInstance().getTlrno())){
                    throw new AppException("审核人不得是操作人");
                }
                currentDataStatus = BeanUtils.getProperty(e, "dataStatus");
                associatedUserStatus = BeanUtils.getProperty(e, "associatedUserStatus");
                Map<String,String> map = new HashMap<String,String>();
                if ("00".equals(currentDataStatus)){
                    map.put("currDataStatus", currentDataStatus);
                }else{
                    map.put("currDataStatus", associatedUserStatus);
                }
//                Map<String,String> map = new HashMap<String,String>();
//                map.put("currDataStatus", currentDataStatus);
                if ("01".equals(associatedUserStatus) ||"04".equals(associatedUserStatus)||"07".equals(associatedUserStatus)
                        ||"10".equals(associatedUserStatus) ||"13".equals(associatedUserStatus)||"15".equals(associatedUserStatus)){
                        throw new AppException("不需要重复审核。");

                }else if("00".equals(currentDataStatus) ||"03".equals(associatedUserStatus)||"06".equals(associatedUserStatus)
                        ||"09".equals(associatedUserStatus) ||"12".equals(associatedUserStatus)){
                        map.put("actionId", "apv");
                    Map<String,String> resultMap = mbtCommonBaseService.RedataStatus(map);

                    targetDataStatus = resultMap.get("dataStatus");
                    associatedUserStatus = targetDataStatus;
                    if(null==resultMap.get("errMsg") ||"".equals(resultMap.get("errMsg"))) {
                        targetDataStatus = resultMap.get("dataStatus");
                    }else {
                        throw new AppException(resultMap.get("errMsg"));
                    }
                }else { // 其它状态
                    throw new AppException("当前状态不需要审核。");
                }
                BeanUtils.setProperty(e, "dataApvUser", GlobalInfo.getCurrentInstance().getTlrno());
                BeanUtils.setProperty(e, "dataApvTime", DateUtil.get14Date());
                BeanUtils.setProperty(e, "dataApvDate", DateUtil.get8Date());
                BeanUtils.setProperty(e, "associatedUserStatus", associatedUserStatus);
                if (!(null== targetDataStatus)) {
                    BeanUtils.setProperty(e, "dataStatus", targetDataStatus);
                }
                rootdao.update(e);
                Object clazz =Class.forName("com.gingkoo.orm.entity.MbtSendUserManageLog").newInstance();

                BeanUtils.setProperty(e, "userStatusChangeDate", DateUtil.get8Date());
                BeanUtils.setProperty(e, "userStatusChangeTime", DateUtil.get14Date());
                BeanUtils.setProperty(e, "bindTime", DateUtil.get14Date());
                BeanUtils.setProperty(e, "bindDate", DateUtil.get8Date());
                BeanUtils.copyProperties(clazz,e);
                String dataId = UUID.randomUUID().toString().replace("-", "");
                 map = new HashMap<String,String>();
                BeanUtils.copyProperties(map,e);
                BeanUtils.setProperty(clazz,"pdataId", map.get("dataId"));
                BeanUtils.setProperty(clazz,"dataId", dataId);
                BeanUtils.setProperty(clazz, "userStatusChangeUserName", userStatusChangeUserName);
                BeanUtils.setProperty(clazz, "userStatusChangeUser", userStatusChangeUser);

                //操作类型字段赋值
                rootdao.save(clazz);
            } catch (Exception e1) {
                e1.printStackTrace();
                logger.error(e1.getLocalizedMessage());
                throw new AppException(e1.getLocalizedMessage());

            }
        }
    }

}
