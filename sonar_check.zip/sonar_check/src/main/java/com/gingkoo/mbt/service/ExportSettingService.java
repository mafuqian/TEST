package com.gingkoo.mbt.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.gingkoo.common.batch.entity.GpBmIdFielddata;
import com.gingkoo.common.batch.entity.GpBmIdFiledata;
import com.gingkoo.common.batch.entity.GpBmIdSheetdata;
import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.common.query.entity.GpBmExportField;
import com.gingkoo.common.query.entity.GpBmExportFunction;
import com.gingkoo.common.query.entity.GpBmExportSheet;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.config.database.base.MyHibernateTemplate;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.gf4j2.framework.util.ExceptionUtil;

@Service
public class ExportSettingService {

	private static final Log logger = LogFactory.getLogger(ExportSettingService.class);


	@Resource
	private ROOTDAO rootDao;
	
	
	@Autowired
	private GpBmInqCfgQueryService inqQueryService;
	
	
	
	/**
	 * 根据菜单层的 dataId 查询sheet层数据
	 * 
	 * @param pDataId
	 *            sheet层的pDataId,菜单层的dataId
	 * @throws CommonException
	 */
	public GpBmExportSheet getGpBmExportSheetByDataId(String dataId) throws CommonException {
		List<GpBmExportSheet> sheetList = new ArrayList<GpBmExportSheet>();
		String hql = "from GpBmExportSheet where 1=1 and dataId = ? ";
		try {
			sheetList = ((MyHibernateTemplate) ApplicationContextUtil.getBean(MyHibernateTemplate.class)).find(hql,
					new Object[] { dataId });
		} catch (Exception var6) {
			var6.printStackTrace();
			ExceptionUtil.throwCommonException("查询失败！");
		}
		return sheetList.get(0);
	}

	/**
	 * 根据菜单层的 dataId 查询sheet层数据
	 * 
	 * @param pDataId
	 *            sheet层的pDataId,菜单层的dataId
	 * @throws CommonException
	 */
	public List<GpBmExportSheet> getGpBmExportSheetList(String pDataId) throws CommonException {
		List<GpBmExportSheet> sheetList = new ArrayList<GpBmExportSheet>();
		String hql = "from GpBmExportSheet where 1=1 and pDataId = ?  order by to_number(sheetNum) ";
		try {
			sheetList = ((MyHibernateTemplate) ApplicationContextUtil.getBean(MyHibernateTemplate.class)).find(hql,
					new Object[] { pDataId });
		} catch (Exception var6) {
			var6.printStackTrace();
			ExceptionUtil.throwCommonException("查询失败！");
		}
		return sheetList;
	}
	
	
	/**
	 * 根据菜单层的 dataId 查询sheet层数据 并根据主sheet标志倒序，sheetnum正序，更新日期 排序。
	 * 
	 * @param pDataId
	 *            sheet层的pDataId,菜单层的dataId
	 * @throws CommonException
	 */
	public List<GpBmExportSheet> getGpBmExportSheetListOrderByMainflag(String pDataId) throws CommonException {
		List<GpBmExportSheet> sheetList = new ArrayList<GpBmExportSheet>();
		String hql = "from GpBmExportSheet where 1=1 and pDataId = ?  order by mainSheetFlag desc,to_number(sheetNum),dataChgTime desc ";
		try {
			sheetList = ((MyHibernateTemplate) ApplicationContextUtil.getBean(MyHibernateTemplate.class)).find(hql,
					new Object[] { pDataId });
		} catch (Exception var6) {
			var6.printStackTrace();
			ExceptionUtil.throwCommonException("查询失败！");
		}
		return sheetList;
	}
	
	
	/**
	 * 根据菜单层的 dataId 查询菜单层数据 
	 * 
	 * @throws CommonException
	 */
	public GpBmExportFunction getGpBmExportFunctionByDataId(String dataId) throws CommonException {
		List<GpBmExportFunction> exportFunctionList = new ArrayList<GpBmExportFunction>();
		
		String hql = "from GpBmExportFunction where 1=1 and dataId = ? ";
		try {
			exportFunctionList = ((MyHibernateTemplate) ApplicationContextUtil.getBean(MyHibernateTemplate.class)).find(hql,
					new Object[] { dataId });
		} catch (Exception var6) {
			var6.printStackTrace();
			ExceptionUtil.throwCommonException("查询失败！");
		}
		if(exportFunctionList.size()>0) {
			return  exportFunctionList.get(0);
		}
		return null;
	}
	
	
	/**
	 * 根据funcid获取当前的文件名
	 * @param funcid
	 * @return
	 * @throws CommonException 
	 */
	@SuppressWarnings("unchecked")
	public String getTemplateFileName(String funcid) throws CommonException {
		String fileName = "";
		logger.info("根据菜单号查询导出配置表，判断是否为模板导出配置。");
		String str = "from GpBmExportFunction where 1=1 and functionId = '"+funcid+"'";
		List<GpBmExportFunction> list = new ArrayList<>();
		Iterator<GpBmExportFunction> it = rootDao.queryByQL(str);	
		while(it.hasNext()) {
			fileName = it.next().getFileName();
		}
		return fileName;
	}
	
	
	
	/**
	 * 根据菜单层的 dataId 查询sheet层 主sheet DataId
	 * 
	 * @param pDataId
	 *            sheet层的pDataId,菜单层的dataId
	 * @throws CommonException
	 */
	public String getGpBmExportSheetMainSheetDataId(String pDataId) throws CommonException {
		List<GpBmExportSheet> sheetList = new ArrayList<GpBmExportSheet>();
		String dataId = "";
		String hql = "from GpBmExportSheet where 1=1 and pDataId = ? and mainSheetFlag= ?  ";
		try {
			sheetList = ((MyHibernateTemplate) ApplicationContextUtil.getBean(MyHibernateTemplate.class)).find(hql,
					new Object[] { pDataId,"01" });
		} catch (Exception var6) {
			var6.printStackTrace();
			ExceptionUtil.throwCommonException("查询失败！");
		}
		if(sheetList.size()>0) {
			dataId = sheetList.get(0).getDataId();
		}
		return dataId;
	}
	
	
	/**
	 * 根据sheet层的 dataId 查询字段层数据
	 * 
	 * @param pDataId
	 *            字段层的pDataId,sheet层的dataId
	 * @throws CommonException
	 */
	public List<GpBmExportField> getGpBmExportFieldList(String pDataId) throws CommonException {
		List<GpBmExportField> fieldList = new ArrayList<GpBmExportField>();
		String hql = "from GpBmExportField where 1=1 and pDataId = ?  order by exportNum ";
		try {
			fieldList = ((MyHibernateTemplate) ApplicationContextUtil.getBean(MyHibernateTemplate.class)).find(hql,
					new Object[] { pDataId });
		} catch (Exception var6) {
			var6.printStackTrace();
			ExceptionUtil.throwCommonException("查询失败！");
		}
		return fieldList;
	}
	
	/**
	 * 根据字段层的 dataId 查询字段层数据
	 * 
	 * @param dataId 字段层的dataId
	 * @throws CommonException
	 */
	public GpBmExportField getGpBmExportFieldByDataId(String dataId) throws CommonException {
		List<GpBmExportField> fieldList = new ArrayList<GpBmExportField>();
		String hql = "from GpBmExportField where 1=1 and dataId = ?  ";
		try {
			fieldList = ((MyHibernateTemplate) ApplicationContextUtil.getBean(MyHibernateTemplate.class)).find(hql,
					new Object[] { dataId });
		} catch (Exception var6) {
			var6.printStackTrace();
			ExceptionUtil.throwCommonException("查询失败！");
		}
		return fieldList.get(0);
	}

	/**
	 * 根据导出配置中菜单层的 dataId 删除导出配置中的sheet层数据
	 * 
	 * @param pDataId
	 *            sheet层的pDataId,菜单层的dataId
	 * @throws CommonException
	 */
	public void deleteExportSheetData(String pDataId) throws CommonException {
		List<GpBmExportSheet> sheetList = getGpBmExportSheetList(pDataId);
		for (GpBmExportSheet sheetData : sheetList) {
			inqQueryService.deleteGpBmInqCfgByDataId(sheetData.getSqlDataId());
			this.deleteExportFieldData(sheetData.getDataId());
			rootDao.delete(sheetData);
		}
	}

	/**
	 * 根据导出配置中sheet层dataId 删除 导出配置中字段层数据。
	 * @param pDataId
	 *            字段层的pDataId,sheet层的dataId
	 * @throws CommonException
	 */
	public void deleteExportFieldData(String pDataId) throws CommonException {
		List<GpBmExportField> fieldList = getGpBmExportFieldList(pDataId);
		for (GpBmExportField fieldData : fieldList) {
			this.rootDao.delete(fieldData);
		}
	}

	
	
	
	/**
	 * 根据 guid 获取 文件导出主表的 的 导出策略类型
	 * 只导出：onlyExport
	 * 导出导入：exportAndImport
	 * @param dataId
	 * @return
	 * @throws CommonException 
	 */
	public String getGpBmExportFunctionExportStrategyType(String dataId) throws CommonException {
		GpBmExportFunction function = getGpBmExportFunctionByDataId(dataId);
		if(function== null) {
			return "";
		}
		if(function.getExportStrategyType()!=null) {
			return function.getExportStrategyType();
		}
		return "";
	}
	
	
	
	
	
	/**
	 * 根据pDataId获取当前字段层中最大的值
	 * @param pDataId
	 * @return
	 */
	public int getGpBmExportFieldMaxSeqno(String pDataId) {
		String sql = "select nvl(max(EXPORT_NUM),0) as EXPORT_NUM from GP_BM_EXPORT_FIELD where P_DATA_ID = '"+pDataId+"'";
		Map<String,Object> map = rootDao.findBySql(sql).get(0);
		BigDecimal EXPORT_NUM = (BigDecimal) map.get("EXPORT_NUM");
		return EXPORT_NUM.intValue();
	}
	
	
	
	public List<GpBmExportField> getGpBmExportFieldListOrderBySeqNo(String pDataId) throws CommonException{
		List<GpBmExportField> fieldList = new ArrayList<GpBmExportField>();
		String hql = "from GpBmExportField where 1=1  and pDataId = ?  order by exportFlag desc,to_number(seqNo),dataChgTime desc ";
		try {
			fieldList = ((MyHibernateTemplate) ApplicationContextUtil.getBean(MyHibernateTemplate.class)).find(hql,
					new Object[] { pDataId });
		} catch (Exception var6) {
			var6.printStackTrace();
			ExceptionUtil.throwCommonException("查询失败！");
		}
		return fieldList;
	}
	
	
	/**
	 * 根据外键进行 查询 只导出的部分。
	 * @param pDataId
	 * @return
	 * @throws CommonException
	 */
	public List<GpBmExportField> getGpBmExportFieldListWithExportOrderBySeqNo(String pDataId) throws CommonException{
		List<GpBmExportField> fieldList = new ArrayList<GpBmExportField>();
		String hql = "from GpBmExportField where 1=1 and exportFlag='01' and pDataId = ?  order by exportNum ";
		try {
			fieldList = ((MyHibernateTemplate) ApplicationContextUtil.getBean(MyHibernateTemplate.class)).find(hql,
					new Object[] { pDataId });
		} catch (Exception var6) {
			var6.printStackTrace();
			ExceptionUtil.throwCommonException("查询失败！");
		}
		return fieldList;
	}
	
	
	
	
	
	
}
