package com.gingkoo.mbt.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommCommitToApvService;
import com.gingkoo.orm.entity.Mbt110Ex;
import com.gingkoo.orm.entity.Mbt120;

public class Mbt120CommitAction extends WebAlterAction {

	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
			throws AppException {
		 UpdateReturnBean returnBean = new UpdateReturnBean();
	     String dsId = multiUpdateResultBean.getUpdateResult().containsKey("Mat_120_TabPageList_ds") ? "Mat_120_TabPageList_ds" : "Mat_120_ds";
	     UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID(dsId);
	     /*new MbtCommCommitToApvService(resultBean, Mbt120.class).commitToApproverove();*/

		WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
		MbtCommCommitToApvService mbtCommCommitToApvService = (MbtCommCommitToApvService) context.getBean("mbtCommCommitToApvService");
		 mbtCommCommitToApvService.commitToApprove(resultBean, Mbt120.class,returnBean);
		   if("".equals(returnBean.getParameter("E_CODE"))) {
		    	returnBean.setParameter("isOptSucc", "true");
		   }else {
			   returnBean.setParameter("isOptSucc", "false");
		   }

	     return returnBean;
	}

}
