package com.gingkoo.mbt.action;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.orm.entity.MbtSendUserManage;
import com.gingkoo.orm.entity.MbtTableCfg;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class Mbt710SaveAction extends WebAlterAction {

    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mbt710Add_Bas_ds");
        //1.拿接口用户代码、接入机构代码、状态（待绑定、已绑定、系统已锁定、人工已锁定、已启用）查询记录,若有记录，则提示"接口用户已绑定"
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
        if ("add".equals(recordMap.get("opr"))){
            String associatedUserId = recordMap.get("associatedUserId");
            String associatedOrgNo = recordMap.get("associatedOrgNo");
//        String sysDepartId = recordMap.get("sysDepartId");
            //查询当前表中是否已存在相同的数据 存在则将错误信息返回给前台 否则走2
            String hql = "from MbtSendUserManage where associatedUserId= ?  and associatedOrgNo=? and dataStatus in ('00','01','10','13','15')";
            List<MbtTableCfg> listExMap;
            try {
                listExMap = ROOTDAOUtils.getROOTDAO().queryByQL2List(hql, new Object[] {associatedUserId,associatedOrgNo}, null);
                if(!CollectionUtils.isEmpty(listExMap)) {
                    returnBean.setParameter("errMsg","接口用户已绑定");
                    return returnBean;
                }
            } catch (CommonException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                returnBean.setParameter("errMsg","获取数据失败");
                return returnBean;
            }

            //管理状态（待绑定）
            recordMap.put("associatedUserStatus","00");
        }
        //2.保存赋值数据状态（待绑定）、密码修改时间（系统时间）、管理状态（待绑定）
        String  time1=recordMap.get("passwordModifyTime");
        String  time2=recordMap.get("userStatusChangeTime");
        //密码修改时间（系统时间）
        recordMap.put("passwordModifyTime",trim(time1));
        //密码修改时间（系统时间）
        recordMap.put("userStatusChangeTime",trim(time2));
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");
        try{
            mbtCommSaveService.process(resultBean,MbtSendUserManage.class);

        }catch (Exception e){
            throw new AppException(e.getCause().getMessage());
        }

        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("dataId", mbtCommSaveService.getDataId());

        return returnBean;
    }
    public String trim(String str) {
        if(!"".equals(str) && null != str) {
            str = str.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
        }
        return str;
    }
}
