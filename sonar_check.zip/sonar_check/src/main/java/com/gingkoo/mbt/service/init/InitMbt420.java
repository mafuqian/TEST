package com.gingkoo.mbt.service.init;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.mbt.util.CompareUtils;
import com.gingkoo.mbt.util.MapToObject;
import com.gingkoo.orm.entity.Mbt420;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.sys.log.Log;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InitMbt420 {
    protected static final Log logger = LogFactory.getLogger(InitMbt420.class);

    protected ROOTDAO dao = ROOTDAOUtils.getROOTDAO();
	/**
     * 给Mbt420赋值报告时点
     * author:wuxy 
     * time:2018年11月06日15:39:58
     * @throws Exception 
     * 报告时点： 10-授信开始      数据未上报过且授信生效日期大于等于今天
     * 			20-授信到期/失效  额度日期小于等于今天
     * 			30-额度调整      上报的额度与当前变更过的额度不一致 
     */
    
    public Mbt420 initMbt420(Mbt420 mbt420) throws Exception {
    	String bRptDateCode = !("").equals(mbt420.getBRptDateCode()) ? mbt420.getBRptDateCode() : "10";
    	String dataId="";
    	dataId = mbt420.getDataId();
    	//1.查询历史表是否存在数据
    	String sql_his_table = "from  Mbt420His where odsDataId= ?  order by hisDate desc";
		List hisTableData = dao.queryByQL2List(sql_his_table, new Object[] { dataId }, null);

    	//存在 查询上报表数据
		if (null != hisTableData && hisTableData.size() > 0) {
			Map<String, String> map_his = new HashMap<String, String>();
			Object his_data_obj = hisTableData.get(0);
			map_his = MapToObject.objectToMap(his_data_obj);
			String sql_rpt_table = "from  Mbt420Rpt where odsDataId= ? and dataStatus='27' order by rptDate desc";
			dataId = map_his.get("dataId");
			List rptTableData = dao.queryByQL2List(sql_rpt_table, new Object[] { dataId }, null);
			// 有 
			if (null != rptTableData && rptTableData.size() > 0) {
				Map<String, String> map_rpt = new HashMap<String, String>();
				Object rpt_data_obj = rptTableData.get(0);
				map_rpt = MapToObject.objectToMap(rpt_data_obj);
				Mbt420 mbt420His = new Mbt420();
				MapToObject.mapToObject(mbt420His,map_rpt,"");

				//2、额度状态是否为2
				if(mbt420.getDConStatus().equals("2")) {
					bRptDateCode ="20";
				}else {
					//3.授信额度字段值是否变更
					Map<String, String> map_filed = new HashMap<String, String>();
					map_filed.put("dCreditLim", "dCreditLim");
					Map map_filed_list = CompareUtils.getModifyContent(mbt420, mbt420His, map_filed);
					if (!(null == map_filed_list || map_filed_list.size() == 0 || map_filed_list.isEmpty())) {
						bRptDateCode = "30";
					}
				}
			}
		}
    	mbt420.setBRptDateCode(bRptDateCode);
		return mbt420;
    }
}
