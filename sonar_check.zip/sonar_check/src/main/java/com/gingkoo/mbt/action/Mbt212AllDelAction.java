package com.gingkoo.mbt.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.orm.entity.MbtUnusalList;

public class Mbt212AllDelAction extends MbtUpdCommitAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mbt212Upd_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);

            if (recordMap.get("opr").equals("allDel")){
                recordMap.put("infRecType", "214");
                recordMap.put("optType", "03");
            }
        recordMap.put("tableName","Mbt210Rpt");
        process(resultBean, MbtUnusalList.class);
        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("dataId", getDataId());
        return returnBean;
    }
}
