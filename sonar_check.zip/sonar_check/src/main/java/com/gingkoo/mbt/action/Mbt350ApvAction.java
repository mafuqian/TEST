package com.gingkoo.mbt.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommApvService;
import com.gingkoo.orm.entity.Mbt350;

public class Mbt350ApvAction extends WebAlterAction {

	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mat_350_TabPageList_ds");
        /*new MbtCommApvService(resultBean, Mbt350.class)
                .approve();
*/
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommApvService mbtCommApvService = (MbtCommApvService) context.getBean("mbtCommApvService");
        mbtCommApvService.setEntityName(Mbt350.class.getName());
        mbtCommApvService.setUpdateResultBean(resultBean);
            mbtCommApvService.approve();
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }

}
