package com.gingkoo.mbt.action;

import java.io.*;
import java.net.URLEncoder;
import java.util.Map;
import java.util.zip.ZipOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.util.DateHelper;
import com.gingkoo.mbt.dao.CommonDao;
import com.gingkoo.mbt.util.ZipUtil;

@Controller
@RequestMapping("/do/getMbtFile")
public class FileDownAction {
    @Value("${mbt.output.path}")
    private String filePath;

    @Autowired
    CommonDao commonDao;

    @RequestMapping("/zipdown")
    public ModelAndView zipFileDown(HttpServletRequest request, HttpServletResponse response)
            throws CommonException, IOException {
        String dfile = request.getParameter("file");
        String type = request.getParameter("type");
        String[] dfiles = null;
        if (dfile != null) {
            if (dfile.indexOf(',') > 0) {
                dfiles = dfile.split(",");
            } else {
                dfiles = new String[]{dfile};
            }
        }
        if (dfiles.length == 1) {
            response.setContentType("application/octet-stream");
            OutputStream os = null;
            FileInputStream in = null;
            try {
                if (dfiles[0] != null) {
                    Map<String, Object> infoBaseField = commonDao.getOneBySql("select FILE_PATH ,FILE_ENC_PATH from MBT_FILE_UPLOAD_INFO where FILE_NAME=?", new String[]{dfiles[0]});
                    if (infoBaseField.get("FILE_PATH") != null) {
                    	String path = "";
                    	if("1".equals(type)) {
                    		path = infoBaseField.get("FILE_PATH").toString();
                    	}else {
                    		path = infoBaseField.get("FILE_ENC_PATH").toString();
                    	}
                    	
                    	
                        File f = new File(path);
                        response.setHeader("content-disposition", "attachment;filename=" + encodeFilename(f.getName(), request));
                        os = response.getOutputStream();
                        in = new FileInputStream(f); // 获取文件的流
                        int len = 0;
                        byte buf[] = new byte[1024];// 缓存作用
                        while ((len = in.read(buf)) > 0) // 切忌这后面不能加 分号 ”;“
                        {
                            os.write(buf, 0, len);// 向客户端输出，实际是把数据存放在response中，然后web服务器再去response中读取
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (in != null)
                    in.close();
                if (os != null) {
                    os.flush();
                    os.close();
                }
            }
            return null;
        } else if (dfiles.length > 1) {
            response.setContentType("application/zip");
            response.setHeader("content-disposition", "attachment;filename=zipdownload.zip");
            OutputStream os = response.getOutputStream();
            ZipOutputStream out = new ZipOutputStream(os);
            try {
                for (int i = 0; i < dfiles.length; i++) {
                    if (dfiles[i] == null) continue;
                    Map<String, Object> infoBaseField = commonDao.getOneBySql("select FILE_PATH,FILE_ENC_PATH from MBT_FILE_UPLOAD_INFO where FILE_NAME=?", new String[]{dfiles[i]});
                    if (infoBaseField.get("FILE_PATH") != null) {
                    	String path = "";
                    	if("1".equals(type)) {
                    		path = infoBaseField.get("FILE_PATH").toString();
                    	}else {
                    		path = infoBaseField.get("FILE_ENC_PATH").toString();
                    	}
                        File f = new File(path);
                       // File f = new File(infoBaseField.get("FILE_PATH").toString());

                        //File f = new File(filePath, dfiles[i]);
                        ZipUtil.doCompress(f, out);
                    }
                    response.flushBuffer();

                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                out.close();
                os.flush();
                os.close();
            }
            return null;
        }
        return fail("文件不存在.");
    }

    public String encodeFilename(String filename, HttpServletRequest request) {
        /**
         * 获取客户端浏览器和操作系统信息 在IE浏览器中得到的是：User-Agent=Mozilla/4.0 (compatible; MSIE 6.0;
         * Windows NT 5.1; SV1; Maxthon; Alexa Toolbar)
         * 在Firefox中得到的是：User-Agent=Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN;
         * rv:1.7.10) Gecko/20050717 Firefox/1.0.6
         */
        String agent = request.getHeader("USER-AGENT");
        try {
            if ((agent != null) && (-1 != agent.indexOf("MSIE"))) {
                String newFileName = URLEncoder.encode(filename, "UTF-8");
                newFileName = StringUtils.replace(newFileName, "+", "%20");
                if (newFileName.length() > 150) {
                    newFileName = new String(filename.getBytes("GB2312"), "ISO8859-1");
                    newFileName = StringUtils.replace(newFileName, " ", "%20");
                }
                return newFileName;
            }
            if ((agent != null) && (-1 != agent.indexOf("Mozilla"))) {
                return new String(filename.getBytes("UTF-8"), "ISO8859-1");
            }
            return filename;
        } catch (Exception ex) {
            return filename;
        }
    }

    private ModelAndView succ(String msg) {
        ModelAndView mav = new ModelAndView();
        mav.addObject("msg", msg);
        mav.setViewName("/common/success.jsp");
        return mav;
    }

    private ModelAndView fail(String msg) {
        ModelAndView mav = new ModelAndView();
        mav.addObject("msg", msg);
        mav.setViewName("/common/error.jsp");
        return mav;
    }

    private ModelAndView err(String msg) {
        ModelAndView mav = new ModelAndView();
        mav.addObject("msg", msg);
        mav.setViewName("/common/500.jsp");
        return mav;
    }

    @RequestMapping("/downloadFile")
    public void downloadFile(HttpServletRequest request, HttpServletResponse response) throws AppException {
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/pdf");

        String file = request.getParameter("file");
        String download = request.getParameter("download");
        InputStream inputStream;
        OutputStream outputStream;
        try {
            inputStream = new BufferedInputStream(new FileInputStream(file));
            if (!StringUtils.isEmpty(download)) {
                response.setHeader("content-disposition", "attachment;filename=" + DateHelper.now() + ".pdf");
            }
            outputStream = response.getOutputStream();
            IOUtils.copy(inputStream, outputStream);
        } catch (IOException e) {
            throw new AppException("下载文件出错", e);
        }
    }

}
