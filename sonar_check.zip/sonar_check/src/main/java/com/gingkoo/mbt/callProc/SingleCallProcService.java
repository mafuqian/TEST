package com.gingkoo.mbt.callProc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.common.platform.util.DataDicUtils;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.config.database.base.MyHibernateTemplate;
import com.gingkoo.mbt.util.MapToObject;
import com.gingkoo.orm.entity.Mbt110;
import com.gingkoo.orm.entity.Mbt120;
import com.gingkoo.orm.entity.Mbt130;
import com.gingkoo.orm.entity.Mbt210;
import com.gingkoo.orm.entity.Mbt220;
import com.gingkoo.orm.entity.Mbt230;
import com.gingkoo.orm.entity.Mbt310;
import com.gingkoo.orm.entity.Mbt410;
import com.gingkoo.orm.entity.Mbt420;
import com.gingkoo.orm.entity.Mbt440;
import com.gingkoo.orm.entity.Mbt510;
import com.gingkoo.orm.entity.Mbt610;
import com.gingkoo.orm.entity.Mbt620;
import com.gingkoo.orm.entity.Mbt630;
import com.gingkoo.orm.entity.Mbt640;
import com.gingkoo.orm.entity.Mbt650;


@Component
public class SingleCallProcService {
    @Autowired
    private MyHibernateTemplate template;

    public List<String>  call (String procName,List<String> listPara) throws AppException {

        List<String> l = new ArrayList<String>();
        StringBuffer strBuf = new StringBuffer();
        strBuf.append("{ call " + procName +"}");

        Session session = null;
        Connection conn = null;
        CallableStatement statement = null;
        String bRptDateCode = "";
        try {
            session = template.getSession();
            conn = session.connection();

            statement = conn.prepareCall(strBuf.toString());
			/*for(int i = 0; i < listPara.size(); i++) {
				statement.setString(3, listPara.get(0));
			}*/
            statement.setString(1, "");
            statement.setString(2, "");
            statement.setString(3, listPara.get(0));

            statement.registerOutParameter(4, Types.CHAR);

            statement.executeUpdate();

            bRptDateCode = statement.getString(4);

            String mag = statement.getString(2);
            if(null != bRptDateCode && !"".equals(bRptDateCode)) {
                l.add("0");
                l.add(bRptDateCode);

            }else {
                l.add("1");
                l.add(mag);
                return l;
            }

            statement.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                if(statement != null)statement.close();
                if(conn != null)conn.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            throw new AppException(e.getMessage());
        }


        return l;

    }

    public String  getMsg (Object bean) throws AppException {
        Map<String, String> map1;
        String procName = "";
        String msg = "";
        try {
            map1 = MapToObject.objectToMap(bean);
            String bRptDateCode = map1.get("bRptDateCode");
            if("88".equals(bRptDateCode) || "99".equals(bRptDateCode)) {
                return "";
            }
            String dataId = map1.get("dataId");

            if(bean instanceof Mbt110) {
                procName = "SP_ODS_MBT_110(?,?,?,?)";
            }else if(bean instanceof Mbt210) {
                procName = "SP_ODS_MBT_210(?,?,?,?)";
            }else if(bean instanceof Mbt220) {
                procName = "SP_ODS_MBT_220(?,?,?,?)";
            }else if(bean instanceof Mbt230) {
                procName = "SP_ODS_MBT_230(?,?,?,?)";
            }else if(bean instanceof Mbt510) {
                procName = "SP_ODS_MBT_510(?,?,?,?)";
            }else if(bean instanceof Mbt310) {
                procName = "SP_ODS_MBT_310(?,?,?,?)";
            }else if(bean instanceof Mbt410) {
                procName = "SP_ODS_MBT_410(?,?,?,?)";
            }else if(bean instanceof Mbt420) {
                procName = "SP_ODS_MBT_420(?,?,?,?)";
            }else if(bean instanceof Mbt440) {
                procName = "SP_ODS_MBT_440(?,?,?,?)";
            } else if(bean instanceof Mbt610) {
                procName = "SP_ODS_MBT_610(?,?,?,?)";
            }else if(bean instanceof Mbt620) {
                procName = "SP_ODS_MBT_620(?,?,?,?)";
            }else if(bean instanceof Mbt630) {
                procName = "SP_ODS_MBT_630(?,?,?,?)";
            }else if(bean instanceof Mbt640) {
                procName = "SP_ODS_MBT_640(?,?,?,?)";
            }else if(bean instanceof Mbt650) {
                procName = "SP_ODS_MBT_650(?,?,?,?)";
            }else if(bean instanceof Mbt120) {
                procName = "SP_ODS_MBT_120(?,?,?,?)";
            }else if(bean instanceof Mbt130) {
                procName = "SP_ODS_MBT_130(?,?,?,?)";
            }else {
                return "";
            }

            List<String> l = new ArrayList<String>();
            l.add(dataId);
            List<String> list = new ArrayList<String>();
            list = call(procName,l);

            if(!list.isEmpty() && list.size() == 2) {
                String falg = list.get(0);
                if("1".equals(falg)) {
                    msg = list.get(1);
                }else {
                    String bRptDateCodeTmp = list.get(1);
                    if(!bRptDateCode.equals(bRptDateCodeTmp)) {
                        if(bean instanceof Mbt110) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19139",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19139",bRptDateCode);
                        }else if(bean instanceof Mbt210) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19257",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19257",bRptDateCode);
                        }else if(bean instanceof Mbt220) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19278",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19278",bRptDateCode);
                        }else if(bean instanceof Mbt230) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19246",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19246",bRptDateCode);
                        }else if(bean instanceof Mbt510) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19155",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19155",bRptDateCode);
                        }else if(bean instanceof Mbt310) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19126",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19126",bRptDateCode);
                        }else if(bean instanceof Mbt410) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19098",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19098",bRptDateCode);
                        }else if(bean instanceof Mbt420) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19082",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19082",bRptDateCode);
                        }else if(bean instanceof Mbt440) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19087",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19087",bRptDateCode);
                        }else if(bean instanceof Mbt610) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19079",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19079",bRptDateCode);
                        }else if(bean instanceof Mbt620) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19079",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19079",bRptDateCode);
                        }else if(bean instanceof Mbt630) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19079",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19079",bRptDateCode);
                        }else if(bean instanceof Mbt640) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19079",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19079",bRptDateCode);
                        }else if(bean instanceof Mbt650) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19079",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19079",bRptDateCode);
                        }
                    }
                }
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            throw new AppException(e.getMessage());
        }

        return msg;

    }



    public String  getMsg (Map<String,String> map) throws AppException {
        String procName = "";
        String msg = "";
        try {
            String bRptDateCode = map.get("bRptDateCode");
            if("88".equals(bRptDateCode)) {
                return "";
            }
            String dataId = map.get("dataId");
            String tableName = map.get("tableName");


            if("MBT_110".equals(tableName)) {
                procName = "SP_ODS_MBT_110(?,?,?,?)";
            }else if("MBT_210".equals(tableName)) {
                procName = "SP_ODS_MBT_210(?,?,?,?)";
            }else if("MBT_220".equals(tableName)) {
                procName = "SP_ODS_MBT_220(?,?,?,?)";
            }else if("MBT_230".equals(tableName)) {
                procName = "SP_ODS_MBT_230(?,?,?,?)";
            }else if("MBT_510".equals(tableName)) {
                procName = "SP_ODS_MBT_510(?,?,?,?)";
            }else if("MBT_310".equals(tableName)) {
                procName = "SP_ODS_MBT_310(?,?,?,?)";
            }else if("MBT_410".equals(tableName)) {
                procName = "SP_ODS_MBT_410(?,?,?,?)";
            }else if("MBT_420".equals(tableName)) {
                procName = "SP_ODS_MBT_420(?,?,?,?)";
            }else if("MBT_440".equals(tableName)) {
                procName = "SP_ODS_MBT_440(?,?,?,?)";
            } else if("MBT_610".equals(tableName)) {
                procName = "SP_ODS_MBT_610(?,?,?,?)";
            }else if("MBT_620".equals(tableName)) {
                procName = "SP_ODS_MBT_620(?,?,?,?)";
            }else if("MBT_630".equals(tableName)) {
                procName = "SP_ODS_MBT_630(?,?,?,?)";
            }else if("MBT_640".equals(tableName)) {
                procName = "SP_ODS_MBT_640(?,?,?,?)";
            }else if("MBT_650".equals(tableName)) {
                procName = "SP_ODS_MBT_650(?,?,?,?)";
            }else if("MBT_120".equals(tableName)) {
                procName = "SP_ODS_MBT_120(?,?,?,?)";
            }else if("MBT_130".equals(tableName)) {
                procName = "SP_ODS_MBT_130(?,?,?,?)";
            }else {
                return "";
            }

            List<String> l = new ArrayList<String>();
            l.add(dataId);
            List<String> list = new ArrayList<String>();
            list = call(procName,l);

            if(!list.isEmpty() && list.size() == 2) {
                String falg = list.get(0);
                if("1".equals(falg)) {
                    msg = list.get(1);
                }else {
                    String bRptDateCodeTmp = list.get(1);
                    if(!bRptDateCode.equals(bRptDateCodeTmp)) {
                        if("MBT_110".equals(tableName)) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19139",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19139",bRptDateCode);
                        }else if("MBT_210".equals(tableName)) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19257",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19257",bRptDateCode);
                        }else if("MBT_220".equals(tableName)) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19278",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19278",bRptDateCode);
                        }else if("MBT_230".equals(tableName)) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19246",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19246",bRptDateCode);
                        }else if("MBT_510".equals(tableName)) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19155",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19155",bRptDateCode);
                        }else if("MBT_310".equals(tableName)) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19126",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19126",bRptDateCode);
                        }else if("MBT_410".equals(tableName)) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19098",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19098",bRptDateCode);
                        }else if("MBT_410".equals(tableName)) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19082",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19082",bRptDateCode);
                        }else if("MBT_440".equals(tableName)) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19087",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19087",bRptDateCode);
                        }else if("MBT_610".equals(tableName)) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19079",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19079",bRptDateCode);
                        }else if("MBT_620".equals(tableName)) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19079",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19079",bRptDateCode);
                        }else if("MBT_630".equals(tableName)) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19079",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19079",bRptDateCode);
                        }else if("MBT_640".equals(tableName)) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19079",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19079",bRptDateCode);
                        }else if("MBT_650".equals(tableName)) {
                            msg = "信息报告时点错误，系统计算为："+DataDicUtils.getDicName("19079",bRptDateCodeTmp)+",而页面为:"
                                    +DataDicUtils.getDicName("19079",bRptDateCode);
                        }
                    }
                }
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            throw new AppException(e.getMessage());
        }

        return msg;

    }
}
