package com.gingkoo.mbt.action;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.service.SysParamService;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.orm.entity.MbtArchiveManage;

@Controller
public class Mbt810SaveAction  extends WebAlterAction{

    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mbt810Add_Bas_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);

        String dataId = recordMap.get("dataId");
        if(StringUtils.isEmpty(dataId)){
            String identifyNo = recordMap.get("identifyNo");
            String authorizationEntryDate = recordMap.get("authorizationEntryDate");
            String hql = "from MbtArchiveManage where clientId = ? and authorizationEntryDate <= ? and authorizationValidityDate >= ?";

            ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
            List<MbtArchiveManage> list = rootdao.queryByQL2List(hql, new Object[] {identifyNo,authorizationEntryDate,authorizationEntryDate}, null);
            if(list.size() > 0){
                returnBean.setParameter("isOptSucc", "false");
                returnBean.setParameter("desc", "客户授权在有效期内");
                return returnBean;
            }
        }
        //发送 档案编号---如果再MBT_ARCHIVE_MANAGE表已存在的话不让他保存

            String authorizationId = recordMap.get("authorizationId");
            ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
            String hql = "from MbtArchiveManage where authorizationId = ? ";

            List<MbtArchiveManage> list = rootdao.queryByQL2List(hql, new Object[] {authorizationId}, null);
            if(list.size() > 0){
                returnBean.setParameter("isOptSucc", "false");
                returnBean.setParameter("desc", "档案编号已存在！");
                return returnBean;
            }

        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");
        String  path = mbtCommSaveService.getUploadPath();
        String uploadFilePath = SysParamService.getSysParamDir(path, "GPMS|UPLOAD_PATH");
        resultBean.getTotalList().get(0).put("filePath",uploadFilePath);
        mbtCommSaveService.process810(resultBean,MbtArchiveManage.class);

        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("dataId", mbtCommSaveService.getDataId());
        return returnBean;
    }
}
