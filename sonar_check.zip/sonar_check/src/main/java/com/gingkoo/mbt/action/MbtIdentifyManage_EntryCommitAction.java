package com.gingkoo.mbt.action;

import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommCommitToApvService;
import com.gingkoo.orm.entity.MbtArchiveManage;
import com.gingkoo.orm.entity.MbtIdentifyManage;
import com.gingkoo.orm.entity.ToCheckInf;

public class MbtIdentifyManage_EntryCommitAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        String dsId = multiUpdateResultBean.getUpdateResult().containsKey("MbtIdentifyManage_Entry_Bas_ds") ? "MbtIdentifyManage_Entry_Bas_ds" : "MbtIdentifyManage_Entry_ds";
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID(dsId);
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
        Map<String,String> record=resultBean.getParamMap();
        ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
        //授权档案表数据状态不为22
        Iterator iterator = rootdao.queryByQL("from " + MbtArchiveManage.class.getTypeName() + " where (clientId=? or identifyType=? or identifyNo=?) and dataStatus!='22'", new String[]{recordMap.get("clientId"),recordMap.get("identifyType"),recordMap.get("identifyNo")}, null);
       if (record.get("opr").equals("del")){
        if(iterator.hasNext()){
            return returnBean;
        }
       }
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommCommitToApvService mbtCommCommitToApvService = (MbtCommCommitToApvService) context.getBean("mbtCommCommitToApvService");

        mbtCommCommitToApvService.commitToApprove(resultBean, MbtIdentifyManage.class,returnBean);
        if("".equals(returnBean.getParameter("E_CODE"))) {
        	returnBean.setParameter("isOptSucc", "true");
        }else {
        	returnBean.setParameter("isOptSucc", "false");
        }
        return returnBean;
    }
}
