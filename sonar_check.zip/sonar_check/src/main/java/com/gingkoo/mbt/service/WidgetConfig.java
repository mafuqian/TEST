package com.gingkoo.mbt.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.directwebremoting.WebContextFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.EastWgtCfg;
import com.gingkoo.gf4j2.framework.entity.GpBmDataDic;
import com.gingkoo.gf4j2.framework.entity.GpBmRoleInfo;
import com.gingkoo.gf4j2.framework.entity.GpBmSysParam;
import com.gingkoo.gf4j2.framework.entity.GpBmTlrRoleRel;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.gf4j2.framework.util.DateHelper;
import com.gingkoo.gf4j2.framework.web.base.BaseDwrAction;
import com.gingkoo.mbt.util.CompareUtils;
import com.gingkoo.orm.entity.MbtDataChangeLog;
import com.gingkoo.orm.entity.MbtDataCheckField;

@Service
public class WidgetConfig extends BaseDwrAction{
    
	@Value("${role.maker}")
	private String roleMaker;
	@Value("${role.checker}")
	private String roleChecker;
	@Value("${role.query}")
	private String query;
	
	private static final Log logger = LogFactory.getLogger(WidgetConfig.class);

    public static String getChangePartByDataId(String dataId) {
        ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		/*
		String sql = "from EastWgtCfg where type = '1' and funcid ='"+tableName+"'
		and depart ='"+depart+"'";
		*/
        String sql = " from MbtDataChangeLog where pdataId = ?";
        List<MbtDataChangeLog> list = (List<MbtDataChangeLog>) rootdao.getHibernateTemplate().find(sql, dataId);

        if (null == list || list.size() == 0) {
            return null;
        }
        String temp = "";
        for (int i = 0; i < list.size(); i++) {
            String str = list.get(i).getPart();
            if (!temp.contains(str)) {
                temp = str + "," + temp;
            }

        }
        if (temp.indexOf(",") != -1) {
            temp = temp.substring(0, temp.length() - 1);
        }

        return temp;
    }

    public static String getChangeFieldByDataId(String pdataId, String part, String dataId) {
        ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
        // String sql = "from EastWgtCfg where type = '1' and funcid ='"+tableName+"'
        // and depart ='"+depart+"'";
        Map<String, String> map = new HashMap<String, String>();
        String sql = " from MbtDataChangeLog where pdataId = ? and part = ? and dtlDataId= ?";
        List<MbtDataChangeLog> list = (List<MbtDataChangeLog>) rootdao.getHibernateTemplate().find(sql, pdataId, part, dataId);

        if (null == list || list.size() == 0) {
            return null;
        }
        String temp = "";
        for (int i = 0; i < list.size(); i++) {
            String str = list.get(i).getField();
            String value = list.get(i).getFieldValueOld();
            if (null == map.get(str)) {
                temp = str + '#' + value + "," + temp;
                map.put(str, str);
            }
        }
        if (temp.indexOf(",") != -1) {
            temp = temp.substring(0, temp.length() - 1);
        }
        return temp;
    }

    public static String getChangeFieldByDataId(String pdataId, String part, String dataId, String beanName) {
        ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
        String temp = "";

        String changeLogSql = " from MbtDataChangeLog where pdataId = ? and data_crt_date = ?";
        List<MbtDataChangeLog> changeLogs = (List<MbtDataChangeLog>) rootdao.getHibernateTemplate().find(changeLogSql, dataId, DateHelper.today());

        if (CollectionUtils.isEmpty(changeLogs)) {
            String todayBak = beanName + "TodayBak";
            String tmpTable = beanName + "Tmp";
            Object nowData;
            Object todayBakData;
            String hql = "from " + beanName + " where dataId = '" + dataId + "'";
            String todayBakSql = "from " + todayBak + " where dataId = '" + dataId + "'";
            String tmpSql = "from " + tmpTable + " where odsDataId = '" + dataId + "'";
            try {
                List list = rootdao.queryByQL2List(hql);
                if (CollectionUtils.isEmpty(list)) {
                    logger.error(beanName + "表DataId：" + dataId + " 的数据为空");
                    return "";
                }
                nowData = list.get(0);
                List todayBakList = rootdao.queryByQL2List(todayBakSql);
                List tmpList = rootdao.queryByQL2List(tmpSql);
                // 对于不是从ODS导入的数据（手工从前台录入的数据），当天此处为空，
                // 但经过跑批后，会产生当日备份数据
                // 新数据
                if (CollectionUtils.isEmpty(tmpList)) {
                    logger.warn(todayBak + "表DataId：" + dataId + " 的数据为空");
                    return "#new#data";
                }
                if (!CollectionUtils.isEmpty(todayBakList)) {
                    changeLogSql = " from MbtDataChangeLog where pdataId = ? and data_crt_date != ?";
                    changeLogs = (List<MbtDataChangeLog>) rootdao.getHibernateTemplate().find(changeLogSql, dataId, DateHelper.today());
                    for (MbtDataChangeLog changeLog : changeLogs) {
                        rootdao.delete(changeLog);
                    }
                    todayBakData = todayBakList.get(0);
                    String checkHql = "from MbtDataCheckField where tableName = ? ";
                    List<MbtDataCheckField> checkFields = null;
                    try {
                        checkFields = rootdao.queryByQL2List(checkHql, new Object[]{beanName}, null);
                    } catch (CommonException e) {
                        logger.error("查询报错", e);
                    }

                    Map<String, MbtDataCheckField> fieldMap = new HashMap<>();
                    if (!CollectionUtils.isEmpty(checkFields)) {
                        for (int i = 0; i < checkFields.size(); i++) {
                            fieldMap.put(checkFields.get(i).getField(), checkFields.get(i));
                        }
                    }
                    Map<String, List<Object>> fieldMapList = CompareUtils.getModifyContentListValue(nowData, todayBakData, fieldMap);

                    for (String in : fieldMapList.keySet()) {
                        MbtDataChangeLog changeLog = new MbtDataChangeLog();
                        changeLog.setDataId(UuidHelper.getCleanUuid());
                        changeLog.setPdataId(pdataId);
                        changeLog.setDtlDataId(dataId);
                        changeLog.setPart(part);
                        changeLog.setField(in);
                        //得到每个key多对用value的值
                        List<Object> l = fieldMapList.get(in);
                        if (l.size() > 0) {
                            changeLog.setFieldValue(l.get(0).toString());
                        }
                        String oldVlue = l.get(1).toString();
                        if (l.size() > 1) {
                            changeLog.setFieldValueOld(oldVlue);
                        }
                        changeLog.setDataCrtDate(DateHelper.today());
                        changeLog.setDataCrtTime(DateHelper.now());
                        changeLog.setRsv1("ODS导入修改");
                        rootdao.save(changeLog);
                        temp = in + "#" + oldVlue + "," + temp;
                    }
                    if (!StringUtils.isEmpty(temp)) {
                        return temp;
                    }
                }
            } catch (Exception e) {
                logger.error("字段比较业务异常", e);
            }
        }

        long start = System.currentTimeMillis();
        String sql = " from MbtDataChangeLog where pdataId = ? and part = ? and dtlDataId= ?";
        List<MbtDataChangeLog> list = (List<MbtDataChangeLog>) rootdao.getHibernateTemplate().find(sql, pdataId, part, dataId);
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }

        for (int i = 0; i < list.size(); i++) {
            String field = list.get(i).getField();
            String value = list.get(i).getFieldValueOld();
            temp = field + "#" + value + "," + temp;
        }
        long end = System.currentTimeMillis();
        logger.info("WidgetConfig.getChangeFieldByDataId()此次比较共耗时：" + (end - start) + "毫秒");
        return temp;
    }

    public static String getDataDic(String dataTypeNo, String dataNo, String rsv1, String rsv2) {
        ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
        List<GpBmDataDic> list = new ArrayList<>();
        BigDecimal big = new BigDecimal(dataTypeNo);
        String sql = "";
        if ("".equals(rsv1) && "".equals(rsv2)) {
            sql = "  from GpBmDataDic where dataTypeNo = ? and dataNo = ? ";
            list = (List<GpBmDataDic>) rootdao.getHibernateTemplate().find(sql, big, dataNo);

        } else {
            sql = "  from GpBmDataDic where dataTypeNo = ? and dataNo = ? and rsv1= ? and rsv2=?";
            list = (List<GpBmDataDic>) rootdao.getHibernateTemplate().find(sql, big, dataNo, rsv1, rsv2);

        }
        if (null == list || list.size() == 0) {
            return null;
        }

        return list.get(0).getDataName();
    }


    public static List getCfg() {
        List<EastWgtCfg> list = new ArrayList<>();
        try {
        	HttpServletRequest request = WebContextFactory.get().getHttpServletRequest();
        	GlobalInfo gi = GlobalInfo.getInstanceFromRequest(request);
            String tableName = gi.getFuncId();
            String depart = gi.getGroupId();
            ROOTDAO rootdao = (ROOTDAO) ApplicationContextUtil.getBean("ROOTDAO");
            String sql = "from EastWgtCfg where " + "  funcid = ? " + " and depart = ?";
            list = (List<EastWgtCfg>) rootdao.getHibernateTemplate().find(sql, tableName, depart);

            if (null == list || list.size() == 0) {
                return null;
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return list;
        }
    }

    public  List getButtonCfg(String tableName, String depart, String username, String part) {
    	
    	return getButtonCfgByRole(tableName, depart, username, part);
    	
    	/*
        List<EastWgtCfg> list = new ArrayList<>();
        try {

            ROOTDAO rootdao = (ROOTDAO) ApplicationContextUtil.getBean("ROOTDAO");
            String sql = "from EastWgtCfg where   funcid =\'" + tableName + "\' and depart = \'" + depart + "\' "
                    + "and usernamelist like \'%" + username + "%\'";

            list = (List<EastWgtCfg>) rootdao.getHibernateTemplate().find(sql);
            if (null == list || list.size() == 0) {
                sql = "from EastWgtCfg where   funcid =\'" + tableName + "\' and depart = \'" + depart + "\' ";
                list = (List<EastWgtCfg>) rootdao.getHibernateTemplate().find(sql);
            }

            if (null == list || list.size() == 0) {
                return null;
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            List<EastWgtCfg> l = new ArrayList<>();
            l = getButton(list, part);
            return l;
        }
    */}
    
    
    @SuppressWarnings("finally")
	public  List getButtonCfgByRole(String tableName, String depart, String username, String part) {
        List<EastWgtCfg> list = new ArrayList<>();
        try {
        	
        
        	if(GlobalInfo.getCurrentInstanceWithoutException() == null) {
				return list;
			}
        	String userId = GlobalInfo.getCurrentInstance().getTlrno();
        	
        	List<GpBmTlrRoleRel> roleList = new ArrayList<GpBmTlrRoleRel>();
            ROOTDAO rootdao = (ROOTDAO) ApplicationContextUtil.getBean("ROOTDAO");
            String sql = "from GpBmTlrRoleRel where tlrno ='" + userId + "'";
            
            roleList = (List<GpBmTlrRoleRel>) rootdao.getHibernateTemplate().find(sql);
            
            for(int i =0;i<roleList.size();i++) {
            	GpBmTlrRoleRel bmTlrRoleRel = roleList.get(i);
            	String roleId = bmTlrRoleRel.getRoleId();
            	
            	sql = "from GpBmRoleInfo where roleId ='" + roleId + "'";
            	
            	List<GpBmRoleInfo> ll =(List<GpBmRoleInfo>) rootdao.getHibernateTemplate().find(sql);
            	
            	for(int j=0;j<ll.size();j++) {
            		GpBmRoleInfo bmRoleInfo = ll.get(j);
            		String roleName = bmRoleInfo.getRoleName();
            		if(roleName.toUpperCase().indexOf(roleMaker.toUpperCase()) !=-1) {
            			EastWgtCfg cfg = new EastWgtCfg();
            			cfg.setButtontype("1");
            			cfg.setButtonid("btnApv,btnBatApv");
            			cfg.setRsv1("1");
            			list.add(cfg);
            		}else if (roleName.toUpperCase().indexOf(roleChecker.toUpperCase()) !=-1){
            			EastWgtCfg cfg = new EastWgtCfg();
            			cfg.setButtontype("1");
            			cfg.setButtonid("btnAdd,btnMod,btnDel,btnDelTmp,btnBatDel,btnBatDelTmp,btnUpload");
            			list.add(cfg);
            		}else if(roleName.toUpperCase().indexOf(query.toUpperCase()) !=-1) {
            			EastWgtCfg cfg = new EastWgtCfg();
            			cfg.setButtontype("1");
            			cfg.setButtonid("btnAdd,btnMod,btnDel,btnDelTmp,btnUpload,btnBatDel,btnBatDelTmp,btnApv,btnBatApv");
            			list.add(cfg);
            		}
            	}
            	
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
           
            return list;
        }
    }
    
    
    @SuppressWarnings("finally")
  	public  String getRoleType(String a) {
    	return "";
    }


    public static List<EastWgtCfg> getButton(List<EastWgtCfg> list, String part) {
        List<EastWgtCfg> l = new ArrayList<EastWgtCfg>();
        for (int i = 0; i < list.size(); i++) {
            StringBuffer temp = new StringBuffer();
            StringBuffer tempbutton = new StringBuffer();
            EastWgtCfg cfg = list.get(i);

            String part_temp = "";
            String button_temp = "";

            String rsv1 = cfg.getButtonpart();
            String buttonid = cfg.getButtonid();
            if (!"".equals(rsv1) && null != rsv1) {
                String[] a = rsv1.split(",");
                String[] b = buttonid.split(",");
                for (int j = 0; j < a.length; j++) {
                    String str = a[j];
                    if (part.equals(str)) {
                        temp.append(str).append(",");
                        tempbutton.append(b[j]).append(",");
                    }
                }
                if (temp.indexOf(",") != -1) {
                    part_temp = temp.toString().substring(0, temp.length() - 1);
                    button_temp = tempbutton.substring(0, tempbutton.length() - 1);
                }
                cfg.setRsv1(part_temp);
                cfg.setButtonid(button_temp);
            }

            String rsv2 = cfg.getFieldpart();
            String field = cfg.getFieldname();
            temp = new StringBuffer();
            tempbutton = new StringBuffer();

            if (!"".equals(rsv2) && null != rsv2) {
                String[] c = rsv2.split(",");
                String[] d = field.split(",");

                for (int j = 0; j < c.length; j++) {
                    String str = c[j];
                    if (part.equals(str)) {
                        temp.append(str).append(",");
                        tempbutton.append(d[j]).append(",");
                    }
                }
                part_temp = "";
                button_temp = "";

                if (temp.indexOf(",") != -1) {
                    part_temp = temp.toString().substring(0, temp.length() - 1);
                    button_temp = tempbutton.substring(0, tempbutton.length() - 1);
                }
                cfg.setRsv2(part_temp);
                cfg.setFieldname(button_temp);
            }
            l.add(cfg);
        }
        return l;
    }

    public static String getRptType() {
        ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
        List<GpBmSysParam> list = new ArrayList<>();
        String sql = "";
        sql = "  from GpBmSysParam where paramId = ? and paramGroupId = ? ";
        list = (List<GpBmSysParam>) rootdao.getHibernateTemplate().find(sql, "RPT_TYPE", "MBT");

        if (null == list || list.size() == 0) {
            return null;
        }
        return list.get(0).getParamValue();
    }
}
