package com.gingkoo.mbt.util;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import com.itextpdf.text.pdf.BaseFont;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.w3c.dom.Document;
import org.xhtmlrenderer.pdf.ITextFontResolver;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.gingkoo.orm.entity.MbtPb01;
import com.gingkoo.orm.entity.MbtPb01b;

/**
 * @Author: li.jy
 * @Date: 2019/2/28
 */
public class HtmlToPdf {

    protected static final Logger logger = LogManager.getLogger(HtmlToPdf.class);

    public static final String DATETIME_PATTERN = "yyyy-MM-dd HH:mm:ss";

    /**
     * 将FTL文件转换成PDF的工具类
     *
     * @param templateName 模板文件名字
     * @param destPath     生成PDF的存储路径
     * @param map          Ftl数据
     */
    public static void ftl2pdf(String templateName, String destPath, Map<String, Object> map) {
        try {
            // 将生成的内容写入html文件中
            ResourceLoader resourceLoader = new DefaultResourceLoader();

            Resource fontResource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                    .getResource("classpath:simsun.ttc");
            Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                    .getResource("classpath:templete/ftl");

            Configuration conf = new Configuration(Configuration.VERSION_2_3_23);
            conf.setDirectoryForTemplateLoading(resource.getFile());
            conf.setEncoding(Locale.getDefault(), StandardCharsets.UTF_8.displayName());
            conf.setDateFormat(DATETIME_PATTERN);
            Template template = conf.getTemplate(templateName);
            StringWriter stringWriter = new StringWriter();
            BufferedWriter writer = new BufferedWriter(stringWriter);
            template.process(map, writer);
            String htmlStr = stringWriter.toString();
            System.out.println(htmlStr);
            logger.debug("转换html成功" + htmlStr);
            // 将生成的内容写入html转换成pdf
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = builder.parse(new ByteArrayInputStream(htmlStr.getBytes(StandardCharsets.UTF_8)));
            ITextRenderer renderer = new ITextRenderer();
            // 解决中文支持问题
            ITextFontResolver fontResolver = renderer.getFontResolver();

            // 设置pdf中文字体为宋体
//            if (isOsWindow()) {
//                fontResolver.addFont("src/main/resources/SimSun.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
//            } else {
//                fontResolver.addFont("/usr/share/fonts/ttc/SimSun.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
//            }

            fontResolver.addFont(fontResource.getFile().getPath(), BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
            renderer.setDocument(doc, null);
            renderer.layout();
            try (OutputStream out = new FileOutputStream(new File(destPath))) {
                renderer.createPDF(out);
            }

            logger.info("===================pdf转换成功===================");
        } catch (Exception e) {
            logger.error("===================pdf转换错误===================", e);
        }
    }

    /**
     * 获取系统类型
     *
     * @return
     */
    private static boolean isOsWindow() {
        String osName = System.getProperties().getProperty("os.name");
        if (osName.toLowerCase().indexOf("win") != -1) {
            return true;
        }
        return false;
    }

    public static void main(String[] args) {
        String destPath = "C:\\Users\\Administrator\\Desktop\\index.pdf";
        Map<String, Object> map = new HashMap<>();
        MbtPb01 mbtPb01 = new MbtPb01();
        mbtPb01.setPb01ad01("1");
        mbtPb01.setPb01ar01("2");
        mbtPb01.setPb01ad02("3");
        mbtPb01.setPb01ad03("4");
        mbtPb01.setPb01ad04("5");
        mbtPb01.setPb01aq01("6");
        mbtPb01.setPb01aq02("7");
        mbtPb01.setPb01ad05("8");
        mbtPb01.setPb01aq03("9");

        MbtPb01b mbtPb01b = new MbtPb01b();
        mbtPb01b.setPb01bq01("a");
        mbtPb01b.setPb01br01("b");

        map.put("mbtPb01", mbtPb01);
        map.put("mbtPb01b", mbtPb01b);
        ftl2pdf("personalCreditReport.ftl", destPath, map);
    }
}
