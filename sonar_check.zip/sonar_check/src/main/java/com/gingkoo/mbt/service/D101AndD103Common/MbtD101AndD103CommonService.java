package com.gingkoo.mbt.service.D101AndD103Common;

import java.lang.reflect.InvocationTargetException;
import java.util.*;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.util.DateHelper;
import com.gingkoo.mbt.service.base.MbtCommonBaseService;
import com.gingkoo.mbt.util.MapToObject;
import com.gingkoo.orm.entity.MbtApplyDownloadManage;
import com.gingkoo.orm.entity.MbtArchiveManage;

@Component
public class MbtD101AndD103CommonService {
    protected static final  Logger logger = LogManager.getLogger(MbtD101AndD103CommonService.class);

    @Autowired
    ROOTDAO rootdao;
    /**
     * 通过data_id重新将数据塞回recordMap
     * @param recordMap
     * @param tableName
     */
    public Map<String, String> selectDataReToMap(Map<String, String> recordMap, String tableName) throws AppException {
        String hql = "from " + tableName + " where dataId=?";
        List mbtD103QryList = rootdao.queryByQL2List(hql, new Object[]{recordMap.get("dataId")}, null);
        try {
            Object bean = Class.forName("com.gingkoo.orm.entity." + tableName).newInstance();
            BeanUtils.copyProperties(bean, mbtD103QryList.get(0));
            recordMap = MapToObject.objectToMap(bean);
        } catch (IllegalAccessException e) {
            logger.error("属性拷贝出错");
            throw new AppException("属性拷贝出错");
        } catch (InvocationTargetException e) {
            logger.error("属性拷贝出错");
            throw new AppException("属性拷贝出错");
        } catch (Exception e) {
            logger.error("属性拷贝出错");
            throw new AppException("属性拷贝出错");
        }
        return recordMap;
    }

    public Map<String, String> selectDataReToMap(Map<String, String> recordMap, MbtApplyDownloadManage mbtApplyDownloadManage) throws AppException {
        String hql = "from MbtApplyDownloadManage where dataId=?";
        List mbtD103QryList = rootdao.queryByQL2List(hql, new Object[]{recordMap.get("dataId")}, null);
        try {
            BeanUtils.copyProperties(mbtApplyDownloadManage, mbtD103QryList.get(0));
            recordMap = MapToObject.objectToMap(mbtApplyDownloadManage);
        } catch (IllegalAccessException e) {
            logger.error("属性拷贝出错");
            throw new AppException("属性拷贝出错");
        } catch (InvocationTargetException e) {
            logger.error("属性拷贝出错");
            throw new AppException("属性拷贝出错");
        } catch (Exception e) {
            logger.error("属性拷贝出错");
            throw new AppException("属性拷贝出错");
        }
        return recordMap;
    }

    public boolean checkTimes(String paramId, String applyTlrno, String applyStatus) throws AppException {
        MbtCommonBaseService mbtCommonBaseService = new MbtCommonBaseService();
        String nowDate = DateHelper.today();
        Integer configureTimes = Integer.parseInt(mbtCommonBaseService.getParamValue(paramId));
        // 查询"已下载/已打印"的数据总数
        String sql = "SELECT COUNT(*) FROM MBT_APPLY_DOWNLOAD_MANAGE WHERE APPLY_STATUS='" + applyStatus + "'";
        if (!StringUtils.isEmpty(applyTlrno)) {
            sql += " AND APPLY_TLRNO='" + applyTlrno + "'";
        }
        if (paramId.contains("TODAY")) {
            sql += " AND (DATA_CRT_DATE ='" + nowDate + "' OR DATA_CHG_DATE ='" + nowDate + "')";
        }
        Integer times = 0;
        Iterator it = rootdao.queryBySQL(sql);
        while (it.hasNext()) {
            times = Integer.parseInt(it.next().toString());
        }
        return times < configureTimes;
    }

    /**
     * 生成行为监控记录
     * @param resultBean
     * @param recordMap
     * @param clazz
     * @throws AppException
     */
    @Transactional(rollbackFor = Exception.class)
    public  void record(UpdateResultBean resultBean,Map<String,String> recordMap,Class<?> clazz) throws  AppException{
        //行为监控记录保存
        Object clazz1;
        Map<String,String> beRecordMap = new HashMap<String,String>();
        try {
            clazz1 =Class.forName("com.gingkoo.orm.entity.MbtBehaviourMonitor").newInstance();
            String  dataId = UUID.randomUUID().toString().replace("-", "");
            beRecordMap.put("dataId", dataId);
            beRecordMap.put("dataCrtUser", GlobalInfo.getCurrentInstance().getTlrno());
            beRecordMap.put("dataCrtTime", DateUtil.get14Date());
            beRecordMap.put("dataDate", DateUtil.get8Date());
            beRecordMap.put("dataCrtDate", DateUtil.get8Date());
            beRecordMap.put("corpId", GlobalInfo.getCurrentInstance().getCorpId());
            beRecordMap.put("orgId", GlobalInfo.getCurrentInstance().getBrno());
            beRecordMap.put("groupId", GlobalInfo.getCurrentInstance().getGroupId());
            beRecordMap.put("inqOrgID","");
            beRecordMap.put("dataSource","1");
            beRecordMap.put("oprCorpId", GlobalInfo.getCurrentInstance().getCorpId());
            beRecordMap.put("oprOrgId", GlobalInfo.getCurrentInstance().getBrno());
            beRecordMap.put("oprDepartId", GlobalInfo.getCurrentInstance().getGroupId());
            beRecordMap.put("oprTlrno",GlobalInfo.getCurrentInstance().getTlrno());
            beRecordMap.put("oprTlrname",resultBean.getParamMap().get("tlrName"));
            beRecordMap.put("oprDate", DateUtil.get8Date());
            beRecordMap.put("oprTime", DateUtil.get14Date());
            beRecordMap.put("exceptionLevel", recordMap.get("expLevel"));
            beRecordMap.put("exceptionDesc", recordMap.get("desc"));
            if (clazz != null && (clazz.getName().contains("MbtD101") || clazz.getName().contains("Mbt103Qry"))) {
                String hql;
                String identifyName;
                String identifyType;
                String identifyNo;
                // 根据主体姓名 主体类型 主体证件号  name id_type id_num  101 subject_type='个人'
                //103 ent_name ent_cert_type ent_cert_num  subject_type='企业'
                if (clazz.getName().contains("MbtD101")) {
                    hql = " from MbtArchiveManage where identifyName = ? and identifyType=? and identifyNo=? and subjectType='个人'";
                    identifyName = recordMap.get("name");
                    identifyType = recordMap.get("idType");
                    identifyNo = recordMap.get("idNum");
                } else {
                    hql = " from MbtArchiveManage where identifyName = ? and identifyType=? and identifyNo=? and subjectType='企业'";
                    identifyName = recordMap.get("entName");
                    identifyType = recordMap.get("entCertType");
                    identifyNo = recordMap.get("entCertNum");
                }
                List<MbtArchiveManage> archiveManageList;
                archiveManageList = rootdao.queryByQL2List(hql, new Object[]{identifyName, identifyType, identifyNo}, null);
                if (!CollectionUtils.isEmpty(archiveManageList)) {
                    beRecordMap.put("clientId", archiveManageList.get(0).getClientId());
                    beRecordMap.put("identifyName", archiveManageList.get(0).getIdentifyName());
                    beRecordMap.put("authorizationId", archiveManageList.get(0).getAuthorizationId());
                    beRecordMap.put("subjectType", archiveManageList.get(0).getSubjectType());
                }
            } else {
                beRecordMap.put("clientId", recordMap.get("clientId"));
                beRecordMap.put("identifyName", recordMap.get("identifyName"));
                beRecordMap.put("authorizationId", recordMap.get("authorizationId"));
                beRecordMap.put("subjectType", recordMap.get("subjectType"));
            }
            //opr
            beRecordMap.put("oprCode", resultBean.getParamMap().get("opr"));
            try {
                BeanUtils.copyProperties(clazz1,beRecordMap);
            } catch (IllegalAccessException e) {
                logger.error(e);
                throw new AppException("属性拷贝出错");
            } catch (InvocationTargetException e) {
                logger.error(e);
                throw new AppException("属性拷贝出错");
            }
            rootdao.save(clazz1);

        } catch (InstantiationException | IllegalAccessException |ClassNotFoundException e) {
            logger.error(e);
            throw new AppException("系统错误，创建类" + clazz.getName() + "实例时出错。");
        }
    }
}
