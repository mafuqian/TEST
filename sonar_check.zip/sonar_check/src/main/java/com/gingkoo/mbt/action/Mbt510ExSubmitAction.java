package com.gingkoo.mbt.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommCommitToApvService;
import com.gingkoo.orm.entity.Mbt510Ex;
import com.gingkoo.orm.entity.Mbt511;

public class Mbt510ExSubmitAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
            throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        String dsId = "";

        if(multiUpdateResultBean.getUpdateResult().containsKey("Mat_510_Ex_TabPageList_ds")) {
        	dsId = "Mat_510_Ex_TabPageList_ds";
        }else if (multiUpdateResultBean.getUpdateResult().containsKey("Mat_510_P_Ex_TabPageList_ds")) {
        	dsId = "Mat_510_P_Ex_TabPageList_ds";
        }else if (multiUpdateResultBean.getUpdateResult().containsKey("Mat_510_P_Ex_ds")){
        	dsId = "Mat_510_P_Ex_ds";
        }else{
            dsId = "Mat_510_Ex_ds";

        }

        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID(dsId);
/*
        new MbtCommCommitToApvService(resultBean, Mbt510Ex.class).commitToApprove();
*/
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommCommitToApvService mbtCommCommitToApvService = (MbtCommCommitToApvService) context.getBean("mbtCommCommitToApvService");
        mbtCommCommitToApvService.commitToApprove(resultBean, Mbt510Ex.class,returnBean);
        if("".equals(returnBean.getParameter("E_CODE"))) {
        	returnBean.setParameter("isOptSucc", "true");
        }else {
        	returnBean.setParameter("isOptSucc", "false");
        }
        return returnBean;
    }


}
