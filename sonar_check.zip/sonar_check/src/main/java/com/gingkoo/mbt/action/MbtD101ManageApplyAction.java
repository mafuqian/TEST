package com.gingkoo.mbt.action;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtD101AndD103ApplyService;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @Author: li.jy
 * @Date: 2019/1/30
 */
public class MbtD101ManageApplyAction extends WebAlterAction {
    private static String TABLE_NAME = "MbtD101";

    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(httpServletRequest.getServletContext());
        MbtD101AndD103ApplyService mbtD101AndD103Service = (MbtD101AndD103ApplyService) context.getBean("mbtD101AndD103ApplyService");

        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("D101Qry_Bas_ds");
        mbtD101AndD103Service.apply(resultBean, TABLE_NAME);

        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }

}
