package com.gingkoo.mbt.util;

public class DoThrowExpection {
    public static <E extends Exception> void doThrow(Exception e) throws E {
        throw (E)e;
    }
}
