package com.gingkoo.mbt.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;

public class FileGenerator {
	private static final Log log = LogFactory.getLog(FileGenerator.class);

	// 1-14 数据提供机构 区段码 AN14 数据提供机构区段码是征信系统分配给数据提供机构的，用于 作为标识前缀，防止各数据提供机构自行编码导致冲突的编码。
	// 15-22 文件生成日期 N8 数据报送文件的生成日期。 格式为“YYYYMMDD”。
	// 23-25 所含信息 记录类型 N3 数据报送文件中所含记录的类型。 具体参见系列标准其他部分中各信息记录类型代码。
	// 26-26 预留位 AN1 目前统一填“0”。
	// 27-29 流水号 AN3 当文件名前 26 位相同时，用于区分不同文件的编号，以保证数 据报送文件命名的唯一性。
	// 30-30 反馈标识 N1 对于数据报送文件，统一填“0”。
	public static String generateMbtFileName(String orgId, String inftype, String seqNo) {
		if (orgId == null || orgId.length() != 14) {
			log.info("数据提供机构号不符要求,无法生成。");
		} else if (inftype == null || inftype.length() != 3) {
			log.info("信息记录类型代码不符要求,无法生成。");
		} else if (seqNo == null || seqNo.length() != 3) {
			log.info("流水号不符要求,无法生成。");
		} else {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
			String createDate = formatter.format(new Date());
			StringBuffer sb = new StringBuffer(orgId);
			sb.append(createDate).append(inftype).append("0").append(seqNo).append("0");
			return sb.toString();
		}
		return null;
	}

	// 1-1 文件头起始标识 AN1 填“A”表示文件头开始。
	// 2-4 文件头长度 N3 说明文件头所含字节数(含“文件头起始标识”和“文件头长 度”)的十进制数字串。不足 3 位的，左侧用“0”补齐。
	// 5-7 所含记录类型 N3 数据报送文件中所含记录的类型。
	// 8-12 信息记录版本号 AN5 用于标识数据报送机构生成文件体中信息记录依据的是哪个 版本的规格定义。 格式为 N.N.N。
	// 13-14 信息记录 模板类型 AN2 信息记录采用的模板类型代码。  对于基本信息，填写其模板类型代码;  对于其他信息，填写空值(即，两个空格)。
	// 15-28 数据提供机构 区段码 AN14 数据提供机构区段码是征信系统分配给数据提供机构的、用作 标识前缀、防止各数据提供机构自行编码导致冲突的编码。
	// 29-42 文件生成时间 N14 生成数据报送文件的具体时间。 格式为“YYYYMMDDHHMMSS”。
	// 43-43 预留位 AN1 对应文件名中的第 26 位。 目前统一填“0”。
	// 44-50 信息记录数 N7 说明文件中所含信息记录数的十进制数字串。不足 7 位的，左 侧用“0”补齐。
	public static String generateMbtFileHead(String inftype, String infversion, String infmodeltype, String orgId,
			int recordLength) {
		if (inftype == null || inftype.length() != 3) {
			log.info("信息记录类型代码不符要求,无法生成。");
		} else if (infversion == null || infversion.length() != 5) {
			log.info("信息记录版本号不符要求,无法生成。");
		} else if (infmodeltype == null || infmodeltype.length() != 2) {
			log.info("信息记录模板类型不符要求,无法生成。");
		} else if (orgId == null || orgId.length() != 14) {
			log.info("数据提供机构号不符要求,无法生成。");
		}else {
			String headStart = "A";
			int headLength = 50;
			String headLengthStr = "0" + headLength;
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
			String createDate = formatter.format(new Date());
			String preposition = "0";
			String recordLengthStr = String.valueOf(recordLength);
			int  recordLengthStrLength = recordLengthStr.length();
			for (int i = 0; i < 7 - recordLengthStrLength; i++) {
				recordLengthStr = "0" + recordLengthStr;
			}
			StringBuffer sb = new StringBuffer(headStart);
			sb.append(headLengthStr).append(inftype).append(infversion).append(infmodeltype).append(orgId)
					.append(createDate).append(preposition).append(recordLengthStr);
			if(sb.length()!=50) {
				log.error("文件头【"+sb.toString()+"】长度有误。");
			}
			return sb.toString();
		}
		return null;
	}
}
