package com.gingkoo.mbt.service;

import com.gingkoo.common.batch.service.SqlNoGlobalInfoCommonService;
import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.workflow.entity.bean.TaskTotal;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.config.database.sql.SqlParserImpl;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.*;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.*;

/**
 * 页面待办事项service。
 * 通过多线程来进行查询待办事项。
 */
@Service
public class HomePageTodoTasksService {

    private Log logger = LogFactory.getLogger(HomePageTodoTasksService.class);

    @Value("${role.maker}")
    private String roleMaker;
    @Value("${role.checker}")
    private String roleChecker;
    @Value("${role.query}")
    private String query;
    @Autowired
    private ROOTDAO rootdao;
    @Autowired
    private SqlParserImpl parser;
    @Autowired
    private SqlNoGlobalInfoCommonService sqlNoGlobalInfoCommonService;


    /**
     * 获取当前用户的待办任务。
     *
     * @return
     * @throws CommonException
     */
    @SuppressWarnings("unchecked")
    public List<TaskTotal> getToDoTasks() throws CommonException {
        List<TaskTotal> list = new ArrayList<TaskTotal>();
        GlobalInfo globalInfo;
        rootdao = ROOTDAOUtils.getROOTDAO();
        try {
            globalInfo = GlobalInfo.getCurrentInstance();
        } catch (CommonException e) {
            logger.error(e.getMessage());
            return null;
        }
        GpBmTlrInfo tlrInfo = new GpBmTlrInfo();
        HashMap<String, Object> map = new HashMap<>();
        map.put("v_depart", globalInfo.getGroupId());
        map.put("v_user", globalInfo.getTlrno());
        map.put("v_brno", globalInfo.getBrno());
        map.put("v_corpid", globalInfo.getCorpId());
        tlrInfo.setCorpId(globalInfo.getCorpId());
        tlrInfo.setBrcode(globalInfo.getBrno());
        tlrInfo.setTlrno(globalInfo.getTlrno());
        tlrInfo.setGroupId(globalInfo.getGroupId());

        //获取用户拥有的权限菜单列表
        Map<String, List<String>> funcidRoleNameMap =getFuncidRoleNameMapByUserid(globalInfo.getTlrno());
        //当前用户拥有的的权限菜单。
        ArrayList<String> funcidList = new ArrayList<>();
        funcidList.addAll(funcidRoleNameMap.keySet());

        String hql = " from EastWelcomeCfg ";
        List<EastWelcomeCfg> listCfg = (List<EastWelcomeCfg>) rootdao.queryByQL2List(hql);

        //使用多线程方式进行查询操作。
        List<Future<TaskTotal>> futureTaskList = new ArrayList<>();
        ExecutorService executorService = Executors.newFixedThreadPool(10);

        for (EastWelcomeCfg cfg : listCfg) {
            Callable<TaskTotal> queryCall = new Callable<TaskTotal>() {
                @Override
                public TaskTotal call() throws Exception {
                    TaskTotal total = null;
                    HashMap<String, Object> qryMap = new HashMap<>();
                    qryMap.putAll(map);
                    String funcid = cfg.getFuncid();
                    String makerOrchecker = cfg.getRsv1();
                    String roleMakerChecker = "";

                    boolean flag = false;
                    //检查是否有当前菜单的权限，如果没有当前的权限，则直接返回。
                    if (funcidList.contains(funcid)) {
                        if(makerOrchecker==null||"".equals(makerOrchecker)){//如果判断标志为空，则直接进行查询。
                            flag = true;
                        }else{
                            List<String> roleNameList = funcidRoleNameMap.get(funcid);
                            for(String roleName : roleNameList){
                                if(roleName.toUpperCase().indexOf(roleMaker.toUpperCase()) !=-1){
                                    roleMakerChecker = "maker";
                                }
                                if(roleName.toUpperCase().indexOf(roleChecker.toUpperCase()) !=-1){
                                    roleMakerChecker = "checker";
                                }
                                if(roleMakerChecker.toUpperCase().equals(makerOrchecker.trim().toUpperCase())){
                                    flag = true;
                                    break;
                                }
                            }
                        }
                        if(flag){
                            GlobalInfo.setCurrentInstance(globalInfo);
                            total = getTask(cfg, qryMap, tlrInfo);
                        }

                    }
                    return total;
                }
            };
            //添加到task中,执行查询
            FutureTask<TaskTotal> futureTask = new FutureTask<TaskTotal>(queryCall);
            futureTaskList.add(futureTask);
            executorService.submit(futureTask);
        }
        executorService.shutdown();
        for (Future<TaskTotal> futureTask : futureTaskList) {
            TaskTotal total = null;
            try {
                total = futureTask.get();
                if (total != null) {
                    list.add(total);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
                Thread.currentThread().interrupt();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }

        }

        return list;
    }


    /**
     * 根据单个EastWelcomeCfg对象来调用方法实现单次调用。
     *
     * @param cfg
     * @param map
     * @param tlrInfo
     * @return
     */

    @SuppressWarnings("rawtypes")
    public TaskTotal getTask(EastWelcomeCfg cfg, HashMap<String, Object> map, GpBmTlrInfo tlrInfo) throws CommonException {
        String query = cfg.getSqlString();
        map.put("funcid", cfg.getFuncid());
        // 获取经过转换后的sql语句。
        query = sqlNoGlobalInfoCommonService.getSql(query, map, tlrInfo);
        //解析sql，将sql中的参数组装拼接到sql语句中。
        query = parser.parse(query, map).getSql();
        Iterator it = null;
        try {
            it = rootdao.queryBySQL(query);
        } catch (CommonException e) {
            logger.error(e.getErrMessage());
            logger.error(e.getErrCode());
            return null;
        }

        String type = cfg.getTypeDesc();
        String desc = String.valueOf(it.next().toString());
        String funcid = cfg.getFuncid();
        TaskTotal total = null;

        if (Integer.valueOf(desc) > 0) {
            total = buildTask(type, desc, funcid);
        }
        return total;
    }


    private TaskTotal buildTask(String type, String desc, String funcid) throws CommonException {
        GlobalInfo globalInfo = GlobalInfo.getCurrentInstance();
        GpBmFunction function = globalInfo.getAllFunctions().get(funcid);
        if (function == null) return null;
        TaskTotal total = new TaskTotal();
        total.setTaskTyeName(type);
        total.setTaskCount(desc);
        total.setTaskTitle(function.getFuncname());
        total.setTaskTypeId(funcid);
        total.setDealUrl(function.getPagepath());
        return total;
    }


    /**
     * 根据用户名获取当前用户的角色权限和菜单权限。
     * @param userId
     * @return
     */
    public Map<String, List<String>> getFuncidRoleNameMapByUserid(String userId) {
        Map<String, List<String>> funcidRoleNameMap = new HashMap<>();
        try {
            String sql = "select b.ROLE_ID,b.ROLE_NAME,c.FUNCID from gp_bm_tlr_role_rel a inner join gp_bm_role_info b on a.ROLE_ID=b.ROLE_ID inner JOIN gp_bm_role_func_rel c on b.role_id=c.role_id where a.tlrno='" + userId + "'";
            List<Map<String, Object>> list1 = rootdao.findBySql(sql);

            for (int i = 0; i < list1.size(); i++) {
                Map<String, Object> map = list1.get(i);
                String roleName = (String) map.get("ROLE_NAME");
                String funcid = (String) map.get("FUNCID");
                List<String> roleNameList = null;
                if (funcidRoleNameMap.containsKey(funcid)) {
                    roleNameList = funcidRoleNameMap.get(funcid);
                    roleNameList.add(roleName);
                } else {
                    roleNameList = new ArrayList<>();
                    roleNameList.add(roleName);
                    funcidRoleNameMap.put(funcid, roleNameList);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return funcidRoleNameMap;

    }


}
