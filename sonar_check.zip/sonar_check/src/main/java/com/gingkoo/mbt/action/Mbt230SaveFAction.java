package com.gingkoo.mbt.action;

import java.sql.BatchUpdateException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.orm.entity.Mbt230F;
/**
 * Mbt230SaveFAction--->Mbt230Add_Oth_E_ds.xml
 */

public class Mbt230SaveFAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("errCode", "00");
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mat_230_Oth_F_ds");
    //    process(resultBean, Mbt230F.class);
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");
        try {
        mbtCommSaveService.batchprocess(resultBean, Mbt230F.class);
        }catch(Exception e) {
            Throwable cause = e.getCause();
        	logger.error("操作错误 ",e);
        	if(cause instanceof BatchUpdateException||cause instanceof ConstraintViolationException) {
        		returnBean.setParameter("errCode", "01");
        		returnBean.setParameter("isOptSucc", "false");
        	}else {
        		returnBean.setParameter("errCode", "02");
        		returnBean.setParameter("isOptSucc", "false");
        	}
        	e.printStackTrace();
        }

        return returnBean;
    }
}
