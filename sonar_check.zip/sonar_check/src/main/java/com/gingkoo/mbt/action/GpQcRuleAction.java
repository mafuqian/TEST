package com.gingkoo.mbt.action;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.data.qc.gf4j.entity.GpQcRule;
import com.gingkoo.mbt.service.GpQcRuleService;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.OPCaller;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import org.apache.commons.lang.StringUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

public class GpQcRuleAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean arg0,
                                         HttpServletRequest arg1, HttpServletResponse arg2)
            throws AppException {
        logger.info("-------GpQcRuleAction start---------");
        UpdateReturnBean updateReturnBean = new UpdateReturnBean();
        ServiceContext oc = new ServiceContext();

        UpdateResultBean updateResultBean = multiUpdateResultBean
                .getUpdateResultBeanByID("GP_QC_RULE_mat_ds");
        String opr = updateResultBean.getParameter("opr");
        if (updateResultBean.hasNext()) {
            GpQcRule rule = new GpQcRule();
            Map<String, String> map = updateResultBean.next();
            mapToObject(rule, map);
            if ("add".equals(opr)) {
                oc.setAttribute(GpQcRuleService.CMD, GpQcRuleService.CMD_INSERT);
            } else if ("mod".equals(opr)) {
                oc.setAttribute(GpQcRuleService.CMD, GpQcRuleService.CMD_UPDATE);
            } else if("del".equals(opr)){
                oc.setAttribute(GpQcRuleService.CMD, GpQcRuleService.CMD_DELETE);
            }
            try {
                oc.setAttribute(GpQcRuleService.IN_PARAM, rule);
                oc.setAttribute("IN_PARAM_1", map);
                OPCaller.call(GpQcRuleService.ID, oc);
            } catch (CommonException e) {
                e.printStackTrace();
                updateReturnBean.setParameter("res", "99");
                updateReturnBean.setParameter("code", e.getKey());
                updateReturnBean.setParameter("desc", e.getMessage());
                return updateReturnBean;
            }
            if("mod".equals(opr)){
                String str = (String) oc.getAttribute(GpQcRuleService.MOD_SCOPE);
                if(StringUtils.isNotBlank(str)){
                    updateReturnBean.setParameter("res", "");
                    updateReturnBean.setParameter("code", "MOD_SCOPE");
                    updateReturnBean.setParameter("desc", "当前校验修改影响如下校验集："+str+" 。");
                    return updateReturnBean;
                }
            }
        }

        logger.info("-------GpQcRuleAction end---------");

        updateReturnBean.setParameter("res", "");
        updateReturnBean.setParameter("code", "");
        updateReturnBean.setParameter("desc", "");
        return updateReturnBean;
    }
}
