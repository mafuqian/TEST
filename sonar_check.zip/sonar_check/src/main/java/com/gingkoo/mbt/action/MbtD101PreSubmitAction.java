package com.gingkoo.mbt.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommCommitToApvService;
import com.gingkoo.orm.entity.MbtD101Per;

public class MbtD101PreSubmitAction extends MbtSingleRecordAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
            throws AppException {
        // TODO Auto-generated method stub
       UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResult().containsKey("MbtPerAdd_Dtl_ds") ?
                multiUpdateResultBean.getUpdateResultBeanByID("MbtPerAdd_Dtl_ds") : multiUpdateResultBean.getUpdateResultBeanByID("MbtPerAdd_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
        if(!(resultBean.getParameter("opr").equals("del") && "del" == resultBean.getParameter("opr"))){
            process(resultBean, MbtD101Per.class);
        }
        resultBean.setRecodeIndex(0);
/*
        new MbtCommCommitToApvService(resultBean, MbtD101Per.class).commitToApprove();
*/

        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommCommitToApvService mbtCommCommitToApvService = (MbtCommCommitToApvService) context.getBean("mbtCommCommitToApvService");
        mbtCommCommitToApvService.commitToApprove(resultBean, MbtD101Per.class,returnBean);
        if("".equals(returnBean.getParameter("E_CODE"))) {
        	returnBean.setParameter("isOptSucc", "true");
        }else {
        	returnBean.setParameter("isOptSucc", "false");
        }
        return returnBean;
    }
}
