package com.gingkoo.mbt.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.axis.utils.StringUtils;
import org.apache.commons.beanutils.BeanUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.util.DateUtil;

public class Mbt710PassSaveAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mbt710Add_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);

        String  time1=recordMap.get("passwordModifyTime");
        String  time2=recordMap.get("userStatusChangeTime");
        String  bindTime=recordMap.get("bindTime");
        recordMap.put("passwordModifyTime",trim(time1));
        recordMap.put("userStatusChangeTime",trim(time2));
        recordMap.put("passwordModifyDate", DateUtil.get8Date());
        recordMap.put("passwordModifyTime", DateUtil.get14Date());
        if (!StringUtils.isEmpty(bindTime)){
            recordMap.put("bindTime", trim(bindTime));
        }
        //update  PASSWORD_MODIFY_USER_NAME
        //PASSWORD_MODIFY_DATE
        //PASSWORD_MODIFY_TIME
        try{
            Object beanToBeUpdate = Class.forName("com.gingkoo.orm.entity.MbtSendUserManage").newInstance();
            BeanUtils.copyProperties(beanToBeUpdate,recordMap);
            ROOTDAOUtils.getROOTDAO().update(beanToBeUpdate);
        }
        catch(Exception e){
            e.printStackTrace();
            throw new AppException("修改失败！");
        }

        returnBean.setParameter("isOptSucc", "true");
//        returnBean.setParameter("dataId", mbtCommSaveService.getDataId());
        return returnBean;
    }
    public String trim(String str) {
        if(!"".equals(str) && null != str) {
            str = str.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
        }

        return str;
    }
}
