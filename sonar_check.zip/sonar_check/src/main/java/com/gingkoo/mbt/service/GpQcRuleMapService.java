package com.gingkoo.mbt.service;

import com.gingkoo.data.qc.gf4j.entity.GpQcRuleMap;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.BaseService;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.gf4j2.framework.util.ExceptionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Component
public class GpQcRuleMapService extends BaseService {

    @Autowired
    private ROOTDAO rootdao;
    public static final String ID = "gpQcRuleMapService";
    public static final String CMD = "CMD";
    public static final String CMD_INSERT = "CMD_INSERT";
    public static final String CMD_DELETE = "CMD_DEL";
    public static final String IN_PARAM = "IN_PARAM";
    private static final Log logger = LogFactory.getLogger(GpQcRuleService.class);


    @Override
    public void beforeProc(ServiceContext context) throws CommonException {
    }

    @Override
    public void execute(ServiceContext context) throws CommonException {

        String cmd = (String) context.getAttribute(CMD);
        GpQcRuleMap ruleMap = (GpQcRuleMap) context.getAttribute("IN_PARAM");
        Map<String, String> map = (Map<String, String>) context.getAttribute("IN_PARAM_1");
        GlobalInfo gi = GlobalInfo.getCurrentInstance();

        if (CMD_INSERT.equals(cmd)) {
            String ruleSetId = map.get("ruleSetId");
            String ruleId = map.get("dataId");
            List<GpQcRuleMap> list = new ArrayList<>();
            StringBuilder hql = new StringBuilder();
            hql.append(" from GpQcRuleMap b where 1=1 ");
            if ((ruleId != null) && (!"".equals(ruleId))) {
                hql.append(" and b.ruleId = '").append(ruleId).append("' ");
            }
            if ((ruleSetId != null) && (!"".equals(ruleSetId))) {
                hql.append(" and b.ruleSetId = '").append(ruleSetId).append("' ");
            }
            list = rootdao.queryByQL2List(hql.toString());
            if(list.size()>0){
                ExceptionUtil.throwCommonException("当前校验已存在，请重新选择。","新增失败。");
            }
            String dataId = UuidHelper.getCleanUuid();
            GpQcRuleMap ruleMap1 = new GpQcRuleMap();
            ruleMap1.setRuleSetId(ruleSetId);
            ruleMap1.setRuleId(ruleId);
            ruleMap1.setDataId(dataId);
            setGpQcRuleMapCrtInfo(ruleMap1,gi);
            rootdao.save(ruleMap1);
        } else if (CMD_DELETE.equals(cmd)) {
            rootdao.delete(GpQcRuleMap.class,ruleMap.getDataId());
        }


    }





    /**
     * 补充新增信息。
     * @param rule
     * @param gl
     */
    public void setGpQcRuleMapCrtInfo(GpQcRuleMap rule, GlobalInfo gl ) {
        rule.setDataDate(DateUtil.get8Date());
        rule.setCorpId(gl.getCorpId());
        rule.setOrgId(gl.getBrno());
        rule.setDataCrtUser(gl.getTlrno());
        rule.setDataCrtDate(DateUtil.get8Date());
        rule.setDataCrtTime(DateUtil.get14Date());
        setGpQcRuleMapChgInfo(rule, gl);
    }

    /**
     * 补充更新信息
     * @param rule
     * @param gl
     */
    public void setGpQcRuleMapChgInfo(GpQcRuleMap rule, GlobalInfo gl ) {
        rule.setDataChgUser(gl.getTlrno());
        rule.setDataChgDate(DateUtil.get8Date());
        rule.setDataChgTime(DateUtil.get14Date());
    }



    @Override
    public void afterProc(ServiceContext context) throws CommonException {
    }
}