package com.gingkoo.mbt.email;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gingkoo.common.email.entity.GpBmEmailLog;
import com.gingkoo.common.email.excp.MailException;
import com.gingkoo.common.email.excp.MailMessageException;
import com.gingkoo.common.email.excp.MailServerException;
import com.gingkoo.common.email.service.impl.UGnoChlEmailImpl;
import com.gingkoo.common.message.entity.bean.GpBmGnoMsgBean;
import com.gingkoo.common.platform.management.service.PasswordService;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.config.database.base.MyHibernateTemplate;
import com.gingkoo.gf4j2.framework.entity.GpBmTlrInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.security.SHA256;

import net.sf.json.JSONObject;

@Controller
public class SendEmailPassWordAction{
	@Autowired
	
	private MyHibernateTemplate template;
	private Logger logger;
	@Autowired
    private UGnoChlEmailImpl uGnoChlEmailImpl;
    private String send_email;
    public static final String ID = "sendEmailPassWordAction";
    SimpleDateFormat format=new SimpleDateFormat("yyyyMMddHHmmss");
    SimpleDateFormat format1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss EE");
    public SendEmailPassWordAction()
    {
        logger = LoggerFactory.getLogger("com/gingkoo/mbt/email/SendEmailPassWordAction");
    }
    @ResponseBody
	@RequestMapping(value = { "/sendEmailPwd" }, method = { RequestMethod.POST } ,produces = "text/json; charset=utf-8")
	public String sendEmailPassword(@RequestBody String param,HttpServletRequest request, HttpServletResponse response) throws CommonException, Exception {
    	response.reset();
		response.setCharacterEncoding("UTF-8");
		response.setHeader("Content-type", "application/json; charset=utf-8");
		
		JSONObject jsonobject = JSONObject.fromObject(param);
    	
		JSONObject json = new JSONObject();
		
		String username = jsonobject.getString("username");
		
    	String hql1 = "from GpBmTlrInfo where tlrno=?";
		String msg="邮件发送成功";
		GpBmTlrInfo gpBmTlrInfo=template.findFirst(hql1,new Object[] { username });
		if(gpBmTlrInfo!=null){
			String password = getPassWord();
			  gpBmTlrInfo.setRsv3(getPassWordEnc(password));
			  gpBmTlrInfo.setRsv1(format.format(new Date()));
			  gpBmTlrInfo.setRsv2("0");
			  logger.info("-----emailService start------");
		        String title = String.valueOf("CRMS系统登录动态密码");
		        StringBuilder sb = new StringBuilder();
				sb.append("Dear ")
					.append(gpBmTlrInfo.getTlrName()+",<br/>")
					.append("<br/>")
					.append("此邮件是CRMS系统,发送的动态系统登录密码，邮件发送时间：")
					.append(format1.format(new Date())+"<br/>")
					.append("<br/>")
					.append("系统动态登录密码是： ")
					.append(password+"<br/>")
					.append("<br/>")
					/*.append("Due to security reason, this password can be used to access EAST system once only, and will expire in 20 minutes upon your receipt of the password.<br/>")
					.append("<br/>")
					.append("Yours sincerely,<br/>")
					.append("Administrator<br/>")
					.append("<br/>")
					.append("<br/>")
					.append("This message and any attachments (the ").append('"').append("message").append('"').append(") is<br/>")
					.append("intended solely for the intended addressees and is confidential. <br/>")
					.append("If you receive this message in error,or are not the intended recipient(s), <br/>")
					.append("please delete it and any copies from your systems and immediately notify<br/>")
					.append("the sender. Any unauthorized view, use that does not comply with its purpose, <br/>")
					.append("dissemination or disclosure, either whole or partial, is prohibited. Since the internet <br/>")
					.append("cannot guarantee the integrity of this message which may not be reliable, BNP PARIBAS <br/>")
					.append("(and its subsidiaries) shall not be liable for the message if modified, changed or falsified. <br/>")
					.append("Do not print this message unless it is necessary,consider the environment.<br/>")
					.append("<br/>")*/
					.append("------------------------------------------------------------------------------------------<br/>")
					.append("<br/>")
					.append("此邮件由CRMS系统发送").append(". <br/>");
					/*.append("Ce message et toutes les pieces jointes (ci-apres le").append('"').append("message").append('"').append(")<br/>")
					.append("sont etablis a l'intention exclusive de ses destinataires et sont confidentiels.<br/>")
					.append("Si vous recevez ce message par erreur ou s'il ne vous est pas destine,<br/>")
					.append("merci de le detruire ainsi que toute copie de votre systeme et d'en avertir<br/>")
					.append("immediatement l'expediteur. Toute lecture non autorisee, toute utilisation de <br/>")
					.append("ce message qui n'est pas conforme a sa destination, toute diffusion ou toute <br/>")
					.append("publication, totale ou partielle, est interdite. L'Internet ne permettant pas d'assurer<br/>")
					.append("l'integrite de ce message electronique susceptible d'alteration, BNP Paribas <br/>")
					.append("(et ses filiales) decline(nt) toute responsabilite au titre de ce message dans l'hypothese <br/>")
					.append("ou il aurait ete modifie, deforme ou falsifie.  <br/>")
					.append("N'imprimez ce message que si necessaire, pensez a l'environnement. <br/>");*/
		        String mess = String.valueOf(sb.toString());
		        String tlrNo = String.valueOf(username);
		        String hql = "from GpBmTlrInfo where tlrNo = ?";
		        List l = template.find(hql, new Object[] {
		            tlrNo
		        });
		        if(l.size() == 0 || "".equals(((GpBmTlrInfo)l.get(0)).getEmail()) || null == ((GpBmTlrInfo)l.get(0)).getEmail())
		        {
		            logger.info("-------没有配置邮箱！-------");
		            msg="没有配置邮箱！";
		            json.put("success", false);
					json.put("message", msg);
					return json.toString();
		        }
		        String toList = ((GpBmTlrInfo)l.get(0)).getEmail();
		        String corpId = ((GpBmTlrInfo)l.get(0)).getCorpId();
		        GpBmGnoMsgBean msgInfo = new GpBmGnoMsgBean();
		        msgInfo.setMsgTitle(title);
		        msgInfo.setMsgContent(mess);
		        msgInfo.setToList(toList);
		        GpBmEmailLog gpBmEmailLog = new GpBmEmailLog();
		        gpBmEmailLog.setDataId(UuidHelper.getCleanUuid());
		        gpBmEmailLog.setSendDate((new SimpleDateFormat("yyyyMMdd")).format(new Date()));
		        gpBmEmailLog.setSendTime((new SimpleDateFormat("yyyyMMddhhmmss")).format(new Date()));
		        gpBmEmailLog.setCorpId(corpId);
		        gpBmEmailLog.setTitle(title);
		        gpBmEmailLog.setMess(mess);
		        gpBmEmailLog.setReceEmail(toList);
		        gpBmEmailLog.setReceTlrNo(tlrNo);
		        gpBmEmailLog.setSendEmail(send_email);
		        try
		        {
		            uGnoChlEmailImpl.sendMessage(msgInfo);
		            template.update(gpBmTlrInfo);
		            gpBmEmailLog.setStatus("0");
		        }
		        catch( MailMessageException e)
		        {
		            logger.info("----邮件发送失败！----");
		            gpBmEmailLog.setStatus("1");
		            msg="邮件发送失败！";
		            logger.error(e.getMessage());
		            json.put("success", false);
					json.put("message", msg);
					return json.toString();
		        }
		        catch(MailServerException e)
		        {
		        	logger.info("----邮件发送失败！----");
		        	gpBmEmailLog.setStatus("1");
		        	msg="邮件发送失败！";
		        	logger.error(e.getMessage());
		        	json.put("success", false);
					json.put("message", msg);
					return json.toString();
		        }
		        catch(MailException e)
		        {
		        	logger.info("----邮件发送失败！----");
		        	gpBmEmailLog.setStatus("1");
		        	msg="邮件发送失败！";
		        	logger.error(e.getMessage());
		        	json.put("success", false);
					json.put("message", msg);
					return json.toString();
		        }
		        catch(DataAccessException e)
		        {
		        	logger.info("----邮件发送失败！----");
		        	gpBmEmailLog.setStatus("1");
		        	msg="邮件发送失败！";
		        	logger.error(e.getMessage());
		        	json.put("success", false);
					json.put("message", msg);
					return json.toString();
		        }
		        catch(Exception e)
		        {
		        	logger.info("----邮件发送失败！----");
		        	gpBmEmailLog.setStatus("1");
		        	msg="邮件发送失败！";
		        	logger.error(e.getMessage());
		        	json.put("success", false);
					json.put("message", msg);
					return json.toString();
		        }
		        template.save(gpBmEmailLog);
		    
		}else{
			msg="用户名不存在！";
			json.put("success", false);
			json.put("message", msg);
			return json.toString();
		}
		 json.put("success", true);
			json.put("message", msg);
			return json.toString();
	}
	public String dateTest(Date nowTime ,int num){
		long time=num*60*1000;
		Date afterDate=new Date(nowTime.getTime()-time);
		String afterTime=format.format(afterDate);
		return afterTime;
	}
	public String getPassWordEnc(String str){
		SHA256 sha2 = new SHA256();
		str = sha2.getSHA256Str(str);
		BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder();
		str = bcrypt.encode(str);
	    return str;
	}
	
	public String getPassWord(){
		String str = "";
		Random random=new Random();
	    StringBuffer sb=new StringBuffer();
	    for(int i=0;i<8;i++){
	       int number=random.nextInt(3);
	       long result=0;
	       switch(number){
	          case 0:
	              result=Math.round(Math.random()*25+65);
	              sb.append(String.valueOf((char)result));
	              break;
	         case 1:
	             result=Math.round(Math.random()*25+97);
	             sb.append(String.valueOf((char)result));
	             break;
	         case 2:     
	             sb.append(String.valueOf(new Random().nextInt(10)));
	             break;
	        }
	       if(i == 7) {
	    	   str = sb.toString();
	    	   if(str.indexOf("p") ==-1 && str.indexOf("P") ==-1) {
	    		   number=random.nextInt(2);
		        	 int len = random.nextInt(8);

		    	   switch(number){
			          case 0:
			        	  str = str.substring(0, len)+"p"+str.substring(len+1, 8);
			              break;
			         case 1:
			        	 str = str.substring(0, len)+"P"+str.substring(len+1, 8);
			             break;
		    	   }
		       }
	       }
	     }
	    return str;
    }
	
	
	public static void main(String[] args) {
		
		SimpleDateFormat format1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss EE");
		System.out.println(format1.format(new Date()));
	}
}
