package com.gingkoo.mbt.service;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.GpBmTlrInfo;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.util.DateUtil;
import com.gingkoo.mbt.service.base.MbtCommonBaseService;
import com.gingkoo.orm.entity.MbtArchiveManageLog;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Service
public class PersonalTagApvService {
    private UpdateResultBean updateResultBean;

    private Log logger = LogFactory.getLogger(PersonalTagApvService.class);

    private String entityName;

    private String currentDataStatus;

    private boolean flag;

    private String targetDataStatus;

    private String dataRejDesc;

    private String dataId;
    String apvResult ="";

    //   private ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
    @Autowired
    private ROOTDAO rootdao;

    @Autowired
    private MbtBakTablesServive mbtBakTablesServive;

    private Object beanToBeUpdate;

    @Autowired
    private MbtCommonBaseService mbtCommonBaseService;

    public UpdateResultBean getUpdateResultBean() {
        return updateResultBean;
    }

    public void setUpdateResultBean(UpdateResultBean updateResultBean) {
        this.updateResultBean = updateResultBean;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    /**
     * 构造方法
     * @param clazz 实体类
     * @param updateResultBean 前端提交过来的 updateResultBean
     */
    public PersonalTagApvService(UpdateResultBean updateResultBean, Class clazz){
        this.entityName = clazz.getTypeName();
        this.updateResultBean = updateResultBean;
        this.mbtCommonBaseService = new MbtCommonBaseService();
    }

    public PersonalTagApvService(){

    }

    /**
     * 验证数据状态
     * @return true 验证通过，当前数据状态
     */
    private boolean validateDataStatus() throws AppException {
        Map<String, String> recordMap;
        if(updateResultBean.hasNext()){
            recordMap = updateResultBean.next();
        }else {
            throw new AppException("待审核数据为空。");
        }

        updateResultBean.getParamMap().forEach((k, v)->{
            if(StringUtils.isEmpty(recordMap.get(k))){
                recordMap.put(k,v);
            }
        });

        dataId = recordMap.get("dataId");
        apvResult = recordMap.get("apvResult");
        // 检查是否包含dataId 和 apvResult
        if(StringUtils.isEmpty(dataId) || StringUtils.isEmpty(apvResult)){
            logger.error("提交的数据必须包含 dataId, apvResult 字段。");
            throw new AppException("提交的数据不合法。");
        }

        // 检查是否包含拒绝理由
        if("reject".equals(apvResult) && StringUtils.isEmpty(dataRejDesc = recordMap.get("dataRejDesc"))){
            logger.error("拒绝理由为空。");
            throw new AppException("拒绝理由不能为空。");
        }

        Iterator resultDs = rootdao.queryByQL("from " + entityName + " where dataId='" + dataId + "'");
        while (resultDs.hasNext()){
            Object object = resultDs.next();
            try {
//        		GamsCommonBaseService.baseOp("apv",object,updateResultBean,"");

                currentDataStatus = BeanUtils.getProperty(object, "dataStatus");
                Map<String,String> map = new HashMap<String,String>();
                map.put("currDataStatus", currentDataStatus);
                if("21".equals(currentDataStatus) || "22".equals(currentDataStatus)){ // 审核前状态为：补录已审核 或 删除已审核
                    if("pass".equals(apvResult)){ // 审核结果为通过审核
                        throw new AppException("不需要重复审核。");
                    }else {
                        map.put("actionId", "rej");
                        flag = false;
                    }
                }else if("00".equals(currentDataStatus) ||"11".equals(currentDataStatus) || "12".equals(currentDataStatus)){// 审核前状态为：已补录待审核
                    if("pass".equals(apvResult)){ // 审核结果为通过审核
                        map.put("actionId", "apv");
                        flag = true;
                    }else {
                        map.put("actionId", "rej");
                        flag = false;

                    }
                }
                else { // 其它状态
                    throw new AppException("当前状态不需要审核。");
                }
                Map<String,String> resultMap = mbtCommonBaseService.RedataStatus(map);
                if(null==resultMap.get("errMsg") ||"".equals(resultMap.get("errMsg"))) {
                    targetDataStatus = resultMap.get("dataStatus");
                }else {
                    throw new AppException(resultMap.get("errMsg"));
                }
                beanToBeUpdate = object;
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                logger.error(e.getLocalizedMessage());
            }
        }

        return true;
    }

    /**
     * 执行审核
     * @throws AppException APP 异常。
     */
    @Transactional(rollbackFor = Exception.class)
    public void approve() throws AppException {

        try {
            updateObj();

            String dataId = BeanUtils.getProperty(beanToBeUpdate,"dataId");
            String sql = " from MbtDataChangeLog where pdataId='" + dataId +"'";
            rootdao.delete(sql);


            mbtBakTablesServive.bakTables(beanToBeUpdate);

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getLocalizedMessage());
            throw new AppException("审核失败！");
        }

    }


    /**
     * 执行审核
     * @throws AppException APP 异常。
     */
    @Transactional(rollbackFor = Exception.class)
    public void updateObj() throws AppException {
        if(validateDataStatus()){
            try {
                BeanUtils.setProperty(beanToBeUpdate, "dataStatus", targetDataStatus);
                BeanUtils.setProperty(beanToBeUpdate, "dataRejDesc", dataRejDesc);
                BeanUtils.setProperty(beanToBeUpdate, "dataApvUser", GlobalInfo.getCurrentInstance().getTlrno());
                BeanUtils.setProperty(beanToBeUpdate, "dataApvTime", DateUtil.get14Date());
                BeanUtils.setProperty(beanToBeUpdate, "dataApvDate", DateUtil.get8Date());
                apvAdd();
                rootdao.update(beanToBeUpdate);

            } catch (Exception e) {
                e.printStackTrace();
                logger.error(e.getLocalizedMessage());
                throw new AppException("审核失败！");
            }
        }
    }

    private void apvAdd()  {

        try {
            if (apvResult.equals("pass")){
                BeanUtils.setProperty(beanToBeUpdate, "dataState", "2");
            }else if (apvResult.equals("reject")){
                BeanUtils.setProperty(beanToBeUpdate, "dataState", "3");

            }
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

    }

    /**
     * 执行审核
     * @throws AppException APP 异常。
     */
    @Transactional(rollbackFor = Exception.class)
    public void approve810() throws AppException {
        try {
            updateObj();

            String opt = "";
            if(flag){
                opt = "审核通过授权书";
            }else{
                opt = "审核拒绝授权书";
            }
            saveLog(beanToBeUpdate,opt);

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getLocalizedMessage());
            throw new AppException("审核失败！");
        }

    }

    /**
     * 执行审核
     * @throws AppException APP 异常。
     */
    @Transactional(rollbackFor = Exception.class)
    public void saveLog(Object beanToBeUpdate,String opt) throws AppException {
        try {
            MbtArchiveManageLog log = new MbtArchiveManageLog();
            BeanUtils.copyProperties(log,beanToBeUpdate);
            log.setDataId(UUID.randomUUID().toString().replace("-", ""));

            String oprTlrno = GlobalInfo.getCurrentInstance().getTlrno();

            log.setOprTlrno(oprTlrno );
            if(!StringUtils.isEmpty(oprTlrno)){
                String hql = "from GpBmTlrInfo where tlrno = ?";
                List<GpBmTlrInfo> l = rootdao.queryByQL2List(hql,new Object[]{oprTlrno}, null);
                if(null !=l && !l.isEmpty()){
                    String oprTlrname = l.get(0).getTlrName();
                    log.setOprTlrname(oprTlrname);
                }
            }

            log.setOprCode(opt);
            BeanUtils.setProperty(log, "dataStatus", targetDataStatus);
            BeanUtils.setProperty(log, "dataRejDesc", dataRejDesc);
            BeanUtils.setProperty(log, "dataApvUser", GlobalInfo.getCurrentInstance().getTlrno());
            BeanUtils.setProperty(log, "dataApvTime", DateUtil.get14Date());
            BeanUtils.setProperty(log, "dataApvDate", DateUtil.get8Date());
            BeanUtils.setProperty(log, "checkState", "2");

            log.setOprDate(DateUtil.get8Date());
            log.setOprTime(DateUtil.get14Date());



            rootdao.save(log);

            //记录审核日志


        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getLocalizedMessage());
            throw new AppException("审核失败！");
        }

    }
}
