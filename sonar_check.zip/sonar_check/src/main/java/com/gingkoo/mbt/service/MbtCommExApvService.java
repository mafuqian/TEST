package com.gingkoo.mbt.service;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.DataObjectUtils;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.util.DateUtil;
import com.gingkoo.mbt.dao.MbtRootDao;
import com.gingkoo.mbt.service.base.MbtCommonBaseService;
import com.gingkoo.mbt.util.MapToObject;
import com.gingkoo.orm.entity.MbtTableCfg;
import com.gingkoo.orm.entity.MbtUnusalList;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

/**
 * 通用单笔审核 Service, 一般单笔审核可调用此类 Service
 *
 * 调用此审核 Service 的前提条件是 updateResultBean 的记录中必须包含
 * 被审核的记录的唯一标识 dataId 和审核结果apvResult(pass|reject),
 * 若目标状态是审核拒绝(reject)，还需要包含拒绝理由字段dataRejDesc。
 *
 * 在审核过程中，此 Service 会先验证数据的当前状态是否能够被更新为目标状态，
 * 验证通过方能完成审核。合法的状态：
 * 审核通过 34-按段更正待审核-->37-按段更正已审核
 * 审核通过 35-按段删除待审核-->38-按段删除已审核
 * 审核通过 36-整段删除待审核-->39-整段删除已审核
 
 * 审核拒绝： 删除当前bean的数据
 * @author wuxy 2018年11月09日11:00:51
 *
 */
@Service
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class MbtCommExApvService {

    private UpdateResultBean updateResultBean;

    private Log logger = LogFactory.getLogger(MbtCommExApvService.class);

    private String entityName;

    private String currentDataStatus;

    private String targetDataStatus;

    private String dataRejDesc;

    private String dataId;

    @Autowired
    private ROOTDAO rootdao ;

    private Object beanToBeUpdate;

	private Map<String,String> err ;

    private Map<String, String> recordMap ;

	@Autowired
	private MbtCommonBaseService mbtCommonBaseService;
	@Autowired
	protected MbtRootDao dao;

    /**
     * 验证数据状态
     * @return true 验证通过，当前数据状态
     * @throws CommonException 
     * @throws Exception 
     * @throws InstantiationException 
     */
	@Transactional(rollbackFor = Exception.class)
	public boolean validateDataStatus()  {
    	boolean flag = true;
        //1.将传入的bean转成map

        if(updateResultBean.hasNext()){
            recordMap = updateResultBean.next();
        }else {
        	err.put("errMsg", "待审核数据为空。");
        }

        updateResultBean.getParamMap().forEach((k, v)->{
            if(StringUtils.isEmpty(recordMap.get(k))){
                recordMap.put(k,v);
            }
        });

        dataId = recordMap.get("dataId");
		dataRejDesc = recordMap.get("dataRejDesc");
        String apvResult = recordMap.get("apvResult");
        // 检查是否包含dataId 和 apvResult

      if(StringUtils.isEmpty(dataId)){
      logger.error("提交的数据必须包含 dataId 字段。");
  	  err.put("errMsg", "提交的数据不合法。");
  }
      //审核通过的图标
		if("apv".equals(apvResult)) {
	        Iterator resultDs;			
	            try {
	            	resultDs = rootdao.queryByQL("from " + entityName + " where dataId='" + dataId + "'");
	    	        while (resultDs.hasNext()){
    	            Object object = resultDs.next();
    	            Map<String, String> recordMap1 ;
	 	            recordMap1 = MapToObject.objectToMap(object);
	                currentDataStatus = BeanUtils.getProperty(object, "dataStatus");
	                Map<String,String> map = new HashMap<String,String>();
	                map.put("currDataStatus", currentDataStatus);
	                if("21".equals(currentDataStatus) || "22".equals(currentDataStatus)){ // 审核前状态为：补录已审核 或 删除已审核
	                	flag = false;
	                	err.put("errMsg", "不需要重复审核。");
	                }else if("11".equals(currentDataStatus) || "12".equals(currentDataStatus)){// 审核前状态为：已补录待审核         
	                    	//调用审核通过的方法
//	                        targetDataStatus = "21";
                        map.put("actionId", "apv");

	                        apvToEx(recordMap1);                 
	                }
//	                else if("12".equals(currentDataStatus)){// 审核前状态为：已删除待审核
//	                    	//调用审核通过的方法
//	                        targetDataStatus = "22";
//	                        apvToEx(recordMap1);  
//	                }
	                else { // 其它状态
	                	flag = false;
                	  	err.put("errMsg", "当前状态不需要审核。");
	                }
	                if(!flag) {
	                	return flag;
	                }
	                Map<String,String> resultMap = mbtCommonBaseService.RedataStatus(map);
	                if(null==resultMap.get("errMsg") ||"".equals(resultMap.get("errMsg"))) {
	                    targetDataStatus = resultMap.get("dataStatus");
	                }else {
	                	err.put("errMsg",resultMap.get("errMsg"));
	                }
	                beanToBeUpdate = object;
	                }
	            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e ) {
	                logger.error(e.getLocalizedMessage());
            	  	err.put("errMsg", getExceptionAllinformation(e));
	            }catch (CommonException e1) {
					// TODO Auto-generated catch block
            	  	err.put("errMsg", getExceptionAllinformation(e1));

				} catch (Exception e) {
					// TODO Auto-generated catch block
            	  	err.put("errMsg", getExceptionAllinformation(e));
				} 
	        }
			
		else {//审核拒绝
	        
	            try {
	            	Iterator resultDs = rootdao.queryByQL("from " + entityName + " where dataId='" + dataId + "'");
	    	        while (resultDs.hasNext()){
	    	        Object object = resultDs.next();
	                currentDataStatus = BeanUtils.getProperty(object, "dataStatus");
	                Map<String,String> newMap = new HashMap<String,String>();
	                Map<String,String> map = new HashMap<String,String>();
	                map.put("currDataStatus", currentDataStatus);
	                newMap = MapToObject.objectToMap(object);
	                if("22".equals(currentDataStatus)){ 
	                	flag = false;
                	  	err.put("errMsg", "不需要重复审核。");
	                }	else if("21".equals(currentDataStatus) || "11".equals(currentDataStatus) || "12".equals(currentDataStatus) ){
                        map.put("actionId", "rej");
	                	rejToEx(recordMap,newMap);
	                }
//	                else if("11".equals(currentDataStatus) || "12".equals(currentDataStatus) ){
//                             targetDataStatus = "00";
//	                		rejToEx(recordMap,newMap);	                    
//	                }
	                else { // 其它状态
	                	flag = false;
                	  	err.put("errMsg", "当前状态不需要审核。");
	                }
	                
	                Map<String,String> resultMap = mbtCommonBaseService.RedataStatus(map);
	                if(null==resultMap.get("errMsg") ||"".equals(resultMap.get("errMsg"))) {
	                    targetDataStatus = resultMap.get("dataStatus");
	                }else {
	                	err.put("errMsg",resultMap.get("errMsg"));
	                }
	                beanToBeUpdate = object;
	                }
	            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
	                logger.error(e.getLocalizedMessage());
            	  	err.put("errMsg", getExceptionAllinformation(e));
	            } catch (CommonException e) {
					// TODO Auto-generated catch block
            	  	err.put("errMsg", getExceptionAllinformation(e));
				} catch (Exception e) {
					// TODO Auto-generated catch block
            	  	err.put("errMsg", getExceptionAllinformation(e));
				} 
	        	
		}
        return flag;
    }
    
	/**
	 * 审核通过
	 * ex表的data_status赋值为00
	 * list表的data_status赋值为21
	 * @throws Exception 
	 */
	@Transactional(rollbackFor = Exception.class)
	public void apvToEx(Map<String,String> recordMap1 )  {
        Map<String,String> rptResultMap = null ;
        Map<String,String> rptOldResultMap = null ;
		//2.将转成map后的数据的pdata_id取出来 并根据map的inf_rec_type的前两位拼接出rpt表找到数据后转成map  
        String  pdataId =recordMap1.get("pdataId");
        String infRecType = recordMap1.get("infRecType").substring(0, 2);
        StringBuffer ex_table_name = new StringBuffer("com.gingkoo.orm.entity.Mbt").append(infRecType).append("0Ex");
        StringBuffer rpt_old_table_name = new StringBuffer("Mbt").append(infRecType).append("0Rpt");

        //查询数据
        Iterator rptResultDs;
		try {
			String hql = "from " + rpt_old_table_name + " where dataId='" + pdataId + "'";
			List<T> list = rootdao.queryByQL2List(hql, null, null);
			String optType = recordMap1.get("optType");
			//3.映射出ex表
			Object clazz2 = Class.forName(ex_table_name.toString()).newInstance();
			BeanUtils.copyProperties(clazz2,recordMap1);
			recordMap.put("infRecType",recordMap1.get("infRecType"));
//			if (optType.equals("02")){
//				Object clazz =Class.forName(new StringBuffer("com.gingkoo.orm.entity.").append(rpt_old_table_name).toString()).newInstance();
//				BeanUtils.copyProperties(clazz,list.get(0));
//				Map map = new HashMap();
//				map = MapToObject.objectToMap(clazz);
//				String bAcctCode = map.get("bAcctCode")+"";
//				String startDate = recordMap.get("startDate");
//				String endDate = recordMap.get("endDate");
//				//根据rpt的账户标识码拿到rpt表中一样的数据且rpt_date在start_date---end_Date范围内
//				String hql1 = "";
//				if (!(StringUtils.isEmpty(startDate) && StringUtils.isEmpty(endDate))){
//					hql1 = "from " + rpt_old_table_name + " where bAcctCode='" + bAcctCode + "'"+" and rptDate >='"+startDate+"' and rptDate <= '"+endDate +"'";
//				}else if(!(StringUtils.isEmpty(startDate))){
//					hql1 = "from " + rpt_old_table_name + " where bAcctCode='" + bAcctCode + "'"+" and rptDate >='"+startDate+"'";
//				}else if(!(StringUtils.isEmpty(endDate))){
//					hql1 = "from " + rpt_old_table_name + " where bAcctCode='" + bAcctCode + "'"+" and rptDate <= '"+endDate +"'";
//				}else{
//					hql1 = "from " + rpt_old_table_name + " where bAcctCode='" + bAcctCode + "'";
//				}
//				List<T> list1 = rootdao.queryByQL2List(hql1, null, null);
//					//拿list表里面的part_type 看是否有多个有的话做分隔
//				insertDataToEx(list1,clazz2,rpt_old_table_name.toString(),rptResultMap);
//
//			}else{
				insertDataToEx(list,clazz2,rpt_old_table_name.toString(),rptResultMap);
//			}


		} catch (CommonException e) {
			// TODO Auto-generated catch block
    	  	err.put("errMsg", getExceptionAllinformation(e));
		} catch (Exception e) {
			// TODO Auto-generated catch block
    	  	err.put("errMsg", getExceptionAllinformation(e));
		}
	}
	
    /**
     * 审核拒绝
     * 删除list表的数据
     */
	@Transactional(rollbackFor = Exception.class)
	public void rejToEx(Map<String,String> recordMap,Map<String,String> mbt_unusal_list )  {
        String infRecType = mbt_unusal_list.get("infRecType").substring(0, 2);
        StringBuffer ex_table_name = new StringBuffer("Mbt").append(infRecType).append("0Ex");
		StringBuffer rpt_table_name = new StringBuffer("MBT_").append(infRecType).append("0_RPT");

		try {
        	//判断ex表是否存在数据
			if("21".equals(currentDataStatus)) {
				Map<String,String> result = new HashMap<String,String>();
				result = isExists(ex_table_name.toString(),recordMap);
				if(result.isEmpty()){
					rootdao.delete(MbtUnusalList.class, recordMap.get("dataId"));
					//更新 mbtXXXRpt.class的dataRejDesc字段
					String sql  = "update " + rpt_table_name + " set DATA_REJ_DESC ='"+dataRejDesc+"' where DATA_ID ='"+recordMap.get("pdataId")+"'";
					dao.executeSql(sql);
				}else {
					err.put("errMsg", result.get("errMsg"));
				}
			}else {
				rootdao.delete(MbtUnusalList.class, recordMap.get("dataId"));

				String sql  = "update " + rpt_table_name + " set DATA_REJ_DESC ='"+dataRejDesc+"' where DATA_ID ='"+recordMap.get("pdataId")+"'";
				dao.executeSql(sql);
			}
		} catch (CommonException e) {
			// TODO Auto-generated catch block
    	  	err.put("errMsg", getExceptionAllinformation(e));
		}
	}

	/**
	 * 查看当前数据是否存在于ex表中
	 */
	private Map<String,String> isExists(String tableName,Map<String,String> recordMap){
		Map<String,String> flag = new HashMap<String,String>();
		String hqlcfg = "";
		hqlcfg = "from "+tableName +"  where odsDataId = ?  and dataStatus !='22' ";
		List<MbtTableCfg> listExMap;
		try {
			listExMap = rootdao.queryByQL2List(hqlcfg, new Object[] {recordMap.get("pdataId")}, null);
			if(!listExMap.isEmpty()) {
				flag.put("errMsg", "请到异常记录管理的补录页面删除后再拒绝");
			}
		} catch (CommonException e) {
			// TODO Auto-generated catch block
    	  	err.put("errMsg", getExceptionAllinformation(e));
		} 
		return flag;
	}
	/**
	 * 给主表以及子表赋值
	 * @throws Exception 
	 */
	
	private void cfg(String tableName,Map<String,String> recordMap)  {
		String hqlcfg = "";
		hqlcfg = "from MbtTableCfg where tableName = ? ";
		List<MbtTableCfg> listcfg;
		try {
			listcfg = rootdao.queryByQL2List(hqlcfg, new Object[] {tableName}, null);
			//查询到对应的ptableName表
			
			for(int m=0;m<listcfg.size();m++) {
				MbtTableCfg cfg = listcfg.get(m);
				String old_pTableName  =cfg.getOldPtableName();
				String new_pTableName  =cfg.getNewPtableName();
				String pDataId = recordMap.get("odsDataId");
				String pHqlcfg = "";
				pHqlcfg = "from "+old_pTableName +" where pdataId = ? ";
				List<MbtTableCfg> listcfg_p = rootdao.queryByQL2List(pHqlcfg, new Object[] {pDataId}, null);
				for(int i=0;i<listcfg_p.size();i++) {
					//	取原表数据
					Object rptData = listcfg_p.get(i);
					Object newExTable =  Class.forName("com.gingkoo.orm.entity."+new_pTableName).newInstance();
					BeanUtils.copyProperties(newExTable,rptData);
					BeanUtils.setProperty(newExTable, "pdataId", recordMap.get("dataId"));
					BeanUtils.setProperty(newExTable, "odsDataId", BeanUtils.getProperty(newExTable,"dataId"));
					BeanUtils.setProperty(newExTable, "dataId", UuidHelper.getCleanUuid());
					
					BeanUtils.setProperty(newExTable, "dataDate", DateUtil.get8Date());
					BeanUtils.setProperty(newExTable, "dataCrtDate", DateUtil.get8Date());
					BeanUtils.setProperty(newExTable, "dataCrtTime", DateUtil.get14Date());
					BeanUtils.setProperty(newExTable, "dataCrtUser", GlobalInfo.getCurrentInstance().getTlrno());


					//插入到新表？？？
					rootdao.saveOrUpdate(newExTable);
				}				
			}
		} catch (CommonException e) {
			// TODO Auto-generated catch block
    	  	err.put("errMsg", getExceptionAllinformation(e));
		} catch (Exception e) {
			// TODO Auto-generated catch block
    	  	err.put("errMsg", getExceptionAllinformation(e));
		}
	}

	/**
	 * 插入数据到ex表中
	 * @param list
	 * @param clazz2
	 * @param rpt_old_table_name
	 * @param rptResultMap
	 */
	@Transactional(rollbackFor = Exception.class)
	public void insertDataToEx(List list,Object clazz2 ,String rpt_old_table_name,Map<String,String> rptResultMap){
		try {
			for(int i=0;i<list.size();i++){
			BeanUtils.copyProperties(clazz2,list.get(i));
			BeanUtils.setProperty(clazz2, "dataStatus", "00");
			BeanUtils.setProperty(clazz2, "odsDataId", BeanUtils.getProperty(clazz2,"dataId"));
			BeanUtils.setProperty(clazz2, "dataId", UuidHelper.getCleanUuid());
			
			BeanUtils.setProperty(clazz2, "dataDate", DateUtil.get8Date());
			BeanUtils.setProperty(clazz2, "dataCrtDate", DateUtil.get8Date());
			BeanUtils.setProperty(clazz2, "dataCrtTime", DateUtil.get14Date());
			BeanUtils.setProperty(clazz2, "dataCrtUser", GlobalInfo.getCurrentInstance().getTlrno());
			BeanUtils.setProperty(clazz2, "dataChgDate", DateUtil.get8Date());
			BeanUtils.setProperty(clazz2, "dataChgTime", DateUtil.get14Date());
			BeanUtils.setProperty(clazz2, "dataChgUser", GlobalInfo.getCurrentInstance().getTlrno());
			
			BeanUtils.setProperty(clazz2, "dataApvDate", "");
			BeanUtils.setProperty(clazz2, "dataApvTime", "");
			BeanUtils.setProperty(clazz2, "dataApvUser", "");
			BeanUtils.setProperty(clazz2, "fbStatus", "0");

			//BeanUtils.setProperty(clazz2, "bInfRecType", recordMap.get("infRecType"));
				Map<String,String> tmpMap = new HashMap<>();
				tmpMap.put("bInfRecType",recordMap.get("infRecType"));
				mapToObject(clazz2,tmpMap);
			rootdao.saveOrUpdate(clazz2);
			rptResultMap = MapToObject.objectToMap(clazz2);
			//4.调用通用方法，将数据插入ex表中
			cfg(rpt_old_table_name.toString(),rptResultMap);
		}
		} catch (CommonException e) {
			// TODO Auto-generated catch block
			err.put("errMsg", getExceptionAllinformation(e));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			err.put("errMsg", getExceptionAllinformation(e));
		}
	}
	public static String getExceptionAllinformation(Exception ex) {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PrintStream pout = new PrintStream(out);
		ex.printStackTrace(pout);
		String ret = new String(out.toByteArray());
		pout.close();
		try {
		out.close();
		} catch (Exception e) {
		}
		return ret;
		}
	
    /**
     * 执行审核
     * @throws AppException APP 异常。
     */
	@Transactional(rollbackFor = Exception.class)
	public Map<String,String> approve(UpdateResultBean updateResultBean , Class clazz) throws AppException {
		this.entityName = clazz.getTypeName();
		this.err = new HashMap<String,String>();
		this.recordMap = new HashMap<String,String>();
		this.updateResultBean = updateResultBean;
		//TODO
        if(validateDataStatus() && err.isEmpty()){
            try {
                BeanUtils.setProperty(beanToBeUpdate, "dataStatus", targetDataStatus);
                BeanUtils.setProperty(beanToBeUpdate, "dataRejDesc", dataRejDesc);
                BeanUtils.setProperty(beanToBeUpdate, "dataApvUser", GlobalInfo.getCurrentInstance().getTlrno());
                BeanUtils.setProperty(beanToBeUpdate, "dataApvTime", DateUtil.get14Date());
                if((!targetDataStatus.equals("00")) && err.isEmpty()) {
                    rootdao.update(beanToBeUpdate);
                }
            } catch (IllegalAccessException | InvocationTargetException e) {
                logger.error(e.getLocalizedMessage());
        	  	err.put("errMsg", "审核失败！");
            }
        }  
        return err;
    }

	public static Set<String> mapToObject(Object object, Map map) throws AppException {
		HashMap candidates = new HashMap();
		Iterator var4 = map.keySet().iterator();

		while(var4.hasNext()) {
			Object e = var4.next();
			char[] chars = ((String)e).toCharArray();
			if(Character.isUpperCase(chars[1])) {
				chars[0] = (char)(chars[0] - 32);
				candidates.put(String.valueOf(chars), map.get(e));
			}
		}

		map.putAll(candidates);

		try {
			return DataObjectUtils.mapToObject(object, map);
		} catch (Exception var6) {
			throw new AppException("SY", "9999", "属性拷贝出错", var6);
		}
	}
}


