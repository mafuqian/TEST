package com.gingkoo.mbt.job;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.mbt.service.MbtXmlRptService;

@Component("g101Job")
public class G101Job {
    private static final Log logger = LogFactory.getLog(G101Job.class);

    @Autowired
    MbtXmlRptService mbtXmlRptService;
    
    JobResult jr = new JobResult();

    public Map<String, String> execute(String userCode, String passWord, String dataProviderOrgCode,
			String originateOrgCode, String originateUserCode, String beginDate, String endDate) {
        logger.info("===============++++++++++Exec G101Job begin++++++++++=============");
        jr.setErrCode("0");
        jr.setErrMsg("OK");
        try {
        	mbtXmlRptService.psGetToCheckObjReq(userCode, passWord, dataProviderOrgCode, originateOrgCode, originateUserCode, beginDate, endDate);
        } catch (Exception arg6) {
            arg6.printStackTrace();
            logger.info("操作失败，错误信息：" + arg6.getMessage());
            jr.setErrCode("E");
            jr.setErrMsg("操作失败，错误信息：" + arg6.getMessage());
            return jr.getMap();
        }

        logger.info("===============++++++++++Exec G101Job end++++++++++=============");
        return jr.getMap();
    }

}
