package com.gingkoo.mbt.service;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.DataObjectUtils;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.mbt.dao.MbtRootDao;
import com.gingkoo.mbt.service.base.MbtCommonBaseService;

/**
 *
 * 处理前台提交的单条记录的通用 Action
 *
 * @author fuxiang.luo@gingkoo.com
 *
 *
 */
@SuppressWarnings("ALL")
@Service
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class MbtMailSaveService  {

    protected static final Log logger = LogFactory.getLogger(MbtMailSaveService.class);

    @Autowired
    protected MbtRootDao dao;

    private String dataId;

    private boolean falg;

    private String currentDataStatus;

    private String targetDataStatus;

    private  Object bean;
    
    @Autowired
    private MbtCommonBaseService mbtCommonBaseService;

    public String getDataId(){
        return dataId;
    }
    
    public void delete(UpdateResultBean resultBean, Class<?> clazz) throws AppException {
    	 Map<String, String> recordMap = resultBean.next();

         this.dataId = recordMap.get("dataId");
         
         Iterator iterator = dao.queryByQL("from " + clazz.getName() + " where dataId='" + dataId + "'");
         if(iterator.hasNext()){
             bean = iterator.next();
            dao.delete(bean);
         }else {//标识根据 dataId没有检索出数据，说明提交的dataId有问题
             logger.error("前端提交的dataId数据库不存在。");
             throw new AppException("提交的数据不合法。");
         }
         
    	
    }

    @Transactional(rollbackFor = Exception.class)
    public void process(UpdateResultBean resultBean, Class<?> clazz) throws AppException {

        Map<String, String> recordMap = resultBean.next();

        this.dataId = recordMap.get("dataId");
        recordMap.put("dataChgUser", GlobalInfo.getCurrentInstance().getTlrno());
        recordMap.put("dataChgTime", DateUtil.get14Date());
        recordMap.put("dataChgDate", DateUtil.get8Date());

        Map<String,String> map = new HashMap<String,String>();
        // 不含dataId，新增数据
        if(StringUtils.isEmpty(dataId)){
            falg = true;
            try {
                bean = clazz.newInstance();
            } catch (InstantiationException | IllegalAccessException e) {
                logger.error(e.getLocalizedMessage());
                throw new AppException("系统错误，创建类" + clazz.getName() + "实例时出错。");
            }

            dataId = UUID.randomUUID().toString().replace("-", "");
            recordMap.put("dataId", dataId);
            recordMap.put("dataCrtUser",GlobalInfo.getCurrentInstance().getTlrno());
            recordMap.put("dataCrtTime", DateUtil.get14Date());
            recordMap.put("dataDate", DateUtil.get8Date());
            recordMap.put("dataCrtDate", DateUtil.get8Date());
            recordMap.put("corpId", GlobalInfo.getCurrentInstance().getCorpId());
            recordMap.put("inqOrgID","");
            recordMap.put("dataSource","1");
            currentDataStatus = "00";
            map.put("actionId", "add");

        }else {
            falg = false;
            Iterator iterator = dao.queryByQL("from " + clazz.getName() + " where dataId='" + dataId + "'");
            if(iterator.hasNext()){
                bean = iterator.next();
                try {
					currentDataStatus = BeanUtils.getProperty(bean, "dataStatus");
	                map.put("actionId", "mod");
				} catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
	                logger.error(e.getLocalizedMessage());
	            }
            }else {//标识根据 dataId没有检索出数据，说明提交的dataId有问题
                logger.error("前端提交的dataId数据库不存在。");
                throw new AppException("提交的数据不合法。");
            }
        }
        if(null != recordMap.get("dataCrtTime")) {
       	 recordMap.put("dataCrtTime",trim(recordMap.get("dataCrtTime")));
       }

       if(null != recordMap.get("dataApvTime")) {
      	 recordMap.put("dataApvTime",trim(recordMap.get("dataApvTime")));
      }
       map.put("currDataStatus", currentDataStatus);

       Map<String,String> resultMap = mbtCommonBaseService.RedataStatus(map);
       if(null==resultMap.get("errMsg") ||"".equals(resultMap.get("errMsg"))) {
           targetDataStatus = resultMap.get("dataStatus");
       }else {
           throw new AppException(resultMap.get("errMsg"));
       }
       recordMap.put("dataStatus", targetDataStatus);
       recordMap.put("dataRejDesc", "");
       mapToObject(bean, recordMap);
       try {
    	   dao.saveOrUpdate(bean);
       } catch (Exception e) {
           logger.error(e.getLocalizedMessage());
           throw new AppException("系统错误，保存失败。");
       }
    }
    public String trim(String str) {
    	if(!"".equals(str) && null != str) {
    		str = str.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
    	}

    	return str;
    }

    public static Set<String> mapToObject(Object object, Map map) throws AppException {
        HashMap candidates = new HashMap();
        Iterator var4 = map.keySet().iterator();

        while(var4.hasNext()) {
            Object e = var4.next();
            char[] chars = ((String)e).toCharArray();
            if(Character.isUpperCase(chars[1])) {
                chars[0] = (char)(chars[0] - 32);
                candidates.put(String.valueOf(chars), map.get(e));
            }
        }
        map.putAll(candidates);
        try {
            return DataObjectUtils.mapToObject(object, map);
        } catch (Exception var6) {
            throw new AppException("SY", "9999", "属性拷贝出错", var6);
        }
    }

}
