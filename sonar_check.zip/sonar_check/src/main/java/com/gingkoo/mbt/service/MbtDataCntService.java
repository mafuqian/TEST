package com.gingkoo.mbt.service;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.config.database.sql.ParamSql;
import com.gingkoo.gf4j2.framework.config.database.sql.SqlParserImpl;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.BaseService;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.orm.entity.MbtDataSyncInfoCfg;
import com.gingkoo.orm.entity.MbtDataSyncInfoCnt;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class MbtDataCntService extends BaseService {
	//private static final HtLog htlog = HtLogFactory.getLogger(MbtContractUpdService.class);
	public static final String ID = "batchJobMngService";
	public static final String CMD_MOD = "CMD_MOD";
	public static final String CMD_DEL = "CMD_DEL";
	public static final String CMD_ADD = "CMD_ADD";
	public static final String IN_PARAM = "IN_PARAM";
	public static final String CMD = "CMD";
	@Resource
	private ROOTDAO rootDao;

	public void beforeProc(ServiceContext context) throws CommonException {
	}

	public void execute(ServiceContext context) throws CommonException {
		
		String cmd = (String) context.getAttribute("CMD");
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		GlobalInfo GI = GlobalInfo.getCurrentInstance();
		Date date = new Date();
		String dataDate = (new SimpleDateFormat("yyyyMMdd")).format(date);
		MbtDataSyncInfoCnt infoCnt = (MbtDataSyncInfoCnt) context.getAttribute("IN_PARAM");
		String infoType = infoCnt.getInfoType();
		String hql = "";
		Object[] obj = new Object[2] ;
		if("".equals(infoType) || null ==infoType) {
			hql = "from MbtDataSyncInfoCnt where dataDate=?";
			obj[0] = dataDate;
		}else {
			hql = "from MbtDataSyncInfoCnt where dataDate=? and infoType = ?";
			obj[0] = dataDate;
			obj[1] = infoType;
		}
		
		List<MbtDataSyncInfoCnt> list = rootdao.queryByQL2List(hql,obj, null);
		if(list.size() > 0) {
			String sql = "";
			if("".equals(infoType) || null ==infoType) {
				 sql = " from MbtDataSyncInfoCnt where dataDate = '"+ dataDate +"'";
			}else {
				 sql = " from MbtDataSyncInfoCnt where dataDate = '"+ dataDate +"' and infoType = '" + infoType +"'";
			}
			
			ROOTDAOUtils.getROOTDAO().delete(sql);
		}
		
		
		Map<String,String> map = new HashMap<String,String>();
		Object[] ob = new Object[1] ;
		String hqlcfg = "";
		if("".equals(infoType) || null ==infoType) {
			 hqlcfg = "from MbtDataSyncInfoCfg ";
		}else {
			 hqlcfg = "from MbtDataSyncInfoCfg where infoType = ?";
			 ob[0] = infoType;
		}
		
		
		List<MbtDataSyncInfoCfg> listcfg = rootdao.queryByQL2List(hqlcfg, ob, null);
		if(listcfg.size() > 0) {
			for(int i=0;i<listcfg.size();i++) {
				MbtDataSyncInfoCnt cnt = new MbtDataSyncInfoCnt();
				cnt.setDataId(UuidHelper.getCleanUuid());
				cnt.setDataDate(dataDate);
				cnt.setInfoType(listcfg.get(i).getInfoType());
				cnt.setCorpId(GI.getCorpId());
				cnt.setOrgId(GI.getBrno());
				cnt.setGroupId("");
				cnt.setCntTime((new SimpleDateFormat("yyyyMMddHHmmss")).format(date));
				cnt.setDataCrtUser(GI.getTlrno());
				cnt.setDataCrtDate((new SimpleDateFormat("yyyyMMdd")).format(date));
				cnt.setDataCrtTime((new SimpleDateFormat("yyyyMMddHHmmss")).format(date));
				cnt.setDataChgUser(GI.getTlrno());
				cnt.setDataChgDate((new SimpleDateFormat("yyyyMMdd")).format(date));
				cnt.setDataChgTime((new SimpleDateFormat("yyyyMMddHHmmss")).format(date));
				String sqlApv = listcfg.get(i).getApvDataSql();
				String sqlUnApv = listcfg.get(i).getUnapvDataSql();
				String sqlApvAll = listcfg.get(i).getDataSql();
				SqlParserImpl parser = new SqlParserImpl();
				BigDecimal cnt1 = new BigDecimal("0");
				BigDecimal cnt2 = new BigDecimal("0");
				BigDecimal cnt3 = new BigDecimal("0");
				if(null != sqlApv && !"".equals(sqlApvAll)) {
					ParamSql parse = parser.parse(sqlApv, map);
					String query = parse.getSql();
					Iterator it = rootDao.queryBySQL(query);
					while(it.hasNext()){
						cnt1 = (BigDecimal) it.next();
						
					}
				}
				
				if(null != sqlUnApv && !"".equals(sqlUnApv)) {
					ParamSql parse = parser.parse(sqlUnApv, map);
					String query = parse.getSql();
					Iterator it = rootDao.queryBySQL(query);
					while(it.hasNext()){
						cnt2 = (BigDecimal) it.next();
						cnt.setUnapvDataCnt(cnt2.toString());
					}
				}
				
				if(null != sqlApvAll && !"".equals(sqlApvAll)) {
					ParamSql parse = parser.parse(sqlApvAll, map);
					String query = parse.getSql();
					Iterator it = rootDao.queryBySQL(query);
					while(it.hasNext()){
						cnt3 = (BigDecimal) it.next();
					}
				}else {
					cnt3 = cnt1.add(cnt2);
				}
				cnt.setApvDataCnt(cnt1.toString());
				cnt.setUnapvDataCnt(cnt2.toString());
				cnt.setDataCnt(cnt3.toString());
				ROOTDAOUtils.getROOTDAO().save(cnt);
			}
		}
	}

	public void afterProc(ServiceContext context) throws CommonException {
	}
	
	public static void main(String[] args) {
		for(int i=0;i<1197;i++) {
			System.out.println(UuidHelper.getCleanUuid());
		}
	}
}