package com.gingkoo.mbt.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.common.query.entity.GpBmExportSheet;
import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.OPCaller;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.mbt.service.ExportConfigSyncImportService;
import com.gingkoo.mbt.service.ExportSheetConfigAlterService;
import com.gingkoo.mbt.service.ExportSheetSortService;

public class ExportSheetConfigAlterAction extends WebAlterAction {
    private static final String DATASET_ID = "Export_SheetBas_ds";


    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse respone) throws AppException {
        UpdateReturnBean updateReturnBean = new UpdateReturnBean();
        UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
        ServiceContext oc = new ServiceContext();

        try {
            GpBmExportSheet gpBmExportSheet = new GpBmExportSheet();
            String str = "";
            if (updateResultBean.hasNext()) {
                Map<String, String> map = updateResultBean.next();
                String opr = (String)map.get("opr");
                if ("add".equals(opr)) {
                    oc.setAttribute(ExportSheetConfigAlterService.CMD, ExportSheetConfigAlterService.CMD_ADD);
                    str = "新增";
                } else if ("mod".equals(opr)) {
                    oc.setAttribute(ExportSheetConfigAlterService.CMD, ExportSheetConfigAlterService.CMD_MOD);
                    str = "修改";
                } else  if ("del".equals(opr)) {
                	 oc.setAttribute(ExportSheetConfigAlterService.CMD, ExportSheetConfigAlterService.CMD_DEL);
                     str = "删除";
                }

                mapToObject(gpBmExportSheet, map);
                oc.setAttribute(ExportSheetConfigAlterService.IN_PARAM, gpBmExportSheet);
                OPCaller.call(ExportSheetConfigAlterService.ID, oc);
                OPCaller.call(ExportSheetSortService.ID, oc);
                ExportConfigSyncImportService exportConfigSyncImportService = ApplicationContextUtil.getBean(ExportConfigSyncImportService.class);
				exportConfigSyncImportService.execute(exportConfigSyncImportService.SHEET, gpBmExportSheet.getPDataId());
		
            }

            GlobalInfo.getCurrentInstance().appendBizLog("文件导出配置文件菜单关联  -- " + str + "功能");
            updateReturnBean.setParameter("code", "00");
			updateReturnBean.setParameter("desc", "");
        } catch (CommonException e) {
            e.printStackTrace();
            updateReturnBean.setParameter("code", "99");
			updateReturnBean.setParameter("desc", e.getErrMessage());
        }

        return updateReturnBean;
    }
}
