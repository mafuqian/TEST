package com.gingkoo.mbt.action;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.service.base.OPCaller;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.mbt.service.EntTagAlterService;
import com.gingkoo.mbt.service.MbtCommCommitToApvService;
import com.gingkoo.mbt.service.PersonalTagAlterService;
import com.gingkoo.orm.entity.PerTagInf;
import com.gingkoo.orm.entity.TagInf;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

public class EntTagDeleteAlterAction extends WebAlterAction {
    private static final String DATASET_ID = "EntTag_ds";
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        String dsId = multiUpdateResultBean.getUpdateResult().containsKey("EntTag_ds") ? "EntTag_ds" : "EntTag_ds";
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID(dsId);
        Map<String,String> map=resultBean.getTotalList().get(0);
        String objCheckSource =map.get("objCheckSource");
        String dataState =map.get("dataState");

        if(!dataState.equals("4") && !dataState.equals("6") &&!dataState.equals("7") ){
            WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
            MbtCommCommitToApvService mbtCommCommitToApvService = (MbtCommCommitToApvService) context.getBean("mbtCommCommitToApvService");

            mbtCommCommitToApvService.commitToApprove(resultBean, PerTagInf.class,returnBean);
            if("".equals(returnBean.getParameter("E_CODE"))) {
            	returnBean.setParameter("isOptSucc", "true");
            }else {
            	returnBean.setParameter("isOptSucc", "false");
            }

        }else {
            returnBean.setParameter("isOptSucc", "false");
        }
        return returnBean;

    }
}
