package com.gingkoo.mbt.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtD101ApvService;
import com.gingkoo.orm.entity.MbtD103Qry;

public class MbtD103ApvAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("MbtD103Authorization_Dtl_ds");
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtD101ApvService mbtD101ApvService = (MbtD101ApvService) context.getBean("mbtD101ApvService");
        mbtD101ApvService.setEntityName(MbtD103Qry.class.getName());
        mbtD101ApvService.setUpdateResultBean(resultBean);
        mbtD101ApvService.approve();
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }
}
