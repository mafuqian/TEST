package com.gingkoo.mbt.service;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.util.DateUtil;
import com.gingkoo.orm.entity.MbtDataSyncInfoCfg;
import org.apache.commons.beanutils.BeanUtils;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.sys.log.Log;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

/**
 * Created by young on 2018/12/17.
 */
@Service
public class MbtBakTablesServive {

    @Autowired
    private ROOTDAO rootdao;

    private Log logger = LogFactory.getLogger(MbtBakTablesServive.class);

    @Transactional(rollbackFor = Exception.class)
    public void bakTables (Object e)  throws AppException {

        String dataId = null;
        try {
            dataId = BeanUtils.getProperty(e,"dataId");
            Class c =e.getClass();
            String tableName = c.getSimpleName();
            String hql = "from MbtDataSyncInfoCfg where dataId='"+tableName+"'";

            List<MbtDataSyncInfoCfg> cfg = rootdao.queryByQL2List(hql, null, null);
            for(int i=0;i<cfg.size();i++){
                MbtDataSyncInfoCfg mbtDataSyncInfoCfg = cfg.get(i);
                String dataDesc = mbtDataSyncInfoCfg.getDataDesc();
                if (null != dataDesc || !"".equals(dataDesc)) {
                    String[] arr = dataDesc.split(";");
                    String strTableName = "";
                    String packagePath = "";
                    if(arr.length !=0){
                        packagePath = arr[0] ;
                        String  tmpDataId = "";
                        for(int m=1;m<arr.length;m++){
                            strTableName = arr[m];
                            String[] tableArr = strTableName.split(",");
                            String name  = tableArr[0];
                            String page = packagePath + "." +name+"Tmp";
                            Class forName = Class.forName(page);
                            if(m !=1){
                                String queryHql = "from  "+ name +" where pdataId='"+dataId+"'";
                                List<T> list = rootdao.queryByQL2List(queryHql, null, null);
                                for(int n =0;n<list.size();n++){
                                    Object tmp = forName.newInstance();
                                    BeanUtils.copyProperties(tmp,list.get(n));
                                    BeanUtils.setProperty(tmp, "pdataId", tmpDataId);
                                    String dataIdTmp = BeanUtils.getProperty(tmp,"dataId");
                                    BeanUtils.setProperty(tmp, "odsDataId", dataIdTmp);
                                    BeanUtils.setProperty(tmp, "dataId", UUID.randomUUID().toString().replace("-", ""));
                                    BeanUtils.setProperty(tmp, "odsDataMarkDate",  DateUtil.get8Date());
                                    BeanUtils.setProperty(tmp, "odsDataMarkTime",  DateUtil.get14Date());
                                    BeanUtils.setProperty(tmp, "userId", GlobalInfo.getCurrentInstance().getTlrno());
                                    rootdao.save(tmp);

                                }
                            }else {
                                Object tmp = forName.newInstance();
                                tmpDataId = UUID.randomUUID().toString().replace("-", "");
                                BeanUtils.copyProperties(tmp, e);
                                BeanUtils.setProperty(tmp, "odsDataId", dataId);
                                BeanUtils.setProperty(tmp, "dataId", tmpDataId);
                                BeanUtils.setProperty(tmp, "odsDataMarkDate", DateUtil.get8Date());
                                BeanUtils.setProperty(tmp, "odsDataMarkTime", DateUtil.get14Date());
                                BeanUtils.setProperty(tmp, "userId", GlobalInfo.getCurrentInstance().getTlrno());
                                rootdao.save(tmp);
                            }
                        }
                    }
                }

            }
        } catch (Exception e1) {
            e1.printStackTrace();
            logger.error(e1.getLocalizedMessage());
            throw new AppException("审核失败！");
        }
    }

}
