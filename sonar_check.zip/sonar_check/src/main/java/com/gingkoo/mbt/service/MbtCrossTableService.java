package com.gingkoo.mbt.service;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.mbt.callProc.MbtCrossTableValidateCallProcService;
import com.gingkoo.orm.entity.MbtCrossTableValidProcess;
import com.gingkoo.orm.entity.MbtCrossTableValidateCfg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MbtCrossTableService {

    @Autowired
    private ROOTDAO rootdao;

    @Autowired
    private MbtCrossTableValidateCallProcService callProcService;

    /**
     * @param busClass
     */
    public JobResult batchValidate(String busClass, String rptDate) throws AppException {
        JobResult jobResult = new JobResult();
        jobResult.setErrCode("00");
        jobResult.setErrMsg("OK");
        String hql = "from MbtCrossTableValidateCfg where busClass =? ";
        List<MbtCrossTableValidateCfg> list = new ArrayList<>();
        list = rootdao.queryByQL2List(hql, new String[]{busClass}, null);
        if (list.size() == 0) {
            jobResult.setErrCode("99");
            jobResult.setErrMsg("没有查询到批量业务跨表校验配置。");
            return jobResult;
        }
        for (MbtCrossTableValidateCfg crossTableValidateCfg : list) {
            jobResult = callProcService.singleValidate(crossTableValidateCfg, rptDate);
            String errCode = jobResult.getErrCode();
            String errMsg = jobResult.getErrMsg();
            String sqlDelete = "DELETE FROM MBT_CROSS_TABLE_VALID_PROCESS WHERE BUS_CLASS='" + busClass + "' AND RPT_DATA_TYPE='" + crossTableValidateCfg.getRptDataType() + "' " +
                    "AND RPT_DATA_NO='" +crossTableValidateCfg.getRptDataNo()+ "' AND RPT_DATE='"+rptDate+"' ";
            rootdao.executeSql(sqlDelete);
            MbtCrossTableValidProcess process = new MbtCrossTableValidProcess();
            process.setDataId(UuidHelper.getCleanUuid());
            process.setDataDate(DateUtil.get8Date());
            process.setBusClass(busClass);
            process.setRptDataType(crossTableValidateCfg.getRptDataType());
            process.setRptDataNo(crossTableValidateCfg.getRptDataNo());
            process.setRptDate(rptDate);
            process.setBatchId(UuidHelper.getCleanUuid());
            process.setBatchCheckFlag("00".equals(errCode)?"Y":"F");
            process.setBatchCheckDesc(errMsg);
            process.setBatchCheckDate(DateUtil.get8Date());
            process.setBatchCheckTime(DateUtil.get14Date());
            rootdao.save(process);
        }
        return jobResult;
    }


    public JobResult singleValidate(String busClass, String rptDate, String rptDataType) throws AppException {
        JobResult jobResult = new JobResult();
        jobResult.setErrCode("00");
        jobResult.setErrMsg("OK");
        String hql = "from MbtCrossTableValidateCfg where busClass = ? and rptDataType = ?";
        List<MbtCrossTableValidateCfg> list = new ArrayList<>();
        list = rootdao.queryByQL2List(hql, new String[]{busClass, rptDataType}, null);
        if (list.size() == 0) {
            jobResult.setErrCode("99");
            jobResult.setErrMsg("没有查询到单个业务跨表校验配置。");
            return jobResult;
        }
        for (MbtCrossTableValidateCfg crossTableValidateCfg : list) {
            jobResult = callProcService.singleValidate(crossTableValidateCfg, rptDate);
            String errCode = jobResult.getErrCode();
            String errMsg = jobResult.getErrMsg();
            String sqlDelete = "DELETE FROM MBT_CROSS_TABLE_VALID_PROCESS WHERE BUS_CLASS='" + busClass + "' AND RPT_DATA_TYPE='" + rptDataType + "' " +
                    "AND RPT_DATA_NO='" +crossTableValidateCfg.getRptDataNo()+ "' AND RPT_DATE='"+rptDate+"' ";
            rootdao.executeSql(sqlDelete);
            MbtCrossTableValidProcess process = new MbtCrossTableValidProcess();
            process.setDataId(UuidHelper.getCleanUuid());
            process.setDataDate(DateUtil.get8Date());
            process.setBusClass(busClass);
            process.setRptDataType(rptDataType);
            process.setRptDataNo(crossTableValidateCfg.getRptDataNo());
            process.setRptDate(rptDate);
            process.setBatchId(UuidHelper.getCleanUuid());
            process.setBatchCheckFlag("00".equals(errCode)?"Y":"F");
            process.setBatchCheckDesc(errMsg);
            process.setBatchCheckDate(DateUtil.get8Date());
            process.setBatchCheckTime(DateUtil.get14Date());
            rootdao.save(process);
        }
        return jobResult;
    }


}
