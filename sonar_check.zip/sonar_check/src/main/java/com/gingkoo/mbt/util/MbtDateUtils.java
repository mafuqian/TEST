package com.gingkoo.mbt.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.sys.log.Log;

/**
 * @Author: li.jy
 * @Date: 2018/11/20
 */
public class MbtDateUtils {
    private static final Log logger = LogFactory.getLogger(CompareUtils.class);

    public static String updateTime() {
        String upd_sql = ",DATA_CHG_DATE='" + today()
                + "',DATA_CHG_TIME='" + now() + "'";
        return upd_sql;
    }

    public static String now() {
        return toDateTime();
    }

    public static String toDateTime() {
        return toDateTime(new Date());
    }

    public static String toDateTime(Date date) {
        DateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        return to(date, format);
    }

    public static String today() {
        return toDate(new Date());
    }

    public static String toDate(Date date) {
        DateFormat format = new SimpleDateFormat("yyyyMMdd");
        return to(date, format);
    }

    public static String to(Date date, DateFormat format) {
        return date == null ? null : format.format(date);
    }

    public static void main(String[] args) {
        System.out.println(now());
        System.out.println(today());
        System.out.println(updateTime());
    }
}
