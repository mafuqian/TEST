package com.gingkoo.mbt.service;

import com.gingkoo.common.validate.service.CommonValidteServeice;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.mbt.dao.MbtRootDao;
import com.gingkoo.mbt.service.base.MbtCommonBaseService;
import com.gingkoo.mbt.util.MapToObject;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 *
 * 处理前台提交的单条记录的通用 Action
 *
 * @author fuxiang.luo@gingkoo.com
 *
 *
 */
@SuppressWarnings("ALL")
@Service
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class MbtCommCreditReportSaveService  {

    protected static final Log logger = LogFactory.getLogger(MbtCommCreditReportSaveService.class);

    @Autowired
    protected MbtRootDao dao;

    private String dataId;

    @Autowired
    private MbtCommonBaseService mbtCommonBaseService;

    private String currentDataStatus;

    private String targetDataStatus;


    public String getDataId(){
        return dataId;
    }

    /**
     *
     * @param resultBean 包含记录数据的 resultBean
     * @param clazz 实体类
     * @throws AppException app异常
     */
    @Transactional(rollbackFor = Exception.class)
    public void process(UpdateResultBean resultBean, Class<?> clazz) throws AppException {
        Map<String, String> recordMap = resultBean.next();
        resultBean.getParamMap().forEach((k, v) ->{
            if(!StringUtils.isEmpty(v)){
                recordMap.put(k, v);
            }
        });

        Object bean;
        this.dataId = recordMap.get("dataId");
        recordMap.put("dataChgUser", GlobalInfo.getCurrentInstance().getTlrno());
        recordMap.put("dataChgTime", DateUtil.get14Date());
        recordMap.put("dataChgDate", DateUtil.get8Date());

        Map<String,String> map = new HashMap<String,String>();
        if ("stop".equals(recordMap.get("opr"))){
            map.put("actionId", "stop");

        }else if("start".equals(recordMap.get("opr"))){
            map.put("actionId", "start");

        }else if("cancel".equals(recordMap.get("opr"))){
            map.put("actionId", "cancel");

        }else if("lock".equals(recordMap.get("opr"))){
            map.put("actionId", "lock");
        }
            Iterator iterator = dao.queryByQL("from " + clazz.getName() + " where dataId='" + dataId + "'");
            if(iterator.hasNext()){
                bean = iterator.next();
                try {
                  Map<String,String> a =   MapToObject.objectToMap(bean);
                  if (!a.get("dataCrtUser").equals( GlobalInfo.getCurrentInstance().getTlrno())){
                      logger.error("只能是当前操作人操作");
                      throw new AppException("只能是当前操作人操作");
                  }else{
                      currentDataStatus = BeanUtils.getProperty(bean, "dataStatus");
                      if(null != recordMap.get("dataCrtTime")) {
                          recordMap.put("dataCrtTime",trim(recordMap.get("dataCrtTime")));
                      }

                      if(null != recordMap.get("dataApvTime")) {
                          recordMap.put("dataApvTime",trim(recordMap.get("dataApvTime")));
                      }
                      map.put("currDataStatus", currentDataStatus);

                      Map<String,String> resultMap = mbtCommonBaseService.RedataStatus(map);
                      if(null==resultMap.get("errMsg") ||"".equals(resultMap.get("errMsg"))) {
                          targetDataStatus = resultMap.get("dataStatus");
                      }else {
                          throw new AppException(resultMap.get("errMsg"));
                      }
                      recordMap.put("associatedUserStatus", targetDataStatus);

                      try {
                          BeanUtils.copyProperties(bean,recordMap);
                      } catch (IllegalAccessException e) {
                          e.printStackTrace();
                      } catch (InvocationTargetException e) {
                          e.printStackTrace();
                      }
                      dao.saveOrUpdate(bean);
                  }
                } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                    logger.error(e.getLocalizedMessage());
                } catch (Exception e) {
                    throw new AppException(e.getLocalizedMessage());
                }
            }else {//标识根据 dataId没有检索出数据，说明提交的dataId有问题
                logger.error("前端提交的dataId数据库不存在。");
                throw new AppException("提交的数据不合法。");
            }
    }
    public String trim(String str) {
        if(!"".equals(str) && null != str) {
            str = str.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
        }

        return str;
    }

    /**
     * 校验字段
     * @param resultBean 待更新的结果集
     * @param returnBean 处理之后，返回给前端的结果集
     * @return pass - 校验通过; failed - 校验失败
     * @throws CommonException 通用异常
     */
    protected String validateFields(UpdateResultBean resultBean, UpdateReturnBean returnBean) throws CommonException {

        CommonValidteServeice validateService = new CommonValidteServeice();
        String validateResult = validateService.execute(resultBean.getTotalList().get(0), GlobalInfo.getCurrentInstanceWithoutException().getFuncId(),true);
        if(!StringUtils.isEmpty(validateResult)){
            String[] result = validateResult.split("\\|");
            returnBean.setParameter("desc", result[1]);
            returnBean.setParameter("resId", result[0]);
            return "failed";
        }else {
            return "pass";
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public void batchprocess(UpdateResultBean resultBean, Class<?> clazz) throws AppException {

        while (resultBean.hasNext()){

            Map<String, String> recordMap = resultBean.next();
            resultBean.getParamMap().forEach((k, v)->{
                if(!StringUtils.isEmpty(v) && !k.equals("dataId")){
                    recordMap.put(k,v);
                }
            });

            Object bean = null;
            try {
                bean = clazz.newInstance();
            } catch (InstantiationException | IllegalAccessException e) {
                logger.error(e.getLocalizedMessage());
                throw new AppException("实例化类" + clazz.getName() + "时出错。");
            }

            String recordState = recordMap.get("recordState");
            if(StringUtils.isEmpty(recordMap.get("dataId"))){
                recordMap.put("dataId", UUID.randomUUID().toString().replace("-", ""));
            }
            try {
                BeanUtils.copyProperties(bean,recordMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            if("insert".equals(recordState) || "new".equals(recordState)){//新增加的记录
                dao.save(bean);
            }else if ("modify".equals(recordState)){//修改
                dao.update(bean);
            }else if ("delete".equals(recordState) || "discard".equals(recordState)){//被删除或者被舍弃的
                dao.delete(bean);
            }
        }

    }
}
