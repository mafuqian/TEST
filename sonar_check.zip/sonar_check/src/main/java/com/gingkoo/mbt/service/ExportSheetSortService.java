package com.gingkoo.mbt.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.common.query.entity.GpBmExportSheet;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.BaseService;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.gf4j2.framework.util.ExceptionUtil;


/**
 * 
 *将sheet层的数据保存后，
 *需要对sheet的数据重新排列
 */
@Component
public class ExportSheetSortService extends BaseService {
	@Resource
	private ROOTDAO rootDao;
	@Autowired
	private ExportSettingService service;

	public static final String ID = "exportSheetSortService";
	public static final String CMD = "CMD";
	public static final String IN_PARAM = "IN_PARAM";

	public void beforeProc(ServiceContext context) throws CommonException {
	}

	public void execute(ServiceContext context) throws CommonException   {
		GpBmExportSheet gpBmExportSheet = (GpBmExportSheet) context.getAttribute(IN_PARAM);
		List<GpBmExportSheet> sheetList;
		try {
			sheetList = service.getGpBmExportSheetListOrderByMainflag(gpBmExportSheet.getPDataId());
			for(int i = 0 ; i < sheetList.size(); i++) {
				GpBmExportSheet sheet = sheetList.get(i);
				sheet.setSheetNum((long)(i+1));
				rootDao.update(sheet);
			}
		} catch (CommonException e) {
			e.printStackTrace();
			ExceptionUtil.throwCommonException("sheet层排序失败。",e);
		}
		
	}


	public void afterProc(ServiceContext context) throws CommonException {
	}
	
	
	
	
	
	
}
