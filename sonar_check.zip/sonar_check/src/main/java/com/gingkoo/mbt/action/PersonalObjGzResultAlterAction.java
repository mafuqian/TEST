package com.gingkoo.mbt.action;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.OPCaller;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.mbt.service.PersonalObjAlterService;
import com.gingkoo.mbt.service.PersonalObjService;
import com.gingkoo.mbt.webservice.ConnectWebservices;
import com.gingkoo.orm.entity.MbtSendUserManage;
import com.gingkoo.orm.entity.MbtTableCfg;
import com.gingkoo.orm.entity.ToCheckInf;
import org.springframework.context.annotation.Bean;
import org.springframework.util.CollectionUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

public class PersonalObjGzResultAlterAction extends WebAlterAction {
    private static final String DATASET_ID = "PersonalObj_ObjGz_ds";
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse respone) throws AppException {
        UpdateReturnBean updateReturnBean = new UpdateReturnBean();
        UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
        ServiceContext oc = new ServiceContext();
        ToCheckInf toCheckInf = new ToCheckInf();


        Map<String, String> recordMap = updateResultBean.getTotalList().get(0);

       String correctState= recordMap.get("correctState");
       String dataChgUser= recordMap.get("dataChgUser");

/*
        String sysCorpId=GlobalInfo.getCurrentInstance().getCorpId();
*/
        String sysDepartId =GlobalInfo.getCurrentInstance().getGroupId();
        String sysTlrno = GlobalInfo.getCurrentInstance().getTlrno();

        String hql = "from MbtSendUserManage where sysTlrno= ?  and sysDepartId=? ";
        List<MbtSendUserManage> listExMap;
        try {
            listExMap = ROOTDAOUtils.getROOTDAO().queryByQL2List(hql, new Object[] {sysTlrno,sysDepartId}, null);
            if(listExMap.size()<=0) {
                updateReturnBean.setParameter("isOptSucc", "false");
                return updateReturnBean;
            }
        } catch (CommonException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return updateReturnBean;
        }
        //2.保存赋值数据状态（待绑定）、密码修改时间（系统时间）、管理状态（待绑定）
        String  time1=listExMap.get(0).get().get("associatedUserId");
        String  time2=listExMap.get(0).get().get("associatedUserPassword");

        recordMap.put("userCode",time1);

        recordMap.put("passWord",time2);

        String dataProviderOrgCode= recordMap.get("dataProviderOrgCode");
       if (correctState.equals("4") || correctState.equals("6") ){
           PersonalObjService personalObjService=new PersonalObjService();
           Map<String,String> fileStr= personalObjService.shengchengfiles(recordMap,toCheckInf,"G107.ftl");
           ConnectWebservices connectWebservices=new ConnectWebservices();

/*
           connectWebservices.sendPQuery();
*/
           boolean result=personalObjService.psObjCorrectResultQueryReq("");
           if (result){
               recordMap.put("correctState","7");
               oc.setAttribute(PersonalObjAlterService.CMD, PersonalObjAlterService.CMD_MOD);
               mapToObject(toCheckInf, recordMap);
               oc.setAttribute(PersonalObjAlterService.IN_PARAM, toCheckInf);
               OPCaller.call(PersonalObjAlterService.ID , oc);
               updateReturnBean.setParameter("isOptSucc", "true");


           }else {
               recordMap.put("correctState","6");
               oc.setAttribute(PersonalObjAlterService.CMD, PersonalObjAlterService.CMD_MOD);
               mapToObject(toCheckInf, recordMap);
               oc.setAttribute(PersonalObjAlterService.IN_PARAM, toCheckInf);
               OPCaller.call(PersonalObjAlterService.ID , oc);
               updateReturnBean.setParameter("isOptSucc", "true");
           }
        updateReturnBean.setParameter("isOptSucc", "true");

       } else{
           updateReturnBean.setParameter("isOptSucc", "true");
       }

        return updateReturnBean;
    }
}
