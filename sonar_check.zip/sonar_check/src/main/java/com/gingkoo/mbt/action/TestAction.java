package com.gingkoo.mbt.action;

import javax.servlet.http.HttpServletRequest;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gingkoo.mbt.service.MbtResStoreService;
import com.gingkoo.mbt.util.XmlParseUtil;

@Controller("mbtTest")
public class TestAction {
	@Autowired
	MbtResStoreService mbtResStoreService;
	
	@RequestMapping("/test/MbtResPhrase")
	public String testMbtResPhrase(HttpServletRequest request) {
		Document document;
		int result=0;
		try {
			document = XmlParseUtil.loadDocumentByPath("/Users/vettle/Documents/gf4jupdate/mbt/src/main/resources/templete/temp/101.xml");
			System.out.println(document.asXML());
			result = mbtResStoreService.saveResponse("101","53a5b97e8bc043198a9ba561441be03d",document.asXML());
		} catch (DocumentException e) {
			e.printStackTrace();
		}
		return null;
	}
}
