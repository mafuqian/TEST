package com.gingkoo.mbt.action;


import java.sql.BatchUpdateException;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.common.validator.App;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.mbt.util.ExpCommUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.orm.entity.Mbt610;

public class Mbt610SaveAction extends WebAlterAction {

	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
			throws AppException {
		// TODO Auto-generated method stub
//        Throwable a;

        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResult().containsKey("Mat_610_Bas_ds") ? multiUpdateResultBean.getUpdateResultBeanByID("Mat_610_Bas_ds") : multiUpdateResultBean.getUpdateResultBeanByID("Mat_610_Bas_2007_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
/*        if("failed".equals(validateFields(resultBean, returnBean))){
            return returnBean;
        }*/
        if(StringUtils.isEmpty(recordMap.get("dataId")) || StringUtils.isEmpty(recordMap.get("bInfRecType"))){
            recordMap.put("bInfRecType", "610");
        }
    //    process(resultBean, Mbt610.class);
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");

        ExpCommUtils.process(resultBean,Mbt610.class,mbtCommSaveService);
//    try{
//        mbtCommSaveService.process(resultBean,Mbt610.class);
//    }catch (Exception e){
//            if (e instanceof DataIntegrityViolationException){
//              String msg =  ((DataIntegrityViolationException) e).getRootCause().getMessage();
//                throw new AppException("当前数据中的唯一标识字段已存在，错误信息："+msg);
//
//            }else{
//                throw new AppException(e.getMessage());
//
//            }
//
//
//    }
        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("dataId", mbtCommSaveService.getDataId());

        return returnBean;
	}

}
