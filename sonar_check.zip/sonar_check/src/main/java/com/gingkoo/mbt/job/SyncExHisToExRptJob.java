package com.gingkoo.mbt.job;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.orm.entity.MbtDataSyncInfoCfg;

@Component("SyncExHisToExRptJob")
public class SyncExHisToExRptJob {
	private static final Log logger = LogFactory.getLog(SyncExHisToExRptJob.class);

	JobResult jr = new JobResult();
	private static final String DATE_NUMBER_PATTERN = "yyyy-MM-dd";
	private static final String DATE_NUMBER_PATTERN_YYYYMMDD = "yyyyMMdd";

	public Map<String, String> execute() {
		logger.info("===============++++++++++Exec SyncExHisToExRptJob begin++++++++++=============");
		jr.setErrCode("0");
		jr.setErrMsg("OK");
		try {

			ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
			// GlobalInfo GI = GlobalInfo.getCurrentInstance();
			Date date = new Date();
			String dataDate = (new SimpleDateFormat("yyyyMMdd")).format(date);
			String dataDateTime = (new SimpleDateFormat("yyyyMMddHHmmss")).format(date);

			Map<String, String> map = new HashMap<String, String>();
			Object[] ob = new Object[1];
			String hqlcfg = "";
			hqlcfg = "from MbtDataSyncInfoCfg where rsv1 ='ExRpt'";

			List<MbtDataSyncInfoCfg> listcfg = rootdao.queryByQL2List(hqlcfg, null, null);
			
			for(int m=0;m<listcfg.size();m++) {
				MbtDataSyncInfoCfg cfg = listcfg.get(m);
				String data_desc = cfg.getDataDesc();
				if (null != data_desc || !"".equals(data_desc)) {
					String[] arr = data_desc.split(";");
					
					for (int h = 1; h < arr.length; h++) {
						String[] table_dtl = arr[h].split(",");
						//String table_name1 = table_dtl[0];
						String table_name_tmp1 = table_dtl[1];
						/*String sql1 = " from " + table_name1 + " where rsv2 = '" + dataDate + "'";
						ROOTDAOUtils.getROOTDAO().delete(sql1);*/
						
						String sql2 = " from " + table_name_tmp1 + " where rptDate = '" + dataDate + "'";
						ROOTDAOUtils.getROOTDAO().delete(sql2);
					}
					
				}
				
			}
			if (listcfg.size() > 0) {
				for (int i = 0; i < listcfg.size(); i++) {

					MbtDataSyncInfoCfg cfg = listcfg.get(i);
					String data_desc = cfg.getDataDesc();
					if (null != data_desc || !"".equals(data_desc)) {
						String[] arr = data_desc.split(";");
						String pdataId = null;
						String page = "";
						if (arr.length > 1) {
							page = arr[0];
						}
						String[] table = arr[1].split(",");
						String table_name = table[0];
						String table_name_tmp = table[1];
						String qry_hql = "from " + table_name + " where dataStatus = '23'";
						List l = rootdao.queryByQL2List(qry_hql, null, null);
						for (int k = 0; k < l.size(); k++) {
							String id = UuidHelper.getCleanUuid();
							String path = page + "." + table_name;
							String path1 = page + "." + table_name_tmp;
							Class forName = Class.forName(path);
							Class forName1 = Class.forName(path1);
							Object tmp = forName.newInstance();
							Object obj = forName1.newInstance();
							tmp = l.get(k);
							Map oldmap = objectToMap(tmp);

							pdataId = (String) oldmap.get("dataId");
							/**
							 * 将原有的dataId值写入odsDataId
							 */
							oldmap.put("odsDataId", oldmap.get("dataId"));

							oldmap.put("dataId", id);
							oldmap.put("primaryKey", id);
							/*String sql = " from " + table_name_tmp + " where rsv1 = '" + oldmap.get("rsv1") + "'";
							ROOTDAOUtils.getROOTDAO().delete(sql);*/
							/**
							 * 将当前日期写入 rptDate
							 */
							oldmap.put("rptDate", dataDate);

							/**
							 * 将当前日期写入 rptTime
							 */
							oldmap.put("rptTime", dataDateTime);

							oldmap.put("dataStatus", "24");

							mapToObject(obj, oldmap, "");
							ROOTDAOUtils.getROOTDAO().save(obj);
							
							System.out.println("====>"+obj);

							for (int h = 2; h < arr.length; h++) {
								
								String[] table_dtl = arr[h].split(",");
								String table_name1 = table_dtl[0];
								String table_name_tmp1 = table_dtl[1];
								String path2 = page + "." + table_name1;
								String path3 = page + "." + table_name_tmp1;
								forName = Class.forName(path2);
								forName1 = Class.forName(path3);

								String hql21 = "from " + table_name1 + " where pdataId = ?";
								List list = rootdao.queryByQL2List(hql21, new Object[] {pdataId}, null);
								for (int m = 0; m < list.size(); m++) {
									oldmap = new HashMap();
									tmp = forName.newInstance();
									obj = forName1.newInstance();
									tmp = list.get(m);
									oldmap = objectToMap(tmp);

									String str = UuidHelper.getCleanUuid();
									
									oldmap.put("odsDataId", oldmap.get("dataId"));
//									oldmap.put("ODS_DATA_ID", oldmap.get("pdataId"));

									oldmap.put("dataId", str);
									oldmap.put("primaryKey", str);
									oldmap.put("pdataId", id);
									/*String sql1 = " from " + table_name_tmp1 + " where rsv1 = '" + oldmap.get("rsv1") + "'";
									ROOTDAOUtils.getROOTDAO().delete(sql1);*/
									/**
									 * 将当前日期写入 rptDate
									 */
									oldmap.put("rptDate", dataDate);

									/**
									 * 将当前日期写入 rptTime
									 */
									oldmap.put("rptTime", dataDateTime);
									mapToObject(obj, oldmap, "");
									ROOTDAOUtils.getROOTDAO().save(obj);
									System.out.println("----->"+obj);

								}
							}

						}
					}
				}
			}

		} catch (Exception arg6) {
			arg6.printStackTrace();
			logger.info("操作失败，错误信息：" + arg6.getMessage());
			jr.setErrCode("E");
			jr.setErrMsg("操作失败，错误信息：" + arg6.getMessage());
			return jr.getMap();
		}

		logger.info("===============++++++++++Exec SyncExHisToExRptJob end++++++++++=============");
		return jr.getMap();
	}

	public Map<String, String> objectToMap(Object obj) throws Exception {
		if (obj == null)
			return null;

		Map<String, String> map = new HashMap<String, String>();

		BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
		PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
		for (PropertyDescriptor property : propertyDescriptors) {
			String key = property.getName();
			if (key.compareToIgnoreCase("class") == 0) {
				continue;
			}
			Method getter = property.getReadMethod();
			String value = getter != null ? getter.invoke(obj) + "" : null;
			map.put(key, value);
		}

		return map;
	}

	public static Set<String> mapToObject(Object object, Map map, String str)
			throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
		Iterator iterator = map.keySet().iterator();
		Set<String> nullSet = new HashSet<>();
		while (iterator.hasNext()) {
			String fieldName = (String) iterator.next();
			Object o = getNestedProperty(object, fieldName);
			PropertyDescriptor desc = PropertyUtils.getPropertyDescriptor(o, fieldName);
			if (desc == null)
				continue;
			Class cl = desc.getPropertyType();

			Object value = map.get(fieldName);
			if (value == null || (!String.class.isAssignableFrom(cl) && value instanceof String
					&& StringUtils.isEmpty((String) value))) {
				nullSet.add(fieldName);
				PropertyUtils.setProperty(o, fieldName, "null");
				continue;
			}

			if (Date.class.isAssignableFrom(cl)) {
				Long time = convert(value);
				if (time != null)
					BeanUtils.setProperty(o, fieldName, new Date(time));
				else {
					/*
					 * BeanUtils.setProperty(o, propertyName, new java.util.Date(0L));
					 */
					/*
					 * modify by shen_antonio 20080918 BeanUtils.setProperty(o, fieldName,
					 * defaultDate); .
					 */
				}
			} else if (Calendar.class.isAssignableFrom(cl)) {
				Long time = convert(value);
				Calendar calendar = Calendar.getInstance();
				if (time != null) {
					calendar.setTimeInMillis(time);
					BeanUtils.setProperty(o, fieldName, calendar);
				} else {
					// calendar.setTimeInMillis(0L);
					/*
					 * modify by shen_antonio 20080918
					 * calendar.setTimeInMillis(defaultDate.getTime()); BeanUtils.setProperty(o,
					 * fieldName, calendar); .
					 */
				}
			} else if (BigDecimal.class.isAssignableFrom(cl)) {
				String v = (String) value;
				if (!StringUtils.isEmpty(v)) {
					BeanUtils.setProperty(o, fieldName, v);
				}
			} else {
				String v = (String) value;
				// 杩囨护"|"浠ュ強鍥炶溅鎹㈣绗﹀彿銆�
				v = v.replace('|', ' ');
				v = v.replaceAll("\n|\r\n|\r|\u0085|\u2028|\u2029", "^p");
				if ("null".equals(v)) {
					v = "";
				}
				BeanUtils.setProperty(o, fieldName, v);
			}

		}
		return nullSet;
	}

	public static Long convert(Object arg1) {

		String p = (String) arg1;
		if (p == null || p.trim().length() == 0) {
			return null;
		}
		SimpleDateFormat df = null;
		try {
			if (p.indexOf("-") > 0) {
				df = new SimpleDateFormat(DATE_NUMBER_PATTERN);
			} else {
				df = new SimpleDateFormat(DATE_NUMBER_PATTERN_YYYYMMDD);
			}
			return new Long(df.parse(p.trim()).getTime());
		} catch (Exception e) {
			return null;
		}
	}

	private static Object getNestedProperty(Object o, String propertyDesc)
			throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
		Object value = o;
		String properties[] = StringUtils.split(propertyDesc, ".");
		for (int i = 0; i < properties.length; i++) {
			if (properties.length == 1)
				break;
			String property = properties[i];
			value = PropertyUtils.getProperty(value, property);
			if (i + 2 == properties.length)
				break;
		}

		return value;
	}

}