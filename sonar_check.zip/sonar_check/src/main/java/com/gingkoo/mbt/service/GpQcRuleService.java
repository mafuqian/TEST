package com.gingkoo.mbt.service;

import com.gingkoo.common.validator.constants.MbtValidatorRules;
import com.gingkoo.data.qc.gf4j.entity.GpQcRule;
import com.gingkoo.data.qc.gf4j.entity.GpQcRuleMap;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.BaseService;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.gf4j2.framework.util.ExceptionUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Component
public class GpQcRuleService extends BaseService {

    @Autowired
    private ROOTDAO rootdao;

    @Autowired
    private MbtValidatorRules ruleSets;

    public static final String ID = "gpQcRuleService";
    public static final String CMD = "CMD";
    public static final String CMD_INSERT = "CMD_INSERT";
    public static final String CMD_UPDATE = "CMD_UPDATE";
    public static final String CMD_DELETE = "CMD_DEL";
    public static final String IN_PARAM = "IN_PARAM";
    public static final String MOD_SCOPE = "MOD_SCOPE";
    private static final Log logger = LogFactory.getLogger(GpQcRuleService.class);


    @Override
    public void beforeProc(ServiceContext context) throws CommonException {
    }

    @Override
    public void execute(ServiceContext context) throws CommonException {

        String cmd = (String) context.getAttribute(CMD);
        GpQcRule rule = (GpQcRule) context.getAttribute("IN_PARAM");
        Map<String, String> map = (Map<String, String>) context.getAttribute("IN_PARAM_1");
        GlobalInfo gi = GlobalInfo.getCurrentInstance();

        if (CMD_INSERT.equals(cmd)) {
            String funcid = map.get("funcid");
            if(StringUtils.isBlank(funcid)){
                ExceptionUtil.throwCommonException("菜单名称为空。","新增失败。");
            }
            String dataId = getDataId(funcid,rule);
            rule.setDataId(dataId);
            setGpQcRuleCrtInfo(rule,gi);
            rootdao.save(rule);
        } else if (CMD_UPDATE.equals(cmd)) {
            String str = queryRuleMapStr(rule.getDataId());
            context.setAttribute(MOD_SCOPE,str);
            setGpQcRuleChgInfo(rule,gi);
            rootdao.saveOrUpdate(rule);
        } else if (CMD_DELETE.equals(cmd)) {
            checkDeleteRule(rule.getDataId());
            rootdao.delete(rule);
        }

        try {
            ruleSets.resetAllRuleSet();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    /**
     * 新增获取dataId
     * @param funcid
     * @param rule
     * @return
     * @throws CommonException
     */
    public String getDataId(String funcid, GpQcRule rule) throws CommonException {
        String bankBasic = "BANK-BASIC-"+funcid+"-"+rule.getField();
        String dataId = bankBasic;
        int i = 1 ;
        while (true){
            List<GpQcRule> list = queryRule(dataId);
            if(list.size()==0){
                break;
            }
            dataId = bankBasic+"-"+i;
            i++;
        }
        return dataId;
    }


    /**
     * 查询rule校验规则。
     *
     * @param ruleId
     * @throws CommonException
     */
    public List<GpQcRule> queryRule(String ruleId) throws CommonException {
        List<GpQcRule> list = new ArrayList<>();
        StringBuilder hql = new StringBuilder();
        hql.append(" from GpQcRule b where 1=1");
        if ((ruleId != null) && (!"".equals(ruleId))) {
            hql.append(" and b.dataId = '").append(ruleId).append("' ");
        }
        list = rootdao.queryByQL2List(hql.toString());
        return list;
    }



    /**
     * 检查校验影响范围。
     *
     * @param ruleId
     * @throws CommonException
     */
    public String queryRuleMapStr(String ruleId) throws CommonException {
        List<GpQcRuleMap> list = new ArrayList<>();
        StringBuilder hql = new StringBuilder();
        hql.append(" from GpQcRuleMap b where 1=1");
        if ((ruleId != null) && (!"".equals(ruleId))) {
            hql.append(" and b.ruleId = '").append(ruleId).append("' ");
        }
        list = rootdao.queryByQL2List(hql.toString());
        StringBuilder stringBuilder = new StringBuilder();
        if(list.size()>0){
            for(GpQcRuleMap map : list){
                stringBuilder.append(map.getRuleSetId()).append("; ");
            }
        }
        return stringBuilder.toString();
    }




    /**
     * 删除校验规则时，检查数据是否在校验集合中存在使用。
     *
     * @param ruleId
     * @throws CommonException
     */
    public void checkDeleteRule(String ruleId) throws CommonException {
        String str = queryRuleMapStr(ruleId);
        if (StringUtils.isNotBlank(str)) {
            ExceptionUtil.throwCommonException("当前规则存在于"+str+"的规则集中，请先删除"+str+"规则集与当前规则的关联关系。", "删除失败。");
        }
    }


    /**
     * 补充新增信息。
     * @param rule
     * @param gl
     */
    public void setGpQcRuleCrtInfo(GpQcRule rule, GlobalInfo gl ) {
        rule.setDataDate(DateUtil.get8Date());
        rule.setCorpId(gl.getCorpId());
        rule.setOrgId(gl.getBrno());
        rule.setDataCrtUser(gl.getTlrno());
        rule.setDataCrtDate(DateUtil.get8Date());
        rule.setDataCrtTime(DateUtil.get14Date());
        setGpQcRuleChgInfo(rule, gl);
    }

    /**
     * 补充更新信息
     * @param rule
     * @param gl
     */
    public void setGpQcRuleChgInfo(GpQcRule rule, GlobalInfo gl ) {
        rule.setDataChgUser(gl.getTlrno());
        rule.setDataChgDate(DateUtil.get8Date());
        rule.setDataChgTime(DateUtil.get14Date());
    }



    @Override
    public void afterProc(ServiceContext context) throws CommonException {
    }
}