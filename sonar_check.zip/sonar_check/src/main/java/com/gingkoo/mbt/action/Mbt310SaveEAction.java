package com.gingkoo.mbt.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.mbt.util.DoThrowExpection;
import com.gingkoo.mbt.util.ExpCommUtils;
import com.gingkoo.orm.entity.Mbt310C;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.orm.entity.Mbt310E;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Mbt310SaveEAction extends WebAlterAction {
	@Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mat_310_Oth_E_ds");
        //process(resultBean, Mbt310E.class);
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");

       if(!(resultBean.getParamMap().get("opr").equals("del"))){
           //报送主要组成人员信息段时，法定代表人/非法人组织负责人、董事长、监事长各自只能报一个人。
           //报送主要组成人员信息段时，董事长、监事长不能是同一个人。
           List<Map<String,String>> tmp = resultBean.getTotalList();
           tmp= tmp.stream().filter(s->!(s.get("opr").equals("del"))).collect(Collectors.toList());

           for (int i = 0; i < tmp.size()-1; i++) {
               Map<String,String> tmp310 = tmp.get(i);
               for (int j=i+1;j<tmp.size();j++){
                   Map<String,String> tmp3101 = tmp.get(j);
                   if (tmp310.get("mmbPstn").equals(tmp3101.get("mmbPstn"))){
                       //法定代表人/非法人组织负责人 1
                       if (tmp3101.get("mmbPstn").equals("1")){
                           DoThrowExpection.doThrow( new AppException("保存失败，法定代表人/非法人组织负责人只能有一个人，请重新输入后提交！"));
                       }else if (tmp3101.get("mmbPstn").equals("4")){
                           //董事长
                           DoThrowExpection.doThrow( new AppException("保存失败，董事长只能有一个人，请重新输入后提交！"));
                       }else  if (tmp3101.get("mmbPstn").equals("5")){
                           //监事长
                           DoThrowExpection.doThrow( new AppException("保存失败，监事长只能有一个人，请重新输入后提交！"));
                       }
                   }
                   if (tmp310.get("mmbPstn").equals("4") &&tmp3101.get("mmbPstn").equals("5") && tmp310.get("mmbIdNum").equals(tmp3101.get("mmbIdNum") )&& tmp310.get("mmbIdType").equals(tmp3101.get("mmbIdType"))){
                       DoThrowExpection.doThrow( new AppException("保存失败，董事长、监事长不能是同一个人，请重新输入后提交！"));
                   }else if (tmp310.get("mmbPstn").equals("5") &&tmp3101.get("mmbPstn").equals("4") && tmp310.get("mmbIdNum").equals(tmp3101.get("mmbIdNum"))&& tmp310.get("mmbIdType").equals(tmp3101.get("mmbIdType"))){
                       DoThrowExpection.doThrow( new AppException("保存失败，董事长、监事长不能是同一个人，请重新输入后提交！"));
                   }
               }
           }
       }
        ExpCommUtils.batchProcess(resultBean,Mbt310E.class,mbtCommSaveService);

//        mbtCommSaveService.batchprocess(resultBean, Mbt310E.class);
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }
}
