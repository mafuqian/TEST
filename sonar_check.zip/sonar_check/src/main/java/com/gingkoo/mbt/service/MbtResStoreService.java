package com.gingkoo.mbt.service;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.springframework.stereotype.Service;

import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.config.database.base.MyHibernateTemplate;
import com.gingkoo.mbt.util.FileWriteUtil;
import com.gingkoo.mbt.util.MapToObject;
import com.gingkoo.mbt.util.OrderedProperties;
import com.gingkoo.mbt.util.XmlParseUtil;
import com.gingkoo.orm.entity.ToCheckInf;
import com.gingkoo.orm.entity.bean.DataElement;
import com.gingkoo.orm.entity.bean.FbInf;
import com.gingkoo.orm.entity.bean.ResElement;
import com.gingkoo.orm.entity.bean.UnitElement;

@Service
public class MbtResStoreService {
	private static Log logger = LogFactory.getLogger(MbtResStoreService.class);

	@Autowired
	private MyHibernateTemplate template;

	static Map<String, Properties> configProperties = new HashMap<String, Properties>();

	static {
		String templetePath = "templete/response";
		ResourceLoader resourceLoader = new DefaultResourceLoader();
		Resource[] resources;
		try {
			resources = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
					.getResources("classpath:" + templetePath + "/*.properties");
			for (Resource resource : resources) {
				OrderedProperties prop = new OrderedProperties();
				prop.load(new InputStreamReader(resource.getInputStream(), "UTF-8"));
				String fileName = resource.getFilename();
				String key = fileName.substring(0, fileName.lastIndexOf("."));
				configProperties.put(key, prop);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// @Transactional
	public int saveResponse(String businessCode, String businessId, String response) {
		// 按数据单元分组
		List<UnitElement> dataUnit = new ArrayList<UnitElement>();
		List<DataElement> dataEles = new ArrayList<DataElement>();
		int result = 0;
		if (configProperties.isEmpty()) {
			logger.error("无法加载响应处理配置！");
			return result;
		}
		Properties props = configProperties.get(businessCode);
		if (props == null) {
			logger.error("[" + businessCode + "]的响应处理配置不存在！");
			return result;
		}
		try {
			Document document = XmlParseUtil.loadDocumentByText(response);
			Iterator<String> it = props.stringPropertyNames().iterator();
			// Iterator<Entry<Object, Object>> it = props.entrySet().iterator();

			loop: while (it.hasNext()) {
				String key = it.next();

				Node node = document.selectSingleNode(key);
				if (node == null) {
					logger.error("响应信息不包含配置[" + key + "]！");
					continue;
				}

				String value = props.getProperty(key);
				String[] valueSp = value.split(":");
				String type = valueSp[0];
				String table = valueSp[1];
				// String relation = valueSp[2];

				List<String> fields = new ArrayList<String>();
				List<String> values = new ArrayList<String>();

				if (type.equals("UNIT")) {
					UnitElement resEle = new UnitElement();
					List<String> keys = new ArrayList<String>();
					keys.add(key);
					resEle.setKeys(keys);
					resEle.setType(type);
					resEle.setTable(table);
					// resEle.setRelation(relation);
					resEle.setElement((Element) node);
					resEle.setColums(fields);
					resEle.setValues(values);

					resEle.setGuid(UUID.randomUUID().toString().replace("-", ""));
					resEle.setParantid(businessId);

					resEle = mergeUnitElemet(resEle, dataUnit);

					continue;
				} else {
					DataElement resEle = new DataElement();
					resEle.setKey(key);
					resEle.setType(type);
					resEle.setTable(table);
					// resEle.setRelation(relation);
					resEle.setElement((Element) node);
					resEle.setColums(fields);
					resEle.setValues(values);

					List<Element> xmlColums = ((Element) node).elements();
					boolean subEle = false;
					for (Element colum : xmlColums) {
						List<Element> subEles = colum.elements();
						if (subEles.isEmpty()) {
							String columName = colum.getName();
							String columValue = colum.getText();
							fields.add(columName);
							values.add(columValue);
						} else {
							subEle = true;
							continue;
						}
					}

					UnitElement unitEle = getUnitElemet(key, dataUnit);
					if (unitEle == null) {
						resEle.setGuid(UUID.randomUUID().toString().replace("-", ""));
						resEle.setParantid(businessId);
						dataEles.add(resEle);
						continue;
					}

					if (unitEle.getTable().equals(resEle.getTable())) {
						List<String> unitColums = unitEle.getColums();
						if (unitColums == null) {
							unitColums = new ArrayList<String>();
						}
						unitColums.addAll(resEle.getColums());

						List<String> unitValues = unitEle.getValues();
						if (unitValues == null) {
							unitValues = new ArrayList<String>();
						}
						unitValues.addAll(resEle.getValues());
					} else {
						resEle.setGuid(UUID.randomUUID().toString().replace("-", ""));
						resEle.setParantid(unitEle.getGuid());
						// 没有子数据
						if (subEle) {
							dataEles.add(resEle);
						} else {
							mergeDataElemetList(resEle, dataEles);
						}
					}
				}
			}

			List<ResElement> sqlEles = new ArrayList<ResElement>();
			sqlEles.addAll(dataUnit);
			sqlEles.addAll(dataEles);

			for (ResElement data : sqlEles) {
				if (data.getColums().isEmpty()) {
					continue;
				}
				String columStr = "";
				String positionStr = "";
				for (String field : data.getColums()) {
					columStr += field + ",";
					positionStr += "?,";
				}
				String sql = "insert into MBT_" + data.getTable();
				sql += " (";
				sql += columStr;
				sql += "DATA_ID,PDATA_ID";
				sql += ")";
				sql += " Values ";
				sql += "(";
				sql += positionStr;
				sql += "'" + data.getGuid() + "','" + data.getParantid() + "'";
				sql += ")";
				System.out.println(sql + ":" + data.getValues());
				template.bulkUpdateBySql(sql, data.getValues());
			}
		} catch (DocumentException e) {
			e.printStackTrace();
			logger.error("解析响应异常！" + e.getMessage());
		}
		result = 1;
		return result;
	}
	
	public Map<String,Object> getMapByCodeAndFile(File resFile) {
		Map<String,Object> result = new HashMap<String,Object>();
		try {
			FileInputStream fis = new FileInputStream(resFile);
	        InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
	        BufferedReader br = new BufferedReader(isr);
	        String body = "";
	        String line = "";
	        int i=0;
	        while ((line = br.readLine()) != null) {
	        	if(i!=0) {
	        		body = body+line;
	        	}
	        	i++;
	        }
	        br.close();
	        isr.close();
	        fis.close();
			Document document = XmlParseUtil.loadDocumentByText(body);

			result = XmlParseUtil.Dom2Map(document);
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
			logger.error("解析响应异常！" + e.getMessage());
		}
		return result;
	}
	
	public Map<String,Object> getMapByCodeAndXmlStr(String xmlStr) {
		Map<String,Object> result = new HashMap<String,Object>();
		try {
			Document document = XmlParseUtil.loadDocumentByText(xmlStr);
			result = XmlParseUtil.Dom2Map(document);
		} catch (DocumentException e) {
			e.printStackTrace();
			logger.error("解析响应异常！" + e.getMessage());
		}
		return result;
	}
	
	public Map<String,Object> getMapByCodeAndXmlWithHeader(String xmlStr) {
		Map<String,Object> result = new HashMap<String,Object>();
		try {
			ByteArrayInputStream is=new ByteArrayInputStream(xmlStr.getBytes());
			BufferedReader br=new BufferedReader(new InputStreamReader(is));
			String body = "";
	        String line = "";
	        int i=0;
	        while ((line = br.readLine()) != null) {
	        	if(i!=0) {
	        		body = body+line;
	        	}
	        	i++;
	        }
	        br.close();
	        is.close();
			Document document = XmlParseUtil.loadDocumentByText(body);
			result = XmlParseUtil.Dom2Map(document);
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
			logger.error("解析响应异常！" + e.getMessage());
		}
		return result;
	}

	public FbInf getFbInfByFile(File resFile) {
		FbInf result = new FbInf();
		String name = resFile.getName();
		result.setName(name);
		name = name.replace(".txt", "");
		result.setFbFlag(name.substring(name.length()-1, name.length()));
		result.setRtpName(name.substring(0, name.length()-1)+"0.txt");
		result.setType(name.substring(22, 25));
		try {
			FileInputStream fis = new FileInputStream(resFile);
	        InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
	        BufferedReader br = new BufferedReader(isr);
	        String header = "";
	        String body = "";
	        String line = "";
	        int i=0;
	        while ((line = br.readLine()) != null) {
	        	if(i==0) {
	        		header = line;
	        	}else {
	        		body = body+line;
	        	}
	        	i++;
	        }
	        br.close();
	        isr.close();
	        fis.close();
	        
	        result.setHeader(header);
	        result.setBody(body);
	        if("".equals(body) || null ==body ) {
	        	return result;
	        }
	        
			Document document = XmlParseUtil.loadDocumentByText(body);
			
			Node fbErrNumNode = document.selectSingleNode("/Document/FbInf/FbErrNum");
			String fbErrNum = fbErrNumNode.getText();
			result.setFbErrNum(fbErrNum);
			
			Node errRecIdNode = document.selectSingleNode("/Document/FbInf/ErrRecId");
			if( null != errRecIdNode ) {
				String errRecId = errRecIdNode.getText();
				result.setErrRecId(errRecId);
			}
			
			
			Node errRecNode = document.selectSingleNode("/Document/FbInf/ErrRec");
			if( null != errRecNode ) {
				String errRec = errRecNode.getText();
				result.setErrRec(errRec);
			}
			
			
			List<Element> errInfEles = (List<Element>)document.selectNodes("/Document/FbInf/ErrInf");
			
			List<FbInf.ErrInf> errInfs = new ArrayList<FbInf.ErrInf>();
			for(Element errInfEle:errInfEles) {
				String fbCode = errInfEle.elementText("FbCode");
				String fbMsg = errInfEle.elementText("FbMsg");
				
				FbInf.ErrInf errInf = new FbInf().new ErrInf();
				errInf.setFbCode(fbCode);
				errInf.setFbMsg(fbMsg);
				errInfs.add(errInf);
			}
			result.setErrInfs(errInfs);
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	UnitElement mergeUnitElemet(UnitElement resEle, List<UnitElement> dataUnit) {
		for (UnitElement data : dataUnit) {
			if (data.getTable().equals(resEle.getTable())) {
				data.getKeys().addAll(resEle.getKeys());
				return data;
			}
		}
		dataUnit.add(resEle);
		return resEle;
	}

	// 判断是否同一单元的依据由xpath改为表名
	UnitElement getUnitElemet(String key, List<UnitElement> dataUnit) {
		UnitElement resEle = null;
		for (UnitElement data : dataUnit) {
			for (String unitKey : data.getKeys()) {
				if (key.contains(unitKey)) {
					return data;
				}
			}
		}
		return resEle;
	}

	// 判断是否同一单元的依据由xpath改为表名
	List<DataElement> mergeDataElemetList(DataElement dataEle, List<DataElement> dataEles) {
		DataElement removeData = null;
		// 上级列数据
		for (DataElement data : dataEles) {
			if (dataEle.getKey().contains(data.getKey()) && dataEle.getTable().equals(data.getTable())) {
				removeData = data;
				break;
			}
		}
		if (removeData == null) {
			return dataEles;
		}
		// 重复的生成多条数据
		Map<String, List<String>> dataCol = new HashMap<String, List<String>>();
		List<String> curCols = dataEle.getColums();
		List<String> curVals = dataEle.getValues();
		for (int i = 0; i < curCols.size(); i++) {
			String colum = curCols.get(i);
			String value = curVals.get(i);
			if (!dataCol.containsKey(colum)) {
				List<String> valueList = new ArrayList<String>();
				valueList.add(value);
				dataCol.put(colum, valueList);
			} else {
				List<String> valueList = dataCol.get(colum);
				valueList.add(value);
				dataCol.put(colum, valueList);
			}
		}
		// 获取重复数据条数
		int maxEleSize = 0;
		for (Map.Entry<String, List<String>> col : dataCol.entrySet()) {
			List<String> values = col.getValue();
			if (values.size() > maxEleSize) {
				maxEleSize = values.size();
			}
		}
		// 组装数据对象
		for (int i = 0; i < maxEleSize; i++) {
			DataElement dataEleC = (DataElement) removeData.clone();
			for (Map.Entry<String, List<String>> col : dataCol.entrySet()) {
				dataEleC.getColums().add(col.getKey());
				dataEleC.getValues().add(col.getValue().get(i));
			}
			dataEles.add(dataEleC);
		}
		dataEles.remove(removeData);
		return dataEles;
	}
	
	
	public void getG101Info(String xmlConent) {/*
		
		try {
			FbInf result = new FbInf();
			ByteArrayInputStream is=new ByteArrayInputStream(xmlConent.getBytes("UTF-8"));
			BufferedReader br=new BufferedReader(new InputStreamReader(is));
	        String header = "";
	        String body = "";
	        String line = "";
	        int i=0;
	        while ((line = br.readLine()) != null) {
	        	if(i==0) {
	        		header = line;
	        	}else {
	        		body = body+line;
	        	}
	        	i++;
	        }
	        br.close();
	        is.close();
	        
	        result.setHeader(header);
	        result.setBody(body);
	        if("".equals(body) || null ==body ) {
	        	
	        }
	        
			Document document = XmlParseUtil.loadDocumentByText(body);
			
			Node fbErrNumNode = document.selectSingleNode("/Document/FbInf/FbErrNum");
			String fbErrNum = fbErrNumNode.getText();
			result.setFbErrNum(fbErrNum);
			
			Node errRecIdNode = document.selectSingleNode("/Document/FbInf/ErrRecId");
			if( null != errRecIdNode ) {
				String errRecId = errRecIdNode.getText();
				result.setErrRecId(errRecId);
			}
			
			
			Node errRecNode = document.selectSingleNode("/Document/FbInf/ErrRec");
			if( null != errRecNode ) {
				String errRec = errRecNode.getText();
				result.setErrRec(errRec);
			}
			
			
			List<Element> errInfEles = (List<Element>)document.selectNodes("/Document/FbInf/ErrInf");
			
			List<FbInf.ErrInf> errInfs = new ArrayList<FbInf.ErrInf>();
			for(Element errInfEle:errInfEles) {
				String fbCode = errInfEle.elementText("FbCode");
				String fbMsg = errInfEle.elementText("FbMsg");
				
				FbInf.ErrInf errInf = new FbInf().new ErrInf();
				errInf.setFbCode(fbCode);
				errInf.setFbMsg(fbMsg);
				errInfs.add(errInf);
			}
			result.setErrInfs(errInfs);
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		}
		return result;
	*/}

	public static void main(String[] args) {
		/*Document document;
		try {
			document = XmlParseUtil.loadDocumentByPath(
					"/Users/vettle/Documents/gf4jupdate/mbt/src/main/resources/templete/temp/101.xml");
			System.out.println(document.asXML());
			MbtResStoreService service = new MbtResStoreService();
			service.saveResponse("101", "53a5b97e8bc043198a9ba561441be03d", document.asXML());
		} catch (DocumentException e) {
			e.printStackTrace();
		}*/
		/*File f = new File("/Users/vettle/Documents/gf4j3/mbt/src/main/resources/templete/temp/1234567890123456789012345678901234.xml");
		MbtResStoreService service = new MbtResStoreService();
		FbInf fbInf = service.getFbInfByFile(f);
		System.out.println(fbInf);*/
	/*		
		File f = new File("D:\\tmp\\mbtfile\\feedback\\20190826\\20190827\\20190827\\113322331133662019082611000012.txt");
		MbtResStoreService service = new MbtResStoreService();
		FbInf fbInf = service.getFbInfByFile(f);
		System.out.println(fbInf.getErrInfs().get(0).getFbCode());*/
		MbtResStoreService service = new MbtResStoreService();
		String xml = "B2.0.0AH000000000001BF00000000000120160301123118G1022016030100000001000000000000\n" + 
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
				"<Document>"+
				"<Msg>\n" + 
				"<ResultCode>AAA000</ResultCode>\n" + 
				"<ResultDesc>处理成功</ResultDesc> <BeginDate>2016-01-01</BeginDate> <EndDate>2016-03-01</EndDate> <ToCheckNm>2</ToCheckNm> <ToCheckInf> <ObjCheckID>01234567890123456789</ObjCheckID> <ObjCheckNum>100001</ObjCheckNum> <CheckBeginDate>2016-07-05</CheckBeginDate> <Name>李四</Name>\n" + 
				"<IDType>10</IDType> <IDNum>130429198904571522</IDNum> <PhoneNum>18088889999</PhoneNum> <ObjItemInf>sfslieoiowiofwopefoowellf;lwe;lf</ObjItemInf> <ObjItemDesc>未逾期</ObjItemDesc> <DataProviderOrgCode>ABH000000000001</DataProviderOrgCode> <DataOccurOrgCode>ABH00000000010</DataOccurOrgCode> <BusinessCode>ABH0000000001000069287823</BusinessCode> <BusinessType>01</BusinessType> <CheckFinalDate>2016-09-29</CheckFinalDate> <DataOccurDate>2014-09-29</DataOccurDate> <DataOccurAmount>2000</DataOccurAmount> <EnclosureFlag>Y</EnclosureFlag>\n" + 
				"<HistoricalCheckInf> <CheckTime>2016-03-20T10:22:36</CheckTime> <CheckResult>2</CheckResult> <CheckResultDesc>数据无误</CheckResultDesc> <CheckOrgCode>ABH00000000010</CheckOrgCode> <CheckUserCode>zh-jkl</CheckUserCode> <PhoneNum>13931687632</PhoneNum> <CheckAcceptFlag>N</CheckAcceptFlag> <CheckOpinion>建议重新核查</CheckOpinion>\n" + 
				"</HistoricalCheckInf> <HistoricalCheckInf> <CheckTime>2016-04-20T10:22:36</CheckTime> <CheckResult>1</CheckResult> <CheckResultDesc>数据有误</CheckResultDesc> <CheckOrgCode>ABH00000000010</CheckOrgCode> <CheckUserCode>zh-jkl</CheckUserCode> <PhoneNum>13931687632</PhoneNum> <CheckAcceptFlag>N</CheckAcceptFlag> <CheckOpinion>建议重新核查</CheckOpinion></HistoricalCheckInf></ToCheckInf> \n" + 
				"<ToCheckInf> <ObjCheckID>01234567890123456788</ObjCheckID> <ObjCheckNum>200001</ObjCheckNum> <CheckBeginDate>2016-06-05</CheckBeginDate> <Name>张三</Name>\n" + 
				"<IDType>10</IDType> <IDNum>131429198904571522</IDNum> <PhoneNum>18088886666</PhoneNum> <ObjItemInf>sfslieoiowiofwopefoowellf;lwe;lf</ObjItemInf> <ObjItemDesc>未逾期</ObjItemDesc> <DataProviderOrgCode>ABH000000000001</DataProviderOrgCode> <DataOccurOrgCode>ABH00000000010</DataOccurOrgCode> <BusinessCode>ABH0000000001000069287823</BusinessCode> <BusinessType>01</BusinessType> <CheckFinalDate>2016-08-29</CheckFinalDate> <DataOccurDate>2014-08-29</DataOccurDate> <DataOccurAmount>6000</DataOccurAmount> <EnclosureFlag>N</EnclosureFlag> <HistoricalCheckInf> <CheckTime>2016-02-20T10:22:36</CheckTime> <CheckResult>2</CheckResult> <CheckResultDesc>数据无误</CheckResultDesc> <CheckOrgCode>ABH00000000010</CheckOrgCode> <CheckUserCode>zh-jkl</CheckUserCode> <PhoneNum>13931687632</PhoneNum> <CheckAcceptFlag>N</CheckAcceptFlag> <CheckOpinion>建议重新核查</CheckOpinion>\n" + 
				"</HistoricalCheckInf> <HistoricalCheckInf> <CheckTime>2016-05-20T10:22:36</CheckTime> <CheckResult>1</CheckResult> <CheckResultDesc>数据有误</CheckResultDesc> <CheckOrgCode>ABH00000000010</CheckOrgCode> <CheckUserCode>zh-jkl</CheckUserCode> <PhoneNum>13931687632</PhoneNum> <CheckAcceptFlag>N</CheckAcceptFlag> <CheckOpinion>建议重新核查</CheckOpinion></HistoricalCheckInf></ToCheckInf> \n" + 
				"</Msg></Document>";
		
		
		//FileWriteUtil.Write("C://1.xml", xml);
		Map map1 = service.getMapByCodeAndXmlWithHeader(xml);
		System.out.println(map1);
		
		String  ResultDesc =  (String) ((HashMap<Object, Object>) map1.get("Msg")).get("ResultDesc");
		List<HashMap<Object, Object>> list =  (List<HashMap<Object, Object>>) ((HashMap<Object, Object>) map1.get("Msg")).get("ToCheckInf");
		for(int i =0;i<list.size();i++) {
			ToCheckInf inf = new ToCheckInf();
			Map map  = list.get(i);
			System.out.println(map.get("ObjItemInf"));
				
					inf.setDataId("11");
      				inf.setObjCheckId((String) map.get("ObjCheckID"));
      				inf.setObjCheckNum((String) map.get("ObjCheckNum"));
      				inf.setCheckBeginDate((String) map.get("CheckBeginDate"));
      				inf.setName((String) map.get("Name"));
      				inf.setIdType((String) map.get("IDType"));
      				inf.setIdNum((String) map.get("IDNum"));
      				inf.setPhoneNum((String) map.get("PhoneNum"));
      				inf.setObjItemInf((String) map.get("ObjItemInf"));
      				inf.setObjItemDesc((String) map.get("ObjItemDesc"));
      				inf.setDataProviderOrgCode((String) map.get("DataProviderOrgCode"));
      				inf.setDataOccurOrgCode((String) map.get("DataOccurOrgCode"));
      				inf.setBusinessCode((String) map.get("BusinessCode"));
      				inf.setBusinessType((String) map.get("BusinessType"));
      				inf.setCheckFinalDate((String) map.get("CheckFinalDate"));
      				inf.setDataOccurDate((String) map.get("DataOccurDate"));
      				inf.setDataOccurAmount(new BigDecimal((String) map.get("DataOccurAmount")));
      				inf.setEncLosureFlag((String) map.get("EnclosureFlag"));
      				inf.setRsv1("22");
					System.out.println(inf);
				

			List<HashMap<Object, Object>> list2 = (List<HashMap<Object, Object>>) map.get("HistoricalCheckInf");
			for(int j =0;j<list2.size();j++) {
				Map map2  = list2.get(j);
				System.out.println(map2.get("CheckUserCode"));
			}
		}
		
	}
}
