package com.gingkoo.mbt.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.BaseService;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.orm.entity.ToCheckInf;

@Component
public class PersonalObjAlterService extends BaseService {
    @Resource
    private ROOTDAO rootDao;
    public static final String ID = "personalObjAlterService";
    public static final String CMD = "CMD";
    public static final String CMD_ADD = "CMD_ADD";
    public static final String CMD_MOD = "CMD_MOD";
    public static final String CMD_DEL = "CMD_DEL";
    public static final String IN_PARAM = "IN_PARAM";


    public void beforeProc(ServiceContext context) throws CommonException {
    }

    public void execute(ServiceContext context) throws CommonException {
        String cmd = (String)context.getAttribute("CMD");
        ToCheckInf toCheckInf = (ToCheckInf)context.getAttribute("IN_PARAM");
        if ("CMD_ADD".equals(cmd)) {
            toCheckInf.setDataId(UuidHelper.getCleanUuid());
            this.rootDao.save(toCheckInf);
        } else if ("CMD_MOD".equals(cmd)) {
            this.rootDao.update(toCheckInf);
        } else if ("CMD_DEL".equals(cmd)) {
            String pDataId = toCheckInf.getDataId();
            this.rootDao.delete(ToCheckInf.class,pDataId);
        }

    }

    @Override
    public void afterProc(ServiceContext context) throws CommonException {
        // TODO Auto-generated method stub

    }
}
