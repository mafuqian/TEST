package com.gingkoo.mbt.action;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommCommitToApvService;
import com.gingkoo.orm.entity.MbtArchiveManage;
import com.gingkoo.orm.entity.MbtD101;
import com.gingkoo.orm.entity.MbtD103Qry;

public class Mbt810CommitAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        String dsId = multiUpdateResultBean.getUpdateResult().containsKey("Mbt810Add_Bas_ds") ? "Mbt810Add_Bas_ds" : "Mbt810Add_ds";
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID(dsId);
        Map<String, String> recordMap = resultBean.getTotalList().get(0);

        //删除判断根据档案编号在个人信用报告查询申请或企业信用报告查询申请中有记录，则提示“档案已使用，不能删除”
        //AUTHORIZATION_ID select * from MBT_D101 select * from  MBT_D103_QRY
       String opr= resultBean.getParamMap().get("opr");
       if ("del".equals(opr)){
           String authorizationId = recordMap.get("authorizationId");
           String hql = "from MbtD101 where authorizationId = ? ";
           String hql1 = "from MbtD103Qry where authorizationId = ? ";

           ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
           List<MbtD101> list = rootdao.queryByQL2List(hql, new Object[] {authorizationId}, null);
           List<MbtD103Qry> list1 = rootdao.queryByQL2List(hql1, new Object[] {authorizationId}, null);

           if(list.size() > 0 || list1.size() >0){
               returnBean.setParameter("isOptSucc", "false");
               return returnBean;
           }
       }

        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommCommitToApvService mbtCommCommitToApvService = (MbtCommCommitToApvService) context.getBean("mbtCommCommitToApvService");

        mbtCommCommitToApvService.commitToApprove810(resultBean, MbtArchiveManage.class,returnBean);
        if("".equals(returnBean.getParameter("E_CODE"))) {
        	returnBean.setParameter("isOptSucc", "true");
        }else {
        	returnBean.setParameter("isOptSucc", "false");
        }
        return returnBean;
    }
}
