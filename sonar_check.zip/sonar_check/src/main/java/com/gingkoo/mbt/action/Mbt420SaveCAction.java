package com.gingkoo.mbt.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.mbt.util.DoThrowExpection;
import com.gingkoo.mbt.util.ExpCommUtils;
import com.gingkoo.orm.entity.Mbt420;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.orm.entity.Mbt420C;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Mbt420SaveCAction extends WebAlterAction {

	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mat_420_Oth_ds");
    //    process(resultBean, Mbt420C.class);

//        if(!(resultBean.getParamMap().get("opr").equals("del"))) {
//          //  受信人两标 “身份标识类型”、“身份标识号码”
////            D_ARLP_ID_TYPE
////            D_ARLP_CERT_TYPE
////            D_ARLP_CERT_NUM
//            List<Map<String,String>> tmp = resultBean.getTotalList();
//            tmp= tmp.stream().filter(s->!(s.get("opr").equals("del"))).collect(Collectors.toList());
//
//            for (int i = 0; i < tmp.size()-1; i++) {
//                Map<String,String> tmp420 = tmp.get(i);
//                for (int j=i+1;j<tmp.size();j++){
//                    Map<String,String> tmp4201 = tmp.get(j);
//
//                    if (tmp4201.get("dArlpIdType").equals(tmp420.get("dArlpIdType"))
//                            &&tmp4201.get("dArlpCertType").equals(tmp420.get("dArlpCertType"))
//                            && tmp4201.get("dArlpCertNum").equals(tmp420.get("dArlpCertNum"))){
//                        DoThrowExpection.doThrow( new AppException("保存失败，身份类别+身份标识类型+身份标识号码已存在，请重新输入后提交！"));
//                    }
//                }
//            }
//
//            //查询数据库
//            List<Map<String,String>> recordMap = resultBean.getTotalList().stream().filter(s->!s.get("opr").equals("del")).collect(Collectors.toList());
//            for (Map<String,String> tmp1:
//                    recordMap) {
//                //1.看证件类型是不是和主表冲突
//                //个人基本信息记录的标识项为“证件类型”。
//                ROOTDAO dao = ROOTDAOUtils.getROOTDAO();
//                String sql ="select count(1) from MBT_310_C  where  B_ID_TYPE='"+tmp1.get("othIdType")+"' and DATA_ID!='"+tmp1.get("dataId")+"'";
//                Iterator it= dao.queryBySQL(sql);
//                if (it.hasNext()){
//                    BigDecimal str = (BigDecimal)it.next();
//                    System.out.println(str);
//                    if (str.compareTo(new BigDecimal(0))>0)
//                        throw new AppException("保存失败，当前其他标识段的证件类型已在基础段中存在，请重新输入后提交！");
//                }
//
//            }
//
//        }

        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");
//        mbtCommSaveService.batchprocess(resultBean, Mbt420C.class);
        ExpCommUtils.batchProcess(resultBean,Mbt420C.class,mbtCommSaveService);

        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }

}
