package com.gingkoo.mbt.service;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.gingkoo.common.batch.entity.GpBmCheckConfig;
import com.gingkoo.common.batch.entity.GpBmTableCheckConfig;
import com.gingkoo.common.validate.service.DataValidateService;
import com.gingkoo.common.validate.service.base.BaseDataValidate;
import com.gingkoo.common.validate.service.base.BaseDataValidateService;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;

@Service
@Scope("prototype")
public class MbtCommonValidateForPageService extends BaseDataValidateService {

	private static final Log logger = LogFactory.getLogger(MbtCommonValidateForPageService.class);

	@Autowired
	private ROOTDAO rootdao;

	@Autowired
	private DataValidateService validateService;
	
	// 数据表和 段之间的关系
	private Map<String, String> tagMap;
	// 主表的数据集合
	private Map<String, Object> baseDataMap = new HashMap<>();
	// 返回结果集
	Map<String, String> errMap = new HashMap<String, String>();
	// 查询的字段Map.
	Map<String, String> queryColumnMap = new HashMap<String, String>();
	//tableName,GpBmTableCheckConfig
	Map<String,GpBmTableCheckConfig> tableCheckConfigMap = new HashMap<String,GpBmTableCheckConfig>();
	// 调用的dataId
	String dataId;
	//表名列表。
	LinkedList<String> tableNameList = new LinkedList<>();

	
	
	/**
	 * 页面校验执行方法入口。
	 * @param module
	 * @param funcid
	 * @param dataId
	 * @return
	 * @throws ClassNotFoundException
	 */
	public Map<String, String> execute(String module, String funcid, String dataId, GlobalInfo globalInfo) throws CommonException {
		GlobalInfo.setCurrentInstance(globalInfo);
		errMap.put("E_CODE", "");
		errMap.put("E_MSG", "");
		if (module == null || funcid == null || dataId == null || "".equals(module.trim()) || "".equals(funcid.trim())
				|| "".equals(dataId.trim())) {
			return errMap;
		}
		this.dataId = dataId;
		// 根据module 和funcid 来获取TableCheckConfig配置
		List<GpBmTableCheckConfig> gpBmTableCheckConfigList = BaseDataValidate.groupTableCheckCfgs.get(module);
		if (gpBmTableCheckConfigList == null || gpBmTableCheckConfigList.isEmpty()) {
			return errMap;
		}
		for (GpBmTableCheckConfig config : gpBmTableCheckConfigList) {
			String ckgroup = config.getCkGroup();
			if (ckgroup != null && funcid.equals(ckgroup)) {
				String tableName = config.getTableName().toUpperCase();
				tableCheckConfigMap.put(tableName, config);
			}
		}
		getMbtTableSort(funcid);

		for (String tableName : tableNameList) {
			dataValidate(tableName);
		}
		return errMap;
	}

	private void dataValidate(String tableName)
			throws CommonException {
		GpBmTableCheckConfig tableCheckConfig = tableCheckConfigMap.get(tableName);
		Map<String, String> columnMap = new HashMap<String, String>();
		List<GpBmCheckConfig> checkConfigs = BaseDataValidate.tableCheckCfgs.get(tableCheckConfig.getDataId());
		if (checkConfigs == null) {
			logger.info("找不到表:" + tableCheckConfig.getTableName() + " 的校验配置，跳过此校验");
			return;
		}
		List<Map<String, Object>> bussCfgs = BaseDataValidate.ckGroupBussCfgs.get(tableCheckConfig.getCkGroup());

		String queryColumn = queryColumnMap.get(tableName);
		StringBuffer strSql = new StringBuffer("DATA_ID");
		for (GpBmCheckConfig config : checkConfigs) {
			strSql.append(",").append(config.getCkColumnBatch());
			columnMap.put(config.getCkColumnBatch(), config.getCkColumn());
		}
		String sql = "select * from " + tableName + " where 1=1 and " + queryColumn + " = '" + dataId + "'";
		List<Map<String, Object>> dataList = rootdao.findBySql(sql);
		for (Map<String, Object> data : dataList) {
			if("B".equals(tagMap.get(tableName))) {
				baseDataMap = data;
			}else {
				putBaseDataToOtherDataMap(data);
			}
			String validateResult = validateService.validateData(checkConfigs, bussCfgs, data);
			if (!StringUtils.isEmpty(validateResult)) {
				String[] result = validateResult.split("\\|");
				String[] column = result[0].split(";");
				StringBuilder camelColumn = new StringBuilder("");
				for (int i = 0; i < column.length; i++) {
					camelColumn.append(columnMap.get(column[i])).append(";");
				}
				if ("".equals(errMap.get("E_CODE"))) {
					errMap.put("E_CODE", "99");
					errMap.put("E_MSG", tagMap.get(tableName) + "|" + data.get("DATA_ID") + "|" + camelColumn + "|"
							+ result[1]);
				} else {
					String existMsg = errMap.get("E_MSG");
					errMap.put("E_MSG", existMsg + "----" + tagMap.get(tableName) + "|" + data.get("DATA_ID") + "|"
							+ camelColumn + "|" + result[1]);
				}
			}
		}
	}

	/**
	 * 根据funcid 获取表名及查询的主外键。
	 * 
	 * @param funcid
	 * @return
	 */
	private void getMbtTableSort(String funcid) {
		tagMap = new HashMap<String, String>();
		String sql = "SELECT DISTINCT a.CK_GROUP,a.TABLE_NAME,b.RSV1 FROM GP_BM_TABLE_CHECK_CONFIG a LEFT JOIN GP_BM_CHECK_CONFIG b on a.DATA_ID=b.P_DATA_ID where a.CK_GROUP="
				+ "'" + funcid + "'";
		List<Map<String, Object>> list = rootdao.findBySql(sql);
		for (Map<String, Object> map : list) {
			String rsv1 = (map.get("RSV1") == null || "".equals(map.get("RSV1"))) ? "B"
					: map.get("RSV1").toString().toUpperCase();
			String tableName = map.get("TABLE_NAME") == null ? "" : map.get("TABLE_NAME").toString().toUpperCase();
			if ("B".equals(rsv1)) {
				queryColumnMap.put(tableName, "DATA_ID");
				tagMap.put(tableName, "B");
				tableNameList.add(0, tableName);
			} else {
				queryColumnMap.put(tableName, "PDATA_ID");
				tagMap.put(tableName, rsv1);
				tableNameList.add(tableName);
			}
		}
	}
	
	
	
	/**
	 * 将 主表的数据  逐个放置到 从表的map中。
	 * @param dataMap
	 */
	private void putBaseDataToOtherDataMap(Map<String,Object> dataMap) {
		for(String key : baseDataMap.keySet()) {
			if(!dataMap.containsKey(key)) {
				dataMap.put(key, baseDataMap.get(key));
			}
		}
	}

}
