package com.gingkoo.mbt.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.config.database.base.MyHibernateTemplate;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.BaseService;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.gf4j2.framework.util.ExceptionUtil;
import com.gingkoo.orm.entity.LocateInf;
import com.gingkoo.orm.entity.PerTagInf;

@Component
public class EntTagAlterService extends BaseService {
    @Resource
    private ROOTDAO rootDao;
    public static final String ID = "entTagAlterService";
    public static final String CMD = "CMD";
    public static final String CMD_ADD = "CMD_ADD";
    public static final String CMD_MOD = "CMD_MOD";
    public static final String CMD_DEL = "CMD_DEL";
    public static final String IN_PARAM = "IN_PARAM";


    public void beforeProc(ServiceContext context) throws CommonException {
    }

    public void execute(ServiceContext context) throws CommonException {
        String cmd = (String)context.getAttribute("CMD");
        PerTagInf perTagInf = (PerTagInf)context.getAttribute("IN_PARAM");
        if ("CMD_ADD".equals(cmd)) {
            perTagInf.setDataId(UuidHelper.getCleanUuid());
            this.rootDao.save(perTagInf);
        } else if ("CMD_MOD".equals(cmd)) {
            this.rootDao.update(perTagInf);
        } else if ("CMD_DEL".equals(cmd)) {
            String objTagId = perTagInf.getObjTagId();
            String pDataId = perTagInf.getDataId();
            this.deleteSheetData(objTagId);
            this.rootDao.delete(PerTagInf.class,pDataId);
        }

    }
    private void deleteSheetData(String objTagId) throws CommonException {
        List<LocateInf> sheetList = new ArrayList<LocateInf>();
        String hql = "from PerLocateInf where 1=1 and objTagId = ? ";

        try {
            sheetList = ((MyHibernateTemplate)ApplicationContextUtil.getBean(MyHibernateTemplate.class)).find(hql, new Object[]{objTagId});
        } catch (Exception var6) {
            var6.printStackTrace();
            ExceptionUtil.throwCommonException("查询失败！");
        }
        for(LocateInf sheetData :sheetList) {
            rootDao.delete(sheetData);
        }
    }
    @Override
    public void afterProc(ServiceContext context) throws CommonException {
        // TODO Auto-generated method stub

    }
}
