package com.gingkoo.mbt.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.mbt.service.MbtXmlRptService;
import com.gingkoo.mbt.service.PersonalObjService;
import com.gingkoo.orm.entity.TagInf;

public class G103AlterAction extends WebAlterAction {

    private static final String DATASET_ID = "PersonalObj_ds";
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse respone) throws AppException {
        UpdateReturnBean updateReturnBean = new UpdateReturnBean();
        UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
        ServiceContext oc = new ServiceContext();
        TagInf tagInf = new TagInf();

        Map<String, String> map = updateResultBean.next();
        
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtXmlRptService mbtXmlRptService  = (MbtXmlRptService) context.getBean("mbtXmlRptService");
        boolean flag = mbtXmlRptService.psGetEncloReq(map);
		
     
        if (flag){
            updateReturnBean.setParameter("isOptSucc", "true");
        }else {
            updateReturnBean.setParameter("isOptSucc", "false");
        }
        return updateReturnBean;
    }
}
