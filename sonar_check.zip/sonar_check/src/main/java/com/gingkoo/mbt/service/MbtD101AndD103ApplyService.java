package com.gingkoo.mbt.service;

import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.util.DateHelper;
import com.gingkoo.mbt.service.D101AndD103Common.MbtD101AndD103CommonService;
import com.gingkoo.orm.entity.MbtApplyDownloadManage;
import com.gingkoo.orm.entity.MbtD101;
import com.gingkoo.orm.entity.MbtD103Qry;

import static com.gingkoo.mbt.enums.MbtDictEnum.*;

/**
 * @Author: li.jy
 * @Date: 2019/1/31
 */
@Component
public class MbtD101AndD103ApplyService {
    protected static final Logger logger = LogManager.getLogger(MbtD101AndD103ApplyService.class);
    private static String OPR = "opr";
    private static String OPR_DOWNLOAD = "download";
    private static String OPR_EXTRA_DOWNLOAD = "extraDownload";
    private static String OPR_EXTRA_DOWNLOAD_TODAY = "extraDownloadToday";

    private static String OPR_PRINT = "print";
    private static String OPR_EXTRA_PRINT = "extraPrint";
    private static String OPR_EXTRA_PRINT_TODAY = "extraPrintToday";

    private static String OPR_BROWSE = "browse";
    private static String MBT_D101 = "MbtD101";

    @Autowired
    ROOTDAO dao;
    @Autowired
    private MbtD101AndD103CommonService commonService;

    public void apply(UpdateResultBean resultBean, String tableName) throws AppException {
        String opr = resultBean.getParamMap().get(OPR);
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
        String applyPhase = recordMap.get("applyPhase");
        recordMap = commonService.selectDataReToMap(recordMap, tableName);
        recordMap.put("applyPhase", applyPhase);
        MbtApplyDownloadManage applyDownloadManage = new MbtApplyDownloadManage();
        setMbtApplyDownloadManage(applyDownloadManage, recordMap, tableName);
        if (OPR_DOWNLOAD.equals(opr) || OPR_EXTRA_DOWNLOAD.equals(opr) || OPR_EXTRA_DOWNLOAD_TODAY.equals(opr)) {
            if (OPR_EXTRA_DOWNLOAD.equals(opr) || OPR_EXTRA_DOWNLOAD_TODAY.equals(opr)) {
                recordMap.put("expLevel", "提示");
                recordMap.put("desc", "当日下载次数已超过规定值");
                if (MBT_D101.equals(tableName)) {
                    commonService.record(resultBean, recordMap, MbtD101.class);
                } else {
                    commonService.record(resultBean, recordMap, MbtD103Qry.class);
                }
            }
            applyDownloadManage.setApplyType(APPLY_TYPE_DOWNLOAD.getNo());
            applyDownloadManage.setApplyStatus(DOWNLOAD_STATUS_02.getNo());
            dao.save(applyDownloadManage);
            updateQueryReport(tableName, recordMap, OPR_DOWNLOAD);
        } else if (OPR_PRINT.equals(opr) || OPR_EXTRA_PRINT.equals(opr) || OPR_EXTRA_PRINT_TODAY.equals(opr)) {
            if (OPR_EXTRA_PRINT.equals(opr) || OPR_EXTRA_PRINT_TODAY.equals(opr)) {
                recordMap.put("expLevel", "提示");
                recordMap.put("desc", "当日打印次数已超过规定值");
                if (MBT_D101.equals(tableName)) {
                    commonService.record(resultBean, recordMap, MbtD101.class);
                } else {
                    commonService.record(resultBean, recordMap, MbtD103Qry.class);
                }
            }
            applyDownloadManage.setApplyType(APPLY_TYPE_PRINT.getNo());
            applyDownloadManage.setApplyStatus(PRINT_STATUS_02.getNo());
            dao.save(applyDownloadManage);
            updateQueryReport(tableName, recordMap, OPR_PRINT);
        } else if (OPR_BROWSE.equals(opr)) {
            applyDownloadManage.setApplyType(APPLY_TYPE_BROWSE.getNo());
            applyDownloadManage.setApplyStatus(BROWSE_STATUS_02.getNo());
            dao.save(applyDownloadManage);
            updateQueryReport(tableName, recordMap, OPR_BROWSE);
        } else {
            throw new AppException("系统错误，请联系管理员");
        }
    }


    private void updateQueryReport(String tableName, Map<String, String> recordMap, String type) throws AppException {
        MbtD101 mbtD101;
        MbtD103Qry mbtD103Qry;
        // 个人
        if (MBT_D101.equals(tableName)) {
            mbtD101 = new MbtD101();
            try {
                BeanUtils.populate(mbtD101, recordMap);
            } catch (Exception e) {
                logger.error("类型转换出错", e);
            }
            switch (type) {
                case "download":
                    mbtD101.setDownloadStatus(DOWNLOAD_STATUS_02.getNo());
                    break;
                case "print":
                    mbtD101.setPrintStatus(PRINT_STATUS_02.getNo());
                    break;
                case "browse":
                    mbtD101.setBrowseStatus(BROWSE_STATUS_02.getNo());
                    break;
                default:
                    throw new AppException("个人信用报告：系统错误");
            }
            dao.update(mbtD101);
            //企业
        } else {
            mbtD103Qry = new MbtD103Qry();
            try {
                BeanUtils.populate(mbtD103Qry, recordMap);
            } catch (Exception e) {
                logger.error("类型转换出错", e);
            }
            switch (type) {
                case "download":
                    mbtD103Qry.setDownloadStatus(DOWNLOAD_STATUS_02.getNo());
                    break;
                case "print":
                    mbtD103Qry.setPrintStatus(PRINT_STATUS_02.getNo());
                    break;
                case "browse":
                    mbtD103Qry.setBrowseStatus(BROWSE_STATUS_02.getNo());
                    break;
                default:
                    throw new AppException("企业信用报告：系统错误");
            }
            dao.update(mbtD103Qry);
        }
    }

    private MbtApplyDownloadManage setMbtApplyDownloadManage(MbtApplyDownloadManage applyDownloadManage,
                                                             Map<String, String> recordMap, String tableName) throws AppException {
        GlobalInfo GI = GlobalInfo.getCurrentInstance();
        applyDownloadManage.setDataId(UuidHelper.getCleanUuid());
        applyDownloadManage.setDataDate(DateHelper.today());
        applyDownloadManage.setNextAction("00");
        applyDownloadManage.setDataStatus("99");
        applyDownloadManage.setOrgId(GI.getBrno());
        applyDownloadManage.setDataCrtUser(GI.getTlrno());
        applyDownloadManage.setDataCrtDate(DateUtil.get8Date());
        applyDownloadManage.setDataCrtTime(DateUtil.get14Date());
        applyDownloadManage.setDataChgUser(GI.getTlrno());
        applyDownloadManage.setDataChgDate(DateUtil.get8Date());
        applyDownloadManage.setDataChgTime(DateUtil.get14Date());
        applyDownloadManage.setPDataId(recordMap.get("dataId"));
        applyDownloadManage.setApplyDepartId(GI.getBrno());
        applyDownloadManage.setApplyTlrno(GI.getTlrno());
        applyDownloadManage.setAuthorizationId(recordMap.get("authorizationId"));
        // 个人
        if (MBT_D101.equals(tableName)) {
            applyDownloadManage.setSubjectType("个人");
            applyDownloadManage.setIdentifyName(recordMap.get("name"));
            applyDownloadManage.setClientId(recordMap.get("idNum"));
            // 企业
        } else {
            applyDownloadManage.setSubjectType("企业");
            applyDownloadManage.setIdentifyName(recordMap.get("entName"));
            applyDownloadManage.setClientId(recordMap.get("entCertNum"));
        }
        applyDownloadManage.setApplyPhase(recordMap.get("applyPhase"));
        applyDownloadManage.setApplyDate(DateUtil.get8Date());
        applyDownloadManage.setApplyTime(DateUtil.get14Date());
        return applyDownloadManage;
    }

}
