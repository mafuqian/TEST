package com.gingkoo.mbt.util;

import java.io.File;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.gingkoo.gf4j2.framework.util.FileUploadResources;

/**
 * 
 * 获取运行时目录
 * 根据init.properties中的application.home属性值获取运行时目录
 * 
 * @author kane
 * @version [版本号, 2016年10月18日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
public class AppHomeUtil {
	private static final Log logger = LogFactory.getLog(AppHomeUtil.class);
	
	/**
	 * 根据init.properties中的application.home属性值替换传入路径的${APP_HOME}
	 * 并对路径进行处理来适应不同的系统环境
	 * application.home值后面不要带斜杠 
	 * @param path 配置路径 以斜杠或反斜杠开头
	 * @return
	 * @see [类、类#方法、类#成员]
	 */
	public static String getDir(String path) {
		if (path == null) {
			return path;
		}
		String appHome = FileUploadResources.getInstance().getMessage("application.home");
		path = path.replace("${APP_HOME}", appHome);
		path = path.replace("\\", File.separator);
		path = path.replace("/", File.separator);
		return path;
	}

	public static void main(String[] args) {
		System.out.println(AppHomeUtil.getDir("${APP_HOME}\\123\\123"));
	}
}
