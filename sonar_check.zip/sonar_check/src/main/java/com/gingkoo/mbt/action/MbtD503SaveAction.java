package com.gingkoo.mbt.action;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.orm.entity.MbtD503;

public class MbtD503SaveAction extends MbtSingleRecordAction {
    UpdateResultBean resultBean;
    String dataId;
    String ognOrgCode;

    public MbtD503SaveAction(UpdateResultBean resultBean,String dataId,String ognOrgCode){
        this.dataId = dataId;
        this.ognOrgCode = ognOrgCode;
        this.resultBean = resultBean;
    }




    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
            throws AppException {

        UpdateReturnBean returnBean = new UpdateReturnBean();


        Map<String, String> MbtD503recordMap = new HashMap<>();
        if(resultBean.getParamMap().get("opr") .equals("add")){
            if(dataId==null || dataId.equals("")) {
                String dataCrtDate = DateUtil.get8Date();
                int i = (int)(Math.random()*900)+100;
                String type = "D503";
                MbtD503recordMap.put("fileName",ognOrgCode+dataCrtDate+type+i+"0");
                MbtD503recordMap.put("sendStatus","00");
            }else{
                MbtD503recordMap.put("dataId",dataId );
            }
        }else{
            MbtD503recordMap.put("dataId",dataId );
        }
        resultBean.getTotalList().add(MbtD503recordMap);

        process(resultBean, MbtD503.class);
        return returnBean;
    }
}
