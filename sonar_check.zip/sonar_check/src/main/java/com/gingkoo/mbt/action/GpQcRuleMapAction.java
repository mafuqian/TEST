package com.gingkoo.mbt.action;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.data.qc.gf4j.entity.GpQcRule;
import com.gingkoo.data.qc.gf4j.entity.GpQcRuleMap;
import com.gingkoo.mbt.service.GpQcRuleMapService;
import com.gingkoo.mbt.service.GpQcRuleService;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.OPCaller;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

public class GpQcRuleMapAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean arg0,
                                         HttpServletRequest arg1, HttpServletResponse arg2)
            throws AppException {
        logger.info("-------GpQcRuleAction start---------");
        UpdateReturnBean updateReturnBean = new UpdateReturnBean();
        ServiceContext oc = new ServiceContext();

        UpdateResultBean updateResultBean = multiUpdateResultBean
                .getUpdateResultBeanByID("GP_QC_RULE_MAP_ds");
        String opr = updateResultBean.getParameter("opr");
        if (updateResultBean.hasNext()) {
            GpQcRuleMap rule = new GpQcRuleMap();
            Map<String, String> map = updateResultBean.next();
            mapToObject(rule, map);
            if ("del".equals(opr)) {
                oc.setAttribute(GpQcRuleMapService.CMD, GpQcRuleMapService.CMD_DELETE);
            }
            try {
                oc.setAttribute("IN_PARAM", rule);
                oc.setAttribute("IN_PARAM_1", map);
                OPCaller.call(GpQcRuleMapService.ID, oc);
            } catch (CommonException e) {
                e.printStackTrace();
                updateReturnBean.setParameter("res", "99");
                updateReturnBean.setParameter("code", e.getKey());
                updateReturnBean.setParameter("desc", e.getMessage());
                return updateReturnBean;
            }
        }

        logger.info("-------GpQcRuleAction end---------");

        updateReturnBean.setParameter("res", "");
        updateReturnBean.setParameter("code", "");
        updateReturnBean.setParameter("desc", "");
        return updateReturnBean;
    }
}
