package com.gingkoo.mbt.dao;

import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.CriteriaSpecification;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.stereotype.Repository;

import com.gingkoo.gf4j2.framework.config.database.base.MyDaoSupport;

/**
 * @Author: li.jy
 * @Date: 2018/11/23
 */
@Repository("commonDao")
public class CommonDao extends MyDaoSupport {

    public List<Map<String, Object>> findBySql(String sql) {
        return (List<Map<String, Object>>) this.getHibernateTemplate().execute(new HibernateCallback() {
            @Override
            public Object doInHibernate(Session session) throws HibernateException {
                SQLQuery sqlQuery = session.createSQLQuery(sql);
                sqlQuery.setResultTransformer(CriteriaSpecification.ALIAS_TO_ENTITY_MAP);
                return sqlQuery.list();
            }
        });
    }

    public List<Map<String, Object>> findBySql(String sql, Object[] objs) {
        return (List<Map<String, Object>>) this.getHibernateTemplate().execute(new HibernateCallback() {
            @Override
            public Object doInHibernate(Session session) throws HibernateException {
                SQLQuery sqlQuery = session.createSQLQuery(sql);
                if (objs != null)
                    for (int i = 0; i < objs.length; i++) {
                        sqlQuery.setParameter(i, objs[i]);
                    }
                sqlQuery.setResultTransformer(CriteriaSpecification.ALIAS_TO_ENTITY_MAP);
                return sqlQuery.list();
            }
        });
    }

    public Map<String, Object> getOneBySql(String sql, Object[] objs) {
        return (Map<String, Object>) this.getHibernateTemplate().execute(new HibernateCallback() {
            @Override
            public Object doInHibernate(Session session) throws HibernateException {
                SQLQuery sqlQuery = session.createSQLQuery(sql);
                if (objs != null)
                    for (int i = 0; i < objs.length; i++) {
                        sqlQuery.setParameter(i, objs[i]);
                    }
                sqlQuery.setResultTransformer(CriteriaSpecification.ALIAS_TO_ENTITY_MAP);
                List<Map<String, Object>> result = (List<Map<String, Object>>) sqlQuery.list();
                if (result.size() > 0) {
                    return result.get(0);
                }
                return null;
            }
        });
    }

    public Map<String, Object> getOneBySql(String sql) {
        return (Map<String, Object>) this.getHibernateTemplate().execute(new HibernateCallback() {
            @Override
            public Object doInHibernate(Session session) throws HibernateException {
                SQLQuery sqlQuery = session.createSQLQuery(sql);
                sqlQuery.setResultTransformer(CriteriaSpecification.ALIAS_TO_ENTITY_MAP);
                List<Map<String, Object>> result = (List<Map<String, Object>>) sqlQuery.list();
                if (result.size() > 0) {
                    return result.get(0);
                }
                return null;
            }
        });
    }

    public void save(Object po) {
        this.getHibernateTemplate().save(po);
    }
    
    public void update(Object po) {
        this.getHibernateTemplate().update(po);
    }
    
    public void saveOrUpdate(Object po) {
        this.getHibernateTemplate().saveOrUpdate(po);
    }
    
    
}
