package com.gingkoo.mbt.util;

import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.*;

import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import org.springframework.util.StringUtils;

/**
 * @Author: li.jy
 * @Date: 2019/2/15
 */
public class PdfUtils {

    /**
     * 透明度 默认0.1f
     */
    private static float default_opacity = 0.1f;
    /**
     * 水印间隔 默认15，数字越大，间隔越大
     */
    private static int default_interval = 15;
    /**
     * 字体大小 默认18
     */
    private static int default_font_size = 18;
    /**
     * 旋转角度 默认45
     */
    private static float default_rotation = 45;

    /**
     * 生成PDF文件
     *
     * @throws Exception 异常
     */
    public static void generatePdf(String filePath, String fileName, String content) throws Exception {
        //实现A4纸页面 并且横向显示（不设置则为纵向）
        File file = new File(filePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        Document document = new Document(PageSize.A4.rotate());
        PdfWriter pdfWriter = PdfWriter.getInstance(document, new FileOutputStream(filePath + fileName));
        // 打开文档
        document.open();
        // 创建第一页（如果只有一页的话，这一步可以省略）
        document.newPage();

        // 加入文档内容
        document.add(new Paragraph(content));
        // 关闭文档
        document.close();
        pdfWriter.close();
    }

    /**
     * 单个水印
     *
     * @param InPdfFile   要加水印的文件路径
     * @param outPath     生成水印的文件路径
     * @param word        文字
     * @param rotationStr 旋转角度（可以为空）
     * @throws Exception 异常
     */
    public static void addWordMark(String InPdfFile, String outPath, String outFileName, String word, String
            rotationStr) throws Exception {
        File file = new File(outPath);
        if (!file.exists()) {
            file.mkdirs();
        }
        if (StringUtils.isEmpty(word)) {
            throw new Exception("水印文字不能为空");
        }
        float rotation;
        if (StringUtils.isEmpty(rotationStr)) {
            rotation = default_rotation;
        } else {
            rotation = Float.parseFloat(rotationStr);
        }
        PdfReader reader = new PdfReader(InPdfFile, "PDF".getBytes());
        PdfStamper stamp = new PdfStamper(reader, new FileOutputStream(outPath + outFileName));

        //设置字体
        BaseFont bf = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI, BaseFont.EMBEDDED);

        // 设置水印透明度
        PdfGState gs = new PdfGState();
        // 设置填充字体不透明度为0.4f
        gs.setFillOpacity(default_opacity);

        //取得Pdf文件的总页数
        int pageSize = reader.getNumberOfPages();
        //获取每页的宽度和高度
        Rectangle pageRect = reader.getPageSizeWithRotation(1);
        float pageWidth = pageRect.getWidth();
        float pageHeight = pageRect.getHeight();

        for (int i = 1; i <= pageSize; i++) {
            PdfContentByte over = stamp.getOverContent(i);
            over.beginText();
            // 设置透明度
            over.setGState(gs);
            over.setFontAndSize(bf, default_interval);
            over.showTextAligned(Element.ALIGN_CENTER, word, pageWidth / 2, pageHeight / 2, rotation);
            over.setColorFill(BaseColor.LIGHT_GRAY);
            over.endText();
        }
        stamp.close();
        reader.close();

        // 删除不带水印文件
        File tempfile = new File(InPdfFile);
        if (tempfile.exists()) {
            tempfile.delete();
        }
    }

    /**
     * 全屏水印
     *
     * @param InPdfFile   要加水印的文件路径
     * @param outPath     生成水印的文件路径
     * @param word        文字
     * @param interval    水印之间的间隔（可以为空）
     * @param rotationStr 旋转角度（可以为空）
     * @throws Exception 异常
     */
    public static void addWordMark(String InPdfFile, String outPath, String outFileName, String word, String
            rotationStr, int interval) throws Exception {
        File file = new File(outPath);
        if (!file.exists()) {
            file.mkdirs();
        }
        if (StringUtils.isEmpty(word)) {
            throw new Exception("水印文字不能为空");
        }
        //设置interval和rotation默认值
        if (interval == 0) {
            interval = default_interval;
        }
        float rotation;
        if (StringUtils.isEmpty(rotationStr)) {
            rotation = default_rotation;
        } else {
            rotation = Float.parseFloat(rotationStr);
        }

        PdfReader reader = new PdfReader(InPdfFile, "PDF".getBytes());
        PdfStamper stamp = new PdfStamper(reader, new FileOutputStream(outPath + outFileName));

        //设置字体
        BaseFont bf = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI, BaseFont.EMBEDDED);
        // 设置水印透明度
        PdfGState gs = new PdfGState();
        // 设置填充字体不透明度为0.4f
        gs.setFillOpacity(default_opacity);

        //取得Pdf文件的总页数
        int pageSize = reader.getNumberOfPages();

        JLabel label = new JLabel();
        FontMetrics metrics;
        int textH;
        int textW;
        label.setText(word);
        metrics = label.getFontMetrics(label.getFont());
        //字符串的高,   只和字体有关
        textH = metrics.getHeight();
        //字符串的宽
        textW = metrics.stringWidth(label.getText());

        Rectangle pageRect;
        for (int i = 1; i <= pageSize; i++) {
            pageRect = reader.getPageSizeWithRotation(i);
            PdfContentByte over = stamp.getOverContent(i);
            over.beginText();
            // 设置透明度
            over.setGState(gs);
            over.setFontAndSize(bf, default_font_size);

            // 水印文字成45（默认）度角倾斜
            for (int height = interval + textH; height < pageRect.getHeight(); height = height + textH * interval) {
                for (int width = interval + textW; width < pageRect.getWidth() + textW; width = width + textW) {
                    over.showTextAligned(Element.ALIGN_LEFT, word, width - textW, height - textH, rotation);
                }
            }

            over.setColorFill(BaseColor.LIGHT_GRAY);
            over.endText();
        }
        stamp.close();
        reader.close();

        // 删除不带水印文件
        File tempfile = new File(InPdfFile);
        if (tempfile.exists()) {
            tempfile.delete();
        }
    }

    /**
     * 生成图片水印
     *
     * @param InPdfFile     要加水印的文件路径
     * @param outPdfFile    生成水印的文件路径
     * @param markImagePath 图片路径
     * @throws Exception
     */
    public static void addImgMark(String InPdfFile, String outPdfFile, String markImagePath) throws Exception {
        PdfReader reader = new PdfReader(InPdfFile, "PDF".getBytes());
        PdfStamper stamp = new PdfStamper(reader, new FileOutputStream(new File(outPdfFile)));

        PdfContentByte under;
        PdfGState gs = new PdfGState();
        // 透明度设置
        gs.setFillOpacity(0.4f);
        // 插入图片水印
        Image img = Image.getInstance(markImagePath);
        // 坐标
        img.setAbsolutePosition(300, 300);
        // 旋转弧度
        img.setRotation(30);
        //img.setRotationDegrees(45);// 旋转角度
        // img.scaleAbsolute(200,100);//自定义大小
        //依照比例缩放
        img.scalePercent(50);
        // 原pdf文件的总页数
        int pageSize = reader.getNumberOfPages();
        for (int i = 1; i <= pageSize; i++) {
            // 水印在之前文本下
            under = stamp.getUnderContent(i);
            // under = stamp.getOverContent(i);//水印在之前文本上

            // 图片水印 透明度
            under.setGState(gs);
            // 图片水印
            under.addImage(img);
        }
        stamp.close();
        reader.close();
        // 删除不带水印文件
        File tempfile = new File(InPdfFile);
        if (tempfile.exists()) {
            tempfile.delete();
        }
    }

    public static void main(String[] args) throws Exception {
        addWordMark("C:\\Users\\Administrator\\Desktop\\20190304143733.pdf","C:\\Users\\Administrator\\Desktop",
                "今天测试.pdf","水印水印","");

        String FILE_DIR = "C:" + File.separator + "Users" + File.separator + "Administrator" + File.separator + "Desktop" + File.separator;
//        try {
//            File tempfile = new File(FILE_DIR + "testPdf1.pdf");
//            if (tempfile.exists()) {
//                tempfile.delete();
//            }
//            generatePdf(FILE_DIR, "testPdf.pdf", "ss");
//            addWordMark(FILE_DIR + "testPdf.pdf", FILE_DIR + "testPdf1.pdf",
//                    "GINGKOO COPYRIGHT", "45", 15);
////            addImgMark(FILE_DIR + "testPdf.pdf", FILE_DIR + "testPdf1.pdf",
////                    FILE_DIR + "姆巴佩.jpg");
//        } catch (Exception e) {
//            // TODO Auto-generated catch block
//            System.out.println("失败。。。。");
//            e.printStackTrace();
//        }
//        System.out.println("成功。");
    }


    public static void fillTemplate(String tempPath, String pdfPath, String[] content) {
        //模板路径
        String templatePath = "src/main/resources/templete/ftl/personalCreditReport.ftl";
        //生成的新文件路径
        PdfReader reader;
        FileOutputStream out;
        ByteArrayOutputStream bos;
        PdfStamper stamper;
        try {
            out = new FileOutputStream(pdfPath);
            reader = new PdfReader(templatePath);
            bos = new ByteArrayOutputStream();
            stamper = new PdfStamper(reader, bos);
            AcroFields form = stamper.getAcroFields();

            int i = 0;
            java.util.Iterator<String> it = form.getFields().keySet().iterator();
            while (it.hasNext()) {
                String name = it.next().toString();
                System.out.println(name);
                form.setField(name, content[i++]);
            }
            //如果为false那么生成的PDF文件还能编辑，一定要设为true
            stamper.setFormFlattening(true);
            stamper.close();

            Document doc = new Document();
            PdfCopy copy = new PdfCopy(doc, out);
            doc.open();
            PdfImportedPage importPage = copy.getImportedPage(new PdfReader(bos.toByteArray()), 1);
            copy.addPage(importPage);
            doc.close();

        } catch (IOException e) {
            System.out.println(1);
        } catch (DocumentException e) {
            System.out.println(2);
        }
    }
}
