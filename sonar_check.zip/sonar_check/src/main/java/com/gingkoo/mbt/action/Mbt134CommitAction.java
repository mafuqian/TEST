package com.gingkoo.mbt.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.orm.entity.MbtUnusalList;

public class Mbt134CommitAction extends MbtUpdCommitAction{
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
            throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mbt134Upd_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);

        if(recordMap.get("opt").equals("allDel") || recordMap.get("opt") == "allDel"){
            recordMap.put("infRecType", "134");
            recordMap.put("optType", "03");
        }
        recordMap.put("tableName","Mbt130Rpt");

        process(resultBean, MbtUnusalList.class);
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }
}
