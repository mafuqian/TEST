package com.gingkoo.mbt.action;

import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.mbt.service.HomePageService;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Controller
public class HomePageAction {
	private Log logger = LogFactory.getLogger(HomePageAction.class);
	
    @Autowired
    HomePageService homePageService;


    @RequestMapping(value = "/userLoginInfo", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
    @ResponseBody
    public JSONObject loginInfo(@RequestBody String param)
            throws CommonException, IOException {
    	logger.info(param);
    	JSONObject jsonobject = JSONObject.fromObject(param);
        /*response.reset();
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Content-type", "application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String tlrNo = request.getParameter("tlrNo");
        */
		String tlrNo = jsonobject.getString("tlrNo");
        Map<String,Object> result = new HashMap<String,Object>();
        try {
        	result = homePageService.getLoginInfo(tlrNo);
        } catch (Exception e) {
        	result.put("hasError", 0);
            result.put("message", e.getMessage());
        } finally {        	
        	return JSONObject.fromObject(result);
        }

    }
    
    @RequestMapping(value = "/taskStatistics", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
    @ResponseBody
    public JSONObject taskStatistics(@RequestBody String param)
            throws CommonException, IOException {
    	logger.info(param);
    	JSONObject jsonobject = JSONObject.fromObject(param);
        /*response.reset();
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Content-type", "application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String tlrNo = request.getParameter("tlrNo");
        */
		String tlrNo = jsonobject.getString("tlrNo");
        Map<String,Object> result = new HashMap<String,Object>();
        try {
        	result = homePageService.getTaskStatistics(tlrNo);
        } catch (Exception e) {
        	result.put("hasError", 0);
            result.put("message", e.getMessage());
        } finally {        	
        	return JSONObject.fromObject(result);
        }

    }
    
    @RequestMapping(value = "/reportStatistics", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
    @ResponseBody
    public JSONObject reportStatistics(@RequestBody String param)
            throws CommonException, IOException {
    	logger.info(param);
    	JSONObject jsonobject = JSONObject.fromObject(param);
        /*response.reset();
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Content-type", "application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String tlrNo = request.getParameter("tlrNo");
        */
		String censusType = jsonobject.getString("censusType");
        Map<String,Object> result = new HashMap<String,Object>();
        try {
        	result = homePageService.getReportStatistics(censusType);
        } catch (Exception e) {
        	result.put("hasError", 0);
            result.put("message", e.getMessage());
        } finally {        	
        	return JSONObject.fromObject(result);
        }

    }
    
    @RequestMapping(value = "/itemInfo", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
    @ResponseBody
    public JSONObject getItemInfo(@RequestBody String param,HttpServletRequest request)
            throws CommonException, IOException {
    	logger.info(param);
    	JSONObject jsonobject = JSONObject.fromObject(param);
        /*response.reset();
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Content-type", "application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String tlrNo = request.getParameter("tlrNo");
        */
    	System.out.println(request.getSession());
    	Map<String,Object> result = new HashMap<String,Object>();
        try {
        	String curPage = jsonobject.getString("page");
        	int rows = Integer.parseInt(jsonobject.getString("rows"));
        	result = homePageService.getItemInfo(curPage, rows, request);
        } catch (Exception e) {
        	result.put("hasError", 0);
            result.put("message", e.getMessage());
        } finally {        	
        	return JSONObject.fromObject(result);
        }

    }
    
    @RequestMapping(value = "/noticeInfo", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
    @ResponseBody
    public JSONObject getNoticeInfo(@RequestBody String param,HttpServletRequest request)
            throws CommonException, IOException {
    	logger.info(param);
    	JSONObject jsonobject = JSONObject.fromObject(param);
      
    	System.out.println(request.getSession());
    	Map<String,Object> result = new HashMap<String,Object>();
        try {
        	String curPage = jsonobject.getString("page");
        	int rows = Integer.parseInt(jsonobject.getString("rows"));
        	String noticeType = jsonobject.getString("noticeType");
        	result = homePageService.getNoticeInfo(curPage, rows, noticeType);
        } catch (Exception e) {
        	result.put("hasError", 0);
            result.put("message", e.getMessage());
        } finally {  
            return JSONObject.fromObject(result);
        }

    }


    @RequestMapping(value = "/getOrgId", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
    @ResponseBody
    public JSONObject getOrgId()
            throws CommonException, IOException {
        String tlrNo = GlobalInfo.getCurrentInstance().getTlrno();
        Map<String,Object> result = new HashMap<String,Object>();
        try {
            result = homePageService.getOrgId(tlrNo);
        } catch (Exception e) {
            result.put("hasError", 0);
            result.put("message", e.getMessage());
        } finally {
            return JSONObject.fromObject(result);
        }
    }

    @RequestMapping(value = "/setOrgId", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
    @ResponseBody
    public JSONObject setOrgId(@RequestBody String brNo) throws CommonException, IOException {
        String tlrNo = GlobalInfo.getCurrentInstance().getTlrno();
        Map<String,Object> result = new HashMap<String,Object>();
        logger.info(brNo);
        JSONObject jsonobject = JSONObject.fromObject(brNo);
        try {
            result = homePageService.setOrgId(tlrNo,jsonobject.getString("brNo"));
        } catch (Exception e) {
            result.put("hasError", 0);
            result.put("message", e.getMessage());
        } finally {
            return JSONObject.fromObject(result);
        }
    }

}
