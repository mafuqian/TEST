package com.gingkoo.mbt.action;

import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.mbt.util.DoThrowExpection;
import com.gingkoo.mbt.util.ExpCommUtils;
import com.gingkoo.orm.entity.Mbt440EEx;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.orm.entity.Mbt440;

public class Mbt440SaveAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mat_440_BAS_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);

//        if("failed".equals(validateFields(resultBean, returnBean))){
//            return returnBean;
//        }
        if ("add".equals(recordMap.get("opr"))&& (null==recordMap.get("dataId") || "".equals(recordMap.get("dataId")))){
            //企业担保账户信息记录的标识项为“账户标识码+信息报告日期”。
            ROOTDAO dao = ROOTDAOUtils.getROOTDAO();
            String sql ="select count(1) from MBT_440 a where a.B_ACCT_CODE='"+recordMap.get("bAcctCode")+"'";
            Iterator it= dao.queryBySQL(sql);
            it.forEachRemaining(obj -> {
                if (obj.toString().compareTo("0")>0) {
                    DoThrowExpection.doThrow( new AppException("保存失败，当前的账户标识码已存在，请重新输入后提交！"));
                }
            });
        }
        if(StringUtils.isEmpty(recordMap.get("dataId")) || StringUtils.isEmpty(recordMap.get("bInfRecType"))){
            recordMap.put("bInfRecType", "440");
        }
        //process(resultBean, Mbt440.class);
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");
//        mbtCommSaveService.process(resultBean,Mbt440.class);
        ExpCommUtils.process(resultBean,Mbt440.class,mbtCommSaveService);

        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("dataId", mbtCommSaveService.getDataId());
        return returnBean;
    }
}
