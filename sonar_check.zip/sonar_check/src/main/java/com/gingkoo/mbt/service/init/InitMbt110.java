package com.gingkoo.mbt.service.init;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.mbt.util.CompareUtils;
import com.gingkoo.mbt.util.MapToObject;
import com.gingkoo.orm.entity.Mbt110;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.sys.log.Log;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InitMbt110 {
    protected static final Log logger = LogFactory.getLogger(InitMbt110.class);

    protected ROOTDAO dao = ROOTDAOUtils.getROOTDAO();
	/**
     * 给Mbt110赋值报告时点
     * @throws Exception 
     */
    
    public Mbt110 initMbt110(Mbt110 mbt110) throws Exception {
    	String bRptDateCode = !("").equals(mbt110.getBRptDateCode()) ? mbt110.getBRptDateCode() : "10";
    	String dataId="";
    	dataId = mbt110.getDataId();
    	//1.如果数据在历史表中查询不到则赋10-新增客户资料/首次上报
    	String sql_his_table = "from  Mbt110His where odsDataId= ? order by hisDate desc";
    	 List hisTableData = dao.queryByQL2List(sql_his_table, new Object[] { dataId }, null);
      	//2.查询到了 去查上报表中是否有该笔数据
			if (null != hisTableData && hisTableData.size() > 0) {
					Map<String, String> map_his = new HashMap<String, String>();
					Object his_data_obj = hisTableData.get(0);
					map_his = MapToObject.objectToMap(his_data_obj);
					String sql_rpt_table = "from  Mbt110Rpt where odsDataId= ? and dataStatus='27' order by rptDate desc";
					dataId = map_his.get("dataId");
			    	 List rptTableData = dao.queryByQL2List(sql_rpt_table, new Object[] { dataId }, null);
		             	//有 --- 判断基础段的各字段是否变更
						if (null != rptTableData && rptTableData.size() > 0) {
							Map<String, String> map_rpt = new HashMap<String, String>();
							Object rpt_data_obj = rptTableData.get(0);
							Mbt110 mbt110His = new Mbt110();
							map_rpt =MapToObject.objectToMap(rpt_data_obj);
							MapToObject.mapToObject(mbt110His,map_rpt,"");
							Map<String, String> map_filed = new HashMap<String, String>();
							map_filed.put("bInfRecType", "bInfRecType");
							map_filed.put("bName", "bName");
							map_filed.put("bIdType", "bIdType");
							map_filed.put("bIdNum", "bIdNum");
							map_filed.put("bInfSurcCode", "bInfSurcCode");
							map_filed.put("bRptDate", "bRptDate");
							map_filed.put("bRptDateCode", "bRptDateCode");
							map_filed.put("bCimoc", "bCimoc");
							map_filed.put("bCustomerType", "bCustomerType");
                            Map map_filed_list = CompareUtils.getModifyContent(mbt110, mbt110His,map_filed);
                            //20-更新客户资料
							if (!(null == map_filed_list || map_filed_list.size() == 0 || map_filed_list.isEmpty())) {
				                 bRptDateCode ="20";
						}
					}
			}
			mbt110.setBRptDateCode(bRptDateCode);
		return mbt110;
    }
}
