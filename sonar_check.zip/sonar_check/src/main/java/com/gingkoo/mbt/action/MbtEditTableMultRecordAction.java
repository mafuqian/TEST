package com.gingkoo.mbt.action;

import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;

/**
 *
 * 处理前台提交的多条记录的通用 Action，适用于前端提交的表格类型的表单，
 * 此类型的表单一次性有多条记录提交，需要对每条记录在前端的操作类型进行判断，
 * 根据操作类型选择持久化的方式。
 *
 * @author fuxiang.luo@gingkoo.com
 *
 * @date 2018-9-5
 *
 */
public abstract class MbtEditTableMultRecordAction extends WebAlterAction {

    private ROOTDAO dao = ROOTDAOUtils.getROOTDAO();

    protected Log logger = LogFactory.getLogger(MbtEditTableMultRecordAction.class);

    /**
     * @param resultBean 包含多条记录的 UpdateResultBean
     * @param clazz 记录对应的实体类
     * @throws AppException APP异常
     */
    protected void process(UpdateResultBean resultBean, Class<?> clazz) throws AppException {

        while (resultBean.hasNext()){

            Map<String, String> recordMap = resultBean.next();
            resultBean.getParamMap().forEach((k, v)->{
                if(!StringUtils.isEmpty(v) && !k.equals("dataId")){
                    recordMap.put(k,v);
                }
            });

            Object bean = null;
            try {
                bean = clazz.newInstance();
            } catch (InstantiationException | IllegalAccessException e) {
                logger.error(e.getLocalizedMessage());
                throw new AppException("实例化类" + clazz.getName() + "时出错。");
            }

            String recordState = recordMap.get("recordState");
            if(StringUtils.isEmpty(recordMap.get("dataId"))){
                recordMap.put("dataId", UUID.randomUUID().toString().replace("-", ""));
            }

            mapToObject(bean, recordMap);
            if("insert".equals(recordState) || "new".equals(recordState)){//新增加的记录
                dao.save(bean);
            }else if ("modify".equals(recordState)){//修改
                dao.update(bean);
            }else if ("delete".equals(recordState) || "discard".equals(recordState)){//被删除或者被舍弃的
                dao.delete(bean);
            }
        }

    }

}
