package com.gingkoo.mbt.service;

import java.io.File;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.config.database.base.MyHibernateTemplate;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.orm.entity.MbtFbFile;
import com.gingkoo.orm.entity.MbtFbFileDtlInf;
import com.gingkoo.orm.entity.MbtFbFileListErrInf;
import com.gingkoo.orm.entity.bean.FbInf;

import cn.com.gingkoo.main.PbocTool;
import cn.com.gingkoo.main.Sm4Obj;
import cn.com.gingkoo.main.ZipObj;

@Service
public class MbtXmlFbService {
    protected static final Log logger = LogFactory.getLogger(MbtXmlFbService.class);

	@Autowired
	ROOTDAO dao;
	
	@Autowired
	private MyHibernateTemplate template;
	
	@Value("${mbt.output.path}")
	private String output;

	@Autowired
	MbtResStoreService mbtResStoreService;
	
	
	public ZipObj FbEncMsg(String filename) {
		PbocTool  pboc = new PbocTool();
		File file = new File(filename);
		String encFilePath = file.getPath();
		Sm4Obj obj1 = pboc.sm4(filename, encFilePath, "2");
		ZipObj obj =pboc.gzip(obj1.getEncFilePath(),encFilePath, "2");
		return obj;
		
	}
	
	public boolean FbAnayMsg(String filename,String dataId1,String orgId,String corpId) throws AppException {
		try {
			String filepath = filename;
			File file = new File(filepath);
			if(file.exists() ) {
				FbInf fbInf = mbtResStoreService.getFbInfByFile(file);
				if(null != fbInf) {
					String fbFlag = fbInf.getFbFlag();
					String status ="08";
					String msg = "";
					if("1".equals(fbFlag)) {
						status = "05";
						msg="成功入库";
					}else if("2".equals(fbFlag)) {
						status = "06";
						msg="文件名错误";
					}else if("3".equals(fbFlag)) {
						status = "07";
						msg="反馈错误";
					}else {
						status = "08";
					}
					
					String sql = "update mbt_File_Upload_Info set rpt_is_success='"+status
							+ "',fb_File_Is_Load='04' where data_id='"+dataId1+"'";
					dao.executeSql(sql);
					
					if("08".equals(status)) {
						return false;
					}
					
					String dataId = UUID.randomUUID().toString().replace("-", "");
					MbtFbFile mbtFbFile= new MbtFbFile();
					mbtFbFile.setDataId(dataId);
					mbtFbFile.setOrgId(orgId);
					mbtFbFile.setCorpId(corpId);
					mbtFbFile.setDataDate(DateUtil.get8Date());
					mbtFbFile.setFilePath(filepath);
					mbtFbFile.setFeddBackFileName(fbInf.getName());
					mbtFbFile.setRptFileName(fbInf.getRtpName());
					mbtFbFile.setType(fbInf.getType());
					mbtFbFile.setIsAnalysis("0");
					mbtFbFile.setIsError(fbInf.getFbFlag());
					mbtFbFile.setErrorMsg(msg);
					mbtFbFile.setAnalsisTime(DateUtil.get14Date());
					dao.save(mbtFbFile);
					
					
					if(!"1".equals(fbFlag)) {
						MbtFbFileDtlInf dtl = new MbtFbFileDtlInf();
						String dtlDataId = UUID.randomUUID().toString().replace("-", "");
						dtl.setDataId(dtlDataId);
						dtl.setPdataId(dataId);
						dtl.setFbErrNum(fbInf.getFbErrNum());
						dtl.setErrRecId(fbInf.getErrRecId());
						dtl.setErrRec(fbInf.getErrRec());
						dao.save(dtl);
						//MBT_FB_FILE_LIST_ERR_INF
						List<FbInf.ErrInf> errInfs = fbInf.getErrInfs();
						if(!errInfs.isEmpty() && errInfs.size() > 0) {
							MbtFbFileListErrInf errInf = new MbtFbFileListErrInf();
							for(int i=0;i<errInfs.size();i++) {
								errInf = new MbtFbFileListErrInf();
								FbInf.ErrInf errinfo = errInfs.get(i);
								errInf.setDataId(UUID.randomUUID().toString().replace("-", ""));
								errInf.setPdataId(dtlDataId);
								errInf.setFbCode(errinfo.getFbCode());
								errInf.setFbMsg(errinfo.getFbMsg());
								dao.save(errInf);
							}
						}
					}
				} 
			}else {
				return false;
			}
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage(),e);
			e.printStackTrace();
            throw new AppException("文件解析失败！"+e.getLocalizedMessage());
		}
		return true;
	}

	public boolean FbMsg(List<Map<String, String>> list)  {	
		try {
			for(int i=0;i<list.size();i++) {
				String path = list.get(i).get("fbFilePath");
				String orgId = list.get(i).get("orgId");
				String corpId = list.get(i).get("corpId");
				if(path.toUpperCase().endsWith(".TXT")) {
					boolean flag = FbAnayMsg(path,list.get(i).get("dataId"),orgId,corpId);
					return true;
				}
				ZipObj obj = FbEncMsg(path);
				
				String status = obj.getStatus();
				
				if(!"SUCCESS".equals(status)) {
					String sql = "update mbt_File_Upload_Info set fb_file_is_load='03'"
							+ " where data_id='"+list.get(i).get("dataId")+"'";
					dao.executeSql(sql);
					return true;
				}else {
					boolean flag = FbAnayMsg(obj.getZipFilePath(),list.get(i).get("dataId"),orgId,corpId);
					if(!flag) {
						String sql = "update mbt_File_Upload_Info set fb_file_is_load='08'"
								+ " where data_id='"+list.get(i).get("dataId")+"'";
						dao.executeSql(sql);
					}
					return flag;
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean fbFileUpdate() throws AppException {
		List<String>  l= call("SP_FB_RPT_TO_PM(?,?)");
		if(l.size()>0 && !l.isEmpty()) {
			String code = l.get(0);
			if(null ==code || "".equals(code)) {
				return true;
			}else {
				return false;
			}
		}
		return true;
	}
	
	public List<String>  call (String procName) throws AppException {
		
		List<String> l = new ArrayList<String>();
		StringBuffer strBuf = new StringBuffer();
		strBuf.append("{ call " + procName +"}");
		
		Session session = null;
		Connection conn = null;
		CallableStatement statement = null;
		try {
			session = template.getSession();
			conn = session.getSessionFactory().getCurrentSession().connection();
			
			statement = conn.prepareCall(strBuf.toString());
			
			statement.registerOutParameter(1, Types.CHAR);
			statement.registerOutParameter(2, Types.CHAR);
			
			statement.executeUpdate();
			
			String code = statement.getString(1);
			String msg = statement.getString(2);
			l.add(code);
			l.add(msg);
			statement.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				if(statement != null)statement.close();
				if(conn != null)conn.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			throw new AppException(e.getMessage());
			}
		
	
		return l;
		
	}
	
}
