package com.gingkoo.mbt.action;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.orm.entity.MbtF501;

public class MbtF501SaveAction extends MbtSingleRecordAction {

    UpdateResultBean resultBean;
    String dataId;
    String ognOrgCode;

    public MbtF501SaveAction(UpdateResultBean resultBean,String dataId,String ognOrgCode){
        this.dataId = dataId;
        this.ognOrgCode = ognOrgCode;
        this.resultBean = resultBean;
    }




    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
            throws AppException {
        // TODO Auto-generated method stub
        UpdateReturnBean returnBean = new UpdateReturnBean();


        Map<String, String> MbtF501recordMap = new HashMap<>();
        if(resultBean.getParamMap().get("opr") .equals("add")){
            if(dataId==null || dataId.equals("")) {
                String dataCrtDate = DateUtil.get8Date();
                int i = (int)(Math.random()*900)+100;
                String type = "F501";
                MbtF501recordMap.put("fileName",ognOrgCode+dataCrtDate+type+i+"0");
                MbtF501recordMap.put("sendStatus","00");
            }else{
                MbtF501recordMap.put("dataId",dataId );
            }
        }else{
            MbtF501recordMap.put("dataId",dataId );
        }
        resultBean.getTotalList().add(MbtF501recordMap);

        process(resultBean, MbtF501.class);
        return returnBean;
    }
}
