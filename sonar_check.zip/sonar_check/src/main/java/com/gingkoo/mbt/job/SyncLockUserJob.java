package com.gingkoo.mbt.job;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.exception.AppException;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.GpBmTlrInfo;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.orm.entity.MbtSendUserManage;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 *
 * 自动扫描指定目录并导入文件 job。可以用定时任务进行调用。 如果没有特别的需求功能，直接使用定时任务调用execute方法即可。
 * 如果有一些逻辑需求，可以重写execute方法。按照相关需求可以调用相关代码进行导入。
 *
 * @author 吴新玥
 * @date 20180408
 */
@Component("syncLockUserJob")
public class SyncLockUserJob {
    private static final Log logger = LogFactory.getLog(SyncLockUserJob.class);

    JobResult jr = new JobResult();

    public Map<String, String> execute() {
        logger.info("===============++++++++++Exec syncLockUserJob begin++++++++++=============");
        jr.setErrCode("0");
        jr.setErrMsg("OK");
        try {
            ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();

            //用户名
            String  tlrNo = GlobalInfo.getCurrentInstance().getTlrno();
            //部门
            String groupId = GlobalInfo.getCurrentInstance().getGroupId();
            //根据部门+用户名得出用户名称
            //用户名称
            String tlrName ="";
            String hqlcfg = "";
            hqlcfg =" from gpBmTlrInfo where tlrno = ? and groupId = ?";
            List<GpBmTlrInfo> gpBmTlrInfo = rootdao.queryByQL2List(hqlcfg,new Object[]{tlrNo,groupId},null);
            if (gpBmTlrInfo.size()==0){
                throw new AppException("找不到该用户");
            }else{
                tlrName = gpBmTlrInfo.get(0).getTlrName();
            }

            //查询当前MBT_SEND_USER_MANAGE表中存在的用户但是在个人/企业里面没有进行过申请的用户但是申请日期大于30天
            hqlcfg = "from  mbtSendUserManage where  floor(sysdate - to_date(dataCrtDate,'yyyymmdd'))>30 and sysTlrno=? and sysTlrname=? and sysOrgId=? ";
            List<MbtSendUserManage> listcfg = rootdao.queryByQL2List(hqlcfg, new Object[]{tlrNo,tlrName,groupId}, null);
            if (listcfg.size()>0){
                for (int i = 0; i < listcfg.size(); i++) {
                    /**
                     * 检查绑定用户表中连续30天未进行查询操作锁定接口查询用户：
                     * 数据状态（系统锁定）、原因（连续30天未进行查询操作）；
                     */
                    listcfg.get(i).setUserStatusChangeReason("连续30天未进行查询操作");
                    listcfg.get(i).setDataStatus("15");
                    Object bean;
                    bean = listcfg.get(i);
                    rootdao.update(bean);
                }
            }
//            else{
//                throw new AppException("没有超过30天未查询的");
//            }
        } catch (Exception arg6) {
            arg6.printStackTrace();
            logger.info("操作失败，错误信息：" + arg6.getMessage());
            jr.setErrCode("E");
            jr.setErrMsg("操作失败，错误信息：" + arg6.getMessage());
            return jr.getMap();
        }

        logger.info("===============++++++++++Exec syncLockUserJob end++++++++++=============");
        return jr.getMap();
    }

}
