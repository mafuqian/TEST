package com.gingkoo.mbt.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommCommitToApvService;
import com.gingkoo.orm.entity.TagInf;

public class PersonalTagDeleteAlterAction extends WebAlterAction {
    private static final String DATASET_ID = "PersonalTag_ds";

    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        String dsId = multiUpdateResultBean.getUpdateResult().containsKey("PersonalTag_ds") ? "PersonalTag_ds" : "PersonalTag_ds";
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID(dsId);
        Map<String,String> map=resultBean.getTotalList().get(0);
        String objCheckSource =map.get("objCheckSource");
        String dataState =map.get("dataState");

        if(!dataState.equals("4") && !dataState.equals("6") &&!dataState.equals("7") ){
            WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
            MbtCommCommitToApvService mbtCommCommitToApvService = (MbtCommCommitToApvService) context.getBean("mbtCommCommitToApvService");

            mbtCommCommitToApvService.commitToApprove(resultBean, TagInf.class,returnBean);
            if("".equals(returnBean.getParameter("E_CODE"))) {
            	returnBean.setParameter("isOptSucc", "true");
            }else {
            	returnBean.setParameter("isOptSucc", "false");
            }

        }else {
            returnBean.setParameter("isOptSucc", "false");
        }
        return returnBean;

    }
}
