package com.gingkoo.mbt.action;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommBatApvService;
import com.gingkoo.orm.entity.Mbt220;

public class Mbt220BatApvAction extends WebAlterAction {

	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean updateReturnBean = new UpdateReturnBean();
        List<Map<String, String>> records = multiUpdateResultBean.getUpdateResultBeanByID("Mat_220_ds").getTotalList();
/*
        new MbtCommBatApvService(Mbt220.class, records).approve();
*/

        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommBatApvService mbtCommBatApvService = (MbtCommBatApvService) context.getBean("mbtCommBatApvService");
        mbtCommBatApvService.setEntityName(Mbt220.class.getName());
        mbtCommBatApvService.setToBeApproveRecords(records);
        mbtCommBatApvService.approve();

        updateReturnBean.setParameter("isOptSucc", "true");
        return updateReturnBean;
    }

}
