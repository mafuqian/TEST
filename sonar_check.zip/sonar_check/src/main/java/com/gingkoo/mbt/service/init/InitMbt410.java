package com.gingkoo.mbt.service.init;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.mbt.util.CompareUtils;
import com.gingkoo.mbt.util.DateConvertUtils;
import com.gingkoo.mbt.util.MapToObject;
import com.gingkoo.orm.entity.Mbt410;
import com.gingkoo.orm.entity.Mbt410His;
import org.apache.commons.lang.StringUtils;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.sys.log.Log;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InitMbt410 {

    protected static final Log logger = LogFactory.getLogger(InitMbt410.class);

    protected ROOTDAO dao = ROOTDAOUtils.getROOTDAO();

    private String bRptDateCode;

    /**
     * 给Mbt410赋值报告时点
     * author:wuxy
     * time:2018年11月15日18:26:44
     *
     * @throws Exception
     */
    public Mbt410 initMbt410(Mbt410 mbt410) throws AppException {
        bRptDateCode = !("").equals(mbt410.getBRptDateCode()) ? mbt410.getBRptDateCode() : "10";
        String dataId = "";
        dataId = mbt410.getDataId();
        //1.查询历史表是否存在数据
        String sql_his_table = "from  Mbt410His where odsDataId= ?  order by hisDate desc";
        List hisTableData = dao.queryByQL2List(sql_his_table, new Object[]{dataId}, null);
        if (null != hisTableData && hisTableData.size() > 0) {
            Map<String, String> map_his = new HashMap<String, String>();
            Object his_data_obj = hisTableData.get(0);
            try {
                map_his = MapToObject.objectToMap(his_data_obj);
                String sql_rpt_table = "from  Mbt410Rpt where odsDataId= ? and dataStatus='27' order by rptDate desc";
                dataId = map_his.get("dataId");
                List rptTableData = dao.queryByQL2List(sql_rpt_table, new Object[]{dataId}, null);
                if (null != rptTableData && rptTableData.size() > 0) {
                    Map<String, String> map_rpt = new HashMap<String, String>();
                    Object rpt_data_obj = hisTableData.get(0);
                    map_rpt = MapToObject.objectToMap(rpt_data_obj);
                    if (map_rpt.get("COpenDate").equals(map_his.get("COpenDate"))) {
                        //说明历史数据中的开户日期与上报数据中的一致 继续比较其他字段
                        assignmentCFlag(mbt410);
                    }
                }
            } catch (Exception e) {
                logger.error(e.getLocalizedMessage());
            }

        }
        mbt410.setBRptDateCode(bRptDateCode);
        return mbt410;
    }

    /**
     * cFlag  放款
     * 对于2-贷款额度分次发放，且所有放款使用统一的D1账户合并报送 ，指首次放款后的其他放款日期
     *  对于 D2/R1/R4/C1 类账户，一次性发款的 D1 账户、分次放款且分别在多个账户上管理的 D1 账户不适用该时点。
     */
    private void assignmentCFlag(Mbt410 mbt410) {
        String bAcctType = mbt410.getBAcctType();
        String cFlag = mbt410.getCFlag();

            if ("D1".equals(bAcctType) && "2".equals(cFlag)) {
                //首次放款后的其他放款日期有值 开户日期有值则设置为31
                if (!StringUtils.isEmpty(mbt410.getCOpenDate())) {
                    bRptDateCode = "31";
                } else {
                    //约定还款
                    assignmentHSettDate(mbt410);
                }

            } else {
                //约定还款
                assignmentHSettDate(mbt410);
            }
    }

    /**
     * 约定还款 32  hSettDate 不含账户在约定还款日关闭 账户关闭日期不等于约定还款日并且最近一次约定还款日等于最近一次实际还款日期
     */
    private void assignmentHSettDate(Mbt410 mbt410) {
        String bAcctType = mbt410.getBAcctType();

        if ("D1".equals(bAcctType) || "D2".equals(bAcctType) || "R4".equals(bAcctType)) {
            //最近一次约定还款日
           String  hLatAgrrRpyDate = mbt410.getHLatAgrrRpyDate();
            //最近一次实际还款日期
            String hLatRpyDate = mbt410.getHLatRpyDate();
                String hCloseDate = mbt410.getHCloseDate();
                if (!hLatAgrrRpyDate.equals(hCloseDate) && hLatAgrrRpyDate.equals(hLatRpyDate)) {
                    bRptDateCode = "32";
                } else {
                    //实际还款
                    assignmenthRpmtTypeAndhLatRpyAmt(mbt410);
                }
        } else {
            //实际还款
            assignmenthRpmtTypeAndhLatRpyAmt(mbt410);
        }
    }

    /**
     * 实际还款  hRpmtType还款方式10正常还款 hLatRpyAmt最近一次实际还款金额
     * hLatRpyDate 最近一次实际还款日期 hLatRpyPrincAmt 最近一次实际归还本金
     * 特指在非约定还款日还款  最近一次约定还款日不等于最近一次实际还款日期
     */
    private void assignmenthRpmtTypeAndhLatRpyAmt(Mbt410 mbt410) {
        String bAcctType = mbt410.getBAcctType();
        String hRpmtType = mbt410.getHRpmtType();
        if ("D1".equals(bAcctType) || "D2".equals(bAcctType) || "R4".equals(bAcctType) || "C1".equals(bAcctType)) {
            String hAcctStatus = mbt410.getHAcctStatus();
            if ("10".equals(hRpmtType) && !bRptDateCode.equals("33")) {
                //最近一次约定还款日
                String  hLatAgrrRpyDate = mbt410.getHLatAgrrRpyDate();
                //最近一次实际还款日期
                String hLatRpyDate = mbt410.getHLatRpyDate();
                if (!hLatAgrrRpyDate.equals(hLatRpyDate)) {
                    bRptDateCode = "33";
                } else {
                    //五级分类
                    assignmentFiveLevelClassification(mbt410);
                }
            } else {
                //五级分类
                assignmentFiveLevelClassification(mbt410);
            }
        } else {
            //五级分类
            assignmentFiveLevelClassification(mbt410);
        }
    }

    /**
     * 五级分类调整
     * 比较与历史表中的数据是否一致
     * hFiveCate 五级分类
     * hFiveCateAdjDate
     */

    public void assignmentFiveLevelClassification(Mbt410 mbt410) {
        String bAcctType = mbt410.getBAcctType();
        if ("D1".equals(bAcctType) || "D2".equals(bAcctType) || "R4".equals(bAcctType) || "C1".equals(bAcctType)) {
            Map<String, String> map_filed1 = new HashMap<String, String>();
            //比较五级分类日期
//			map_filed1.put("hFiveCate", "hFiveCate");
            map_filed1.put("hFiveCateAdjDate", "hFiveCateAdjDate");
            String sql_his_table = "from  Mbt410His where odsDataId= ?  order by hisDate desc";
            List hisTableData = null;
            Mbt410 mbt410His = new Mbt410();
            try {
                hisTableData = dao.queryByQL2List(sql_his_table, new Object[]{mbt410.getDataId()}, null);
                if (null != hisTableData && hisTableData.size() > 0) {
                    Map<String, String> map_his = new HashMap<String, String>();
                    Object his_data_obj = hisTableData.get(0);
                    map_his = MapToObject.objectToMap(his_data_obj);
                    MapToObject.mapToObject(mbt410His, map_his, "");
                }
                Map map_filed_list1 = CompareUtils.getModifyContent(mbt410, mbt410His, map_filed1);
                if (!(null == map_filed_list1 || map_filed_list1.size() == 0 || map_filed_list1.isEmpty())) {
                    bRptDateCode = "41";
                } else {
                    //展期发生
                    assignmentIChanTranType(mbt410);
                }
            } catch (CommonException e) {
                logger.error(e.getLocalizedMessage());
            } catch (NoSuchMethodException e) {
                logger.error(e.getLocalizedMessage());
            } catch (IllegalAccessException e) {
                logger.error(e.getLocalizedMessage());
            } catch (InvocationTargetException e) {
                logger.error(e.getLocalizedMessage());
            } catch (Exception e) {
                logger.error(e.getLocalizedMessage());
            }

        } else {
            //展期发生
            assignmentIChanTranType(mbt410);
        }
    }

    /**
     * 展期发生 42
     */

    private void assignmentIChanTranType(Mbt410 mbt410) {
        //MBT_410_I
        Map<String, String> mbt410IMap = new HashMap<>();
        String iTranDate = "";
        try {
            String sql_rpt_table = "from  Mbt410I where pdataId= ?";
            List mbt410ITableData = dao.queryByQL2List(sql_rpt_table, new Object[]{mbt410.getDataId()}, null);
            if (null != mbt410ITableData && mbt410ITableData.size() > 0) {
                for (int i = 0; i < mbt410ITableData.size(); i++) {
                    Object mbt210K_data_obj = mbt410ITableData.get(i);
                    mbt410IMap = MapToObject.objectToMap(mbt210K_data_obj);
                    String iChanTranType = mbt410IMap.get("IChanTranType");
                    if ("11".equals(iChanTranType)) {
                        //取交易日期
                        iTranDate = mbt410IMap.get("ITranDate");
                    }
                }
                if (StringUtils.isEmpty(iTranDate)) {
                    //其他情况
                    assignmentOthReports(mbt410);
                } else {
                    bRptDateCode = "42";
                }
            } else {
                //其他情况
                assignmentOthReports(mbt410);
            }
        } catch (Exception e) {
            logger.error(e.getLocalizedMessage());
        }

    }

    /**
     * 其他报送
     * D1/R4 账户逾期时，要求每月至少更新一次账户的还款表现信息
     * 对于D1/D2/R4/C1类账户，当发生担保变化、账户核销等情况，不要求“T+1报送”，仅与关键时点发生的信息一并组织上报即可。如果该账户在某月内
     * 没有关键业务时点，则发生担保变化、账户核销等情况允许延迟到月底最后一天报送;
     * 对于 R1 账户，除账户开立、账户关闭两个时点外，不要求在放款(不含首次放款)等另外 5 个时点“T+1 报送”，只需要在账户生命周期中的每个月固定
     * 一天报送数据。这一天的选择遵循以下原则:1.对于按月结算的(指每月统一还款或出账单)，取结算日;2.其他情况，统一取月底最后一天。
     */
    private void assignmentOthReports(Mbt410 mbt410) {
        Mbt410His mbt410His = new Mbt410His();
        String bAcctType = mbt410.getBAcctType();
        //D1/R4 账户逾期 并且hTotOverd hOverdPrinc hOverdDy
        BigDecimal hTotOverd = mbt410.getHTotOverd();
        BigDecimal hOverdPrinc = mbt410.getHOverdPrinc();
        String dataId = mbt410.getDataId();
        Short hOverdDy = mbt410.getHOverdDy();
        //查询当月是否上报过
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        String endDate = DateConvertUtils.getLastDate().replaceAll("-", "");
        StringBuffer startDate = new StringBuffer(year + "" + month + "01");
        String sql_his_table = "from  Mbt410His where odsDataId= ? and hisDate >=? and hisDate <=? and bRptDateCode ='49' order by hisDate desc";
        List hisTableData = null;
        try {
            hisTableData = dao.queryByQL2List(sql_his_table, new Object[]{dataId, startDate.toString(), endDate}, null);

            if (null != hisTableData && hisTableData.size() > 0) {
                Map<String, String> map_his = new HashMap<String, String>();
                Object his_data_obj = hisTableData.get(0);
                try {
                    map_his = MapToObject.objectToMap(his_data_obj);
                    MapToObject.mapToObject(mbt410His, map_his, "");
                    String sql_rpt_table = "from  Mbt410Rpt where odsDataId= ? and hisDate >=? and hisDate <=? and bRptDateCode ='49' order by rptDate desc";
                    dataId = map_his.get("dataId");
                    List rptTableData = dao.queryByQL2List(sql_rpt_table, new Object[]{dataId, startDate.toString(), endDate}, null);
                    if (null != rptTableData && rptTableData.size() > 0) {
//							Map<String, String> map_rpt = new HashMap<String, String>();
//							Object rpt_data_obj = hisTableData.get(0);
//							map_rpt = MapToObject.objectToMap(rpt_data_obj);
                        //账户关闭
                        assignmenthCloseDate(mbt410);
                    } else {
                        if ("D1".equals(bAcctType) || "D4".equals(bAcctType) && hTotOverd.compareTo(new BigDecimal(0)) > 0 && hOverdPrinc.compareTo(new BigDecimal(0)) > 0 && !(hOverdDy.equals(0))) {
                            bRptDateCode = "49";
                        } else if (("D1".equals(bAcctType) || "D4".equals(bAcctType) || "D2".equals(bAcctType) || "C1".equals(bAcctType)) && (!"49".equals(bRptDateCode))) {
                            Map<String, String> map_filed1 = new HashMap<String, String>();
                            //比较担保变化 账户核销 cGuarMode  hAcctStatus 31-32
                            map_filed1.put("cGuarMode", "cGuarMode");
//									map_filed1.put("hAcctStatus", "hAcctStatus");
                            Map map_filed_list1 = CompareUtils.getModifyContent(mbt410, mbt410His, map_filed1);
                            if (!(null == map_filed_list1 || map_filed_list1.size() == 0 || map_filed_list1.isEmpty()) || (("31").equals(mbt410.getHAcctStatus()) || ("32").equals(mbt410.getHAcctStatus()))) {
                                bRptDateCode = "49";
                            } else {
                                //账户关闭
                                assignmenthCloseDate(mbt410);
                            }
                        } else if ("R1".equals(bAcctType)) {
                            bRptDateCode = "49";
                        }
                    }

                } catch (Exception e) {
                    logger.error(e.getLocalizedMessage());
                }

            } else {
                assignmenthCloseDate(mbt410);
            }
        } catch (CommonException e) {
            e.printStackTrace();
        }
    }

    /**
     * 账户关闭  有账户关闭日期的hCloseDate
     *
     * @param mbt410
     * @return
     */
    private void assignmenthCloseDate(Mbt410 mbt410) {
        if (!StringUtils.isEmpty(mbt410.getHCloseDate())) {
            bRptDateCode = "20";
        }
    }
}