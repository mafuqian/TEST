package com.gingkoo.mbt.action;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.orm.entity.MbtUnusalList;
import org.apache.commons.lang.StringUtils;

public class Mbt442CommitAction extends MbtUpdCommitAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
            throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        String dsId = multiUpdateResultBean.getUpdateResult().containsKey("Mbt442Upd_Opt_ds") ? "Mbt442Upd_Opt_ds" : "Mbt442Upd_ds";
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID(dsId);
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
        List<Map<String, String>> records = resultBean.getTotalList();

        StringBuffer partName = new StringBuffer("");
        StringBuffer partType = new StringBuffer("");
        for(Map<String, String> one:records){
            if (!(one.get("partName")==null || "".equals(one.get("partName")))){
                partName.append(one.get("partName")).append(",");
            }
            if (!(one.get("partType")==null || "".equals(one.get("partType")))){
                partType.append(one.get("partType")).append(",");
            }
        }
        String opr = resultBean.getParamMap().get("opr");

        if(opr.equals("mod") || opr == "mod"){
            recordMap.put("infRecType", "442");
            recordMap.put("optType", "01");
        }else if(opr.equals("del") || opr == "del"){
            recordMap.put("infRecType", "443");
            recordMap.put("optType", "02");
        }else if(opr.equals("alldel") || opr == "alldel"){
            recordMap.put("infRecType", "444");
            recordMap.put("optType", "03");
        }
        recordMap.put("partName",partName.substring(0,partName.length()-1));
        recordMap.put("partType",partType.substring(0,partType.length()-1));

        /** startDate和endDate不为空则转换*/
        if (!StringUtils.isEmpty(resultBean.getParamMap().get("startDate"))){
            resultBean.getParamMap().put("startDate",new SimpleDateFormat("YYYYMMdd").format(Long.valueOf(resultBean.getParamMap().get("startDate"))));
        }
        if (!StringUtils.isEmpty(resultBean.getParamMap().get("endDate"))){
            resultBean.getParamMap().put("endDate",new SimpleDateFormat("YYYYMMdd").format(Long.valueOf(resultBean.getParamMap().get("endDate"))));
        }
        recordMap.put("tableName","Mbt440Rpt");

        process(resultBean, MbtUnusalList.class);
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }
}
