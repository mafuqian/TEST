package com.gingkoo.mbt.action;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.service.base.OPCaller;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.mbt.service.EntObjAlterService;
import com.gingkoo.mbt.service.PersonalObjAlterService;
import com.gingkoo.mbt.service.PersonalObjApvService;
import com.gingkoo.mbt.service.PersonalObjHisApvService;
import com.gingkoo.orm.entity.ToCheckInf;
import com.gingkoo.orm.entity.ToEntCheckInf;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

public class EntObjHisApvAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request,
                                         HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        PersonalObjHisApvService mbtCommApvService = (PersonalObjHisApvService) context.getBean("personalObjHisApvService");
        mbtCommApvService.setEntityName(ToEntCheckInf.class.getName());
        mbtCommApvService.setUpdateResultBean(multiUpdateResultBean.getUpdateResultBeanByID("EntObj_TabPageList_ds"));
        mbtCommApvService.approve();
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }
}
