package com.gingkoo.mbt.callProc;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.config.database.base.MyHibernateTemplate;
import com.gingkoo.orm.entity.MbtCrossTableValidateCfg;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;

@Service
public class MbtCrossTableValidateCallProcService {

    @Autowired
    private MyHibernateTemplate template;



    public JobResult singleValidate(MbtCrossTableValidateCfg crossTableValidateCfg , String rptDate)throws AppException{
        JobResult jobResult = new JobResult();
        jobResult.setErrMsg("00");
        jobResult.setErrMsg("OK");
        String busClass = crossTableValidateCfg.getBusClass();
        String rptDataType = crossTableValidateCfg.getRptDataType();
        String rptDataNo = crossTableValidateCfg.getRptDataNo();
        String busExplain = crossTableValidateCfg.getBusExplain();
        String msg = "";
        String procName = "";
        try {
            if("C".equals(busClass)){
                switch (rptDataType){
                    case "340":
                        procName = "SP_MBT_CROSS_TABLE_340(?,?,?,?,?,?)";
                        break;
                    case "350":
                        procName = "SP_MBT_CROSS_TABLE_350(?,?,?,?,?,?)";
                        break;
                    case "410":
                        procName = "SP_MBT_CROSS_TABLE_410(?,?,?,?,?,?)";
                        break;
                    case "412":
                        procName = "SP_MBT_CROSS_TABLE_412(?,?,?,?,?,?)";
                        break;
                    case "420":
                        procName = "SP_MBT_CROSS_TABLE_420(?,?,?,?,?,?)";
                        break;
                    case "422":
                        procName = "SP_MBT_CROSS_TABLE_422(?,?,?,?,?,?)";
                        break;
                    case "440":
                        procName = "SP_MBT_CROSS_TABLE_440(?,?,?,?,?,?)";
                        break;
                    case "442":
                        procName = "SP_MBT_CROSS_TABLE_442(?,?,?,?,?,?)";
                        break;
                    case "510_C":
                        procName = "SP_MBT_CROSS_TABLE_510_C(?,?,?,?,?,?)";
                        break;
                    case "610":
                        procName = "SP_MBT_CROSS_TABLE_610(?,?,?,?,?,?)";
                        break;
                    case "620":
                        procName = "SP_MBT_CROSS_TABLE_620(?,?,?,?,?,?)";
                        break;
                    case "630":
                        procName = "SP_MBT_CROSS_TABLE_630(?,?,?,?,?,?)";
                        break;
                    case "640":
                        procName = "SP_MBT_CROSS_TABLE_640(?,?,?,?,?,?)";
                        break;
                    case "650":
                        procName = "SP_MBT_CROSS_TABLE_650(?,?,?,?,?,?)";
                        break;
                    default:
                        procName = "";
                        break;
                }
            }else if("P".equals(busClass)){
                switch (rptDataType){
                    case "120" :
                        procName = "SP_MBT_CROSS_TABLE_120(?,?,?,?,?,?)";
                        break;
                    case "130" :
                        procName = "SP_MBT_CROSS_TABLE_130(?,?,?,?,?,?)";
                        break;
                    case "140" :
                        procName = "SP_MBT_CROSS_TABLE_140(?,?,?,?,?,?)";
                        break;
                    case "210" :
                        procName = "SP_MBT_CROSS_TABLE_210(?,?,?,?,?,?)";
                        break;
                    case "212" :
                        procName = "SP_MBT_CROSS_TABLE_212(?,?,?,?,?,?)";
                        break;
                    case "215" :
                        procName = "SP_MBT_CROSS_TABLE_215(?,?,?,?,?,?)";
                        break;
                    case "220" :
                        procName = "SP_MBT_CROSS_TABLE_220(?,?,?,?,?,?)";
                        break;
                    case "222" :
                        procName = "SP_MBT_CROSS_TABLE_222(?,?,?,?,?,?)";
                        break;
                    case "230" :
                        procName = "SP_MBT_CROSS_TABLE_230(?,?,?,?,?,?)";
                        break;
                    case "232" :
                        procName = "SP_MBT_CROSS_TABLE_232(?,?,?,?,?,?)";
                        break;
                    case "510_P" :
                        procName = "SP_MBT_CROSS_TABLE_510_P(?,?,?,?,?,?)";
                        break;
                    default:
                        procName = "";
                        break;
                }
            }
            if("".equals(procName)){
                jobResult.setErrCode("99");
                jobResult.setErrMsg("没有找到相应的存储过程方法。");
                return jobResult;
            }

            jobResult = call(procName,rptDataType,rptDataNo,rptDate,busExplain);

        } catch (Exception e) {
            e.printStackTrace();
            throw new AppException(e.getMessage());
        }

        return jobResult;

    }


    public JobResult call (String procName, String rptDataType, String rptDataNo, String rptDate, String busExplain) throws AppException {
        JobResult jobResult = new JobResult();
        String errCode = "";
        String errMsg = "";
        StringBuffer strBuf = new StringBuffer();
        strBuf.append("{ call " + procName +"}");

        Session session = null;
        Connection conn = null;
        CallableStatement statement = null;

        try {
            session = template.getSession();
            conn = session.getSessionFactory().getCurrentSession().connection();

            statement = conn.prepareCall(strBuf.toString());

            statement.setString(1, rptDataType);
            statement.setString(2, rptDataNo);
            statement.setString(3, rptDate);
            statement.setString(4, busExplain);

            statement.registerOutParameter(5, Types.VARCHAR);
            statement.registerOutParameter(6, Types.VARCHAR);

            statement.executeUpdate();

            errCode = statement.getString(5);
            errMsg = statement.getString(6);
            jobResult.setErrCode(errCode);
            jobResult.setErrMsg(errMsg);
            statement.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                if(statement != null)statement.close();
                if(conn != null)conn.close();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            throw new AppException(e.getMessage());
        }
        return jobResult;
    }

    public static void main(String[] args) {
        long s = 1568736000000L;

        System.out.println(new SimpleDateFormat("yyyyMMdd").format(s));
    }


}
