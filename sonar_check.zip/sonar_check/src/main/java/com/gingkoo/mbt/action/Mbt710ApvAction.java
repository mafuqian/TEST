package com.gingkoo.mbt.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommCreditReportApvService;
import com.gingkoo.orm.entity.MbtSendUserManage;

public class Mbt710ApvAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mbt710Apv_Bas_ds");
       /* new MbtCommApvService(resultBean, Mbt441.class)
                .approve();*/
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommCreditReportApvService mbtCommCreditReportApvService = (MbtCommCreditReportApvService) context.getBean("mbtCommCreditReportApvService");
        mbtCommCreditReportApvService.setEntityName(MbtSendUserManage.class.getName());
        mbtCommCreditReportApvService.setUpdateResultBean(resultBean);
        mbtCommCreditReportApvService.approve();
        //如果是审核通过插入核查表
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }
}
