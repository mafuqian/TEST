package com.gingkoo.mbt.service;

import com.gingkoo.common.query.entity.GpBmExportField;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.BaseService;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.gf4j2.framework.util.ExceptionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Component
public class ExportFieldConfigAlterService extends BaseService {

	@Resource
    private ROOTDAO rootDao;
    
    @Autowired
    private ExportSettingService exportSettingService;
    
    public static final String ID = "exportFieldConfigAlterService";
    public static final String CMD = "CMD";
    public static final String CMD_ADD = "CMD_ADD";
    public static final String CMD_BATCH_ADD = "CMD_BATCH_ADD";
    public static final String CMD_MOD = "CMD_MOD";
    public static final String CMD_DEL = "CMD_DEL";
    public static final String IN_PARAM = "IN_PARAM";
    public static final String IN_MAP = "IN_MAP";


    public void beforeProc(ServiceContext context) throws CommonException {
    }

    @SuppressWarnings("unchecked")
	public void execute(ServiceContext context) throws CommonException {
        String cmd = (String)context.getAttribute(CMD);
        GlobalInfo gl = GlobalInfo.getCurrentInstance();
        GpBmExportField gpBmExportField = (GpBmExportField)context.getAttribute(IN_PARAM);
        Map<String, String> map = (Map<String, String>)context.getAttribute(IN_MAP);
        if (CMD_ADD.equals(cmd)) {
        	checkFieldExistsWithAdd(gpBmExportField);
            gpBmExportField.setDataId(UuidHelper.getCleanUuid());
            setGpBmExportFieldCrtInfo(gpBmExportField, gl);
            this.rootDao.save(gpBmExportField);
        }else if(CMD_BATCH_ADD.equals(cmd)) {
        	int exportNumMax = exportSettingService.getGpBmExportFieldMaxSeqno(gpBmExportField.getPDataId());
        	String batchColumnName = map.get("batchColumnName");
        	String batchColumnComments = map.get("batchColumnComments");
        	String[] batchColumnN = batchColumnName.split(",");
        	String[] batchColumnC = batchColumnComments.split(",");
        	checkFieldExistsWithBatchAdd(gpBmExportField, batchColumnN, batchColumnC);
        	for(int i = 0 ; i < batchColumnC.length;i++) {
        		GpBmExportField field = new GpBmExportField();
        		int exportNum = exportNumMax+1+i;
        		field.setDataId(UuidHelper.getCleanUuid());
        		field.setPDataId(gpBmExportField.getPDataId());
        		field.setExportFlag(gpBmExportField.getExportFlag());
        		field.setColumnName(batchColumnN[i]);
        		field.setColumnComments(batchColumnC[i]);
        		field.setExportNum(BigDecimal.valueOf(exportNum));
        		field.setSeqNo(Integer.toString(exportNum));
        		field.setReadonlyFlag("N");
        		field.setDataDicNo("");
        		setGpBmExportFieldCrtInfo(field, gl);
        		this.rootDao.save(field);
        	}
        }else if (CMD_MOD.equals(cmd)) {
        	GpBmExportField field = exportSettingService.getGpBmExportFieldByDataId(gpBmExportField.getDataId());
        	gpBmExportField.setDataDate(field.getDataDate());
        	gpBmExportField.setCorpId(field.getCorpId());
        	gpBmExportField.setOrgId(field.getOrgId());
        	gpBmExportField.setDataCrtUser(field.getDataCrtUser());
        	gpBmExportField.setDataCrtDate(field.getDataCrtDate());
        	gpBmExportField.setDataCrtTime(field.getDataCrtTime());
        	setGpBmExportFieldChgInfo(gpBmExportField, gl);
            this.rootDao.saveOrUpdate(gpBmExportField);
        } else if (CMD_DEL.equals(cmd)) {
            String dataId = gpBmExportField.getDataId();
            this.rootDao.delete(GpBmExportField.class,dataId);
        }

    }

    public void afterProc(ServiceContext context) throws CommonException {
    }

    
    /**
	 * 补充新增信息。
	 * @param field
	 * @param gl
	 */
	public void setGpBmExportFieldCrtInfo(GpBmExportField field,GlobalInfo gl ) {
		field.setDataDate(DateUtil.get8Date());
		field.setCorpId(gl.getCorpId());
		field.setOrgId(gl.getBrno());
		field.setDataCrtUser(gl.getTlrno());
		field.setDataCrtDate(DateUtil.get8Date());
		field.setDataCrtTime(DateUtil.get14Date());
		setGpBmExportFieldChgInfo(field, gl);
	}
	
	/**
	 * 补充更新信息
	 * @param field
	 * @param gl
	 */
	public void setGpBmExportFieldChgInfo(GpBmExportField field,GlobalInfo gl ) {
		field.setDataChgUser(gl.getTlrno());
		field.setDataChgDate(DateUtil.get8Date());
		field.setDataChgTime(DateUtil.get14Date());
	}
	

	/**
	 * 检查新增的字段是否重复。
	 * @param gpBmExportField
	 * @return
	 * @throws CommonException
	 */
    public void checkFieldExistsWithAdd(GpBmExportField gpBmExportField) throws CommonException {
    	String currentFieldName = gpBmExportField.getColumnName().trim().toUpperCase();
    	String pDataId = gpBmExportField.getPDataId();
    	List<GpBmExportField> list = exportSettingService.getGpBmExportFieldList(pDataId);
    	String errmsg = "";
    	for (GpBmExportField field : list) {
			String fieldName = field.getColumnName().trim().toUpperCase();
			String fieldComments = field.getColumnComments();
			if(fieldName.equals(currentFieldName)) {
				errmsg = "添加的"+fieldName+"--"+fieldComments+"字段重复。";
				ExceptionUtil.throwCommonException(errmsg);
			}
		}
    	
    }
    
    
    /**
     * 检查 批量新增的字段是否重复。
     * @param gpBmExportField
     * @param batchColumnN
     * @param batchColumnC
     * @return
     * @throws CommonException
     */
    public void checkFieldExistsWithBatchAdd(GpBmExportField gpBmExportField ,String[] batchColumnN ,String[] batchColumnC) throws CommonException {
    	boolean existsFlag = false;
    	String currentFieldName = "";
    	String pDataId = gpBmExportField.getPDataId();
    	List<GpBmExportField> list = exportSettingService.getGpBmExportFieldList(pDataId);
    	StringBuilder sb = new StringBuilder("添加的");
    	for(int i = 0 ; i < batchColumnN.length ; i ++) {
    		currentFieldName = batchColumnN[i].trim().toUpperCase();
    		for (GpBmExportField field : list) {
    			String fieldName = field.getColumnName().trim().toUpperCase();
    			String fieldComments = field.getColumnComments();
    			if(fieldName.equals(currentFieldName)) {
    				existsFlag = true;
    				sb.append("字段：").append(fieldName).append("--").append(fieldComments).append(";");
    			}
    		}
    	}
    	if(existsFlag) {
    		sb.append("已存在，请重新选择字段。");
    		ExceptionUtil.throwCommonException(sb.toString());
    	}
    }
    
}
