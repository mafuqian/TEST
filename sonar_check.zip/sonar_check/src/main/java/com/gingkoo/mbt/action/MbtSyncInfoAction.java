package com.gingkoo.mbt.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.exception.AppException;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.OPCaller;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.orm.entity.MbtDataSyncInfoCnt;

public class MbtSyncInfoAction extends WebAlterAction {
	private static final String DATASET_ID = "ContractBase";

	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request,
			HttpServletResponse respone) throws AppException {
		UpdateReturnBean updateReturnBean = new UpdateReturnBean();
		ServiceContext oc = new ServiceContext();
		try {
			UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID("MbtSyncInfo_ds");
			String opr = updateResultBean.getParameter("opr");
			if (opr != null) {
				if("cnt".equals(opr)) {
					if(!updateResultBean.hasNext()) {
						OPCaller.call("mbtContractApvService", oc);
					}
					while (updateResultBean.hasNext()) {
						MbtDataSyncInfoCnt contractBase = new MbtDataSyncInfoCnt();
						Map<String, String> map = updateResultBean.next();
						mapToObject(contractBase, map);
						
						oc.setAttribute("IN_PARAM", contractBase);
						oc.setAttribute("CMD", "apv");
						try {
							OPCaller.call("mbtDataCntService", oc);
						} catch (CommonException e) {
							logger.error(e.getMessage());
							updateReturnBean.setParameter("res", e.getMessage());
							break;
						}
					}
				}else if ("sync".equals(opr)) {
					while (updateResultBean.hasNext()) {
						MbtDataSyncInfoCnt contractBase = new MbtDataSyncInfoCnt();
						Map<String, String> map = updateResultBean.next();
						mapToObject(contractBase, map);
						
						oc.setAttribute("IN_PARAM", contractBase);
						oc.setAttribute("CMD", "apv");
						try {
							OPCaller.call("mbtDataSyncService", oc);
						} catch (CommonException e) {
							logger.error(e.getMessage());
							updateReturnBean.setParameter("res", e.getMessage());
							break;
						}
					}
				}
				
			
			}	
			GlobalInfo.getCurrentInstance().appendBizLog("合同信息基础段");
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return updateReturnBean;
	}
}