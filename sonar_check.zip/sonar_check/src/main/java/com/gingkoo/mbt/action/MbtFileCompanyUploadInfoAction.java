package com.gingkoo.mbt.action;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.CollectionUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.mbt.service.MbtFileUploadService;

/**
 * @Author: li.jy
 * @Date: 2018/11/20
 */

public class MbtFileCompanyUploadInfoAction extends WebAlterAction {

    private static final Log logger = LogFactory.getLogger(MbtFileCompanyUploadInfoAction.class);

    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("MbtCompanyRptFile_ds");
        List<Map<String, String>> list = resultBean.getTotalList();
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        MbtFileUploadService mbtFileUploadService = ApplicationContextUtil.getBean(MbtFileUploadService.class);
        mbtFileUploadService.execute(list);
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }
}

