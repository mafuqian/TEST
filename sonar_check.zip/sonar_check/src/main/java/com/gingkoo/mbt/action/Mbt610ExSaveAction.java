package com.gingkoo.mbt.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.mbt.util.ExpCommUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.orm.entity.Mbt610Ex;

public class Mbt610ExSaveAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
//        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mat_610_Ex_610Bas_ds");
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResult().containsKey("Mat_610_Ex_610Bas_ds") ? multiUpdateResultBean.getUpdateResultBeanByID("Mat_610_Ex_610Bas_ds") : multiUpdateResultBean.getUpdateResultBeanByID("Mat_610_Ex_610Bas_2007_ds");

        //process(resultBean, Mbt610Ex.class);
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");
//        mbtCommSaveService.process(resultBean,Mbt610Ex.class);
        ExpCommUtils.process(resultBean,Mbt610Ex.class,mbtCommSaveService);

        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("dataId", mbtCommSaveService.getDataId());
        return returnBean;
    }
}
