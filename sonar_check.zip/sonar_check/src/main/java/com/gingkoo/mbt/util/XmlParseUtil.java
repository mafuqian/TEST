package com.gingkoo.mbt.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

public class XmlParseUtil {

	public static Document loadDocumentByPath(String path) throws DocumentException {
		SAXReader reader = new SAXReader();
		Document document = reader.read(new File(path));
		return document;
	}

	public static Document loadDocumentByResourcePath(InputStream path) throws DocumentException {
		SAXReader reader = new SAXReader();
		Document document = reader.read(path);
		return document;
	}

	public static Map<String, Document> loadDocumentsByPath(String path) throws DocumentException {
		File dir = new File(path);
		String[] files = dir.list();
		Map<String, Document> documents = new HashMap<String, Document>();
		for (String fileName : files) {
			SAXReader reader = new SAXReader();
			File file = new File(path, fileName);
			String key = fileName.substring(0, fileName.lastIndexOf("."));
			Document document = reader.read(file);
			documents.put(key, document);
		}
		return documents;
	}

	public static Map<String, Document> loadDocumentsByResourcePath(String path) throws DocumentException, IOException {
		ResourceLoader resourceLoader = new DefaultResourceLoader();
		Resource[] resources = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
				.getResources("classpath:" + path + "/*.xml");
		Map<String, Document> documents = new HashMap<String, Document>();
		for (Resource resource : resources) {
			String fileName = resource.getFilename();
			InputStream is = resource.getInputStream();
			String key = fileName.substring(0, fileName.lastIndexOf("."));
			SAXReader reader = new SAXReader();
			Document document = reader.read(is);
			documents.put(key, document);
		}
		return documents;
	}

	public static Document loadDocumentByText(String text) throws DocumentException {
		Document document = DocumentHelper.parseText(text);
		return document;
	}

	public static Document createDocument() {
		Document doc = DocumentHelper.createDocument();
		return doc;
	}

	@SuppressWarnings("unchecked")
	public static Map<String, Object> Dom2Map(Document doc) {
		Map<String, Object> map = new HashMap<String, Object>();
		if (doc == null)
			return map;
		Element root = doc.getRootElement();
		for (Iterator iterator = root.elementIterator(); iterator.hasNext();) {
			Element e = (Element) iterator.next();
			List list = e.elements();
			if (list.size() > 0) {
				map.put(e.getName(), Dom2Map(e));
			} else
				map.put(e.getName(), e.getText());
		}
		return map;
	}

	@SuppressWarnings("unchecked")
	public static Map Dom2Map(Element e) {
		Map map = new HashMap();
		List list = e.elements();
		if (list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				Element iter = (Element) list.get(i);
				List mapList = new ArrayList();

				if (iter.elements().size() > 0) {
					Map m = Dom2Map(iter);
					if (map.get(iter.getName()) != null) {
						Object obj = map.get(iter.getName());
						if (!obj.getClass().getName().equals("java.util.ArrayList")) {
							mapList = new ArrayList();
							mapList.add(obj);
							mapList.add(m);
						}
						if (obj.getClass().getName().equals("java.util.ArrayList")) {
							mapList = (List) obj;
							mapList.add(m);
						}
						map.put(iter.getName(), mapList);
					} else
						map.put(iter.getName(), m);
				} else {
					if (map.get(iter.getName()) != null) {
						Object obj = map.get(iter.getName());
						if (!obj.getClass().getName().equals("java.util.ArrayList")) {
							mapList = new ArrayList();
							mapList.add(obj);
							mapList.add(iter.getText());
						}
						if (obj.getClass().getName().equals("java.util.ArrayList")) {
							mapList = (List) obj;
							mapList.add(iter.getText());
						}
						map.put(iter.getName(), mapList);
					} else
						map.put(iter.getName(), iter.getText());
				}
			}
		} else
			map.put(e.getName(), e.getText());
		return map;
	}
}
// 1.获取文档的根节点.
// Element root = document.getRootElement();
// 2.取得某个节点的子节点.
// Element element=node.element(“四大名著");
// 3.取得节点的文字
// String text=node.getText();
// 4.取得某节点下所有名为“csdn”的子节点，并进行遍历.
// List nodes = rootElm.elements("csdn");
// for (Iterator it = nodes.iterator(); it.hasNext();) {
// Element elm = (Element) it.next();
// // do something
// }
// 5.对某节点下的所有子节点进行遍历.
// for(Iterator it=root.elementIterator();it.hasNext();){
// Element element = (Element) it.next();
// // do something
//// }
// 6.在某节点下添加子节点
// Element elm = newElm.addElement("朝代");
// 7.设置节点文字. elm.setText("明朝");
// 8.删除某节点.//childElement是待删除的节点,parentElement是其父节点
// parentElement.remove(childElment);
// 9.添加一个CDATA节点.Element contentElm =
// infoElm.addElement("content");contentElm.addCDATA(“cdata区域”);
//
