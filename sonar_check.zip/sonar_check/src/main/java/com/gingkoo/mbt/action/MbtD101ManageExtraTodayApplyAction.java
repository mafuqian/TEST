package com.gingkoo.mbt.action;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.D101AndD103Common.MbtD101AndD103CommonService;
import com.gingkoo.mbt.service.MbtD101AndD103ApplyService;
import com.gingkoo.orm.entity.MbtD101;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @Author: li.jy
 * @Date: 2019/1/30
 */
@Deprecated
public class MbtD101ManageExtraTodayApplyAction extends WebAlterAction {
    private static String TABLE_NAME = "MbtD101";
    private static String OPR = "opr";
    private static String OPR_DOWNLOAD = "download";
    private static String OPR_PRINT = "print";
    private static String OPR_BROWSE = "browse";
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(httpServletRequest.getServletContext());
        MbtD101AndD103ApplyService mbtD101AndD103Service = (MbtD101AndD103ApplyService) context.getBean("mbtD101AndD103ApplyService");
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("D101Qry_ds");
        mbtD101AndD103Service.apply(resultBean, TABLE_NAME);
        MbtD101AndD103CommonService commonService = new MbtD101AndD103CommonService();
        if (OPR_DOWNLOAD.equals(resultBean.getParamMap().get(OPR))) {
            resultBean.getTotalList().get(0).put("expLevel","提示");
            resultBean.getTotalList().get(0).put("desc","当日下载次数已超过规定值");

        } else if (OPR_PRINT.equals(resultBean.getParamMap().get(OPR))) {
            resultBean.getTotalList().get(0).put("expLevel","提示");
            resultBean.getTotalList().get(0).put("desc","当日打印次数已超过规定值");
        }
        commonService.record(resultBean,resultBean.getTotalList().get(0), MbtD101.class);
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }

}
