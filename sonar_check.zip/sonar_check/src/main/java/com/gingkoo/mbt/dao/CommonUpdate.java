package com.gingkoo.mbt.dao;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.excp.CommonException;

/**
 * 通用更新类，根据实例和要更新的字段更新某个实例。
 *
 * @author fuxiang.luo@gingkoo.com
 */
public class CommonUpdate {

    private static final Log logger = LogFactory.getLogger(CommonUpdate.class);

    /**
     * 某条数据中的一列
     * @param bean 待更新的实体
     * @param columnName 列名，即 bean的属性名
     * @param dataId 待更新行的数据ID
     * @param value 待更新的值
     * @return 1-更新成功，0-更新失败
     */
    public static int updateOneColumn(Class bean, String dataId, String columnName, String value){
        Map<String, String> param = new HashMap<>();
        param.put(columnName, value);
        param.put("dataId", dataId);
        return update(bean, param);
    }

    /**
     *
     * @param bean 待更新的实体，
     * @param parameters 更新的字段，必须包含 dataId
     * @return 1-更新成功， 0-更新失败。
     */
    public static int update(Class bean, Map<String, String> parameters){
        ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
        int updated = 0;

        String dataId = parameters.get("dataId");
        if(StringUtils.isEmpty(dataId)){
            logger.error("dataId 为空，此update方法不适用。");
        }else {

            //检索出待更新的实例
            Object beanToBeUpdate = null;
            try {
                Iterator iterator = rootdao.queryByQL("from " + bean.getTypeName() + " where dataId=?", new String[]{dataId}, null);
                if(iterator.hasNext()){
                    beanToBeUpdate = iterator.next();
                }
            } catch (CommonException e) {
                logger.error(e.getErrMessage());
            }

            if(beanToBeUpdate!=null){
                //设置参数
                for (Map.Entry<String, String> parameter : parameters.entrySet()){
                    try {
                        BeanUtils.setProperty(beanToBeUpdate, parameter.getKey(), parameter.getValue());
                    } catch (IllegalAccessException | InvocationTargetException e) {
                        logger.error(e.getLocalizedMessage());
                        return 0;
                    }
                }
                try {
                    rootdao.update(beanToBeUpdate);
                    updated = 1;
                } catch (CommonException e) {
                    logger.error(e.getErrMessage());
                }
            }
        }

        return updated;
    }

}
