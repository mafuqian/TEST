package com.gingkoo.mbt.action;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommCommitToApvService;
import com.gingkoo.orm.entity.Mbt421;
import com.gingkoo.orm.entity.Mbt440;
import com.gingkoo.orm.entity.Mbt440D;
import com.gingkoo.orm.entity.Mbt440E;

public class Mbt440CommitAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        String dsId = multiUpdateResultBean.getUpdateResult().containsKey("Mat_440_TabPageList_ds") ? "Mat_440_TabPageList_ds" : "Mat_440_ds";
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID(dsId);

        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommCommitToApvService mbtCommCommitToApvService = (MbtCommCommitToApvService) context.getBean("mbtCommCommitToApvService");


        Map<String,String> map = new HashMap<>();
        map.put("dataId","dataId");
        map.put("type","B");
        String flag = mbtCommCommitToApvService.validateFields(Mbt440.class,resultBean, returnBean,map);
        map.put("dataId","pdataId");
        map.put("type","D");
        String flag1 = mbtCommCommitToApvService.validateFields(Mbt440D.class,resultBean, returnBean,map);
        map.put("type","E");
        String flag2 = mbtCommCommitToApvService.validateFields(Mbt440E.class,resultBean, returnBean,map);
        if (flag.equals("failed") || flag1.equals("failed") || flag2.equals("failed")) {
            return returnBean;
        }

		mbtCommCommitToApvService.commitToApprove(resultBean, Mbt440.class,returnBean);
        if("".equals(returnBean.getParameter("E_CODE"))) {
        	returnBean.setParameter("isOptSucc", "true");
        }else {
        	returnBean.setParameter("isOptSucc", "false");
        }
        return returnBean;
    }
}
