package com.gingkoo.mbt.action;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.service.base.OPCaller;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.mbt.service.EntObjAlterService;
import com.gingkoo.mbt.service.EntObjAlterService;
import com.gingkoo.mbt.service.PersonalObjService;
import com.gingkoo.orm.entity.ToCheckInf;
import com.gingkoo.orm.entity.ToEntCheckInf;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

public class EntObjGzResultAlterAction extends WebAlterAction {
    private static final String DATASET_ID = "EntObj_ObjGz_ds";
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse respone) throws AppException {
        UpdateReturnBean updateReturnBean = new UpdateReturnBean();
        UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
        ServiceContext oc = new ServiceContext();
        ToEntCheckInf toEntCheckInf = new ToEntCheckInf();

        Map<String, String> map = updateResultBean.next();
        String correctState= map.get("correctState");
        String objCheckId= map.get("objCheckId");
        String dataProviderOrgCode= map.get("dataProviderOrgCode");
        if (correctState.equals("4") || correctState.equals("6") ){
            PersonalObjService personalObjService=new PersonalObjService();
            Map<String,String> fileStr= personalObjService.shengchengfiles(map,toEntCheckInf,"G107.ftl");

            boolean result=personalObjService.psObjCorrectResultQueryReq("");
            if (result){
                map.put("correctState","7");
                oc.setAttribute(EntObjAlterService.CMD, EntObjAlterService.CMD_MOD);
                mapToObject(toEntCheckInf, map);
                oc.setAttribute(EntObjAlterService.IN_PARAM, toEntCheckInf);
                OPCaller.call(EntObjAlterService.ID , oc);
                updateReturnBean.setParameter("isOptSucc", "true");


            }else {
                map.put("correctState","6");
                oc.setAttribute(EntObjAlterService.CMD, EntObjAlterService.CMD_MOD);
                mapToObject(toEntCheckInf, map);
                oc.setAttribute(EntObjAlterService.IN_PARAM, toEntCheckInf);
                OPCaller.call(EntObjAlterService.ID , oc);
                updateReturnBean.setParameter("isOptSucc", "true");
            }
            updateReturnBean.setParameter("isOptSucc", "true");

        } else{
            updateReturnBean.setParameter("isOptSucc", "true");
        }

        return updateReturnBean;
    }
}
