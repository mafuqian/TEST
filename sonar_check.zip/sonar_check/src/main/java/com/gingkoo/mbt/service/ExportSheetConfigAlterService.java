package com.gingkoo.mbt.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.common.query.entity.GpBmExportSheet;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.GpBmInqCfg;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.BaseService;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.gf4j2.framework.util.ExceptionUtil;

@Component
public class ExportSheetConfigAlterService extends BaseService {
	@Resource
	private ROOTDAO rootDao;
	@Autowired
	private ExportSettingService exportSettingService;
	@Autowired
	private GpBmInqCfgQueryService inqCfgQueryService;
	

	public static final String ID = "exportSheetConfigAlterService";
	public static final String CMD = "CMD";
	public static final String CMD_ADD = "CMD_ADD";
	public static final String CMD_MOD = "CMD_MOD";
	public static final String CMD_DEL = "CMD_DEL";
	public static final String IN_PARAM = "IN_PARAM";
	public static final String SQL_SUFFIX = "_TemQry";
	public static final String SQL_PREFIX = "Export_";

	public void beforeProc(ServiceContext context) throws CommonException {
	}

	public void execute(ServiceContext context) throws CommonException {
		GlobalInfo gl = GlobalInfo.getCurrentInstance();
		String cmd = (String) context.getAttribute(CMD);
		GpBmExportSheet gpBmExportSheet = (GpBmExportSheet) context.getAttribute(IN_PARAM);
		List<GpBmExportSheet> sheetList = exportSettingService.getGpBmExportSheetList(gpBmExportSheet.getPDataId());
		String exportStrategyType =exportSettingService.getGpBmExportFunctionExportStrategyType(gpBmExportSheet.getPDataId());
		JobResult jr = new JobResult();
		if (CMD_ADD.equals(cmd)) {//首先根据sqlFlag检查sql语句是否正确；再检查主sheet是否冲突；再保存sql语句到数据库中。
			gpBmExportSheet.setDataId(UuidHelper.getCleanUuid());
			gpBmExportSheet.setGuid(gpBmExportSheet.getDataId());
			gpBmExportSheet.setSheetNum((long)(sheetList.size()+1));
			jr = checkTableNameWithAdd(gpBmExportSheet,sheetList);
			if (!"00".equals(jr.getErrCode())) {
				ExceptionUtil.throwCommonException(jr.getErrMsg());
			}
			jr = checkSqlFlag(gpBmExportSheet);//检查sql语句
			if (!"00".equals(jr.getErrCode())) {
				ExceptionUtil.throwCommonException(jr.getErrMsg());
			}
			jr = checkMainSheetFlag(gpBmExportSheet);//判断是否已经存在主sheet。
			if (!"00".equals(jr.getErrCode())) {
				ExceptionUtil.throwCommonException(jr.getErrMsg());
			}
			saveSqlInfoWithCmdAdd(gpBmExportSheet);
			setGpBmExportSheetCrtInfo(gpBmExportSheet, gl);
			this.rootDao.save(gpBmExportSheet);
		} else if (CMD_MOD.equals(cmd)) {//首先根据sqlFlag检查sql语句是否正确；再检查主sheet是否冲突；再保存sql语句到数据库中。
			jr = checkSqlFlag(gpBmExportSheet);//检查sql语句
			if (!"00".equals(jr.getErrCode())) {
				ExceptionUtil.throwCommonException(jr.getErrMsg());
			}
			jr = checkMainSheetFlag(gpBmExportSheet);//判断是否已经存在主sheet。
			if (!"00".equals(jr.getErrCode())) {
				ExceptionUtil.throwCommonException(jr.getErrMsg());
			}
			saveSqlInfoWithCmdMod(gpBmExportSheet);
			
			//从数据库中获取当前的数据的系统值，并赋值给实体。。
			GpBmExportSheet sheet = exportSettingService.getGpBmExportSheetByDataId(gpBmExportSheet.getDataId());
			gpBmExportSheet.setDataDate(sheet.getDataDate());
			gpBmExportSheet.setCorpId(sheet.getCorpId());
			gpBmExportSheet.setOrgId(sheet.getOrgId());
			gpBmExportSheet.setDataCrtUser(sheet.getDataCrtUser());
			gpBmExportSheet.setDataChgDate(sheet.getDataChgDate());
			gpBmExportSheet.setDataChgTime(sheet.getDataChgTime());
			setGpBmExportSheetChgInfo(gpBmExportSheet, gl);
			this.rootDao.saveOrUpdate(gpBmExportSheet);
		} else if (CMD_DEL.equals(cmd)) {//首先删除字段配置；再删除sheet配置；再删除sql语句。
			String pguid = gpBmExportSheet.getDataId();
			exportSettingService.deleteExportFieldData(pguid);
			this.rootDao.delete(GpBmExportSheet.class, pguid);
			if("00".equals(gpBmExportSheet.getMainSheetFlag())){//如果是非主sheet，则必有sql语句。则删除sql语句
				this.rootDao.delete(GpBmInqCfg.class,gpBmExportSheet.getSqlDataId());				
			}
		}

	}




	public void afterProc(ServiceContext context) throws CommonException {
	}
	
	
	/**
	 * 检查tableName是否重复。
	 * @param gpBmExportSheet
	 * @param sheetList
	 */
	private JobResult checkTableNameWithAdd(GpBmExportSheet gpBmExportSheet, List<GpBmExportSheet> sheetList) {
		String tableName = gpBmExportSheet.getTableName().trim().toUpperCase();
		JobResult jr = new JobResult();
		jr.setErrCode("00");
		jr.setErrMsg("OK");
		for(int i = 0 ; i < sheetList.size(); i++) {
			String tableName1 = sheetList.get(i).getTableName().trim().toUpperCase();
			if(tableName.equals(tableName1)) {
				jr.setErrCode("11");
				jr.setErrMsg("表名重复，请重新输入。");
				break;
			}
		}
		return jr;
	}
	
	

	/**
	 * 根据sql生成策略，检查前台传值是否符合制定的规则。
	 * 
	 * @param gpBmExportSheet
	 * @return
	 * @throws CommonException
	 */
	@SuppressWarnings("unchecked")
	private JobResult checkSqlFlag(GpBmExportSheet gpBmExportSheet) throws CommonException {
		JobResult jr = new JobResult();
		String tableName = gpBmExportSheet.getTableName().toUpperCase();
		gpBmExportSheet.setTableName(tableName);
		String sqlFlag = gpBmExportSheet.getSqlFlag();
		if ("00".equals(sqlFlag)) {// 默认方法，即使用页面上的sql获取dataId,再根据dataId进行查询。
			String sqlString = inqCfgQueryService.getSqlStringByTabelName(gpBmExportSheet.getTableName()).toUpperCase();//根据获取sql语句。
			gpBmExportSheet.setSqlString(sqlString);
		} else if ("01".equals(sqlFlag)) {// 自动生成sql. 将从系统底层视图中查询出当前表的所有字段信息。
			String sqlString = inqCfgQueryService.getSqlStringByTabelName(gpBmExportSheet.getTableName()).toUpperCase();//根据获取sql语句。
			gpBmExportSheet.setSqlString(sqlString);
		} else if ("02".equals(sqlFlag)) {// 手工填写sql，校验sql是否符合规则 ，
			String sqlString = gpBmExportSheet.getSqlString().toUpperCase();
			jr = inqCfgQueryService.checkSqlStringMatchRule(tableName, sqlString);
			gpBmExportSheet.setSqlString(sqlString);
		} else if ("03".equals(sqlFlag)) {// 填写sqlId。检查sql是否存在。
			String sqlId = gpBmExportSheet.getSqlId();
			jr = inqCfgQueryService.checkSqlIdisExists(sqlId);
			if("00".equals(jr.getErrCode())){
				GpBmInqCfg gpBmInqCfg = inqCfgQueryService.getGpBmInqCfgBySqlId(sqlId);
				String sqlString = gpBmInqCfg.getSqlString();
				String dataId = gpBmInqCfg.getDataId();
				if(dataId.trim().length()!=32) {//如果不是系统生成的dataId,需要将原来的语句删掉，
					inqCfgQueryService.deleteGpBmInqCfg(sqlId);
					dataId = UuidHelper.getCleanUuid();
					inqCfgQueryService.saveGpBmInqCfg(dataId, sqlId.toUpperCase(), sqlString);
				}
				gpBmExportSheet.setSqlString(sqlString);//修改，不做变形，另外同时更新GP_BM_INQ_CFG设置dataiD为系统设置值。
				gpBmExportSheet.setSqlDataId(dataId);
				gpBmExportSheet.setSqlId(sqlId.toUpperCase());
			}
			
		} else {
			jr.setErrCode("08");
			jr.setErrMsg("输入参数不合法。");
		}
		return jr;
	}

	/**
	 * 新增时，保存sql语句。
	 * @param sheet
	 * @throws CommonException
	 */
	private void saveSqlInfoWithCmdAdd(GpBmExportSheet sheet) throws CommonException {
		String sqlFlag = sheet.getSqlFlag();
		String tableName = sheet.getTableName();
		String sqlId = "";
		
		switch(sqlFlag) {
		case "00"://自动获取sql
			sheet.setSqlDataId(UuidHelper.getCleanUuid());
			sqlId =getSqlIdDynamic(tableName).toUpperCase();
			sheet.setSqlId(sqlId);
			inqCfgQueryService.saveGpBmInqCfg(sheet.getSqlDataId(), sqlId, sheet.getSqlString());
			break;
		case "01"://自动获取sql
			sheet.setSqlDataId(UuidHelper.getCleanUuid());
			sqlId =getSqlIdDynamic(tableName).toUpperCase();
			sheet.setSqlId(sqlId);
			inqCfgQueryService.saveGpBmInqCfg(sheet.getSqlDataId(), sqlId, sheet.getSqlString());
			break;
		case "02"://手写sql
			sheet.setSqlDataId(UuidHelper.getCleanUuid());
			sqlId =getSqlIdDynamic(tableName).toUpperCase();
			sheet.setSqlId(sqlId);
			inqCfgQueryService.saveGpBmInqCfg(sheet.getSqlDataId(), sqlId, sheet.getSqlString());
			break;
		case "03"://sqlid
//			sqlId = sheet.getSqlId().toUpperCase();
//			sheet.setSqlId(sqlId);
//			inqCfgQueryService.saveGpBmInqCfg(sheet.getSqlDataId(), sqlId, sheet.getSqlString());
			break;
		}
	}
	
	
	/**
	 * 修改时，表名不允许修改，保存sql语句。
	 * @param sheet
	 * @throws CommonException
	 */
	private void saveSqlInfoWithCmdMod(GpBmExportSheet sheet) throws CommonException {
		String sqlFlag = sheet.getSqlFlag();
		String tableName = sheet.getTableName();
		String sqlDataId = sheet.getSqlDataId();
		GpBmExportSheet gpBmExportSheet = exportSettingService.getGpBmExportSheetByDataId(sheet.getDataId());
		String sqlFlagDb = gpBmExportSheet.getSqlFlag();
		GpBmInqCfg inq = inqCfgQueryService.queryGpBmInqCfgByDataId(sqlDataId);
		String sqlId = sheet.getSqlId().toUpperCase();
		if(!sqlFlagDb.equals(sqlFlag)) {
			switch(sqlFlag) {
			case "00":
				if("03".equals(sqlFlagDb)) {
					sqlId =getSqlIdDynamic(tableName).toUpperCase();
					sheet.setSqlId(sqlId);	
				}
				inqCfgQueryService.saveGpBmInqCfg(sheet.getSqlDataId(), sqlId, sheet.getSqlString());
				break;
			case "01"://自动获取sql
				if("03".equals(sqlFlagDb)) {//如果数据库中的sql语句中和当前修改后的tableName 不一致。
					sqlId =getSqlIdDynamic(tableName).toUpperCase();
					sheet.setSqlId(sqlId);				
				}
				inqCfgQueryService.saveGpBmInqCfg(sheet.getSqlDataId(), sqlId, sheet.getSqlString());
				break;
			case "02"://手写sql
				if("03".equals(sqlFlagDb)) {//如果数据库中的sql语句中和当前修改后的tableName 不一致。
					sqlId =getSqlIdDynamic(tableName).toUpperCase();
					sheet.setSqlId(sqlId);				
				}
				inqCfgQueryService.saveGpBmInqCfg(sheet.getSqlDataId(), sqlId, sheet.getSqlString());
				break;
			case "03"://sqlId
//				sheet.setSqlId(sqlId);
//				inqCfgQueryService.saveGpBmInqCfg(sheet.getSqlDataId(), sqlId, sheet.getSqlString());
				break;
			}
		}
		
	}
	
	
	/**
	 * 根据当前的GpBmExportSheet进行判断，如果已经存在mainSheet，则返回错误。
	 * 逻辑：一个菜单导出只有一个主sheet。
	 * @param sheet
	 * @return
	 * @throws CommonException 
	 */
	private JobResult checkMainSheetFlag(GpBmExportSheet sheet) throws CommonException {
		JobResult jr = new JobResult();
		jr.setErrCode("00");
		jr.setErrMsg("OK");
		String mainSheetFlag = sheet.getMainSheetFlag();//00-否，01-是
		if("01".equals(mainSheetFlag)) {
			String dataId = exportSettingService.getGpBmExportSheetMainSheetDataId(sheet.getPDataId());
			if(!"".equals(dataId)) {
				if(!dataId.equals(sheet.getDataId())) {
					jr.setErrCode("10");
					jr.setErrMsg("主sheet已存在，请重新设置。");
				}
				
			}
		}
		return jr;
	}

	
	/**
	 * 根据表名动态生成SqlId
	 * @param tableName
	 * @param sqlId
	 * @return
	 * @throws CommonException
	 */
	private String getSqlIdDynamic(String tableName) throws CommonException {
		boolean sqlExists = true;
		String sqlId = SQL_PREFIX+tableName+SQL_SUFFIX;
		int i = 1;
		while(sqlExists) {
			sqlExists = inqCfgQueryService.sqlIdIsExists(sqlId.toUpperCase());
			if(sqlExists) {
				sqlId = sqlId+i;				
				i++;
			}
		}
		return sqlId;
	}
	
	
	/**
	 * 补充新增信息。
	 * @param sheet
	 * @param gl
	 */
	public void setGpBmExportSheetCrtInfo(GpBmExportSheet sheet,GlobalInfo gl ) {
		sheet.setDataDate(DateUtil.get8Date());
		sheet.setCorpId(gl.getCorpId());
		sheet.setOrgId(gl.getBrno());
		sheet.setDataCrtUser(gl.getTlrno());
		sheet.setDataCrtDate(DateUtil.get8Date());
		sheet.setDataCrtTime(DateUtil.get14Date());
		setGpBmExportSheetChgInfo(sheet, gl);
	}
	
	/**
	 * 补充更新信息
	 * @param sheet
	 * @param gl
	 */
	public void setGpBmExportSheetChgInfo(GpBmExportSheet sheet,GlobalInfo gl ) {
		sheet.setDataChgUser(gl.getTlrno());
		sheet.setDataChgDate(DateUtil.get8Date());
		sheet.setDataChgTime(DateUtil.get14Date());
	}
	
	
}
