package com.gingkoo.mbt.action;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.orm.entity.MbtUnusalList;

import java.util.Map;


public class Mbt422AllDelAction extends MbtUpdCommitAction{

	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
			throws AppException {
		// TODO Auto-generated method stub
		UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mbt422Upd_ds");
		Map<String, String> recordMap = resultBean.getTotalList().get(0);
		recordMap.put("tableName","Mbt420Rpt");

		process(resultBean, MbtUnusalList.class);
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
	}

}
