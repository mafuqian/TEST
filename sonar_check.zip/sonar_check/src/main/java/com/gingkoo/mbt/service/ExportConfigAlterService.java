package com.gingkoo.mbt.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.gingkoo.common.batch.entity.GpBmIdFiledata;
import com.gingkoo.common.query.entity.GpBmExportFunction;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.BaseService;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;

@Component
public class ExportConfigAlterService extends BaseService {
	@Resource
	private ROOTDAO rootDao;
	@Autowired
	private ExportSettingService service;
	@Autowired
	private GpBmIdImportSettingService importSettingService;
	@Autowired
	private ExportConfigSyncImportService exportConfigSyncImportService;

	
	
	public static final String ID = "exportConfigAlterService";
	public static final String CMD = "CMD";
	public static final String CMD_ADD = "CMD_ADD";
	public static final String CMD_MOD = "CMD_MOD";
	public static final String CMD_DEL = "CMD_DEL";
	public static final String IN_PARAM = "IN_PARAM";

	public void beforeProc(ServiceContext context) throws CommonException {
	}

	public void execute(ServiceContext context) throws CommonException {
		String cmd = (String) context.getAttribute("CMD");
		GpBmExportFunction gpBmExportFunction = (GpBmExportFunction) context.getAttribute("IN_PARAM");
		if ("CMD_ADD".equals(cmd)) {//新增时，同时生成导入配置
			gpBmExportFunction.setDataId(UuidHelper.getCleanUuid());
			gpBmExportFunction.setGuid(gpBmExportFunction.getDataId());
			checkFileName(gpBmExportFunction);//检查文件名
//			checkGpBmIdFiledataByexportStrategyType(gpBmExportFunction);//根据到处策略类型检查并更新导入配置
			this.rootDao.save(gpBmExportFunction);
		} else if ("CMD_MOD".equals(cmd)) {//修改时，同时检查导入配置并同时修改
			checkFileName(gpBmExportFunction);//检查文件名
//			checkGpBmIdFiledataByexportStrategyType(gpBmExportFunction);//根据到处策略类型检查并更新导入配置
			this.rootDao.update(gpBmExportFunction);
		} else if ("CMD_DEL".equals(cmd)) {//删除时，删除导出配置，并同时删除导入配置。
			String pDataId = gpBmExportFunction.getDataId();
			service.deleteExportSheetData(pDataId);
//			service.deleteImportGpBmIdFiledata(gpBmExportFunction.getGuid());
			this.rootDao.delete(GpBmExportFunction.class, pDataId);
		}
		exportConfigSyncImportService.execute(ExportConfigSyncImportService.FILE, gpBmExportFunction.getDataId());
	}

	@Override
	public void afterProc(ServiceContext context) throws CommonException {
		// TODO Auto-generated method stub

	}

	/**
	 * 校验文件名。 当文件导出策略为只导出时，文件名不能以 “ExcelTemplate_” 开头
	 * 当文件导出策略为导出并导入时，文件名必须以“ExcelTemplate_”开头。
	 * 
	 * @param gpBmExportFunction
	 */
	private void checkFileName(GpBmExportFunction gpBmExportFunction) {
		String exportStrategyType = gpBmExportFunction.getExportStrategyType();// 导出策略
		String fileName = gpBmExportFunction.getFileName();
		if ("onlyExport".equals(exportStrategyType)) {// 只导出
			if (fileName.trim().startsWith("ExcelTemplate_")) {
				fileName = fileName.trim().substring(14);
			}
		} else if ("exportAndImport".equals(exportStrategyType)) {// 导出并导入
			if(!fileName.trim().startsWith("ExcelTemplate_")) {
				fileName = "ExcelTemplate_"+fileName.trim();
			}
		}
		gpBmExportFunction.setFileName(fileName);
	}
	
	/**
	 * 根据导出策略类型判断，是否需要自动生成文件导入配置
	 * 当导出策略类型为  “exportAndImport” 时，自动生成导入配置。
	 * 当导出策略类型为“”时，则不生成导入配置；如果已经有导入配置，则删除。
	 * @param gpBmExportFunction
	 * @throws CommonException 
	 */
	private void checkGpBmIdFiledataByexportStrategyType(GpBmExportFunction gpBmExportFunction) throws CommonException {
		String exportStrategyType = gpBmExportFunction.getExportStrategyType();
		String guid = gpBmExportFunction.getGuid();
		List<GpBmIdFiledata> filedataList = new ArrayList<GpBmIdFiledata>();
		filedataList = importSettingService.getImportGpBmIdFiledataByGuid(guid);
		int size = filedataList.size();
		if ("onlyExport".equals(exportStrategyType)) {// 只导出
			if(size>0) { //如果导出策略类型为只导出，且存在导入配置，则删除该导入配置。
				GpBmIdFiledata fileData = filedataList.get(0);
				importSettingService.deleteImportGpBmIdFiledata(fileData.getGuid());
			}
		} else if ("exportAndImport".equals(exportStrategyType)) {// 导出并导入
			if(size>0) {//如果导出策略配置为导出并导入。且存在导入配置，则更新该导入配置。
				importSettingService.updateGpBmIdFiledataByGpBmExportFunction(gpBmExportFunction);
			}else {//如果导出策略配置为导出并导入。且没有 导入配置，则生成该导入配置。
				importSettingService.generateGpBmIdFiledataByGpBmExportFunction(gpBmExportFunction);
			}
		}
	}
	
}
