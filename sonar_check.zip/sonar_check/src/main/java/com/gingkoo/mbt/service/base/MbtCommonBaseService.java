package com.gingkoo.mbt.service.base;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.workflow.entity.GpBmNextAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.orm.entity.GpBmBusinessParam;

/**
 *
 * 通用的增删改服务 继承自CommonBaseService 若GlobalInfo不存在的时候不报错 会创建一个空的GlobalInfo对象
 *
 * @author kane
 * @version [版本号, 2016年10月18日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
@Component
public class MbtCommonBaseService  {
	private static final Log logger = LogFactory
			.getLogger(MbtCommonBaseService.class);

	public Map<String,String> RedataStatus(Map<String,String> map) {
		Map<String,String> errMsg = new HashMap<String,String>();
		String newDataStatus ="";
		StringBuffer actionId = new StringBuffer();
		String currDataStatus = map.get("currDataStatus");
		GlobalInfo globalInfo = null;
		try {
			globalInfo = GlobalInfo.getCurrentInstance();
			GpBmNextAction ga = new GpBmNextAction();
			ga.setCorpId(globalInfo.getCorpId());
			ga.setCurrDataStatus(currDataStatus);
			actionId.append(globalInfo.getFuncId()+"_"+map.get("actionId"));
			ga.setActionId(actionId.toString());
			ga.setConditionId("001");
			logger.info("======= 查询NEXT_ACTION =======");
			logger.info("CORP_ID[" + ga.getCorpId()
					+ "] CURR_DATA_STATUS[" + ga.getCurrDataStatus()
					+ "] ACTION_ID[" + ga.getActionId()
					+ "] CONDITION_ID[" + ga.getConditionId() + "]");
			//hql查询
			String sql = " from GpBmNextAction where (corpId=? or corpId is null) and currDataStatus=? and actionId=? ";
			ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();

			List<GpBmNextAction> resultList = rootdao.queryByQL2List(sql, new Object[] { globalInfo.getCorpId(),currDataStatus,actionId.toString()}, null);
			if(!resultList.isEmpty()) {
				GpBmNextAction GpBmNextAction=	resultList.get(0);
				newDataStatus = GpBmNextAction.getDataStatus();
				errMsg.put("dataStatus", newDataStatus);
			}else {
				errMsg.put("errMsg", "未查询到对应的dataStatus值，请检查配置表");
			}

		} catch (CommonException e) {
			e.printStackTrace();
		}

		return errMsg;
	}

    public String getParamValue(String paramId) throws AppException {
        ROOTDAO dao = ROOTDAOUtils.getROOTDAO();
        // 参数表获取PDF文件保存路径
        String sql = "from GpBmBusinessParam where paramId='" + paramId + "'";
        List<GpBmBusinessParam> gpBmBusinessParamList = dao.queryByQL2List(sql);
        if (CollectionUtils.isEmpty(gpBmBusinessParamList)) {
            throw new AppException("请设置-" + paramId);
        }
        return gpBmBusinessParamList.get(0).getParamValue();
    }

}
