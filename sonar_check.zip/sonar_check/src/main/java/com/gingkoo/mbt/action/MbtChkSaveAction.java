package com.gingkoo.mbt.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.orm.entity.MbtToChkInfo;

public class MbtChkSaveAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
            throws AppException {
        // TODO Auto-generated method stub
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("MbtChk_Info_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
/*        if("failed".equals(validateFields(resultBean, returnBean))){
            return returnBean;
        }*/
//        if(StringUtils.isEmpty(recordMap.get("dataId")) || StringUtils.isEmpty(recordMap.get("bInfRecType"))){
//            recordMap.put("bInfRecType", "650");
//        }
    //    process(resultBean, MbtToChkInfo.class);
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");
        mbtCommSaveService.process(resultBean,MbtToChkInfo.class);

        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("dataId", mbtCommSaveService.getDataId());
        return returnBean;
    }
}
