package com.gingkoo.mbt.service;

import com.gingkoo.common.workflow.entity.bean.TaskTotal;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.dao.range.PageQueryCondition;
import com.gingkoo.gf4j2.framework.dao.range.PageQueryResult;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.util.DateHelper;
import com.ibm.icu.text.SimpleDateFormat;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.*;

/**
 * 首页service
 */

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class HomePageService {

	private Log logger = LogFactory.getLogger(HomePageService.class);

	@Autowired
	private ROOTDAO rootdao;
	//待办事项service
	@Autowired
    private HomePageTodoTasksService homePageTodoTasksService;

    private List<TaskTotal> taskTotalList = null;
	/**
	 * 登陆信息
	 */
	@SuppressWarnings("rawtypes")
	public Map<String, Object> getLoginInfo(String tlrNo) throws AppException {
		/*
		 * Map<String, String> recordMap; if(updateResultBean.hasNext()){ recordMap =
		 * updateResultBean.next(); }else { throw new AppException("参数为空"); }
		 * 
		 * updateResultBean.getParamMap().forEach((k, v)->{
		 * if(StringUtils.isEmpty(recordMap.get(k))){ recordMap.put(k,v); } });
		 * 
		 * String tlrNo = recordMap.get("tlrNo");
		 */

		Map<String, Object> result = new LinkedHashMap<String, Object>();
		result.put("hasError", 1);
		result.put("message", "");
		// 检查tlrNo
		if (StringUtils.isEmpty(tlrNo)) {
			logger.error("提交的数据必须包含tlrNo字段");
			throw new AppException("提交的数据不合法。");
		}
		Iterator resultDs = rootdao.queryBySQL("select A.LAST_ACCESS_TIME,A.LAST_FAILED_TIME,A.BRNO,B.BRNAME from GP_BM_TLR_INFO A, GP_BM_BRANCH B where A.BRNO=B.BRNO and A.TLRNO='" + tlrNo + "'");

//		Iterator resultDs = rootdao.queryBySQL("SELECT L.BR_NO,L.LOGIN_SUC_TM,L.LOGIN_FAIL_TM,B.BRNAME FROM GP_BM_LOGIN_LOG L, GP_BM_BRANCH B WHERE L.BR_NO = B.BRNO and L.TLR_NO='" + tlrNo + "'");
		while (resultDs.hasNext()) {
			Object[] object = (Object[]) resultDs.next();
			Map<String, Object> tempResult = new LinkedHashMap<String, Object>();
			try {
				tempResult.put("tlrNo", tlrNo);
				tempResult.put("brNo", new StringBuilder().append(object[2]).append("-").append(object[3]).toString());
				tempResult.put("loginSucTm", object[0] != null ? object[0].toString() : "");
				tempResult.put("loginFailTm", object[1] != null ? object[1].toString() : "");
				result.put("data", tempResult);
				//登录成功将LAST_ACCESS_TIME设置为现在
				String time = DateHelper.now();
				String sql = "update GP_BM_TLR_INFO set LAST_ACCESS_TIME='"+time+"' where TLRNO='" + tlrNo + "'";
				rootdao.updateBySQL(sql);
				break;
			} catch (Exception e) {
				logger.error(e.getLocalizedMessage());
				//登录失败将LAST_FAILED_TIME设置为现在
				String time = DateHelper.now();
				String sql = "update GP_BM_TLR_INFO set LAST_FAILED_TIME='"+time+"' where TLRNO='" + tlrNo + "'";
				rootdao.updateBySQL(sql);
				throw new AppException("获取登陆信息失败");
			}
		}

		return result;
	}

	/**
	 * 获取任务统计信息
	 */
	public Map<String, Object> getTaskStatistics(String tlrNo) throws AppException {
		Map<String, Object> result = new LinkedHashMap<String, Object>();
		result.put("hasError", 1);
		result.put("message", "");
		// 检查tlrNo
		if (StringUtils.isEmpty(tlrNo)) {
			logger.error("提交的数据必须包含tlrNo字段");
			throw new AppException("提交的数据不合法。");
		}
		Map<String, Object> tempResult = new LinkedHashMap<String, Object>();
		long iTasks = 0L;
		taskTotalList = null;
		while (taskTotalList == null ){
		    try {
		    Thread.sleep(10);
            }catch (Exception e){
		        e.printStackTrace();
		        iTasks = 0L;
		        break;
            }
        }
        for (TaskTotal task : taskTotalList){
		    try{
                long num = Long.valueOf(task.getTaskCount());
                iTasks = iTasks+num;
            }catch (Exception e){
                e.printStackTrace();
                iTasks = 0L;
                break;
            }

        }

		tempResult.put("processedProp", 0);
		tempResult.put("iTasks", iTasks);
		tempResult.put("iCompleteTasks", 0);
		result.put("data", tempResult);

		return result;

	}

	/**
	 * 获取报送统计
	 */
	@SuppressWarnings("rawtypes")
	public Map<String, Object> getReportStatistics(String censusType) throws AppException {
		Map<String, Object> result = new LinkedHashMap<String, Object>();
		result.put("hasError", 1);
		result.put("message", "");
		// 检查censusType
		if (StringUtils.isEmpty(censusType)) {
			logger.error("提交的数据必须包含censusType字段");
			throw new AppException("提交的数据不合法。");
		}

		// 检查tlrNo
		if (StringUtils.isEmpty(censusType)) {
			censusType = "2";// 默认是月
		}
		BigDecimal reportNum = new BigDecimal(0);
		BigDecimal feedbackNum = new BigDecimal(0);
		List<Map<String, Object>> mList = new ArrayList<Map<String, Object>>();
		Iterator resultDs = null;
		if ("1".equals(censusType)) {
			resultDs = rootdao.queryBySQL("SELECT CRTTIME reportSize, RC reportNum,EC feedbackNum FROM "
					+ "(select SUBSTR(FILE_CRT_TIME, 0, 8) CRTTIME, SUM(DATA_COUNT) RC from MBT_FILE_UPLOAD_INFO GROUP BY SUBSTR(FILE_CRT_TIME, 0, 8))T LEFT JOIN "
					+ "(SELECT SUBSTR(F.ARRIVE_TIME, 0, 8) ARRTIME, SUM(D.FB_ERR_NUM) EC FROM MBT_FB_FILE f,MBT_FB_FILE_DTL_INF d  WHERE F.DATA_ID = D.PDATA_ID GROUP BY SUBSTR(ARRIVE_TIME, 0, 8)) E "
					+ "ON T. CRTTIME = ARRTIME  " + "WHERE ROWNUM <= 12 ORDER BY CRTTIME DESC");
		} else if ("2".equals(censusType)) {
			resultDs = rootdao.queryBySQL("SELECT CRTTIME reportSize, RC reportNum,EC feedbackNum FROM "
					+ "(select SUBSTR(FILE_CRT_TIME, 0, 6) CRTTIME, SUM(DATA_COUNT) RC from MBT_FILE_UPLOAD_INFO GROUP BY SUBSTR(FILE_CRT_TIME, 0, 6))T LEFT JOIN "
					+ "(SELECT SUBSTR(F.ARRIVE_TIME, 0, 6) ARRTIME, SUM(D.FB_ERR_NUM) EC FROM MBT_FB_FILE f,MBT_FB_FILE_DTL_INF d  WHERE F.DATA_ID = D.PDATA_ID GROUP BY SUBSTR(ARRIVE_TIME, 0, 6)) E "
					+ "ON T. CRTTIME = ARRTIME  " + "WHERE ROWNUM <= 12 ORDER BY CRTTIME DESC");
		} else {
			logger.error("请求信息不合法");
			throw new AppException("请求信息不合法");
		}
		Date now = new Date();
		Calendar ca = Calendar.getInstance();
		// ca.add(Calendar.YEAR, -1); //年份减1
		// ca.add(Calendar.MONTH, -1);//求前一月
		// ca.add(Calendar.DATE, -1);//前一天
		// Date lastMonth = ca.getTime(); //结果
		Object[] object = (Object[]) resultDs.next();
		boolean isPiPei = false;
		for (int i = 0; i < 12; i++) {
			ca.setTime(now); // 设置时间为当前时间

			try {
				if (isPiPei && resultDs.hasNext()) {
					object = (Object[]) resultDs.next();
				}
				BigDecimal mReportNum = new BigDecimal(0);
				BigDecimal mFeedbackNum = new BigDecimal(0);
				String mReportSize = "";
				String reportSize = "";
				Map<String, Object> map = new LinkedHashMap<String, Object>();

				mReportSize = object[0].toString();
				mReportNum = object[1] != null ? new BigDecimal(object[1].toString()) : new BigDecimal(0);
				mFeedbackNum = object[2] != null ? new BigDecimal(object[2].toString()) : new BigDecimal(0);
				if ("1".equals(censusType)) {
					ca.add(Calendar.DATE, -i);
					reportSize = new SimpleDateFormat("yyyyMMdd").format(ca.getTime());
				} else if ("2".equals(censusType)) {
					ca.add(Calendar.MONTH, -i);
					reportSize = new SimpleDateFormat("yyyyMM").format(ca.getTime());
				}
				if (reportSize.equals(mReportSize)) {
					isPiPei = true;
					/*
					 * map.put("reportSize", object[0].toString().substring("1".equals(censusType) ?
					 * 6 : 4) + ("1".equals(censusType) ? "日" : "月")); map.put("reportNum",
					 * mReportNum + ""); map.put("feedbackNum", mFeedbackNum + "");
					 */
					map.put(object[0].toString().substring("1".equals(censusType) ? 6 : 4)
							+ ("1".equals(censusType) ? "日" : "月"),
							new String[] { mReportNum + "", mFeedbackNum + "" });
					mList.add(map);
					reportNum = reportNum.add(mReportNum);
					feedbackNum = feedbackNum.add(mFeedbackNum);
				} else {
					isPiPei = false;
					/*
					 * map.put("reportSize", reportSize.substring("1".equals(censusType) ? 6 : 4) +
					 * ("1".equals(censusType) ? "日" : "月")); map.put("reportNum", "0");
					 * map.put("feedbackNum", "0");
					 */
					map.put(reportSize.substring("1".equals(censusType) ? 6 : 4) + ("1".equals(censusType) ? "日" : "月"),
							new String[] { "0", "0" });
					mList.add(map);
					reportNum = reportNum.add(new BigDecimal(0));
					feedbackNum = feedbackNum.add(new BigDecimal(0));
				}
			} catch (Exception e) {
				logger.error(e.getLocalizedMessage());
				throw new AppException("获取登陆信息失败");
			}

		}
		/*
		 * else { Map<String,String> map = new HashMap<String,String>();
		 * map.put("reportSize", new SimpleDateFormat("1".equals(censusType) ? "dd日" :
		 * "MM月").format(new Date())); map.put("reportNum", "0"); map.put("feedbackNum",
		 * "0"); }
		 */
		
		Map<String, Object> tempResult = new LinkedHashMap<String, Object>();
		tempResult.put("censusType", censusType);
		tempResult.put("reportNum", reportNum.intValue());
		tempResult.put("feedbackNum", feedbackNum.intValue());
		tempResult.put("reportSizeInfo", mList);
		result.put("data", tempResult);
		return result;

	}


    /**
     * 待办事项
     */
    @SuppressWarnings("rawtypes")
    public Map<String, Object> getItemInfo(String curPage, int rows, HttpServletRequest request) throws AppException {
        Map<String, Object> result = new LinkedHashMap<String, Object>();
        result.put("hasError", 1);
        result.put("message", "");
        // 检查curPage
        if (StringUtils.isEmpty(curPage)) {
            logger.error("提交的数据必须包含curPage字段");
            throw new AppException("提交的数据不合法。");
        }
		GlobalInfo.setCurrentInstance(GlobalInfo.getInstanceFromRequest(request));
        int iCurPage = Integer.parseInt(curPage);

        List<Map<String, String>> mList = new ArrayList<Map<String, String>>();
        taskTotalList = homePageTodoTasksService.getToDoTasks();
        List<TaskTotal> newList = new ArrayList<>();
        newList = taskTotalList.subList((iCurPage-1)*rows, iCurPage*rows>taskTotalList.size()?taskTotalList.size():iCurPage*rows);
        for(TaskTotal taskTotal : newList){
            Map<String, String> map = new LinkedHashMap<String, String>();
            map.put("itemName", taskTotal.getTaskTyeName());
            map.put("itemNum", taskTotal.getTaskCount());
            map.put("itemUrl", taskTotal.getDealUrl());
            map.put("funcId", taskTotal.getTaskTypeId());
            mList.add(map);
        }
        Map<String, Object> tempResult = new LinkedHashMap<String, Object>();
        tempResult.put("total", taskTotalList.size());
        tempResult.put("page", curPage);
        tempResult.put("rows", mList);
        result.put("data", tempResult);
        return result;
    }

    /**
	 * 通知
	 */
	@SuppressWarnings("rawtypes")
	public Map<String, Object> getNoticeInfo(String curPage, int rows, String noticeType) throws AppException {
		Map<String, Object> result = new LinkedHashMap<String, Object>();
		result.put("hasError", 1);
		result.put("message", "");
		// 检查curPage
		if (StringUtils.isEmpty(curPage)) {
			logger.error("提交的数据必须包含curPage字段");
			throw new AppException("提交的数据不合法。");
		}
		// 检查noticeType
		if (StringUtils.isEmpty(noticeType)) {
			logger.error("提交的数据必须包含noticeType字段");
			throw new AppException("提交的数据不合法。");
		}

		int iCurPage = Integer.parseInt(curPage);

		List<Map<String, String>> mList = new ArrayList<Map<String, String>>();

		PageQueryCondition queryCondition = new PageQueryCondition();
		queryCondition.setPageIndex(iCurPage);
		queryCondition.setPageSize(rows);
		PageQueryResult pageQueryResult = null;
		Iterator resultDs = null;
		if ("1".equals(noticeType)) {
			//消息
			queryCondition.setQueryString("SELECT MSG_TITLE, MSG_CONTENT, DATA_CRT_TIME, DATA_ID from GP_BM_GNO_Q");
			pageQueryResult = rootdao.pageQueryBySQL(queryCondition);
			resultDs = pageQueryResult.getQueryResult().iterator();
		} else if ("2".equals(noticeType)) {
			//公告
			queryCondition.setQueryString("SELECT MSG_TITLE, MSG_CONTENT, DATA_CRT_TIME, DATA_ID from GP_BM_GNO_Q");
			pageQueryResult = rootdao.pageQueryBySQL(queryCondition);
			resultDs = pageQueryResult.getQueryResult().iterator();
		} else {
			logger.error("请求信息不合法");
			throw new AppException("请求信息不合法");
		}

		while (resultDs.hasNext()) {
			Object[] object = (Object[]) resultDs.next();
			try {
				Map<String, String> map = new LinkedHashMap<String, String>();
				map.put("noticeDesc", object[0].toString());
				map.put("noticeUrl", "");
				map.put("noticeTime", object[2] != null ? object[2].toString() : "");
				map.put("funcId", "");
				map.put("dataId", object[3] != null ? object[3].toString() : "");
				mList.add(map);
			} catch (Exception e) {
				logger.error(e.getLocalizedMessage());
				throw new AppException("获取通知信息失败");
			}
		}
		Map<String, Object> tempResult = new LinkedHashMap<String, Object>();
		tempResult.put("total", pageQueryResult.getTotalCount());
		tempResult.put("page", curPage);
		tempResult.put("rows", mList);
		result.put("data", tempResult);
		return result;
	}

	/**
	 * 根据用户角色查询出岗位，再根据岗位查询出部门信息
	 */
	public Map<String,Object>  getOrgId(String tlrNo) throws AppException{
		Map<String,Object> result= new HashMap<>();
		Iterator resultDs = rootdao.queryBySQL("SELECT c.role_id,c.corp_id FROM  GP_BM_TLR_ROLE_REL b,GP_BM_ROLE_INFO c WHERE b.TLRNO='"+tlrNo+"' AND b.ROLE_ID=c.ROLE_ID");
		while (resultDs.hasNext()) {
			Object[] object = (Object[]) resultDs.next();
			try {
				Iterator resultDs1 = rootdao.queryBySQL("SELECT b.BRNO, b.BRNAME FROM gp_bm_branch b ,gp_bm_role_org_rel c WHERE b.BRNO = c.CHG_ORG_ID AND b.status='1' AND c.role_id='"+object[0]+"' AND c.CORP_ID = '"+object[1]+"' order by c.chg_org_id");
				Map<String, Object> tempResult = new LinkedHashMap<String, Object>();
				while (resultDs1.hasNext()){
						Object[] object1 = (Object[]) resultDs1.next();
						tempResult.put(object1[0].toString(), object1[1]);
					}
				result.put("data", tempResult);

			} catch (Exception e) {
				logger.error(e.getLocalizedMessage());
				throw new AppException("获取部门信息失败");
			}
		}
		return result;
	}
	/**
	 * 更新部门信息
	 */
	public Map<String,Object>  setOrgId(String tlrNo,String brNo) throws AppException{
		Map<String,Object> result= new HashMap<>();
		String sql ="update GP_BM_TLR_INFO set BRCODE='"+brNo+"' ,BRNO='"+brNo +"' where TLRNO='"+tlrNo+"'";
		 int r = rootdao.updateBySQL(sql);
		if (r>0){
			GlobalInfo.getCurrentInstance().setBrno(brNo);
			result.put("data",true);
		}else{
			result.put("data",false);

			throw  new AppException("更新部门失败");
		}
		return result;
	}





}
