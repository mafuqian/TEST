package com.gingkoo.mbt.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.orm.entity.MbtUnusalList;

public class Mbt232SaveAction extends MbtUpdCommitAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
            throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        String dsId = multiUpdateResultBean.getUpdateResult().containsKey("Mbt232Upd_Opt_ds1") ? "Mbt232Upd_Opt_ds1" : "Mbt232Upd_ds";
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID(dsId);
        Map<String, String> recordMap = resultBean.getTotalList().get(0);

        if(recordMap.get("opr").equals("upd") || recordMap.get("opt") == "upd"){
            recordMap.put("infRecType", "232");
            recordMap.put("optType", "01");
        }else if(recordMap.get("opr").equals("del") || recordMap.get("del") == "upd"){
            recordMap.put("infRecType", "233");
            recordMap.put("optType", "02");
        }else if(recordMap.get("opr").equals("alldel") || recordMap.get("alldel") == "upd"){
            recordMap.put("infRecType", "234");
            recordMap.put("optType", "03");
        }

        process(resultBean, MbtUnusalList.class);
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }
}
