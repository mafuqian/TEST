package com.gingkoo.mbt.action;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommCommitToApvService;
import com.gingkoo.orm.entity.Mbt140;
import com.gingkoo.orm.entity.Mbt210;
import com.gingkoo.orm.entity.Mbt210D;
import com.gingkoo.orm.entity.Mbt210E;
import com.gingkoo.orm.entity.Mbt210K;

public class Mbt210CommitAction extends WebAlterAction{
	private static Log logger = LogFactory.getLogger(Mbt210CommitAction.class);
	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
			throws AppException {
		 UpdateReturnBean returnBean = new UpdateReturnBean();
	     UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResult().containsKey("Mat_210_tabPageList_ds") ?
	     multiUpdateResultBean.getUpdateResultBeanByID("Mat_210_tabPageList_ds") : multiUpdateResultBean.getUpdateResultBeanByID("Mat_210_ds");
		WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
		MbtCommCommitToApvService mbtCommCommitToApvService = (MbtCommCommitToApvService) context.getBean("mbtCommCommitToApvService");

		Map<String,String> map = new HashMap<>();
		map.put("dataId","dataId");
		map.put("type","B");
		String flag = mbtCommCommitToApvService.validateFields(Mbt210.class,resultBean, returnBean,map);
		map.put("dataId","pdataId");
		map.put("type","D");
		String flag1 = mbtCommCommitToApvService.validateFields(Mbt210D.class,resultBean, returnBean,map);
		map.put("type","E");
		String flag2 = mbtCommCommitToApvService.validateFields(Mbt210E.class,resultBean, returnBean,map);
		map.put("type","K");
		String flag3 = mbtCommCommitToApvService.validateFields(Mbt210K.class,resultBean, returnBean,map);
		if (flag.equals("failed") || flag1.equals("failed") || flag2.equals("failed") || flag3.equals("failed")){
			return returnBean;
		}
/*
	     new MbtCommCommitToApvService(resultBean, Mbt210.class).commitToApprove();
*/

	     mbtCommCommitToApvService.commitToApprove(resultBean, Mbt210.class,returnBean);
	        if("".equals(returnBean.getParameter("E_CODE"))) {
	        	returnBean.setParameter("isOptSucc", "true");
	        }else {
	        	returnBean.setParameter("isOptSucc", "false");
	        }

	     return returnBean;
	}

}
