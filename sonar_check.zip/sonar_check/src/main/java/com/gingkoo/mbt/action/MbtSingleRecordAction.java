package com.gingkoo.mbt.action;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.common.validate.service.CommonValidteServeice;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.mbt.dao.MbtRootDao;
import com.gingkoo.mbt.service.base.MbtCommonBaseService;
import com.gingkoo.mbt.service.init.InitController;
/**
 *
 * 处理前台提交的单条记录的通用 Action
 *
 * @author fuxiang.luo@gingkoo.com
 *
 *
 */
public abstract class MbtSingleRecordAction extends WebAlterAction {

    protected static final Log logger = LogFactory.getLogger(MbtSingleRecordAction.class);

    protected MbtRootDao dao = (MbtRootDao) ApplicationContextUtil.getBean("mbtRootDao");

    private String dataId;

    private MbtCommonBaseService mbtCommonBaseService;

    private String currentDataStatus;
    
    private String targetDataStatus;


    protected String getDataId(){
        return dataId;
    }

    /**
     *
     * @param resultBean 包含记录数据的 resultBean
     * @param clazz 实体类
     * @throws AppException app异常
     */
    public void process(UpdateResultBean resultBean, Class<?> clazz) throws AppException {
    	mbtCommonBaseService = new MbtCommonBaseService();
        Map<String, String> recordMap = resultBean.next();
        resultBean.getParamMap().forEach((k, v) ->{
            if(!StringUtils.isEmpty(v)){
                recordMap.put(k, v);
            }
        });

        Object bean;
        this.dataId = recordMap.get("dataId");
        recordMap.put("dataChgUser", GlobalInfo.getCurrentInstance().getTlrno());
        recordMap.put("dataChgTime", DateUtil.get14Date());
        recordMap.put("dataChgDate", DateUtil.get8Date());

        Map<String,String> map = new HashMap<String,String>();
        // 不含dataId，新增数据
        if(StringUtils.isEmpty(dataId)){

            try {
                bean = clazz.newInstance();
            } catch (InstantiationException | IllegalAccessException e) {
                logger.error(e.getLocalizedMessage());
                throw new AppException("系统错误，创建类" + clazz.getName() + "实例时出错。");
            }
           
            dataId = UUID.randomUUID().toString().replace("-", "");
            recordMap.put("dataId", dataId);
            recordMap.put("dataCrtUser",GlobalInfo.getCurrentInstance().getTlrno());
            recordMap.put("dataCrtTime", DateUtil.get14Date());
            recordMap.put("dataDate", DateUtil.get8Date());
            recordMap.put("dataCrtDate", DateUtil.get8Date());
            recordMap.put("corpId", GlobalInfo.getCurrentInstance().getCorpId());
            recordMap.put("orgId", GlobalInfo.getCurrentInstance().getBrno());
            recordMap.put("groupId", GlobalInfo.getCurrentInstance().getGroupId());
            recordMap.put("inqOrgID","");
            recordMap.put("dataSource","1");
            currentDataStatus = "00";
            map.put("actionId", "add");

        }
        // 含dataId, 表示修改
        else {
            Iterator iterator = dao.queryByQL("from " + clazz.getName() + " where dataId='" + dataId + "'");
            if(iterator.hasNext()){
                bean = iterator.next();
                try {
					currentDataStatus = BeanUtils.getProperty(bean, "dataStatus");
	                map.put("actionId", "mod");
				} catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
	                logger.error(e.getLocalizedMessage());
	            }
            }else {//标识根据 dataId没有检索出数据，说明提交的dataId有问题
                logger.error("前端提交的dataId数据库不存在。");
                throw new AppException("提交的数据不合法。");
            }
        }
        if(null != recordMap.get("dataCrtTime")) {
       	 recordMap.put("dataCrtTime",trim(recordMap.get("dataCrtTime")));
       }
       
       if(null != recordMap.get("dataApvTime")) {
      	 recordMap.put("dataApvTime",trim(recordMap.get("dataApvTime")));
      }
       map.put("currDataStatus", currentDataStatus);

       Map<String,String> resultMap = mbtCommonBaseService.RedataStatus(map);
       if(null==resultMap.get("errMsg") ||"".equals(resultMap.get("errMsg"))) {
           targetDataStatus = resultMap.get("dataStatus");
       }else {
           throw new AppException(resultMap.get("errMsg"));
       }
       recordMap.put("dataStatus", targetDataStatus);
        mapToObject(bean, recordMap);
        try {
        	bean = new InitController().init(bean);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
            dao.saveOrUpdate(bean);
//       } catch (CommonException e) {
//           logger.error(e.getLocalizedMessage());
//           throw new AppException("系统错误，保存失败"+e.getMessage());
        }
        catch (Exception e) {
            logger.error(e.getLocalizedMessage());
            throw new AppException("系统错误，保存失败"+e.getMessage());
        }    }
    public String trim(String str) {
    	if(!"".equals(str) && null != str) {
    		str = str.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
    	}
    	
    	return str;
    }
    /**
     * 校验字段
     * @param resultBean 待更新的结果集
     * @param returnBean 处理之后，返回给前端的结果集
     * @return pass - 校验通过; failed - 校验失败
     * @throws CommonException 通用异常
     */
    protected String validateFields(UpdateResultBean resultBean, UpdateReturnBean returnBean) throws CommonException {

        CommonValidteServeice validateService = new CommonValidteServeice();
        String validateResult = validateService.execute(resultBean.getTotalList().get(0), GlobalInfo.getCurrentInstanceWithoutException().getFuncId(),true);
        if(!StringUtils.isEmpty(validateResult)){
            String[] result = validateResult.split("\\|");
            returnBean.setParameter("desc", result[1]);
            returnBean.setParameter("resId", result[0]);
            return "failed";
        }else {
            return "pass";
        }
    }
}
