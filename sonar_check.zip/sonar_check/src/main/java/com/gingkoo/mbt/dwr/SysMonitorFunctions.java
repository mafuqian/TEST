package com.gingkoo.mbt.dwr;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.hyperic.sigar.CpuInfo;
import org.hyperic.sigar.CpuPerc;
import org.hyperic.sigar.FileSystem;
import org.hyperic.sigar.FileSystemUsage;
import org.hyperic.sigar.Mem;
import org.hyperic.sigar.NetInterfaceConfig;
import org.hyperic.sigar.NetInterfaceStat;
import org.hyperic.sigar.Sigar;
import org.hyperic.sigar.SigarException;
import org.hyperic.sigar.Swap;

/**
 * Title: System Monitor Dwr Functions Utils Class Copyright: Copyright (c) 2006
 * Company: Shanghai Gingkoo Co., Ltd.
 * 
 * @author shen_antonio
 * @version 1.0, 12/02/13
 */
public class SysMonitorFunctions {

	/**
	 * get jvm available memory info
	 * 
	 * @return
	 */
	public String getJVMAvailableMem() {
		double max = (Runtime.getRuntime().maxMemory()) / (1024.0 * 1024);
		double total = (Runtime.getRuntime().totalMemory()) / (1024.0 * 1024);
		double free = (Runtime.getRuntime().freeMemory()) / (1024.0 * 1024);
		double available = max - total + free;
		// 转换类型，四舍五入
		BigDecimal bAvailable = new BigDecimal(available);
		BigDecimal y = bAvailable.setScale(2, BigDecimal.ROUND_HALF_UP);
		return y.toString();
	}

	/**
	 * get jvm memory info
	 * 
	 * @return jvm memory info list
	 */
	public List<BigDecimal> getJVMMemInfo() {
		double max = (Runtime.getRuntime().maxMemory()) / (1024.0 * 1024);
		double total = (Runtime.getRuntime().totalMemory()) / (1024.0 * 1024);
		double free = (Runtime.getRuntime().freeMemory()) / (1024.0 * 1024);
		double available = max - total + free;
		// 转换类型，四舍五入
		BigDecimal bMax = new BigDecimal(max);
		BigDecimal bTotal = new BigDecimal(total);
		BigDecimal bFree = new BigDecimal(free);
		BigDecimal bAvailable = new BigDecimal(available);
		List<BigDecimal> list = new ArrayList<BigDecimal>();
		list.add(bMax.setScale(2, BigDecimal.ROUND_HALF_UP));
		list.add(bTotal.setScale(2, BigDecimal.ROUND_HALF_UP));
		list.add(bFree.setScale(2, BigDecimal.ROUND_HALF_UP));
		list.add(bAvailable.setScale(2, BigDecimal.ROUND_HALF_UP));
		return list;
	}

	public Map<String, String> getOSProperty() {
		Runtime r = Runtime.getRuntime();
		Properties props = System.getProperties();
		Map<String, String> propertyMap = new LinkedHashMap<String, String>();
		Map<String, String> map = System.getenv();
		String userName = map.get("USERNAME");// 获取用户名
		String computerName = map.get("COMPUTERNAME");// 获取计算机名
		String userDomain = map.get("USERDOMAIN");// 获取计算机域名
		// 操作系统信息
		propertyMap.put("操作系统信息", "GROUP");
		propertyMap.put("计算机名", computerName);
		propertyMap.put("计算机域名", userDomain);
		propertyMap.put("操作系统的名称", props.getProperty("os.name"));
		propertyMap.put("操作系统的构架", props.getProperty("os.arch"));
		propertyMap.put("操作系统的版本", props.getProperty("os.version"));
		propertyMap.put("用户的账户名称", props.getProperty("user.name"));
		propertyMap.put("用户的主目录", props.getProperty("user.home"));
		propertyMap.put("用户的当前工作目录", props.getProperty("user.dir"));
		// JVM信息
		propertyMap.put("JVM信息", "GROUP");
		propertyMap.put("JVM可以使用的总内存", String.valueOf(r.totalMemory()));
		propertyMap.put("JVM可以使用的剩余内存", String.valueOf(r.freeMemory()));
		propertyMap.put("JVM可以使用的处理器个数",
				String.valueOf(r.availableProcessors()));
		// Java运行时信息
		propertyMap.put("JAVA运行时信息", "GROUP");
		propertyMap.put("Java的运行环境版本", props.getProperty("java.version"));
		propertyMap.put("Java的运行环境供应商", props.getProperty("java.vendor"));
		propertyMap.put("Java供应商的URL", props.getProperty("java.vendor.url"));
		propertyMap.put("Java的安装路径", props.getProperty("java.home"));
		propertyMap.put("Java的虚拟机规范版本",
				props.getProperty("java.vm.specification.version"));
		propertyMap.put("Java的虚拟机规范供应商",
				props.getProperty("java.vm.specification.vendor"));
		propertyMap.put("Java的虚拟机规范名称",
				props.getProperty("java.vm.specification.name"));
		propertyMap.put("Java的虚拟机实现版本", props.getProperty("java.vm.version"));
		propertyMap.put("Java的虚拟机实现供应商", props.getProperty("java.vm.vendor"));
		propertyMap.put("Java的虚拟机实现名称", props.getProperty("java.vm.name"));
		propertyMap.put("Java运行时环境规范版本",
				props.getProperty("java.specification.version"));
		propertyMap.put("Java运行时环境规范供应商",
				props.getProperty("java.specification.vender"));
		propertyMap.put("Java运行时环境规范名称",
				props.getProperty("java.specification.name"));
		propertyMap.put("Java的类格式版本号", props.getProperty("java.class.version"));
		propertyMap.put("Java的类路径", props.getProperty("java.class.path"));
		propertyMap.put("加载库时搜索的路径列表", props.getProperty("java.library.path"));
		propertyMap.put("默认的临时文件路径", props.getProperty("java.io.tmpdir"));
		propertyMap.put("一个或多个扩展目录的路径", props.getProperty("java.ext.dirs"));
		propertyMap.put("文件分隔符", props.getProperty("file.separator"));
		propertyMap.put("路径分隔符", props.getProperty("path.separator"));
		propertyMap.put("行分隔符", props.getProperty("line.separator"));

		return propertyMap;
	}

	public List getMemoryInfo() {
		Sigar sigar = new Sigar();
		List infoList = new ArrayList();
		try {
			Mem mem = sigar.getMem();
			// 内存总量
			infoList.add(mem.getTotal() / 1024L / 1024L);
			// 当前内存使用量
			infoList.add(mem.getUsed() / 1024L / 1024L);
			// 当前内存剩余量
			infoList.add(mem.getFree() / 1024L / 1024L);
			Swap swap = sigar.getSwap();
			// 交换区总量
			infoList.add(swap.getTotal() / 1024L / 1024L);
			// 当前交换区使用量
			infoList.add(swap.getUsed() / 1024L / 1024L);
			// 当前交换区剩余量
			infoList.add(swap.getFree() / 1024L / 1024L);
			return infoList;
		} catch (SigarException e) {
			
		}
		return null;
	}

	public String getMemoryFree() {
		Sigar sigar = new Sigar();
		try {
			Mem mem = sigar.getMem();

			return String.valueOf((mem.getFree() / 1024L / 1024L));
		} catch (SigarException e) {
			// TODO Auto-generated catch block
			
		}
		return null;
	}

	public List<Map<String, String>> getCpuInfo() {
		Sigar sigar = new Sigar();
		List<Map<String, String>> cpuInfList = new ArrayList<Map<String, String>>();
		try {
			CpuInfo infos[] = sigar.getCpuInfoList();
			CpuPerc cpuList[] = null;
			cpuList = sigar.getCpuPercList();

			for (int i = 0; i < infos.length; i++) {// 不管是单块CPU还是多CPU都适用
				Map<String, String> cpuMap = new LinkedHashMap<String, String>();
				CpuInfo info = infos[i];
				cpuMap.put("第" + i + "块CPU信息", "GROUP");
				cpuMap.put("CPU的总量MHz", String.valueOf(info.getMhz()));// CPU的总量MHz
				cpuMap.put("CPU的供应商", info.getVendor());// 获得CPU的卖主，如：Intel
				cpuMap.put("CPU的类别", info.getModel());// 获得CPU的类别，如：Celeron
				cpuMap.put("CPU的缓冲存储器数量", String.valueOf(info.getCacheSize()));// 缓冲存储器数量
				cpuMap.put("用户使用率", CpuPerc.format(cpuList[i].getUser()));// 用户使用率
				cpuMap.put("系统使用率", CpuPerc.format(cpuList[i].getSys()));// 系统使用率
				cpuMap.put("当前等待率", CpuPerc.format(cpuList[i].getWait()));// 当前等待率
				cpuMap.put("当前错误率", CpuPerc.format(cpuList[i].getNice()));// 当前错误率
				cpuMap.put("当前空闲率", CpuPerc.format(cpuList[i].getIdle()));// 当前空闲率
				cpuMap.put("总的使用率", CpuPerc.format(cpuList[i].getCombined()));// 总的使用率
				cpuInfList.add(cpuMap);
			}
		} catch (Exception e) {
			
		}
		return cpuInfList;
	}

	public List<BigDecimal> getCpuUser() {
		Sigar sigar = new Sigar();
		try {
			CpuInfo infos[] = sigar.getCpuInfoList();
			CpuPerc cpuList[] = null;
			cpuList = sigar.getCpuPercList();
			List<List<BigDecimal>> allCpuInfoList = new ArrayList<List<BigDecimal>>();
			for (int i = 0; i < infos.length; i++) {// 不管是单块CPU还是多CPU都适用
				List<BigDecimal> cpuInfo = new ArrayList<BigDecimal>();
				DecimalFormat df = new DecimalFormat("#");
				cpuInfo.add(new BigDecimal(
						df.format(cpuList[i].getCombined() * 100)));
				cpuInfo.add(new BigDecimal(df.format(cpuList[i].getSys() * 100)));
				cpuInfo.add(new BigDecimal(
						df.format(cpuList[i].getUser() * 100)));
				cpuInfo.add(new BigDecimal(
						df.format(cpuList[i].getIdle() * 100)));
				allCpuInfoList.add(cpuInfo);
			}
			return clacCpu(allCpuInfoList);
		} catch (Exception e) {
			
		}
		return null;
	}

	private List<BigDecimal> clacCpu(List<List<BigDecimal>> allCpuInfoList) {
		List<BigDecimal> cpuInfoList = new ArrayList<BigDecimal>();
		BigDecimal combined = new BigDecimal(0);
		BigDecimal sys = new BigDecimal(0);
		BigDecimal user = new BigDecimal(0);
		BigDecimal idle = new BigDecimal(0);
		for (int i = 0; i < allCpuInfoList.size(); i++) {
			List<BigDecimal> cpuInfo = allCpuInfoList.get(i);
			combined = combined.add(cpuInfo.get(0));
			sys = sys.add(cpuInfo.get(1));
			user = user.add(cpuInfo.get(2));
			idle = idle.add(cpuInfo.get(3));
		}
		DecimalFormat df = new DecimalFormat("#");
		cpuInfoList.add(new BigDecimal(df.format(combined
				.divide(new BigDecimal(allCpuInfoList.size())))));
		cpuInfoList.add(new BigDecimal(df.format(sys.divide(new BigDecimal(
				allCpuInfoList.size())))));
		cpuInfoList.add(new BigDecimal(df.format(user.divide(new BigDecimal(
				allCpuInfoList.size())))));
		cpuInfoList.add(new BigDecimal(df.format(idle.divide(new BigDecimal(
				allCpuInfoList.size())))));
		return cpuInfoList;
	}

	public List<Map<String, String>> getFile() {
		List<Map<String, String>> fileInfoList = new ArrayList<Map<String, String>>();
		Sigar sigar = new Sigar();
		try {
			FileSystem fslist[] = sigar.getFileSystemList();
			for (int i = 0; i < fslist.length; i++) {
				Map<String, String> fileMap = new LinkedHashMap<String, String>();
				FileSystem fs = fslist[i];
				// 分区的盘符名称
				fileMap.put(fs.getDevName(), "GROUP");
				// 分区的盘符名称
				fileMap.put("盘符路径", fs.getDirName());
				fileMap.put("盘符标志", String.valueOf(fs.getFlags()));
				// 文件系统类型，比如 FAT32、NTFS
				fileMap.put("盘符类型", fs.getSysTypeName());
				// 文件系统类型名，比如本地硬盘、光驱、网络文件系统等
				fileMap.put("盘符类型名", fs.getTypeName());
				// 文件系统类型
				FileSystemUsage usage = null;
				usage = sigar.getFileSystemUsage(fs.getDirName());
				switch (fs.getType()) {
				case 0: // TYPE_UNKNOWN ：未知
					break;
				case 1: // TYPE_NONE
					break;
				case 2: // TYPE_LOCAL_DISK : 本地硬盘
					// 文件系统总大小
					fileMap.put("文件系统总大小", usage.getTotal() + "KB");
					// 文件系统剩余大小
					fileMap.put("文件系统剩余大小", usage.getFree() + "KB");
					// 文件系统可用大小
					fileMap.put("文件系统可用大小", usage.getAvail() + "KB");
					// 文件系统已经使用量
					fileMap.put("文件系统已经使用量", usage.getUsed() + "KB");
					double usePercent = usage.getUsePercent() * 100D;
					// 文件系统资源的利用率
					fileMap.put("文件系统资源利用率", usePercent + "%");
					fileInfoList.add(fileMap);
					break;
				case 3:// TYPE_NETWORK ：网络
					break;
				case 4:// TYPE_RAM_DISK ：闪存
					break;
				case 5:// TYPE_CDROM ：光驱
					break;
				case 6:// TYPE_SWAP ：页面交换
					break;
				}
			}
		} catch (Exception e) {
			
		}
		return fileInfoList;
	}

	public List<BigDecimal> getFileInfo() throws Exception {
		List<BigDecimal> fileInfoList = new ArrayList<BigDecimal>();
		Sigar sigar = new Sigar();
		FileSystem fslist[] = sigar.getFileSystemList();
		BigDecimal total = new BigDecimal(0);
		BigDecimal usered = new BigDecimal(0);
		for (int i = 0; i < fslist.length; i++) {
			FileSystem fs = fslist[i];
			FileSystemUsage usage = null;
			usage = sigar.getFileSystemUsage(fs.getDirName());
			switch (fs.getType()) {
			case 0: // TYPE_UNKNOWN ：未知
				break;
			case 1: // TYPE_NONE
				break;
			case 2: // TYPE_LOCAL_DISK : 本地硬盘
				// 文件系统总大小
				total = total.add(new BigDecimal(usage.getTotal()));
				usered = usered.add(new BigDecimal(usage.getUsed()));
				break;
			case 3:// TYPE_NETWORK ：网络
				break;
			case 4:// TYPE_RAM_DISK ：闪存
				break;
			case 5:// TYPE_CDROM ：光驱
				break;
			case 6:// TYPE_SWAP ：页面交换
				break;
			}
		}
		BigDecimal useredPre = usered.divide(total, BigDecimal.ROUND_UP);
		BigDecimal freePre = new BigDecimal(100).subtract(useredPre);
		fileInfoList.add(useredPre);
		fileInfoList.add(freePre);
		return fileInfoList;
	}

	public List<Map<String, String>> getNetworkInfo() {
		Sigar sigar = new Sigar();
		List<Map<String, String>> nkInfoList = new ArrayList<Map<String, String>>();
		try{
			String ifNames[] = sigar.getNetInterfaceList();
			for (int i = 0; i < ifNames.length; i++) {
				String name = ifNames[i];
				Map<String, String> nkMap = new LinkedHashMap<String, String>();
				NetInterfaceConfig ifconfig = sigar.getNetInterfaceConfig(name);
				nkMap.put("网络设备名:	" + name, "GROUP");// 网络设备名
				nkMap.put("IP地址", ifconfig.getAddress());// IP地址
				nkMap.put("子网掩码", ifconfig.getNetmask());// 子网掩码
				if ((ifconfig.getFlags() & 1L) <= 0L) {
					System.out.println("!IFF_UP...skipping getNetInterfaceStat");
					continue;
				}
				NetInterfaceStat ifstat = sigar.getNetInterfaceStat(name);
				nkMap.put("接收的总包裹数", String.valueOf(ifstat.getRxPackets()));// 接收的总包裹数
				nkMap.put("发送的总包裹数", String.valueOf(ifstat.getTxPackets()));// 发送的总包裹数
				nkMap.put("接收到的总字节数", String.valueOf(ifstat.getRxBytes()));// 接收到的总字节数
				nkMap.put("发送的总字节数", String.valueOf(ifstat.getTxBytes()));// 发送的总字节数
				nkMap.put("接收到的错误包数", String.valueOf(ifstat.getRxErrors()));// 接收到的错误包数
				nkMap.put("发送数据包时的错误数", String.valueOf(ifstat.getTxErrors()));// 发送数据包时的错误数
				nkMap.put("接收时丢弃的包数", String.valueOf(ifstat.getRxDropped()));// 接收时丢弃的包数
				nkMap.put("发送时丢弃的包数", String.valueOf(ifstat.getTxDropped()));// 发送时丢弃的包数
				nkInfoList.add(nkMap);
			}
		}catch (Exception e) {
			
		}
		return nkInfoList;
	}

	public List<BigDecimal> getNetwork() {
		List<BigDecimal> network = new ArrayList<BigDecimal>();
		try{
			Sigar sigar = new Sigar();
			BigDecimal rxBytes = new BigDecimal(0);
			BigDecimal txBytes = new BigDecimal(0);
			String ifNames[] = sigar.getNetInterfaceList();
			for (int i = 0; i < ifNames.length; i++) {
				String name = ifNames[i];
				NetInterfaceConfig ifconfig = sigar.getNetInterfaceConfig(name);
				if ((ifconfig.getFlags() & 1L) <= 0L) {
					System.out.println("!IFF_UP...skipping getNetInterfaceStat");
					continue;
				}
				NetInterfaceStat ifstat = sigar.getNetInterfaceStat(name);
				rxBytes = rxBytes.add(new BigDecimal(ifstat.getRxBytes()));
				txBytes = txBytes.add(new BigDecimal(ifstat.getTxBytes()));
			}
			network.add(rxBytes);
			network.add(txBytes);
			return network;
		}catch (Exception e) {
			
		}
		return null;
	}

}
