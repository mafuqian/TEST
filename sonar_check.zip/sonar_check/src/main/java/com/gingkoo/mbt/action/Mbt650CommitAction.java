package com.gingkoo.mbt.action;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommCommitToApvService;
import com.gingkoo.orm.entity.Mbt650;

public class Mbt650CommitAction extends WebAlterAction{

	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response)
			throws AppException {
		// TODO Auto-generated method stub
		UpdateReturnBean returnBean = new UpdateReturnBean();
		UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResult().containsKey("Mat_650_TabPageList_ds") ?
				multiUpdateResultBean.getUpdateResultBeanByID("Mat_650_TabPageList_ds") : multiUpdateResultBean.getUpdateResultBeanByID("Mat_650_ds");
/*
		  new MbtCommCommitToApvService(resultBean, Mbt650.class).commitToApprove();
*/
		WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
		MbtCommCommitToApvService mbtCommCommitToApvService = (MbtCommCommitToApvService) context.getBean("mbtCommCommitToApvService");
	   mbtCommCommitToApvService.commitToApprove(resultBean, Mbt650.class,returnBean);
        if("".equals(returnBean.getParameter("E_CODE"))) {
        	returnBean.setParameter("isOptSucc", "true");
        }else {
        	returnBean.setParameter("isOptSucc", "false");
        }
		return returnBean;
	}

}
