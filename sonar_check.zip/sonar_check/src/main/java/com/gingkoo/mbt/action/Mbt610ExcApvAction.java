package com.gingkoo.mbt.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommApvService;
import com.gingkoo.orm.entity.Mbt610Ex;
import com.gingkoo.orm.entity.Mbt620Ex;
import com.gingkoo.orm.entity.Mbt630Ex;
import com.gingkoo.orm.entity.Mbt640Ex;
import com.gingkoo.orm.entity.Mbt650Ex;

public class Mbt610ExcApvAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("Mat_610_Ex_TabPageList_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommApvService mbtCommApvService = (MbtCommApvService) context.getBean("mbtCommApvService");
        if(recordMap.get("bInfRecType").equals("614") ){
//            new MbtCommApvService(resultBean, Mbt610Ex.class)
//                    .approve();
            mbtCommApvService.setEntityName(Mbt610Ex.class.getName());
        }else if(recordMap.get("bInfRecType").equals("624")){
//            new MbtCommApvService(resultBean, Mbt620Ex.class)
//                    .approve();
            mbtCommApvService.setEntityName(Mbt620Ex.class.getName());
        }else if(recordMap.get("bInfRecType").equals("634") ){
//            new MbtCommApvService(resultBean, Mbt630Ex.class)
//                    .approve();
            mbtCommApvService.setEntityName(Mbt630Ex.class.getName());
        }else if(recordMap.get("bInfRecType").equals("644") ){
//            new MbtCommApvService(resultBean, Mbt640Ex.class)
//                    .approve();
            mbtCommApvService.setEntityName(Mbt640Ex.class.getName());
        }else if(recordMap.get("bInfRecType").equals("654") ){
//            new MbtCommApvService(resultBean, Mbt650Ex.class)
//                    .approve();
            mbtCommApvService.setEntityName(Mbt650Ex.class.getName());
        }
        mbtCommApvService.setUpdateResultBean(resultBean);
        mbtCommApvService.approve();
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }
}
