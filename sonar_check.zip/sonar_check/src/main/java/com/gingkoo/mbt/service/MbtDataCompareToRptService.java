package com.gingkoo.mbt.service;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.BaseService;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.mbt.util.CompareUtils;
import com.gingkoo.orm.entity.MbtDataCompareField;

@Component
public class MbtDataCompareToRptService extends BaseService {
	// private static final HtLog htlog =
	// HtLogFactory.getLogger(MbtContractUpdService.class);
	private static final String DATE_NUMBER_PATTERN = "yyyy-MM-dd";
	private static final String DATE_NUMBER_PATTERN_YYYYMMDD = "yyyyMMdd";
	public static final String ID = "batchJobMngService";
	public static final String CMD_MOD = "CMD_MOD";
	public static final String CMD_DEL = "CMD_DEL";
	public static final String CMD_ADD = "CMD_ADD";
	public static final String IN_PARAM = "IN_PARAM";
	public static final String CMD = "CMD";
	@Resource
	private ROOTDAO rootDao;

	public void beforeProc(ServiceContext context) throws CommonException {
	}

	public void execute(ServiceContext context) throws CommonException {

		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		Date date = new Date();
		String id = "";
		String dataDate = (new SimpleDateFormat("yyyyMMdd")).format(date);
		String[] arr = new String[] { "MBT_CONTRACT_BASE" };
		Map<String, String> mapflag = new HashMap<String, String>();
		try {
			for (int i = 0; i < arr.length; i++) {
				mapflag = new HashMap<String, String>();
				String name = arr[i];
				String hql = "from MbtDataCompareField  where ptableName = ? and odsTableName = ? order by seqNo ";
				List<MbtDataCompareField> list = rootdao.queryByQL2List(hql, new Object[] { name, name }, null);
				for (int j = 0; j < list.size(); j++) {

					id = UuidHelper.getCleanUuid();
					MbtDataCompareField compareField = new MbtDataCompareField();
					String rsv1 = compareField.getRsv1();
					String rsv2 = compareField.getRsv2();

					compareField = list.get(j);
					String path = compareField.getPackagePath();
					String odsName = compareField.getOdsTableName();
					String rtpName = compareField.getRptTableName();
					Class forName = Class.forName(path + "." + odsName);
					Class forName1 = Class.forName(path + "." + rtpName);
					Object ods = forName.newInstance();
					Object rpt = forName1.newInstance();
					String filed = compareField.getField();

					String sql = " from " + rtpName + " where  dataDate = '" + dataDate + "'";
					ROOTDAOUtils.getROOTDAO().delete(sql);

					String odshql = "from " + odsName + " where dataStatus = ? and dataDate = ? ";
					List odslist = rootdao.queryByQL2List(odshql, new Object[] { "23", dataDate }, null);

					for (int k = 0; k < odslist.size(); k++) {
						Map map = new HashMap();
						ods = odslist.get(i);
						map = objectToMap(ods);
						String rtphql = "from " + rtpName + " where rsv1=?  order by dataDate desc ";
						List rtplist = rootdao.queryByQL2List(rtphql, new Object[] { map.get("dataId") }, null);
						boolean lflag = false;
						if (rtplist.size() == 0) {
							lflag = true;

						} else {
							Map map2 = new HashMap();
							Map map3 = new HashMap();
							String[] arrField = filed.split(",");
							for (int n = 0; n < arrField.length; n++) {
								map2.put(arrField[n], arrField[n]);
							}
							rpt = rtplist.get(0);
							map3 = CompareUtils.getModifyContent(ods, rpt, map2);
							if (map3 != null) {
								lflag = true;
							}else {
								
							}

						}
						if (lflag) {
							String str = UuidHelper.getCleanUuid();
							map.put("rsv1", map.get("dataId"));
							map.put("dataId", id);
							map.put("primaryKey", id);
							mapToObject(rpt, map, "");
							ROOTDAOUtils.getROOTDAO().save(rpt);

							String hqlDtl = "from MbtDataCompareField  where ptableName = ? and odsTableName != ? order by seqNo ";
							List<MbtDataCompareField> listDtl = rootdao.queryByQL2List(hql, new Object[] { name, name },
									null);
							for (int l = 0; l < listDtl.size(); l++) {
								String pdataId = (String) map.get("rsv1");
								map = new HashMap();
								compareField = listDtl.get(l);
								path = compareField.getPackagePath();
								odsName = compareField.getOdsTableName();
								rtpName = compareField.getRptTableName();
								forName = Class.forName(path + "." + odsName);
								forName1 = Class.forName(path + "." + rtpName);
								ods = forName.newInstance();
								rpt = forName1.newInstance();
								sql = " from " + rtpName + " wher  dataDate = '" + dataDate + "'";
								ROOTDAOUtils.getROOTDAO().delete(sql);

								odshql = "from " + odsName + " where pdataId = ? and dataDate = ? ";
								odslist = rootdao.queryByQL2List(odshql, new Object[] { pdataId, dataDate }, null);
								for (int a = 0; a < odslist.size(); a++) {
									str = UuidHelper.getCleanUuid();
									ods = odslist.get(a);
									map = objectToMap(ods);
									map.put("pdataId", id);
									map.put("dataId", str);
									map.put("primaryKey", str);
									mapToObject(rpt, map, "");
									ROOTDAOUtils.getROOTDAO().save(rpt);
								}
							}
						}

					}

				}

			}
		} catch (Exception e) {

		}

	}

	public static Set<String> mapToObject(Object object, Map map, String str)
			throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
		Iterator iterator = map.keySet().iterator();
		Set<String> nullSet = new HashSet<>();
		while (iterator.hasNext()) {
			String fieldName = (String) iterator.next();
			Object o = getNestedProperty(object, fieldName);
			PropertyDescriptor desc = PropertyUtils.getPropertyDescriptor(o, fieldName);
			if (desc == null)
				continue;
			Class cl = desc.getPropertyType();

			Object value = map.get(fieldName);
			if (value == null || (!String.class.isAssignableFrom(cl) && value instanceof String
					&& StringUtils.isEmpty((String) value))) {
				nullSet.add(fieldName);
				PropertyUtils.setProperty(o, fieldName, "null");
				continue;
			}

			if (Date.class.isAssignableFrom(cl)) {
				Long time = convert(value);
				if (time != null)
					BeanUtils.setProperty(o, fieldName, new Date(time));
				else {
					/*
					 * BeanUtils.setProperty(o, propertyName, new java.util.Date(0L));
					 */
					/*
					 * modify by shen_antonio 20080918 BeanUtils.setProperty(o, fieldName,
					 * defaultDate); .
					 */
				}
			} else if (Calendar.class.isAssignableFrom(cl)) {
				Long time = convert(value);
				Calendar calendar = Calendar.getInstance();
				if (time != null) {
					calendar.setTimeInMillis(time);
					BeanUtils.setProperty(o, fieldName, calendar);
				} else {
					// calendar.setTimeInMillis(0L);
					/*
					 * modify by shen_antonio 20080918
					 * calendar.setTimeInMillis(defaultDate.getTime()); BeanUtils.setProperty(o,
					 * fieldName, calendar); .
					 */
				}
			} else if (BigDecimal.class.isAssignableFrom(cl)) {
				String v = (String) value;
				if (!StringUtils.isEmpty(v)) {
					BeanUtils.setProperty(o, fieldName, v);
				}
			} else {
				String v = (String) value;
				// 杩囨护"|"浠ュ強鍥炶溅鎹㈣绗﹀彿銆�
				v = v.replace('|', ' ');
				v = v.replaceAll("\n|\r\n|\r|\u0085|\u2028|\u2029", "^p");
				if ("null".equals(v)) {
					v = "";
				}
				BeanUtils.setProperty(o, fieldName, v);
			}

		}
		return nullSet;
	}

	public static Long convert(Object arg1) {

		String p = (String) arg1;
		if (p == null || p.trim().length() == 0) {
			return null;
		}
		SimpleDateFormat df = null;
		try {
			if (p.indexOf("-") > 0) {
				df = new SimpleDateFormat(DATE_NUMBER_PATTERN);
			} else {
				df = new SimpleDateFormat(DATE_NUMBER_PATTERN_YYYYMMDD);
			}
			return new Long(df.parse(p.trim()).getTime());
		} catch (Exception e) {
			return null;
		}
	}

	private static Object getNestedProperty(Object o, String propertyDesc)
			throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
		Object value = o;
		String properties[] = StringUtils.split(propertyDesc, ".");
		for (int i = 0; i < properties.length; i++) {
			if (properties.length == 1)
				break;
			String property = properties[i];
			value = PropertyUtils.getProperty(value, property);
			if (i + 2 == properties.length)
				break;
		}

		return value;
	}

	public Map<String, String> objectToMap(Object obj) throws Exception {
		if (obj == null)
			return null;

		Map<String, String> map = new HashMap<String, String>();

		BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
		PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
		for (PropertyDescriptor property : propertyDescriptors) {
			String key = property.getName();
			if (key.compareToIgnoreCase("class") == 0) {
				continue;
			}
			Method getter = property.getReadMethod();
			String value = getter != null ? getter.invoke(obj) + "" : null;
			map.put(key, value);
		}

		return map;
	}

	public void afterProc(ServiceContext context) throws CommonException {
	}

	public static void main(String[] args) {
		for (int i = 0; i < 21; i++) {
			System.out.println(UuidHelper.getCleanUuid());
		}
	}
}