package com.gingkoo.mbt.action;

import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.orm.entity.ToCheckInf;

public class PersonalObjAlterAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("PersonalObj_Bas_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
        String objCheckId ;
        String objCheckNum;

        Random random=new Random();
        int i=random.nextInt(47);
        int j=random.nextInt(17);
        objCheckId= String.valueOf(System.currentTimeMillis()+i);
        objCheckNum= String.valueOf(System.currentTimeMillis()+j);

        recordMap.put("dataState","0");
        recordMap.put("checkState","0");
        recordMap.put("correctState","0");
        recordMap.put("objCheckSource","1");
        recordMap.put("dataFlg","0");
        recordMap.put("objCheckId",objCheckId);
        recordMap.put("objCheckNum",objCheckNum);
        recordMap.put("checkBeginDate", DateUtil.get8Date());

        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");
        mbtCommSaveService.process(resultBean,ToCheckInf.class);

        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("dataId", mbtCommSaveService.getDataId());
        return returnBean;
    }
}
