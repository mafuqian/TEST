package com.gingkoo.mbt.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.PersonalObjChgApvService;
import com.gingkoo.orm.entity.ToEntCheckInf;

public class EntObjChgApvAction extends WebAlterAction {
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request,
                                         HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        PersonalObjChgApvService mbtCommApvService = (PersonalObjChgApvService) context.getBean("personalObjChgApvService");
        mbtCommApvService.setEntityName(ToEntCheckInf.class.getName());
        mbtCommApvService.setUpdateResultBean(multiUpdateResultBean.getUpdateResultBeanByID("EntObj_ChgApv_ds"));
        mbtCommApvService.approve();
        returnBean.setParameter("isOptSucc", "true");
        return returnBean;
    }
}
