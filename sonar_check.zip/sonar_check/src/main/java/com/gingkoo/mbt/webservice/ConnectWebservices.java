package com.gingkoo.mbt.webservice;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.rpc.ServiceException;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.stereotype.Component;
@org.springframework.stereotype.Service
public class ConnectWebservices {

	
	public String sendXml(String xml,String url,String medthod) throws Exception {
		String result ="";
		
			String endpoint = url;
			Service service = new Service();
			Call call = (Call) service.createCall();
			call.setTargetEndpointAddress(endpoint);
			call.setOperationName(medthod);
			call.addParameter("querymessage",
					org.apache.axis.encoding.XMLType.XSD_DATE,
					javax.xml.rpc.ParameterMode.IN);
			call.setReturnType(org.apache.axis.encoding.XMLType.XSD_STRING);
			result = (String) call.invoke(new Object[]{xml});
			System.out.println("result is " + result);
			return result;
	}


	public Map<String,String> readStringXml(String xml, Map map) {
		Document document = null;
		try {
			document=DocumentHelper.parseText(xml);
		} catch (DocumentException e) {
		}
		Element rootEle = document.getRootElement();
		System.out.println("根节点名称："+rootEle.getName());//获取根节点
		getNodes(rootEle,map);
		return map;

	}

	public  Map<String,String> getNodes(Element node,Map map){
		System.out.println("--------------------");

		//当前节点的名称、文本内容和属性
		System.out.println("当前节点名称："+node.getName());//当前节点名称
		System.out.println("当前节点的内容："+node.getTextTrim());//当前节点名称
		map.put(node.getName(), node.getTextTrim());
		List<Attribute> listAttr=node.attributes();//当前节点的所有属性的list
		for(Attribute attr:listAttr){//遍历当前节点的所有属性
			String name=attr.getName();//属性名称
			String value=attr.getValue();//属性的值
			System.out.println("属性名称："+name+"属性值："+value);
		}

		//递归遍历当前节点所有的子节点
		List<Element> listElement=node.elements();//所有一级子节点的list
		for(Element e:listElement){//遍历所有一级子节点
			getNodes(e,map);//递归
		}
		return map;
	}

}

