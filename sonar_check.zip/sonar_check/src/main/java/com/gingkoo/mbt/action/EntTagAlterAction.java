package com.gingkoo.mbt.action;

import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.orm.entity.PerTagInf;

public class EntTagAlterAction extends WebAlterAction {
    
	private static final String DATASET_ID = "EntTag_Bas_ds";

    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("EntTag_Bas_ds");
        Map<String, String> recordMap = resultBean.getTotalList().get(0);
        String objCheckId ;
        String opr=recordMap.get("opr");
        Random random=new Random();
        int i=random.nextInt(47);
        int j=random.nextInt(17);
        recordMap.put("dataState","0");
        String dataId = recordMap.get("dataId");
        if ("add".equals(opr)  && null != dataId && "" != dataId ) {
        	objCheckId= String.valueOf(System.currentTimeMillis()+i);

            recordMap.put("dataFlg","0");
            recordMap.put("objTagId",objCheckId);
            recordMap.put("originateOrgCode",GlobalInfo.getCurrentInstance().getBrno());
            recordMap.put("originateUserCode",GlobalInfo.getCurrentInstance().getTlrno());
            returnBean.setParameter("objTagId", objCheckId);
        }
        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");
        mbtCommSaveService.process(resultBean,PerTagInf.class);

        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("dataId", mbtCommSaveService.getDataId());
        return returnBean;
    }
}
