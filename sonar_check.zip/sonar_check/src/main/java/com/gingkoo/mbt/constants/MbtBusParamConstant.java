package com.gingkoo.mbt.constants;

/**
 * @Author: li.jy
 * @Date: 2019/1/18
 */
public class MbtBusParamConstant {

    /**
     * 当日发送次数
     */
    public static final String TODAY_RESULT_SEND_TIMES = "TODAY_RESULT_SEND_TIMES";
    /**
     * 查询结果下载次数
     */
    public static final String RESULT_DOWNLOAN_TIMES = "RESULT_DOWNLOAN_TIMES";

    /**
     * 当日查询结果下载次数
     */
    public static final String TODAY_RESULT_DOWNLOAN_TIMES = "TODAY_RESULT_DOWNLOAN_TIMES";
    /**
     * 查询结果打印次数
     */
    public static final String RESULT_PRINT_TIMES = "RESULT_PRINT_TIMES";

    /**
     * 当日查询结果打印次数
     */
    public static final String TODAY_RESULT_PRINT_TIMES = "TODAY_RESULT_PRINT_TIMES";
}
