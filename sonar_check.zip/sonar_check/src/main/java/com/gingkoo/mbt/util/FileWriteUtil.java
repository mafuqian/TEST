package com.gingkoo.mbt.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;

public class FileWriteUtil {

	public static void Write(String path,String filepath,String content) {
		FileOutputStream outSTr = null;

		BufferedOutputStream Buff = null;

		try {
			File fileDir = new File(path); 
			if(!fileDir.exists()) {
				fileDir.mkdirs();
			}
			
			File file = new File(filepath);
			if(!file.exists()) {
				file.createNewFile();
			}
			outSTr = new FileOutputStream(file);

			Buff = new BufferedOutputStream(outSTr);

			Buff.write(content.getBytes("UTF-8"));

			Buff.flush();

			Buff.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
