package com.gingkoo.mbt.action;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.service.base.OPCaller;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.mbt.service.MbtCommSaveService;
import com.gingkoo.mbt.service.PersonalLocaAlterService;
import com.gingkoo.mbt.service.PersonalTagAlterService;
import com.gingkoo.orm.entity.LocateInf;
import com.gingkoo.orm.entity.TagInf;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;
import java.util.Random;

public class PersonalLocaAlterAction extends WebAlterAction {
    private static final String DATASET_ID = "PersonalTag_LocaBas_ds";
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse response) throws AppException {
        UpdateReturnBean returnBean = new UpdateReturnBean();
        UpdateResultBean resultBean = multiUpdateResultBean.getUpdateResultBeanByID("PersonalTag_Loca_ds");

        WebApplicationContext context= WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        MbtCommSaveService mbtCommSaveService  = (MbtCommSaveService) context.getBean("mbtCommSaveService");
        mbtCommSaveService.batchprocess(resultBean,LocateInf.class);

        returnBean.setParameter("isOptSucc", "true");
        returnBean.setParameter("dataId", mbtCommSaveService.getDataId());
        return returnBean;
    }
}
