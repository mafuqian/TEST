package com.gingkoo.platform.action;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.platform.entity.EastDepart;
import com.gingkoo.common.query.result.ResultMng;
import com.gingkoo.common.query.web.action.base.WebQueryAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.config.database.base.MyHibernateTemplate;
import com.gingkoo.gf4j2.framework.entity.bean.TreeNode;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.Result;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtils;

public class DepartTreeQueryAction extends WebQueryAction {

	@Override
	public Result call() throws AppException {
		List<TreeNode> list = new ArrayList<TreeNode>();
		StringBuffer hql = new StringBuffer();
		hql.append(" from EastDepart where 1=1");
		String id = getCommQueryServletRequest().getParameter("_id");
//		String rootBrcode = null;
//		if (StringUtils.isNotBlank(id)) {
//			hql.append(" and corpId='").append(id).append("'");
//		} else {
//			rootBrcode = GlobalInfo.getCurrentInstance().getCorpId();
//			hql.append(" and corpId = '").append(rootBrcode).append("'");
//		}

		List<EastDepart> eastDeparts = ApplicationContextUtils.getBean(MyHibernateTemplate.class).find(hql.toString());
		Iterator<EastDepart> iter = eastDeparts.iterator();
		while (iter.hasNext()) {
			EastDepart eastDepart = iter.next();
			TreeNode n = this.convert(eastDepart);
			if (StringUtils.isNotBlank(eastDepart.getPDepart())) {
				n.setHasChild(ROOTDAOUtils.getROOTDAO().queryByQL("from EastDepart where pDepart ='"+ eastDepart.getDepart() + "'").hasNext());
			}
			list.add(n);
		}
		ResultMng.fillResultByList(getCommonQueryBean(),getCommQueryServletRequest(), list, getResult());
		getResult().setContent(list);
		getResult().getPage().setTotalPage(1);
		getResult().init();

		return getResult();
	}
	
	private TreeNode convert(final EastDepart eastDepart) {
		TreeNode node = new TreeNode();
		node.setCanSelected(true);
		node.setId(StringUtils.strip(eastDepart.getDepart()));
		node.setPid(StringUtils.strip(eastDepart.getPDepart()));
		if (StringUtils.equalsIgnoreCase(node.getId(), node.getPid())) {
			node.setPid(null);
		}

		node.setText(eastDepart.getDepartName());
		node.setHasChild(false);
		return node;
	}
}
