package com.gingkoo.platform.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.service.base.OPCaller;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;

public class DepartDetailAlterAction extends WebAlterAction {
	@Override
	public UpdateReturnBean saveOrUpdate(
			MultiUpdateResultBean multiUpdateResultBean,
			HttpServletRequest request, HttpServletResponse response)
			throws AppException {
			UpdateReturnBean updateReturnBean = new UpdateReturnBean();
		    UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID("DepartMngDetail");
//			   String p_Depart= updateResultBean.getParameter("pDepart");
		    ServiceContext context = new ServiceContext();
//			EastDepart eastDepart = new EastDepart();
//		      eastDepart.setPDepart(p_Depart);
			

		    while (updateResultBean.hasNext())
		    {
		      Map<String, String> map = updateResultBean.next();
		      context.setAttribute("CMD", "CMD_UPDATE");   
//		      mapToObject(eastDepart, map);
//		      map.put("pDepart", p_Depart);
		      context.setAttribute("IN_PARAM", map);
		    }
		    GlobalInfo.getCurrentInstance().addBizLog("部门管理设置");
		    OPCaller.call("departMngUpdateService", context);
		    return updateReturnBean;
	}
}