package com.gingkoo.platform.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gingkoo.common.query.web.action.base.WebAlterAction;
import com.gingkoo.gf4j2.core.sys.excp.AppException;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.entity.result.MultiUpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateResultBean;
import com.gingkoo.gf4j2.framework.entity.result.UpdateReturnBean;
import com.gingkoo.gf4j2.framework.service.base.OPCaller;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;

public class DepartMngAlterAction extends WebAlterAction {
	@Override
	public UpdateReturnBean saveOrUpdate(
			MultiUpdateResultBean multiUpdateResultBean,
			HttpServletRequest request, HttpServletResponse response)
			throws AppException {
		
	    UpdateReturnBean updateReturnBean = new UpdateReturnBean();
	    UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID("DepartMng");
//	   String p_Depart= updateResultBean.getParameter("pDepart");
	   
	    ServiceContext context = new ServiceContext();
	    while (updateResultBean.hasNext())
	    {
	      Map<String, String> map = updateResultBean.next();
	      String opr = (String)map.get("opr");
	      if ("add".equals(opr)) {
	        context.setAttribute("CMD", "CMD_INSERT");
	      } else if ("mod".equals(opr)) {
	        context.setAttribute("CMD", "CMD_UPDATE");
	      } else if ("alter_status".equals(opr)) {
	        context.setAttribute("CMD", "ALTER_STATUS");
	      } else if ("del".equals(opr)) {
	        context.setAttribute("CMD", "CMD_DEL");
	      }
//	      map.put("pDepart", p_Depart);
	      context.setAttribute("IN_PARAM", map);
	    }
	    GlobalInfo.getCurrentInstance().addBizLog("部门管理设置");
	    OPCaller.call("departMngUpdateService", context);
	    return updateReturnBean;
		
	}
}