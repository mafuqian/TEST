package com.gingkoo.platform.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.gingkoo.common.platform.ROOTDAOUtils;
import com.gingkoo.common.platform.entity.EastDepart;
import com.gingkoo.common.platform.entity.EastDepartPending;
import com.gingkoo.common.workflow.WorkFLowConstant;
import com.gingkoo.common.workflow.entity.bean.ReqData;
import com.gingkoo.common.workflow.service.impl.WorkFlowServiceImpl;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.framework.config.database.base.MyHibernateTemplate;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.service.base.BaseService;
import com.gingkoo.gf4j2.framework.service.base.ServiceContext;
import com.gingkoo.gf4j2.framework.util.ExceptionUtil;

@Component
public class DepartMngApvService extends BaseService {

	@Value("${application.gpms.isCheckSelf}")
	private String isCheckSelf;
	@Autowired
	private MyHibernateTemplate template;
	private static final Log logger = LogFactory.getLogger(DepartMngApvService.class);
	@Autowired
	private WorkFlowServiceImpl workFlowServiceImpl;
	@Override
	public void afterProc(ServiceContext arg0) throws CommonException {

	}

	@Override
	public void beforeProc(ServiceContext arg0) throws CommonException {
		// TODO Auto-generated method stub

	}

	@Override
	public void execute(ServiceContext context) throws CommonException {
		// TODO Auto-generated method stub
		logger.info("-----------DepartMngApvService start-----------------");
		String opr = (String) context.getAttribute("CMD");
		
		Map<String, String> map = (Map<String, String>) context.getAttribute("IN_PARAM");
		String dataId = map.get("dataId");
		List<EastDepartPending> list = template.find("from EastDepartPending where data_id =?", new Object[]{dataId});
		String gpmsNextAction = list.get(0).getGpmsNextAction();
		String depart = map.get("depart");
		String departName = map.get("departname");
		String status = map.get("status");
		String pDepart = map.get("pDepart");
		String datarejdesc = map.get("datarejdesc");
		
		List<Object> entity = new ArrayList();
		ReqData data = null;
		
		
		
		//add by caohuan 20170914 当init.properties中的isCheckSelf为2时，自己不可以操作自己维护的数据
		String dataCrtUser = list.get(0).getDataCrtUser();
		String dataChgUser = list.get(0).getDataChgUser();
		String gpmsNextaction = list.get(0).getGpmsNextAction();
		GlobalInfo globalInfo = GlobalInfo.getCurrentInstance();
		if("2".equals(isCheckSelf) && dataCrtUser.equals(globalInfo.getTlrno())&& "10".equals(gpmsNextaction)){
			ExceptionUtil.throwCommonException("不可以审核自己新增的部门信息", "操作错误");
		}
		if(dataChgUser != null){
			if("2".equals(isCheckSelf) && dataChgUser.equals(globalInfo.getTlrno())&& ("20".equals(gpmsNextaction)||"30".equals(gpmsNextaction))){
				ExceptionUtil.throwCommonException("不可以审核自己修改的部门信息", "操作错误");
			}
		}
		if ("ok".equals(opr)) {
			logger.info("-----------审核通过-----------------");
			
			//新增通过
			if(gpmsNextAction.startsWith("1")){
				//插入主表
//				String hql = "from EastDepartPending where data_id = ?";
//				List<EastDepartPending> l = template.find(hql, new Object[] { dataId });
				EastDepartPending eastDepartPending = list.get(0);
				EastDepart eastDepart = pendingToDepart(eastDepartPending);
				entity.add(eastDepart);
		        data = WorkFLowConstant.getReqData(entity);
				this.workFlowServiceImpl.doWork(data);
				//删除临时表
				delPending(dataId);
			}
			
			//修改、更改状态通过
			if(gpmsNextAction.startsWith("2")||gpmsNextAction.startsWith("3")){
				String hql = "from EastDepart where data_id = ?";
				List<EastDepart> l = template.find(hql, new Object[] { dataId });
				EastDepart eastDepart = l.get(0);
				eastDepart.setDepart(depart);
				eastDepart.setDepartName(departName);
				eastDepart.setStatus(status);
				eastDepart.setPDepart(pDepart);
				eastDepart.setDataRejDesc("");
				if(gpmsNextAction.startsWith("2")){
					eastDepart.setGpmsNextAction("21");
				}
				if(gpmsNextAction.startsWith("3")){
					eastDepart.setGpmsNextAction("31");
				}
				entity.add(eastDepart);
		        data = WorkFLowConstant.getReqData(entity);
		        //更新主表数据
				this.workFlowServiceImpl.doWork(data);
				//删除临时表数据
				delPending(dataId);
			}
		} else if ("ref".equals(opr)) {
			logger.info("-----------审核拒绝-----------------");
			//新增拒绝
			if(gpmsNextAction.startsWith("1")){
				//删除临时表数据
				delPending(dataId);
			}
			//修改、更改状态拒绝
			if(gpmsNextAction.startsWith("2")||gpmsNextAction.startsWith("3")){
				String hql = "from EastDepart where data_id = ?";
				List<EastDepart> l = template.find(hql, new Object[] { dataId });
				EastDepart eastDepart = l.get(0);
				eastDepart.setDataRejDesc(datarejdesc);
				if(gpmsNextAction.startsWith("2")){
					eastDepart.setGpmsNextAction("22");
				}
				if(gpmsNextAction.startsWith("3")){
					eastDepart.setGpmsNextAction("32");
				}
				entity.add(eastDepart);
		        data = WorkFLowConstant.getReqData(entity);
		        //更新主表数据
				this.workFlowServiceImpl.doWork(data);
				//删除临时表数据
				delPending(dataId);
			}
			
		} else {
			ExceptionUtil.throwCommonException("错误的操作", "错误的操作");
		}
		logger.info("-----------DepartMngApvService end-----------------");
	}
	
	public EastDepart pendingToDepart(EastDepartPending eastDepartPending){
		EastDepart eastDepart = new EastDepart();
		eastDepart.setDataId(eastDepartPending.getDataId());
		eastDepart.setDataDate(eastDepartPending.getDataDate());
		eastDepart.setCorpId(eastDepartPending.getCorpId());
		eastDepart.setOrgId(eastDepartPending.getOrgId());
		eastDepart.setGroupId(eastDepartPending.getGroupId());
		eastDepart.setInqOrgId(eastDepartPending.getInqOrgId());
		eastDepart.setInqGroupId(eastDepartPending.getInqGroupId());
		eastDepart.setDepart(eastDepartPending.getDepart());
		eastDepart.setDepartName(eastDepartPending.getDepartName());
		eastDepart.setPDepart(eastDepartPending.getPDepart());
		eastDepart.setStatus(eastDepartPending.getStatus());
		eastDepart.setRemarks(eastDepartPending.getRemarks());
		eastDepart.setCheckFlag(eastDepartPending.getCheckFlag());
		eastDepart.setCheckDesc(eastDepartPending.getCheckDesc());
		eastDepart.setCheckErrType(eastDepartPending.getCheckErrType());
		eastDepart.setNextAction(eastDepartPending.getNextAction());
		eastDepart.setDataStatus(eastDepartPending.getDataStatus());
		eastDepart.setDataFlag(eastDepartPending.getDataFlag());
		eastDepart.setDataSource(eastDepartPending.getDataSource());
		eastDepart.setDataVersion(eastDepartPending.getDataVersion());
		eastDepart.setDataRejDesc(eastDepartPending.getDataRejDesc());
		eastDepart.setDataDelDesc(eastDepartPending.getDataDelDesc());
		eastDepart.setDataCrtUser(eastDepartPending.getDataCrtUser());
		eastDepart.setDataCrtDate(eastDepartPending.getDataCrtDate());
		eastDepart.setDataCrtTime(eastDepartPending.getDataCrtTime());
		eastDepart.setDataChgUser(eastDepartPending.getDataChgUser());
		eastDepart.setDataChgDate(eastDepartPending.getDataChgDate());
		eastDepart.setDataChgTime(eastDepartPending.getDataChgTime());
		eastDepart.setDataApvUser(eastDepartPending.getDataApvUser());
		eastDepart.setDataApvDate(eastDepartPending.getDataApvDate());
		eastDepart.setDataApvTime(eastDepartPending.getDataApvTime());
		eastDepart.setRsv1(eastDepartPending.getRsv1());
		eastDepart.setRsv2(eastDepartPending.getRsv2());
		eastDepart.setRsv3(eastDepartPending.getRsv3());
		eastDepart.setRsv4(eastDepartPending.getRsv4());
		eastDepart.setRsv5(eastDepartPending.getRsv5());
		eastDepart.setGpmsNextAction("11");
		return eastDepart;
	}
	
	public void delPending(String dataId){
		ROOTDAO s = ROOTDAOUtils.getROOTDAO();
		StringBuffer dql = new StringBuffer();
		dql.append("delete from East_Depart_Pending where data_id = \'").append(dataId).append("\'");
		try {
			s.executeSql(dql.toString());
		} catch (CommonException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
