package com.gingkoo.gmo.job;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.gmo.service.GmoExcelImportService;

@Component("gmoExcelImortJob")
public class GmoExcelImortJob {

    private static final Log logger = LogFactory.getLog(GmoExcelImortJob.class);

    @Autowired
    GmoExcelImportService gmoExcelImportService;
    
    JobResult jr = new JobResult();

    public Map<String, String> execute() {
        logger.info("===============++++++++++Exec TxtFileJob begin++++++++++=============");
        jr.setErrCode("00");
        jr.setErrMsg("OK");
        try {
        	gmoExcelImportService.insert();
        	 
        } catch (Exception arg6) {
            arg6.printStackTrace();
            logger.info("操作失败，错误信息：" + arg6.getMessage());
            jr.setErrCode("E");
            jr.setErrMsg("操作失败，错误信息：" + arg6.getMessage());
            return jr.getMap();
        }

        logger.info("===============++++++++++Exec TxtFileJob end++++++++++=============");
        return jr.getMap();
    }

}
