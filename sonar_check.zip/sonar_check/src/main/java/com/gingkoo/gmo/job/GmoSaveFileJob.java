package com.gingkoo.gmo.job;

import java.io.File;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.cupd.service.CupdParaService;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gmo.service.GmoSaveFileService;

/**
 * 
 * East报文生成 <功能详细描述>
 * 
 * 1、使用线程(后改，优化)
 * 2、使用循环调用起线程完成报文生成
 * 
 * 
 * @author kane
 * @version [版本号, 2017年1月7日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
@Component("gmoSaveFileJob")
public class GmoSaveFileJob {
	private static final Log logger = LogFactory.getLog(GmoSaveFileJob.class);
	@Autowired
	GmoSaveFileService gmoSaveFileService;
	@Autowired
	private CupdParaService cupdParaService;
	public Map<String, String> execute(String mail,String fileSign){
        logger.info("===============++++++++++Exec GmoSaveFileJob begin++++++++++=============");

 		JobResult jr = new JobResult(); 
 		
 		try {
			String path = cupdParaService.getParamValue("GMO_PTAH", "GMO");
			/*String dirtmp = DateUtil.get8Date();
			if("".equals(dir)) {
				dir = dirtmp;
			}
			path = path + File.separator + dir;*/
			
			boolean falg = gmoSaveFileService.saveFile(path,mail,fileSign);
			if(falg) {
				jr.setErrCode("00");
				jr.setErrMsg("保存成功");
			}else {
				jr.setErrCode("E");
				jr.setErrMsg("未收到GMO文件");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			jr.setErrCode("E");
			jr.setErrMsg(e.getMessage());
		}
        logger.info("===============++++++++++Exec GmoSaveFileJob end++++++++++=============");

        return jr.getMap();
	}
	
}

