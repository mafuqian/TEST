package com.gingkoo.gmo.job;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.cupd.service.ObjectInsertToTableService;
import com.gingkoo.gmo.service.ExcelImportService;

@Component("txtFileJob")
public class TxtFileJob {

    private static final Log logger = LogFactory.getLog(TxtFileJob.class);

    @Autowired
    ExcelImportService excelImportService;
    
    JobResult jr = new JobResult();

    public Map<String, String> execute(String tableName,String path) {
        logger.info("===============++++++++++Exec TxtFileJob begin++++++++++=============");
        jr.setErrCode("00");
        jr.setErrMsg("OK");
        try {
        	 excelImportService.getSql(tableName, path);
        	 
        } catch (Exception arg6) {
            arg6.printStackTrace();
            logger.info("操作失败，错误信息：" + arg6.getMessage());
            jr.setErrCode("E");
            jr.setErrMsg("操作失败，错误信息：" + arg6.getMessage());
            return jr.getMap();
        }

        logger.info("===============++++++++++Exec TxtFileJob end++++++++++=============");
        return jr.getMap();
    }

}
