package com.gingkoo.gmo.service;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.gingkoo.common.batch.entity.GpBmIdFiledata;
import com.gingkoo.common.batch.entity.GpBmIdSheetdata;
import com.gingkoo.common.batch.entity.bean.DataImportProcess;
import com.gingkoo.common.batch.entity.bean.FileImportMonitor;
import com.gingkoo.common.batch.entity.bean.TFileDataInfo;
import com.gingkoo.common.dataimport.dynamic.JobRegister;
import com.gingkoo.common.dataimport.task.DataImportTask;
import com.gingkoo.common.fileparser.service.base.BaseExcelOp;
import com.gingkoo.common.validate.component.DataValidateComponent;
import com.gingkoo.gf4j2.core.sys.log.Log;
import com.gingkoo.gf4j2.core.sys.log.LogFactory;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.orm.entity.MbtHsbcCupdFileLog;
import com.gingkoo.orm.entity.MbtHsbcGmoFileLog;

/**
 * 文件导入组件
 */
@Component(GmoExcelImportService.ID)
@Scope("prototype")
@Service
public class GmoExcelImportService {
	private static final Log logger = LogFactory.getLogger(GmoExcelImportService.class);

	public static final String ID = "gmoExcelImportService";

	public static final String IN_PARAM = "IN_PARAM";

	@Autowired
	@Qualifier("ROOTDAO")
	ROOTDAO rootdao;

	@Autowired
	@Qualifier("fileImportTaskExecutor") 
	ThreadPoolTaskExecutor taskExecutor;
	
	@Autowired
	JobRegister jobRegister;

	@Autowired
	private DataValidateComponent validateComponent;
	
	public static FileImportMonitor MONITOR = FileImportMonitor.getInstance();

	 public boolean check() throws Exception {
		 	
			String hql = "from MbtHsbcGmoFileLog where dataDate = ? ";
			List<MbtHsbcGmoFileLog> resultList = rootdao.queryByQL2List(hql,new Object[] {DateUtil.get8Date()},null);
			if(resultList.isEmpty()) {
				return true;
			}
		 return false;
				 
	 }
	 
	
	 public boolean insert() throws Exception {
		 	
			String hql = "from MbtHsbcGmoFileLog where isAnalysis = '1' ";
			List<MbtHsbcGmoFileLog> resultList = rootdao.queryByQL2List(hql,null,null);
			if(!resultList.isEmpty()) {
				for (MbtHsbcGmoFileLog mbtHsbcGmoFileLog : resultList) {
					String filePath = mbtHsbcGmoFileLog.getFilePath();
					String guid = mbtHsbcGmoFileLog.getFileGuid();
					String dataId = mbtHsbcGmoFileLog.getDataId();
					this.excute(dataId,guid, filePath, DateUtil.get14Date());	
				}
			}
		 return true;
				 
	 }
	
	public Map<String,Object> beforeExecute(String guid,String filepath) throws CommonException {

		logger.info("开始导入文件处理……");
		
		File importFile = new File(filepath);
		String realFileName = importFile.getAbsolutePath().substring(importFile.getParent().length() + 1);
		String id = guid;
		GpBmIdFiledata fileData = rootdao.query(GpBmIdFiledata.class, id);

		List<TFileDataInfo> tFileDataInfos = new ArrayList<TFileDataInfo>();

		List<GpBmIdSheetdata> sheetData = rootdao.queryByQL2List("from GpBmIdSheetdata where pguid='" + id + "' order by sheetNum asc");
		boolean fileBatchEdit = filePreHandle(importFile.getAbsolutePath());//判断是否是批量编辑。
		for (GpBmIdSheetdata sheet : sheetData) {
			TFileDataInfo curImpFileInfo = new TFileDataInfo();
			// 存放head的map`1
			Map<String, String> headMap = new HashMap<String, String>();
			curImpFileInfo.setHeadMap(headMap);
			curImpFileInfo.setGuid(sheet.getGuid());
			curImpFileInfo.setFilePath(importFile.getParent());
			curImpFileInfo.setRealFileName(realFileName);
			curImpFileInfo.setWorkDate("");
			curImpFileInfo.setGroupId("");

			if (fileData.getBatchNo() != null && !"".equals(fileData.getBatchNo())) {
				curImpFileInfo.setBatchNo(Integer.parseInt(fileData.getBatchNo()));
			}
			if (fileData.getSequenceNo() != null && !"".equals(fileData.getSequenceNo())) {
				curImpFileInfo.setSequenceNo(Integer.parseInt(fileData.getSequenceNo()));
			}
			if (fileData.getKeyFlag() != null && !"".equals(fileData.getKeyFlag())) {
				curImpFileInfo.setKeyFlag(Integer.parseInt(fileData.getKeyFlag()));
			}
			curImpFileInfo.setDepartId(fileData.getDepartId());
			curImpFileInfo.setFileName(fileData.getFileName());
			curImpFileInfo.setFileOwner(fileData.getFileOwner());
			curImpFileInfo.setMainFlag(fileData.getMainFlag());
			curImpFileInfo.setFuid(fileData.getFuid());
			curImpFileInfo.setImportTime(fileData.getImportTime());
			if (fileData.getImportType() != null && !"".equals(fileData.getImportType())) {
				curImpFileInfo.setImportType(Integer.parseInt(fileData.getImportType()));
			}
			curImpFileInfo.setCheckTable(fileData.getCheckTable());
			if (fileData.getJobType() != null && !"".equals(fileData.getJobType())) {
				curImpFileInfo.setJobType(Integer.parseInt(fileData.getJobType()));
			}
			curImpFileInfo.setArgs(fileData.getArgs());

			if (sheet.getStartRow() != null && !"".equals(sheet.getStartRow())) {
				curImpFileInfo.setStartRow(Integer.parseInt(sheet.getStartRow()));
			}
			if (sheet.getStartColumn() != null && !"".equals(sheet.getStartColumn())) {
				curImpFileInfo.setStartColumn(Integer.parseInt(sheet.getStartColumn()));
			}
			if (sheet.getEndColumn() != null && !"".equals(sheet.getEndColumn())) {
				curImpFileInfo.setEndColumn(Integer.parseInt(sheet.getEndColumn()));
			}
			if (sheet.getSheetNum() != null && !"".equals(sheet.getSheetNum())) {
				if(fileBatchEdit) {
					curImpFileInfo.setSheetNum(Integer.parseInt(sheet.getSheetNum())+1);
				}else {
					curImpFileInfo.setSheetNum(Integer.parseInt(sheet.getSheetNum()));
				}
			}
			curImpFileInfo.setBatchEdit(fileBatchEdit);
			curImpFileInfo.setTableName(sheet.getTableName());
			curImpFileInfo.setFormatType(sheet.getFormatType());
			curImpFileInfo.setListSeparator(sheet.getListSeparator());
			curImpFileInfo.setEndRowFlag(sheet.getEndrowFlag());
			curImpFileInfo.setRealTableName(sheet.getTableName());
			tFileDataInfos.add(curImpFileInfo);
		}
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("fileData", fileData);
		result.put("tFileDataInfos", tFileDataInfos);
		result.put("realFileName", realFileName);
		return result;
	}
	
	/**
	 * 文件预处理
	 * @param inParam
	 * @return
	 * @throws IOException 
	 * @throws CommonException 
	 */
	public boolean filePreHandle(String fFName) throws CommonException{
		BaseExcelOp baseExcelOp = new BaseExcelOp();
		StringBuilder strMessage = new StringBuilder();
		boolean isBatchEdit = false;
		try {
			isBatchEdit = baseExcelOp.readFileDescribeSheetContent(fFName,strMessage);
		} catch (IOException e) {
			e.printStackTrace();
			throw new CommonException(strMessage.toString());
		}
		if(!"".equals(strMessage.toString())) {
			logger.error(strMessage.toString());
			throw new CommonException(strMessage.toString());
		}
		return isBatchEdit;
	}
	
	
	
	
	public void excute(String dataId,String guid,String filepath,String date) throws Exception{
		Map<String,Object> fileInfos = beforeExecute(guid,filepath);
		List<TFileDataInfo> tFileDataInfos = (List<TFileDataInfo>)fileInfos.get("tFileDataInfos");
		
		Map<Integer,Future<DataImportProcess>> taskResults=new HashMap<Integer,Future<DataImportProcess>>();
		Map<Integer,DataImportProcess> sheetNumProcesses = new HashMap<Integer,DataImportProcess>();
		for (TFileDataInfo curImpFileInfo : tFileDataInfos) {
			DataImportTask importTask = ApplicationContextUtil.getBean(DataImportTask.class);
			importTask.setCurImpFileInfo(curImpFileInfo);
		//	importTask.setGlobalInfo(GlobalInfo.getCurrentInstance());
			Future<DataImportProcess> importStatus = taskExecutor.submit(importTask);
			taskResults.put(curImpFileInfo.getSheetNum(),importStatus);
		}
		logger.info("导入任务执行中 ...");
		//2.结果归集，用迭代器遍历futureList,高速轮询（模拟实现了并发），任务完成就移除
		int size = taskResults.size();
        while(true){
        	if(size==0) {
        		break;
        	}
        	Iterator<Map.Entry<Integer, Future<DataImportProcess>>> it = taskResults.entrySet().iterator();
        	
        	while (it.hasNext()) {
        		Map.Entry<Integer, Future<DataImportProcess>> entry = it.next();
        		Future<DataImportProcess> taskResult = entry.getValue();
        		//如果任务完成取结果，否则判断下一个任务是否完成
                if (taskResult.isDone() && !taskResult.isCancelled()){
                    //获取结果
                	DataImportProcess process=null;
					try {
						process = taskResult.get();
					} catch (InterruptedException | ExecutionException e) {
						e.printStackTrace();
						size--;
						logger.info(e.getMessage());
						continue;
					}
					if(process!=null) {
						sheetNumProcesses.put(entry.getKey(), process);
					}
					//任务完成移除任务
					it.remove();
					size--;
                }else{
                    try {
						TimeUnit.MILLISECONDS.sleep(1);
					} catch (InterruptedException e) {
						e.printStackTrace();
						size--;
						continue;
					}
                }
        	}
         }
        
		GpBmIdFiledata fileData = (GpBmIdFiledata)fileInfos.get("fileData");
		//String workDate = (String)fileInfos.get("workDate");
		String realFileName = (String)fileInfos.get("realFileName");
		 this.afterImport(fileData,realFileName,sheetNumProcesses,dataId,date);

	}
	
	public int afterImport(GpBmIdFiledata fileData,String realFileName,Map<Integer,DataImportProcess> sheetNumProcesses,String dataId,String date) throws CommonException {
		try {
			int totalRecord=0;
			int errorRecord=0;
			
			for (Map.Entry<Integer, DataImportProcess> entry : sheetNumProcesses.entrySet()) { 
				DataImportProcess process = entry.getValue();
				totalRecord+=process.sumRow;
				if (process.errorNumber > 0) {
					errorRecord += process.errorNumber;
				}
			}
			
			
			String updateSql = "";
			if(errorRecord == 0) {
				updateSql = "UPDATE mbt_hsbc_gmo_file_log SET IS_ANALYSIS ='2',ANALSIS_END_TIME='"+DateUtil.get14Date()+"',ANALSIS_START_TIME='"+date+"' ,IMPORT_LOG='总条数:" + totalRecord + ";插入失败:"
						+ errorRecord + "'  WHERE DATA_ID='" + dataId + "'";
			}else {
				updateSql = "UPDATE mbt_hsbc_gmo_file_log SET IS_ANALYSIS ='3',ANALSIS_END_TIME='"+DateUtil.get14Date()+"',ANALSIS_START_TIME='"+date+"' ,IMPORT_LOG='总条数:" + totalRecord + ";插入失败:"
						+ errorRecord + "'  WHERE DATA_ID='" + dataId + "'";
			}
			
			rootdao.executeSql(updateSql);
			
			logger.info("-------GET problem data from importfile after check is over -----------");

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("ERROR IS " + e.getMessage());
			throw new CommonException("ERROR IS " + e.getMessage());
		} 
		
		logger.info("-------GPMSCallAfterImportService end-----------");
	
		return 1;
	}


	/**
	 * 存储过程执行后无需校验，更新导入状态
	 * 
	 * @param fileName
	 *            上传文件名称
	 * @throws CommonException
	 */
	public void updateAfterStatus(String fileName,String message) throws CommonException {
		String Sql = "update  GP_BM_ID_UPLOADLOG set FILLER1='"+message+"' where file_name='"
				+ fileName + "'";
		try {
			rootdao.executeSql(Sql);
		} catch (Exception e) {
			throw new CommonException("执行状态更新失败！");
		}
	}

	public static String getStringTime() {
		Date currentTime = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
		String dateString = formatter.format(currentTime);
		return dateString;
	}
	
	public static void main(String[] args) {
		File importFile = new File("D:\\hsbc-mbt\\TREATS_CKOVLMP.xlsx");
		String realFileName = importFile.getAbsolutePath().substring(importFile.getParent().length() + 1);
		
		System.out.println(importFile.getParent());
	}
}
