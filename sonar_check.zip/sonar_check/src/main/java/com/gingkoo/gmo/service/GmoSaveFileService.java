package com.gingkoo.gmo.service;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gingkoo.cupd.service.MailServices;
import com.gingkoo.cupd.service.SaveCupdFileService;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.dao.impl.ROOTDAO;
import com.gingkoo.orm.entity.MbtHsbcCupdFileLog;
import com.gingkoo.orm.entity.MbtHsbcGmoFileLog;

@Service
public class GmoSaveFileService {

    private static final Log logger = LogFactory.getLog(SaveCupdFileService.class);

	@Autowired
	ROOTDAO dao;
	@Autowired
	MailServices mailServices;
	//D10052900H00022019090611001020
	public boolean saveFile(String path,String mail,String fileSign) throws Exception {

		String path_sign = path + File.separator + fileSign;
		File file_path_sign = new File(path_sign);
		if(file_path_sign.exists()) {
			
			String newPath = path + File.separator +DateUtil.get8Date() + File.separator;
			delete(newPath,true);
			move(path, newPath);

			File file = new File(newPath);
			File[] lfile = file.listFiles();
			for(int i = 0;i<lfile.length;i++) {
				File f = lfile[i];
				MbtHsbcGmoFileLog log = new MbtHsbcGmoFileLog();
				String name = f.getName();
				String filePath = f.getAbsolutePath();
				
				if(name.equals(fileSign)) {
					continue;
				}

				log = new MbtHsbcGmoFileLog();
				log.setDataDate(DateUtil.get8Date());
				log.setArriveTime(DateUtil.get14Date());
				log.setDataId(UUID.randomUUID().toString().replace("-", ""));
				log.setFilePath(filePath);
				
				String guidname = name.substring(0,name.indexOf("_"));
				
				String sql  = "SELECT GUID,FILE_NAME FROM GP_BM_ID_FILEDATA WHERE file_name LIKE '%"+guidname+"%'";
				Iterator it = dao.queryBySQL(sql);
				while (it.hasNext()) {
					Object[] object = (Object[]) it.next();
					String fileGuid = object[0] != null ? object[0].toString() : "";
					if(!"".equals(fileGuid)) {
						log.setIsAnalysis("1");
						log.setFileGuid(fileGuid);
					}
					
				}
				
				dao.save(log);
			
			}
			delete(path,false);
			return true;
		}else {
			MbtHsbcGmoFileLog log = new MbtHsbcGmoFileLog();
			log = new MbtHsbcGmoFileLog();
			log.setDataDate(DateUtil.get8Date());
			log.setDataId(UUID.randomUUID().toString().replace("-", ""));
			log.setIsAnalysis("4");
			dao.save(log);
			
		    mailServices.send("未收到GMO文件邮件提醒", mail, "未收到GMO文件！");
			return false;
		}
	}
	
	public void copyFile(String sourcePath, String newPath) {
		File start = new File(sourcePath);
		File end = new File(newPath);
		try(BufferedInputStream bis=new BufferedInputStream(new FileInputStream(start));
			BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream(end))) {
			int len = 0;
			byte[] flush = new byte[1024];
			while((len=bis.read(flush)) != -1) {
				bos.write(flush, 0, len);
			}
			bos.flush();
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void delete(String path,boolean falg) {
		File newPathfile = new File(path);
		if(newPathfile.exists()) {
			File[] lfile = newPathfile.listFiles();
			for(int i=0;i<lfile.length;i++) {
				if(lfile[i].isFile()) {
					lfile[i].delete();
				}
				
			}
		}
		if(falg) {
			newPathfile.mkdirs();
		}
	}
	
	
	public void move(String path,String newPath) {
		
		File file = new File(path);
		File[] lfile = file.listFiles();
		for(int i=0;i<lfile.length;i++) {
			File file2 = lfile[i];
			if(file2.isFile()) {
				String newFilePath = newPath + file2.getName();
				copyFile(file2.getAbsolutePath(), newFilePath);
			}
		}
	}
	
	
	
	
	
	public static void main(String[] args) throws Exception {/*
		String path = "D:\\sftp\\tmp\\gmo\\";
		String newPath = path + File.separator +DateUtil.get8Date() + File.separator;
		File newPathfile = new File(newPath);
		if(newPathfile.exists()) {
			File[] lfile = newPathfile.listFiles();
			for(int i=0;i<lfile.length;i++) {
				lfile[i].delete();
			}
			
		}
		newPathfile.mkdir();
		File file = new File(path);
		File[] lfile = file.listFiles();
		for(int i=0;i<lfile.length;i++) {
			File file2 = lfile[i];
			if(file2.isFile()) {
				String newFilePath = newPath + file2.getName();
				copyFile(file2.getAbsolutePath(), newFilePath);
			}
		}
	*/}
}
