package com.gingkoo.gmo.job;

import java.io.File;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gingkoo.common.batch.entity.bean.JobResult;
import com.gingkoo.cupd.service.CupdParaService;
import com.gingkoo.cupd.sftp.SftpUtil;

/**
 * 
 * East报文生成 <功能详细描述>
 * 
 * 1、使用线程(后改，优化)
 * 2、使用循环调用起线程完成报文生成
 * 
 * 
 * @author kane
 * @version [版本号, 2017年1月7日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
@Component("gmoSftpDownLoadFileJob")
public class GmoSftpDownLoadFileJob {
	private static final Log logger = LogFactory.getLog(GmoSftpDownLoadFileJob.class);


	@Autowired
	private CupdParaService cupdParaService;

	
	public Map<String, String> execute(String lpwd){
        logger.info("===============++++++++++Exec GmoSftpDownLoadFileJob begin++++++++++=============");
        logger.info("===============++++++++++Exec GmoSftpDownLoadFileJob end++++++++++=============");

 		JobResult jr = new JobResult(); 
		try {
			String connect = cupdParaService.getParamValue("SFTP_DB_CONNECT", "SFTP");
			if(connect!=null){
				String[] connects = connect.split("\\|");
				String ip = connects[0];
				String user = connects[1];
				String port = connects[2];
				String key =  connects[3];
				String pwd =  connects[4];
				String error =  connects[5];
				String mail =  connects[6];
				
				SftpUtil sftpUtil = new SftpUtil(user, ip, port,key, pwd);
				logger.info("连接成功");
				String path = cupdParaService.getParamValue("SFTP_DB_CONNECT", "SFTP_PATH");
				
				String l_path = cupdParaService.getParamValue("SFTP_DB_CONNECT", "SFTP_LOCATION_PATH");
				l_path = l_path + File.separator+"gmo"+File.separator;
				boolean flag = sftpUtil.batchDownloadFile(path, l_path, "XLSX", false,error,mail,lpwd);
				if(flag) {
					jr.setErrCode("00");
					jr.setErrMsg("OK");
					logger.info("下载成功！");
				}else {
					jr.setErrCode("E");
					jr.setErrMsg("未收到银联文件");
					logger.info("下载失败！");
				}
				
			}else {
				jr.setErrCode("E");
				jr.setErrMsg("SFTP 配置未完成");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			jr.setErrCode("E");
			jr.setErrMsg(e.getMessage());
		}
		
        logger.info("===============++++++++++Exec GmoSftpDownLoadFileJob end++++++++++=============");

		
        return jr.getMap();
	}
	
}

