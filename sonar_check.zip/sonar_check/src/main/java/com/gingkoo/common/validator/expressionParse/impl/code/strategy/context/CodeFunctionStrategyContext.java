package com.gingkoo.common.validator.expressionParse.impl.code.strategy.context;

import com.gingkoo.common.validator.bean.ParseResultNode;
import com.gingkoo.common.validator.bean.ParseResultNodeTree;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.baseInterface.CodeFunctionStrategy;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 
 * <p>
 * Description: 函数策略上下文
 * </p>
 * <p>
 * Copyright: Copyright (c) 2019
 * </p>
 * <p>
 * Company: GINGKOO
 * </p>
 * 
 * @date 2019年6月14日
 * @version 1.0
 */
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class CodeFunctionStrategyContext {

	// 持有一个策略实现的引用
	private CodeFunctionStrategy functionStrategy;

	ParseResultNode resultNode;

	List<ParseResultNodeTree> childsNodeTrees;

	// 注入具体的策略类和参数
	public void setStrategyContext(CodeFunctionStrategy functionStrategy, ParseResultNode resultNode,
			List<ParseResultNodeTree> childsNodeTrees) {
		this.functionStrategy = functionStrategy;
		this.resultNode = resultNode;
		this.childsNodeTrees = childsNodeTrees;
	}

	/**
	 * 函数初判断
	 */
	public void judgeExpression() {
		functionStrategy.judgeExpression(this);
	}

	/**
	 * 解析表达式。
	 */
	public void parseExpress() {
		// 调用策略实现的方法
		functionStrategy.parseFunction(this);
	}

	public ParseResultNode getResultNode() {
		return resultNode;
	}

	public List<ParseResultNodeTree> getChildsNodeTrees() {
		return childsNodeTrees;
	}

}