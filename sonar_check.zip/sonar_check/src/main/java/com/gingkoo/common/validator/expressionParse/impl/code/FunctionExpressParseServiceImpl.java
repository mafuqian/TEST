package com.gingkoo.common.validator.expressionParse.impl.code;

import com.gingkoo.common.validator.bean.ParseResultNode;
import com.gingkoo.common.validator.bean.ParseResultNodeTree;
import com.gingkoo.common.validator.enums.DataValidatorConstants;
import com.gingkoo.common.validator.expressionParse.base.CodeParsingInterface;
import com.gingkoo.common.validator.expressionParse.base.ParseCommonService;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.CodeStrategyFactory;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.baseInterface.CodeFunctionStrategy;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.context.CodeFunctionStrategyContext;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 函数解析
 * 分别为如下函数：
 * SUBSTR
 * --(EXISTS,NOT_EXISTS)没有这两个，这两个函数是sql解析的。
 * NULL,NOT_NULL
 * REGEXP
 * TO_MONTH,TO_DATE,TO_TIME
 * MATH_ADD,MATH_SUBTRACT,MATH_MULTIPLY,MATH_DIVIDE
 */
@Service
public class FunctionExpressParseServiceImpl extends ParseCommonService implements CodeParsingInterface {

	@Override
	public ParseResultNodeTree codeParse(ParseResultNodeTree resultNodeTree) throws CommonException {
		ParseResultNode resultNode = resultNodeTree.getNode();
		List<ParseResultNodeTree> childsNodeTrees = resultNodeTree.getChilds();
		CodeFunctionStrategy codeFunctionStrategy= CodeStrategyFactory.getCodeFunctionParseServiceImpl(resultNode);
		if(codeFunctionStrategy==null) {
			setResultNodeErrMsg(resultNode, "函数"+resultNode.getNodeValue()+"不存在。");
			return resultNodeTree;
		}
		CodeFunctionStrategyContext codeStrategyContext = ApplicationContextUtil.getBean(CodeFunctionStrategyContext.class);
		codeStrategyContext.setStrategyContext(codeFunctionStrategy, resultNode, childsNodeTrees);
		codeStrategyContext.judgeExpression();
		codeStrategyContext.parseExpress();
		return resultNodeTree;
	}


	/**
	 * 函数 初判断
	 */
	public void judgeExpression(ParseResultNode resultNode,List<ParseResultNodeTree> childsNodeTrees) throws CommonException {
		String nodeValue = resultNode.getNodeValue();//函数参数类型
		if (!DataValidatorConstants.FUNCTION_SUBSTR.equals(nodeValue)
				&& !DataValidatorConstants.FUNCTION_NOT_NULL.equals(nodeValue)
				&& !DataValidatorConstants.FUNCTION_NULL.equals(nodeValue)
				&& !DataValidatorConstants.FUNCTION_REGEXP.equals(nodeValue)
				&& !DataValidatorConstants.FUNCTION_TO_MONTH.equals(nodeValue)
				&& !DataValidatorConstants.FUNCTION_TO_DATE.equals(nodeValue)
				&& !DataValidatorConstants.FUNCTION_TO_TIME.equals(nodeValue)
				&& !DataValidatorConstants.FUNCTION_MATH_ADD.equals(nodeValue)
				&& !DataValidatorConstants.FUNCTION_MATH_SUBTRACT.equals(nodeValue)
				&& !DataValidatorConstants.FUNCTION_MATH_MULTIPLY.equals(nodeValue)
				&& !DataValidatorConstants.FUNCTION_MATH_DIVIDE.equals(nodeValue)) {
			setResultNodeErrMsg(resultNode, "函数应该为SUBSTR,NULL,NOT_NULL,REGEXP,TO_MONTH,TO_DATE,TO_TIME,MATH_ADD,MATH_SUBTRACT,MATH_MULTIPLY,MATH_DIVIDE其中的 一种。");
		}
		if ((DataValidatorConstants.FUNCTION_SUBSTR.equals(nodeValue)) && (childsNodeTrees.size() != 3)) {
			setResultNodeErrMsg(resultNode, "SUBSTR函数必须存在3个子节点");
		}
		if ((DataValidatorConstants.FUNCTION_REGEXP.equals(nodeValue)
				|| DataValidatorConstants.FUNCTION_MATH_ADD.equals(nodeValue)
				|| DataValidatorConstants.FUNCTION_MATH_SUBTRACT.equals(nodeValue)
				|| DataValidatorConstants.FUNCTION_MATH_MULTIPLY.equals(nodeValue)
				|| DataValidatorConstants.FUNCTION_MATH_DIVIDE.equals(nodeValue))
				&& childsNodeTrees.size() != 1) {
			setResultNodeErrMsg(resultNode, "函数REGEXP,MATH_ADD,MATH_SUBTRACT,MATH_MULTIPLY,MATH_DIVIDE必须存在2个子节点");
		}
		if ((DataValidatorConstants.FUNCTION_NOT_NULL.equals(nodeValue)
				|| DataValidatorConstants.FUNCTION_NULL.equals(nodeValue)
				|| DataValidatorConstants.FUNCTION_TO_MONTH.equals(nodeValue)
				|| DataValidatorConstants.FUNCTION_TO_DATE.equals(nodeValue)
				|| DataValidatorConstants.FUNCTION_TO_TIME.equals(nodeValue))
				&& childsNodeTrees.size() != 1) {
			setResultNodeErrMsg(resultNode, "函数NULL,TO_MONTH,TO_DATE,TO_TIME只能存在1个子节点");
		}
	}
	
	
	/**
	 * 解析函数节点
	 * @param resultNodeTree
	 * @return
	 */
	private ParseResultNodeTree parseFunctionNode(ParseResultNodeTree resultNodeTree) {
		ParseResultNode resultNode = resultNodeTree.getNode();
		List<ParseResultNodeTree> childsNodeTrees = resultNodeTree.getChilds();
		CodeFunctionStrategy codeFunctionStrategy= CodeStrategyFactory.getCodeFunctionParseServiceImpl(resultNode);
		if(codeFunctionStrategy==null) {
			setResultNodeErrMsg(resultNode, "函数"+resultNode.getNodeValue()+"不存在。");
		}
        CodeFunctionStrategyContext codeStrategyContext = ApplicationContextUtil.getBean(CodeFunctionStrategyContext.class);
        codeStrategyContext.setStrategyContext(codeFunctionStrategy, resultNode, childsNodeTrees);
		codeStrategyContext.judgeExpression();
		codeStrategyContext.parseExpress();
		return resultNodeTree;
	}

	/**
	 * 函数解析 SUBSTR ,ISNULL
	 * @param resultNodeTree
	 * @return
	 */
	private ParseResultNodeTree parseNodeTypefunctionOperator(ParseResultNodeTree resultNodeTree) {
		ParseResultNode resultNode = resultNodeTree.getNode();
		String nodeTypeValue = resultNode.getNodeValue();
		List<ParseResultNodeTree> childsNodeTrees = resultNodeTree.getChilds();
		if(DataValidatorConstants.FUNCTION_SUBSTR.equals(nodeTypeValue)) {
			String subStrC = "";
			String subStrV = "";
			String subStr = "";
			String start = "";
			String length = "";
			String result = "";
			for(ParseResultNodeTree childNodeTree : childsNodeTrees) {
				ParseResultNode childNode = childNodeTree.getNode();
				String funcParamType = childNode.getFuncParamType();
				Object object =  getResultNodeParseResult(childNode);
				if(DataValidatorConstants.FUNC_PARAMETER_SUBSTR_STRING_CONSTANT.equals(funcParamType)) {
					subStrC = parseObjectToString(object);
					if(!"".equals(subStrC)) {
                        subStr = subStrC;
                    }
				}
				if(DataValidatorConstants.FUNC_PARAMETER_SUBSTR_STRING_VARIATE.equals(funcParamType)) {
					subStrV = parseObjectToString(object);
					if(!"".equals(subStrV)) {
                        subStr = subStrV;
                    }
				}
				if(DataValidatorConstants.FUNC_PARAMETER_SUBSTR_STRING_LENGTH.equals(funcParamType)) {
					length = parseObjectToString(object);
					if("".equals(length))  {
						setResultNodeErrMsg(resultNode, "节点SUBSTR_STRING_LENGTH值不正确。");
						length = "0";
					}
				}
				if(DataValidatorConstants.FUNC_PARAMETER_SUBSTR_STRING_START.equals(funcParamType)) {
					start = parseObjectToString(object);
					if("".equals(start))  {
						setResultNodeErrMsg(resultNode, "节点SUBSTR_STRING_START不正确。");
						start = "0";
					}
				}
			}
			try {
				result = functionOperator_substr(subStr, start, length);
			} catch (Exception e) {
				e.printStackTrace();
				setResultNodeErrMsg(resultNode, "解析SUBSTR时出错。字符串值为"+subStr+" , 截取起始位置："+start +" , 截取长度为："+length);
			}
			resultNodeSetParseResult(resultNode, result);
		}
		if(DataValidatorConstants.FUNCTION_NOT_NULL.equals(nodeTypeValue)
				|| DataValidatorConstants.FUNCTION_NULL.equals(nodeTypeValue)) {
			Boolean result = false;
			String nullStr = "";
			for(ParseResultNodeTree childNodeTree : childsNodeTrees) {
				ParseResultNode childNode = childNodeTree.getNode();
				String nodeType = childNode.getNodeType();
				String funcParamType = childNode.getFuncParamType();
				Object object =  getResultNodeParseResult(childNode);
				if(DataValidatorConstants.FUNC_PARAMETER_NULL_PARAM.equals(funcParamType)) {
					nullStr = parseObjectToString(object);
				}else {
					setResultNodeErrMsg(resultNode, "NULL函数的子节点不正确。");
				}
			}
			result = functionOperator_NULL(nodeTypeValue, nullStr);
			resultNodeSetParseResult(resultNode, result);
		}
		return resultNodeTree;
	}
	
	
	/**
	 * 解析SUBSTR
	 * 
	 * @param str
	 * @param start
	 * @param length
	 * @return
	 */
	private String functionOperator_substr(String str, String start, String length) throws Exception {
		int startIndex = Integer.parseInt(start);
		startIndex = startIndex == 0 ? 0 : startIndex - 1;
		int endIndex = startIndex + Integer.parseInt(length);
		endIndex = endIndex > str.length() ? str.length() : endIndex;
		endIndex = endIndex > startIndex ? endIndex:startIndex;
		str = str.substring(startIndex, endIndex);
		return str;
	}

	/**
	 * 
	 * @param nodeTypeValue 
	 * @param param			
	 * @return
	 */
	private boolean functionOperator_NULL(String nodeTypeValue , Object param) {
		String str = parseObjectToString(param);
		if(DataValidatorConstants.FUNCTION_NOT_NULL.equals(nodeTypeValue)) {
			return !"".equals(str);
		}
		if(DataValidatorConstants.FUNCTION_NULL.equals(nodeTypeValue)) {
			return "".equals(str);
		}
		return false;
	}
	


}
