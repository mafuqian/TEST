package com.gingkoo.common.validator.expressionParse.impl.code.strategy.otheraOperation;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gingkoo.common.validator.bean.ParseResultNode;
import com.gingkoo.common.validator.bean.ParseResultNodeTree;
import com.gingkoo.common.validator.enums.DataValidatorConstants;
import com.gingkoo.common.validator.expressionParse.base.ParseCommonService;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.baseInterface.CodeOtherOperationStrategy;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.context.CodeOtherOperationStrategyContext;

/**
 * 其他运算符 LIKE 相关（LIKE,NOT LIKE）。
 */
@Service
public class CodeOtherOperationLikeStrategyImpl  extends ParseCommonService implements CodeOtherOperationStrategy{
	
	
	@Override
	public void judgeExpression(CodeOtherOperationStrategyContext context) {
		ParseResultNode resultNode = context.getResultNode();
		List<ParseResultNodeTree> childsNodeTrees = context.getChildsNodeTrees();
		String nodeValue = resultNode.getNodeValue();
		if ((DataValidatorConstants.OTHER_OPERATOR_R_LIKE.equals(nodeValue)
				||DataValidatorConstants.OTHER_OPERATOR_L_LIKE.equals(nodeValue)
				||DataValidatorConstants.OTHER_OPERATOR_F_LIKE.equals(nodeValue)
				||DataValidatorConstants.OTHER_OPERATOR_R_NOT_LIKE.equals(nodeValue)
				||DataValidatorConstants.OTHER_OPERATOR_L_NOT_LIKE.equals(nodeValue)
				||DataValidatorConstants.OTHER_OPERATOR_F_NOT_LIKE.equals(nodeValue))
				&& childsNodeTrees.size() != 2) {
			setResultNodeErrMsg(resultNode, "其他运算符LIKE必须存在2个子节点。");
		}
	}
	
	@Override
	public ParseResultNode parseFunction(CodeOtherOperationStrategyContext context) {
		ParseResultNode resultNode = context.getResultNode();
		List<ParseResultNodeTree> childsNodeTrees = context.getChildsNodeTrees();
		String nodeValue = resultNode.getNodeValue();
		
		String leftStr = "";
		String rightStr = "";
		Object object = null;
		for (ParseResultNodeTree nodeTree : childsNodeTrees) {
			ParseResultNode node = nodeTree.getNode();
			String parameterBranchType = node.getParameterBranchType();
			if (parameterBranchType == null || "".equals(parameterBranchType)||"0".equals(parameterBranchType)) {
				setResultNodeErrMsg(resultNode, "其他运算符LIKE的参数分支类型配置不正确。");
				return resultNode;
			}
			object = getResultNodeParseResult(node);
			if (DataValidatorConstants.LEFT_PARAMETER.equals(parameterBranchType)) {
				leftStr = parseObjectToString(object);
			} else if (DataValidatorConstants.RIGHT_PARAMETER.equals(parameterBranchType)) {
				rightStr = parseObjectToString(object);
			} else {
				setResultNodeErrMsg(resultNode, "其他运算符中LIKE参数分支类型配置不正确。");
				return resultNode;
			}
		}
		boolean result = parseOtherOperator_LIKES(nodeValue, leftStr, rightStr);			
		resultNodeSetParseResult(resultNode, result);
		return resultNode;
	}
	
	/**
	 * like 解析
	 * @param nodeValue		节点类型的值
	 * @param leftStr		左值
	 * @param rightStr		右值
	 * @return 
	 */
	private boolean parseOtherOperator_LIKES(String nodeValue ,String leftStr, String rightStr) {
		boolean result = false;
		switch (nodeValue) {
		case DataValidatorConstants.OTHER_OPERATOR_R_LIKE:
			result = leftStr.startsWith(rightStr);
			break;
		case DataValidatorConstants.OTHER_OPERATOR_L_LIKE:
			result = leftStr.endsWith(rightStr);
			break;
		case DataValidatorConstants.OTHER_OPERATOR_F_LIKE:
			result = leftStr.contains(rightStr);
			break;
		case DataValidatorConstants.OTHER_OPERATOR_R_NOT_LIKE:
			result = !leftStr.startsWith(rightStr);
			break;
		case DataValidatorConstants.OTHER_OPERATOR_L_NOT_LIKE:
			result = !leftStr.endsWith(rightStr);
			break;
		case DataValidatorConstants.OTHER_OPERATOR_F_NOT_LIKE:
			result = !leftStr.contains(rightStr);
			break;
		default:
			break;
		}
		return result;
	}
	

}