package com.gingkoo.common.validator.expressionParse.impl.code;

import com.gingkoo.common.validator.bean.ParseResultNode;
import com.gingkoo.common.validator.bean.ParseResultNodeTree;
import com.gingkoo.common.validator.enums.DataValidatorConstants;
import com.gingkoo.common.validator.expressionParse.base.CodeParsingInterface;
import com.gingkoo.common.validator.expressionParse.base.ParseCommonService;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.CodeStrategyFactory;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.baseInterface.CodeOtherOperationStrategy;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.context.CodeOtherOperationStrategyContext;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OtherOperationExpressParseServiceImpl extends ParseCommonService  implements CodeParsingInterface {

	@Override
	public ParseResultNodeTree codeParse(ParseResultNodeTree resultNodeTree)
			throws CommonException {
		ParseResultNode resultNode = resultNodeTree.getNode();
		List<ParseResultNodeTree> childsNodeTrees = resultNodeTree.getChilds();
		CodeOtherOperationStrategy codeOtherOperationStrategy= CodeStrategyFactory.getCodeOtherOperationParseServiceImpl(resultNode);
		if(codeOtherOperationStrategy==null) {
			setResultNodeErrMsg(resultNode, "函数"+resultNode.getNodeValue()+"不存在。");
			return resultNodeTree;
		}
		CodeOtherOperationStrategyContext otherOperationStrategyContext = ApplicationContextUtil.getBean(CodeOtherOperationStrategyContext.class);
		otherOperationStrategyContext.setStrategyContext(codeOtherOperationStrategy, resultNode, childsNodeTrees);
		otherOperationStrategyContext.judgeExpression();
		otherOperationStrategyContext.parseExpress();
		return resultNodeTree;
	}

	/**
	 * 其他运算符 初判断
	 */
	public void judgeExpression(ParseResultNodeTree resultNodeTree) throws CommonException {
		ParseResultNode resultNode = resultNodeTree.getNode();
		String nodeTypeValue = resultNode.getNodeValue();
		if (!DataValidatorConstants.OTHER_OPERATOR_EQUALS.equals(nodeTypeValue)
				&& !DataValidatorConstants.OTHER_OPERATOR_NOT_EQUALS.equals(nodeTypeValue)
				&& !DataValidatorConstants.OTHER_OPERATOR_GREATER.equals(nodeTypeValue)
				&& !DataValidatorConstants.OTHER_OPERATOR_SMALLER.equals(nodeTypeValue)
				&& !DataValidatorConstants.OTHER_OPERATOR_GREATER_EQUALS.equals(nodeTypeValue)
				&& !DataValidatorConstants.OTHER_OPERATOR_SMALLER_EQUALS.equals(nodeTypeValue)
				&& !DataValidatorConstants.OTHER_OPERATOR_IN.equals(nodeTypeValue)
				&& !DataValidatorConstants.OTHER_OPERATOR_NOT_IN.equals(nodeTypeValue)
				&& !DataValidatorConstants.OTHER_OPERATOR_R_LIKE.equals(nodeTypeValue)
				&& !DataValidatorConstants.OTHER_OPERATOR_L_LIKE.equals(nodeTypeValue)
				&& !DataValidatorConstants.OTHER_OPERATOR_F_LIKE.equals(nodeTypeValue)
				&& !DataValidatorConstants.OTHER_OPERATOR_R_NOT_LIKE.equals(nodeTypeValue)
				&& !DataValidatorConstants.OTHER_OPERATOR_L_NOT_LIKE.equals(nodeTypeValue)
				&& !DataValidatorConstants.OTHER_OPERATOR_F_NOT_LIKE.equals(nodeTypeValue)) {
			setResultNodeErrMsg(resultNodeTree, "关系运算符不正确。");
		}
	}


	/**
	 * 其他运算符 解析 ，childsNodeTrees 必须存在两个。
	 *
	 * @param resultNode
	 * @param childsNodeTrees
	 * @return
	 * @throws CommonException
	 */
	private boolean parseNodeTypeOtherOperator(ParseResultNode resultNode , List<ParseResultNodeTree> childsNodeTrees)
			throws CommonException {
		String nodeTypeValue = resultNode.getNodeValue();
		Object leftObject = null;
		Object rightObject = null;
		ArrayList<Object> rightObjectList = new ArrayList<Object>();

		for (ParseResultNodeTree nodeTree : childsNodeTrees) {
			ParseResultNode node = nodeTree.getNode();
			String parameterBranchType = node.getParameterBranchType();
			if (parameterBranchType == null || "".equals(parameterBranchType)||"0".equals(parameterBranchType)) {
				setResultNodeErrMsg(resultNode, "其他运算符中的参数分支类型配置不正确。");
				return false;
			}
			if (DataValidatorConstants.LEFT_PARAMETER.equals(parameterBranchType)) {
				leftObject = getResultNodeParseResult(node);
			} else if (DataValidatorConstants.RIGHT_PARAMETER.equals(parameterBranchType)) {
				rightObject = getResultNodeParseResult(node);
				rightObjectList.add(rightObject);
			} else {
				setResultNodeErrMsg(resultNode, "其他运算符中的参数分支类型配置不正确。");
				return false;
			}
		}

		//等于号之类
		if(DataValidatorConstants.OTHER_OPERATOR_EQUALS.equals(nodeTypeValue)
				||DataValidatorConstants.OTHER_OPERATOR_NOT_EQUALS.equals(nodeTypeValue)
				||DataValidatorConstants.OTHER_OPERATOR_GREATER.equals(nodeTypeValue)
				||DataValidatorConstants.OTHER_OPERATOR_SMALLER.equals(nodeTypeValue)
				||DataValidatorConstants.OTHER_OPERATOR_GREATER_EQUALS.equals(nodeTypeValue)
				||DataValidatorConstants.OTHER_OPERATOR_SMALLER_EQUALS.equals(nodeTypeValue)) {
			return parseOtherOperator_EQUALS(nodeTypeValue, leftObject, rightObject);
		}
		// like
		if(DataValidatorConstants.OTHER_OPERATOR_R_LIKE.equals(nodeTypeValue)
				||DataValidatorConstants.OTHER_OPERATOR_L_LIKE.equals(nodeTypeValue)
				||DataValidatorConstants.OTHER_OPERATOR_F_LIKE.equals(nodeTypeValue)
				||DataValidatorConstants.OTHER_OPERATOR_R_NOT_LIKE.equals(nodeTypeValue)
				||DataValidatorConstants.OTHER_OPERATOR_L_NOT_LIKE.equals(nodeTypeValue)
				||DataValidatorConstants.OTHER_OPERATOR_F_NOT_LIKE.equals(nodeTypeValue)) {
			return parseOtherOperator_LIKES(nodeTypeValue, leftObject, rightObject);
		}
		//in
		if(DataValidatorConstants.OTHER_OPERATOR_IN.equals(nodeTypeValue)
				||DataValidatorConstants.OTHER_OPERATOR_NOT_IN.equals(nodeTypeValue)) {
			parseOtherOperator_IN(nodeTypeValue, leftObject, rightObjectList);
		}

		return false;
	}




	/**
	 * 比较大小
	 * @param nodeTypeValue
	 * @param leftObject
	 * @param rightObject
	 * @return
	 * @throws CommonException
	 */
	private boolean parseOtherOperator_EQUALS(String nodeTypeValue , Object leftObject, Object rightObject) throws CommonException {
//		BigDecimal d1 = null;
//		BigDecimal d2 = null;
//		Boolean isBigDecimal = true;
//		try {
//			d1 = parseObjectToBigDecimal(leftObject);
//		}catch(CommonException e) {
//			isBigDecimal = false;
//		}
//		try {
//			d2 = parseObjectToBigDecimal(rightObject);
//		}catch(CommonException e) {
//			isBigDecimal = false;
//		}
//		//如果是数字，就直接进行比较
//		if(isBigDecimal) {
//			if(DataValidatorConstants.OTHER_OPERATOR_EQUALS.equals(nodeTypeValue)) {
//				 return d1.compareTo(d2)==0;
//			}
//			if(DataValidatorConstants.OTHER_OPERATOR_NOT_EQUALS.equals(nodeTypeValue)) {
//				 return d1.compareTo(d2)!=0;
//			}
//			if(DataValidatorConstants.OTHER_OPERATOR_GREATER.equals(nodeTypeValue)) {
//				 return d1.compareTo(d2)>0;
//			}
//			if(DataValidatorConstants.OTHER_OPERATOR_SMALLER.equals(nodeTypeValue)) {
//				 return d1.compareTo(d2)<0;
//			}
//			if(DataValidatorConstants.OTHER_OPERATOR_GREATER_EQUALS.equals(nodeTypeValue)) {
//				 return d1.compareTo(d2)>=0;
//			}
//			if(DataValidatorConstants.OTHER_OPERATOR_SMALLER_EQUALS.equals(nodeTypeValue)) {
//				 return d1.compareTo(d2)<=0;
//			}
//		}else {//值不是数字，比较asc码大小。
			String leftStr = parseObjectToString(leftObject);
			String rightStr = parseObjectToString(rightObject);
			Float leftStr1 = Float.parseFloat(leftStr);
			Float leftStr2 = Float.parseFloat(rightStr);

		if(DataValidatorConstants.OTHER_OPERATOR_EQUALS.equals(nodeTypeValue)) {
				 return leftStr1.compareTo(leftStr2)==0;
			}
			if(DataValidatorConstants.OTHER_OPERATOR_NOT_EQUALS.equals(nodeTypeValue)) {
				 return leftStr1.compareTo(leftStr2)!=0;
			}
			if(DataValidatorConstants.OTHER_OPERATOR_GREATER.equals(nodeTypeValue)) {
				 return leftStr1.compareTo(leftStr2)>0;
			}
			if(DataValidatorConstants.OTHER_OPERATOR_SMALLER.equals(nodeTypeValue)) {
				 return leftStr1.compareTo(leftStr2)<0;
			}
			if(DataValidatorConstants.OTHER_OPERATOR_GREATER_EQUALS.equals(nodeTypeValue)) {
				 return leftStr1.compareTo(leftStr2)>=0;
			}
			if(DataValidatorConstants.OTHER_OPERATOR_SMALLER_EQUALS.equals(nodeTypeValue)) {
				 return leftStr1.compareTo(leftStr2)<=0;
			}
//		}
		return false;
	}


	/**
	 * like 相关
	 * @param nodeTypeValue		节点类型的值
	 * @param leftObject		左值
	 * @param rightObject		右值
	 * @return
	 */
	private boolean parseOtherOperator_LIKES(String nodeTypeValue ,Object leftObject, Object rightObject) {
		String leftStr = "";
		String rightStr = "";
		leftStr = parseObjectToString(leftObject);
		rightStr = parseObjectToString(rightObject);
		if(DataValidatorConstants.OTHER_OPERATOR_R_LIKE.equals(nodeTypeValue)) {
			 return leftStr.startsWith(rightStr);
		}
		if(DataValidatorConstants.OTHER_OPERATOR_L_LIKE.equals(nodeTypeValue)) {
			 return leftStr.endsWith(rightStr);
		}
		if(DataValidatorConstants.OTHER_OPERATOR_F_LIKE.equals(nodeTypeValue)) {
			 return leftStr.contains(rightStr);
		}
		if(DataValidatorConstants.OTHER_OPERATOR_R_NOT_LIKE.equals(nodeTypeValue)) {
			 return !leftStr.startsWith(rightStr);
		}
		if(DataValidatorConstants.OTHER_OPERATOR_L_NOT_LIKE.equals(nodeTypeValue)) {
			 return !leftStr.endsWith(rightStr);
		}
		if(DataValidatorConstants.OTHER_OPERATOR_F_NOT_LIKE.equals(nodeTypeValue)) {
			 return !leftStr.contains(rightStr);
		}
		return false;
	}



	/**
	 * in 相关
	 * @param nodeTypeValue		节点类型的值
	 * @param leftObject		左值
	 * @param rightObjectList		右值
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private boolean parseOtherOperator_IN(String nodeTypeValue ,Object leftObject, List<Object> rightObjectList) {
		String leftStr = parseObjectToString(leftObject);
		ArrayList rightList = new ArrayList<String>();
		for(Object rightObject : rightObjectList) {
			String rightStr = parseObjectToString(rightObject);
			rightList.add(rightStr);
		}
		if(DataValidatorConstants.OTHER_OPERATOR_IN.equals(nodeTypeValue)) {
			 return rightList.contains(leftStr);
		}
		if(DataValidatorConstants.OTHER_OPERATOR_NOT_IN.equals(nodeTypeValue)) {
			 return !rightList.contains(leftStr);
		}
		return false;
	}



//	public static void main(String[] args) {
//		String s1 = "1111.22";
//		String s2 = "1111.22";
//		System.out.println(s1.compareTo(s2));
//	}
}
