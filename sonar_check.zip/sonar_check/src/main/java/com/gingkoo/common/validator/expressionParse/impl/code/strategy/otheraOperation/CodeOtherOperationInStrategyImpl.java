package com.gingkoo.common.validator.expressionParse.impl.code.strategy.otheraOperation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.gingkoo.common.validator.bean.ParseResultNode;
import com.gingkoo.common.validator.bean.ParseResultNodeTree;
import com.gingkoo.common.validator.enums.DataValidatorConstants;
import com.gingkoo.common.validator.expressionParse.base.ParseCommonService;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.baseInterface.CodeOtherOperationStrategy;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.context.CodeOtherOperationStrategyContext;

/**
 * 其他运算符 IN 相关（IN ,NOT IN）。
 */
@Service
public class CodeOtherOperationInStrategyImpl  extends ParseCommonService implements CodeOtherOperationStrategy{
	
	
	@Override
	public void judgeExpression(CodeOtherOperationStrategyContext context) {
		ParseResultNode resultNode = context.getResultNode();
		List<ParseResultNodeTree> childsNodeTrees = context.getChildsNodeTrees();
		String nodeValue = resultNode.getNodeValue();
		if ((DataValidatorConstants.OTHER_OPERATOR_IN.equals(nodeValue)
				||DataValidatorConstants.OTHER_OPERATOR_NOT_IN.equals(nodeValue))
				&& childsNodeTrees.size() < 2) {
			setResultNodeErrMsg(resultNode, "其他运算符IN必须存在两个或两个以上子节点。");
		}
	}
	
	@Override
	public ParseResultNode parseFunction(CodeOtherOperationStrategyContext context) {
		ParseResultNode resultNode = context.getResultNode();
		List<ParseResultNodeTree> childsNodeTrees = context.getChildsNodeTrees();
		String nodeValue = resultNode.getNodeValue();
		Object leftObject = null;
		Object rightObject = null;
		ArrayList<Object> rightObjectList = new ArrayList<Object>();
		
		for (ParseResultNodeTree nodeTree : childsNodeTrees) {
			ParseResultNode node = nodeTree.getNode();
			String parameterBranchType = node.getParameterBranchType();
			if (parameterBranchType == null || "".equals(parameterBranchType)||"0".equals(parameterBranchType)) {
				setResultNodeErrMsg(resultNode, "其他运算符IN的参数分支类型配置不正确。");
				return resultNode;
			}
			if (DataValidatorConstants.LEFT_PARAMETER.equals(parameterBranchType)) {
				leftObject = getResultNodeParseResult(node);
			} else if (DataValidatorConstants.RIGHT_PARAMETER.equals(parameterBranchType)) {
				rightObject = getResultNodeParseResult(node);
				rightObjectList.add(rightObject);
			} else {
				setResultNodeErrMsg(resultNode, "其他运算符IN的参数分支类型配置不正确。");
				return resultNode;
			}
		}
		boolean result = parseOtherOperator_IN(nodeValue, leftObject, rightObjectList);			
		resultNodeSetParseResult(resultNode, result);
		return resultNode;
	}


	/**
	 * in 相关 
	 * @param nodeValue		节点类型的值
	 * @param leftObject		左值
	 * @param rightObject		右值
	 * @return 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private boolean parseOtherOperator_IN(String nodeValue ,Object leftObject, List<Object> rightObjectList) {
		String leftStr = parseObjectToString(leftObject);
		ArrayList rightList = new ArrayList<String>();
		for(Object rightObject : rightObjectList) {
			String rightStr = parseObjectToString(rightObject);
			rightList.add(rightStr);
		}
		if(DataValidatorConstants.OTHER_OPERATOR_IN.equals(nodeValue)) {
			 return rightList.contains(leftStr);
		}
		if(DataValidatorConstants.OTHER_OPERATOR_NOT_IN.equals(nodeValue)) {
			 return !rightList.contains(leftStr);
		}
		return false;
	}
	

}