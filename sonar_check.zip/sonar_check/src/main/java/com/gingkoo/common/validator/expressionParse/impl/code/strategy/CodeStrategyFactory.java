package com.gingkoo.common.validator.expressionParse.impl.code.strategy;

import com.gingkoo.common.validator.bean.ParseResultNode;
import com.gingkoo.common.validator.enums.DataValidatorConstants;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.baseInterface.CodeFunctionStrategy;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.baseInterface.CodeOtherOperationStrategy;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.function.CodeFunctionMathAddStrategyImpl;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.function.CodeFunctionMathDivideStrategyImpl;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.function.CodeFunctionMathMultiplyStrategyImpl;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.function.CodeFunctionMathSubtractStrategyImpl;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.function.CodeFunctionNullStrategyImpl;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.function.CodeFunctionRegexpStrategyImpl;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.function.CodeFunctionSubstrStrategyImpl;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.function.CodeFunctionToDateStrategyImpl;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.function.CodeFunctionToMonthStrategyImpl;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.function.CodeFunctionToTimeStrategyImpl;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.otheraOperation.CodeOtherOperationEqualsStrategyImpl;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.otheraOperation.CodeOtherOperationInStrategyImpl;
import com.gingkoo.common.validator.expressionParse.impl.code.strategy.otheraOperation.CodeOtherOperationLikeStrategyImpl;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;

public class CodeStrategyFactory {

	/**
	 * 获取函数的策略实现类。
	 * @param node
	 * @return
	 */
	public static CodeFunctionStrategy getCodeFunctionParseServiceImpl(ParseResultNode node) {
		CodeFunctionStrategy codeFunctionStrategy = null;
		String nodeValue = node.getNodeValue();
		switch (nodeValue) {
		case DataValidatorConstants.FUNCTION_SUBSTR:
			codeFunctionStrategy = ApplicationContextUtil.getBean(CodeFunctionSubstrStrategyImpl.class);
			break;
		case DataValidatorConstants.FUNCTION_NULL:
		case DataValidatorConstants.FUNCTION_NOT_NULL:
			codeFunctionStrategy = ApplicationContextUtil.getBean(CodeFunctionNullStrategyImpl.class);
			break;
		case DataValidatorConstants.FUNCTION_REGEXP:
			codeFunctionStrategy = ApplicationContextUtil.getBean(CodeFunctionRegexpStrategyImpl.class);
			break;
		case DataValidatorConstants.FUNCTION_TO_MONTH:
			codeFunctionStrategy = ApplicationContextUtil.getBean(CodeFunctionToMonthStrategyImpl.class);
			break;
		case DataValidatorConstants.FUNCTION_TO_DATE:
			codeFunctionStrategy = ApplicationContextUtil.getBean(CodeFunctionToDateStrategyImpl.class);
			break;
		case DataValidatorConstants.FUNCTION_TO_TIME:
			codeFunctionStrategy = ApplicationContextUtil.getBean(CodeFunctionToTimeStrategyImpl.class);
			break;
		case DataValidatorConstants.FUNCTION_MATH_ADD:
			codeFunctionStrategy = ApplicationContextUtil.getBean(CodeFunctionMathAddStrategyImpl.class);
			break;
		case DataValidatorConstants.FUNCTION_MATH_SUBTRACT:
			codeFunctionStrategy = ApplicationContextUtil.getBean(CodeFunctionMathSubtractStrategyImpl.class);
			break;
		case DataValidatorConstants.FUNCTION_MATH_MULTIPLY:
			codeFunctionStrategy = ApplicationContextUtil.getBean(CodeFunctionMathMultiplyStrategyImpl.class);
			break;
		case DataValidatorConstants.FUNCTION_MATH_DIVIDE:
			codeFunctionStrategy = ApplicationContextUtil.getBean(CodeFunctionMathDivideStrategyImpl.class);
			break;
		default:
			break;
		}
		return codeFunctionStrategy;
	}

	/**
	 * 获取其他运算符的策略实现类
	 * @param node
	 * @return
	 */
	public static CodeOtherOperationStrategy getCodeOtherOperationParseServiceImpl(ParseResultNode node) {
		CodeOtherOperationStrategy codeOtherOperationStrategy = null;
		String nodeValue = node.getNodeValue();
		switch (nodeValue) {
		case DataValidatorConstants.OTHER_OPERATOR_IN:
		case DataValidatorConstants.OTHER_OPERATOR_NOT_IN:
			codeOtherOperationStrategy = ApplicationContextUtil.getBean(CodeOtherOperationInStrategyImpl.class);
			break;
		case DataValidatorConstants.OTHER_OPERATOR_F_LIKE:
		case DataValidatorConstants.OTHER_OPERATOR_F_NOT_LIKE:
		case DataValidatorConstants.OTHER_OPERATOR_L_LIKE:
		case DataValidatorConstants.OTHER_OPERATOR_L_NOT_LIKE:
		case DataValidatorConstants.OTHER_OPERATOR_R_LIKE:
		case DataValidatorConstants.OTHER_OPERATOR_R_NOT_LIKE:
			codeOtherOperationStrategy = ApplicationContextUtil.getBean(CodeOtherOperationLikeStrategyImpl.class);
			break;
		case DataValidatorConstants.OTHER_OPERATOR_EQUALS:
		case DataValidatorConstants.OTHER_OPERATOR_NOT_EQUALS:
		case DataValidatorConstants.OTHER_OPERATOR_GREATER:
		case DataValidatorConstants.OTHER_OPERATOR_SMALLER:
		case DataValidatorConstants.OTHER_OPERATOR_GREATER_EQUALS:
		case DataValidatorConstants.OTHER_OPERATOR_SMALLER_EQUALS:
			codeOtherOperationStrategy = ApplicationContextUtil.getBean(CodeOtherOperationEqualsStrategyImpl.class);
			break;
		default:
			break;
		}
		return codeOtherOperationStrategy;
	}
	

}
