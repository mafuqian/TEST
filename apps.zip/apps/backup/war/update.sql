UPDATE GP_QC_RULE SET EXISTS_SQL = 'select 1 from dual where not exists(select 1 from GFDR_PM_CLDWDK where DATA_RPT_DATE = :DATA_RPT_DATE and NBJGH = :NBJGH and DKHTBM = :BDBHTBM and DKCPLB not like ''F06%'') or :JYLX is null or :JYLX = ''02''
' WHERE DATA_ID = 'JS1959';
delete from GP_QC_RULE where DATA_ID in ('JS2444', 'JS2141');
delete from GP_QC_RULE_MAP where DATA_ID in ('JS2444', 'JS2141');