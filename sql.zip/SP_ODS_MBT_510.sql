CREATE OR REPLACE PROCEDURE "SP_ODS_MBT_510"(ERRCODE           IN OUT VARCHAR,
                                             ERRMSG            IN OUT VARCHAR,
                                             TABLE_KEY         IN VARCHAR2,
                                             RPT_DATE_CODE_OUT IN OUT VARCHAR2) AS
  DSC            VARCHAR2(1000);
  BEGINTIME      VARCHAR2(20);
  ENDTIME        VARCHAR2(20);
  CURRENTDATE    VARCHAR2(8);
  CURRENTTIME    VARCHAR2(14);
  B_ARRAYLIST    VARCHAR2(400);
  C_ARRAYLIST    VARCHAR2(400);
  D_ARRAYLIST    VARCHAR2(400);
  E_ARRAYLIST    VARCHAR2(400);
  F_ARRAYLIST    VARCHAR2(400);
  IS_RPT_OUT     VARCHAR2(64);
  INSPECT_RESULT NUMBER;
  V_DATE         VARCHAR2(8);
BEGIN
  B_ARRAYLIST := 'B_INFO_ID_TYPE,B_NAME,B_CERT_TYPE,B_CERT_NUM,B_CUST_NO,CUST_TYPE,B_MNGMT_ORG_CODE';
  C_ARRAYLIST := 'C_GUAR_TYPE,C_CC_AMT,C_CY,C_CC_VAL_DATE,C_CC_EXP_DATE,C_MAX_GUAR,C_CC_STATUS';
  D_ARRAYLIST := 'D_INFO_ID_TYPE,D_GUAR_NAME,D_GUAR_NO';
  E_ARRAYLIST := 'E_PLE_TYPE,E_MOTGA_PROPT_ID_TYPE,E_PLE_CERT_ID,E_PLE_DISTR,E_PLE_VALUE,E_PLE_CY,E_VAL_ORG_TYPE,E_VAL_DATE,E_PLEDGOR_TYPE,E_PLEDGOR_NAME,E_PLEOR_CERT_TYPE,E_PLEOR_CERT_NUM,E_PLE_DESC';
  F_ARRAYLIST := 'F_IMP_TYPE,F_IMP_VAL,F_IMP_CY,F_IPPC,F_PAWN_NAME,F_PAWN_CERT_TYPE,F_PAWN_CERT_NUM';

  CURRENTDATE := TO_CHAR(SYSDATE, 'YYYYMMDD');
  CURRENTTIME := TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS');
  BEGINTIME   := TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS');
  V_DATE      := GET_NEW_DAY(CURRENTDATE);
  DSC         := '##=======MBT510存储过程==开始' || BEGINTIME || '========##';
  DBMS_OUTPUT.PUT_LINE(DSC);

  --校验ODS数据 合同类型为：
  --                       1-抵押合同的  不应该有ODS_MBT_510_F质押表信息
  --                       2-质押合同的  不应该有ODS_MBT_510_E抵押表信息

  IF TABLE_KEY IS NOT NULL THEN
    --处理从页面来的数据
    BEGIN
      SELECT CASE
             -- 未上报过且‘抵(质)押合同状态'<> '2-到期/失效’
               WHEN B.DATA_ID IS NULL AND A.C_CC_STATUS <> '2' THEN
                '10'
             --已上报过且‘抵(质)押合同状态'= '2-到期/失效’ 且未上报过’20-合同到期/失效’时点
               WHEN B.DATA_ID IS NOT NULL AND A.C_CC_STATUS = '2' AND nvl(E.CNT, 0) = 0 THEN
                '20'
             --                CASE
             --                  WHEN B.B_RPT_DATE_CODE = '20' THEN
             --                   '99'
             --                  ELSE
             --                   '20'
             --                END
             --已报送过且未上报过’20-合同到期/失效’时点且（抵押物信息段和最新一次的抵押物信息段信息不一致或质押物信息段和最新一次的质押物信息段信息不一致）
               WHEN B.DATA_ID IS NOT NULL AND
                    (C.B_CC_CODE IS NOT NULL OR D.B_CC_CODE IS NOT NULL) AND
                    nvl(E.CNT, 0) = 0 THEN
                '30'
               ELSE
                '99'
             END
        INTO RPT_DATE_CODE_OUT
        FROM MBT_510 A
        LEFT JOIN (SELECT *
                     FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_CC_CODE ORDER BY RPT_TIME DESC) RN,
                                  T.*
                             FROM MBT_510_RPT T
                            WHERE DATA_STATUS = '27')
                    WHERE RN = 1) B
          ON A.B_CC_CODE = B.B_CC_CODE
        LEFT JOIN (SELECT DISTINCT (B_CC_CODE)
                     FROM ((SELECT B_CC_CODE,
                                   E_PLE_TYPE,
                                   E_MOTGA_PROPT_ID_TYPE,
                                   E_PLE_CERT_ID,
                                   E_PLE_DISTR,
                                   E_PLE_VALUE_ORG,
                                   E_PLE_CY,
                                   E_VAL_ORG_TYPE,
                                   E_VAL_DATE,
                                   E_PLEDGOR_TYPE,
                                   E_PLEDGOR_NAME,
                                   E_PLEOR_CERT_TYPE,
                                   E_PLEOR_CERT_NUM,
                                   E_PLE_DESC
                              FROM MBT_510_E
                            MINUS
                            SELECT B_CC_CODE,
                                   E_PLE_TYPE,
                                   E_MOTGA_PROPT_ID_TYPE,
                                   E_PLE_CERT_ID,
                                   E_PLE_DISTR,
                                   E_PLE_VALUE_ORG,
                                   E_PLE_CY,
                                   E_VAL_ORG_TYPE,
                                   E_VAL_DATE,
                                   E_PLEDGOR_TYPE,
                                   E_PLEDGOR_NAME,
                                   E_PLEOR_CERT_TYPE,
                                   E_PLEOR_CERT_NUM,
                                   E_PLE_DESC
                              FROM (SELECT *
                                      FROM MBT_510_E_HIS
                                     WHERE PDATA_ID IN
                                           (SELECT ODS_DATA_ID
                                              FROM (SELECT ROW_NUMBER() OVER(PARTITION BY TMP.B_CC_CODE ORDER BY TMP.RPT_DATE DESC) RN,
                                                           TMP.*
                                                      FROM MBT_510_RPT TMP
                                                     WHERE TMP.DATA_STATUS = '27')
                                             WHERE RN = 1))) UNION ALL
                           (SELECT B_CC_CODE,
                                   E_PLE_TYPE,
                                   E_MOTGA_PROPT_ID_TYPE,
                                   E_PLE_CERT_ID,
                                   E_PLE_DISTR,
                                   E_PLE_VALUE_ORG,
                                   E_PLE_CY,
                                   E_VAL_ORG_TYPE,
                                   E_VAL_DATE,
                                   E_PLEDGOR_TYPE,
                                   E_PLEDGOR_NAME,
                                   E_PLEOR_CERT_TYPE,
                                   E_PLEOR_CERT_NUM,
                                   E_PLE_DESC
                              FROM (SELECT *
                                      FROM MBT_510_E_HIS
                                     WHERE PDATA_ID IN
                                           (SELECT ODS_DATA_ID
                                              FROM (SELECT ROW_NUMBER() OVER(PARTITION BY TMP.B_CC_CODE ORDER BY TMP.RPT_DATE DESC) RN,
                                                           TMP.*
                                                      FROM MBT_510_RPT TMP
                                                     WHERE TMP.DATA_STATUS = '27')
                                             WHERE RN = 1))
                            MINUS
                            SELECT B_CC_CODE,
                                   E_PLE_TYPE,
                                   E_MOTGA_PROPT_ID_TYPE,
                                   E_PLE_CERT_ID,
                                   E_PLE_DISTR,
                                   E_PLE_VALUE_ORG,
                                   E_PLE_CY,
                                   E_VAL_ORG_TYPE,
                                   E_VAL_DATE,
                                   E_PLEDGOR_TYPE,
                                   E_PLEDGOR_NAME,
                                   E_PLEOR_CERT_TYPE,
                                   E_PLEOR_CERT_NUM,
                                   E_PLE_DESC
                              FROM MBT_510_E))) C
          ON A.B_CC_CODE = C.B_CC_CODE
        LEFT JOIN (SELECT DISTINCT (B_CC_CODE)
                     FROM (SELECT B_CC_CODE,
                                  F_IMP_TYPE,
                                  F_IMP_VAL_ORG,
                                  F_IMP_CY,
                                  F_IPPC,
                                  F_PAWN_NAME,
                                  F_PAWN_CERT_TYPE,
                                  F_PAWN_CERT_NUM
                             FROM MBT_510_F
                           MINUS
                           SELECT B_CC_CODE,
                                  F_IMP_TYPE,
                                  F_IMP_VAL_ORG,
                                  F_IMP_CY,
                                  F_IPPC,
                                  F_PAWN_NAME,
                                  F_PAWN_CERT_TYPE,
                                  F_PAWN_CERT_NUM
                             FROM (SELECT *
                                     FROM MBT_510_F_HIS
                                    WHERE DATA_ID IN
                                          (SELECT ODS_DATA_ID
                                             FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_CC_CODE ORDER BY T.RPT_DATE DESC) RN,
                                                          T.*
                                                     FROM MBT_510_RPT T
                                                    WHERE T.DATA_STATUS = '27')
                                            WHERE RN = 1))
                           UNION ALL
                           SELECT B_CC_CODE,
                                  F_IMP_TYPE,
                                  F_IMP_VAL_ORG,
                                  F_IMP_CY,
                                  F_IPPC,
                                  F_PAWN_NAME,
                                  F_PAWN_CERT_TYPE,
                                  F_PAWN_CERT_NUM
                             FROM (SELECT *
                                     FROM MBT_510_F_HIS
                                    WHERE PDATA_ID IN
                                          (SELECT ODS_DATA_ID
                                             FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_CC_CODE ORDER BY T.RPT_DATE DESC) RN,
                                                          T.*
                                                     FROM MBT_510_RPT T
                                                    WHERE T.DATA_STATUS = '27')
                                            WHERE RN = 1))
                           MINUS
                           SELECT B_CC_CODE,
                                  F_IMP_TYPE,
                                  F_IMP_VAL_ORG,
                                  F_IMP_CY,
                                  F_IPPC,
                                  F_PAWN_NAME,
                                  F_PAWN_CERT_TYPE,
                                  F_PAWN_CERT_NUM
                             FROM MBT_510_F )) D
          ON A.B_CC_CODE = D.B_CC_CODE
        left join (select count(1) cnt, B_CC_CODE
                     from MBT_510_RPT
                    WHERE DATA_STATUS = '27'
                      and B_RPT_DATE_CODE = '20'
                    GROUP BY B_CC_CODE) E
          ON A.B_CC_CODE = E.B_CC_CODE

       WHERE A.DATA_ID = TABLE_KEY;

      SELECT IS_RPT INTO IS_RPT_OUT FROM MBT_510 WHERE DATA_ID = TABLE_KEY;
      IF IS_RPT_OUT IS NULL THEN
        UPDATE MBT_510 SET IS_RPT = '11|000' WHERE DATA_ID = TABLE_KEY;
      END IF;
      --------------------修改B段数据开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_510',
                              'T.B_CC_CODE',
                              'T1.B_CC_CODE=T2.B_CC_CODE',
                              B_ARRAYLIST,
                              1,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T1.C_GUAR_TYPE = T3.ACCT_TYPE
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              TABLE_KEY);
      --------------------修改B段数据结束--------------------
      --------------------修改C段数据开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_510',
                              'T.B_CC_CODE',
                              'T1.B_CC_CODE=T2.B_CC_CODE',
                              C_ARRAYLIST,
                              2,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T1.C_GUAR_TYPE = T3.ACCT_TYPE
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              TABLE_KEY);
      --------------------修改C段数据结束--------------------
      --------------------修改子表[MBT_510_D]数据开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_510_D',
                             'T.B_CC_CODE,T.D_INFO_ID_TYPE,T.D_GUAR_CERT_TYPE,T.D_GUAR_CERT_NUM',
                              'T1.B_CC_CODE=T2.B_CC_CODE AND T1.D_INFO_ID_TYPE=T2.D_INFO_ID_TYPE AND T1.D_GUAR_CERT_TYPE=T2.D_GUAR_CERT_TYPE AND T1.D_GUAR_CERT_NUM = T2.D_GUAR_CERT_NUM',
                              D_ARRAYLIST,
                              4,
                              'MBT_510',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND T3.C_GUAR_TYPE = T4.ACCT_TYPE
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              TABLE_KEY);
      --------------------修改子表[MBT_510_D]结束--------------------
      --------------------修改子表[MBT_510_E]数据开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_510_E',
                               'T.B_CC_CODE,T.E_PLE_TYPE,T.E_PLE_CERT_ID,T.E_PLEDGOR_TYPE,T.E_PLEOR_CERT_TYPE,T.E_PLEOR_CERT_NUM',
                              'T1.B_CC_CODE=T2.B_CC_CODE
                              AND T1.E_PLE_TYPE = T2.E_PLE_TYPE
                              AND T1.E_PLE_CERT_ID = T2.E_PLE_CERT_ID
                              AND T1.E_PLEDGOR_TYPE =T2.E_PLEDGOR_TYPE
                              AND T1.E_PLEOR_CERT_TYPE =T2.E_PLEOR_CERT_TYPE
                              AND T1.E_PLEOR_CERT_NUM =T2.E_PLEOR_CERT_NUM ',
                              E_ARRAYLIST,
                              5,
                              'MBT_510',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND T3.C_GUAR_TYPE = T4.ACCT_TYPE
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              TABLE_KEY);
      --------------------修改子表[MBT_510_E]结束--------------------
      --------------------修改子表[MBT_510_F]数据开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_510_F',
                              'T.B_CC_CODE,T.F_IMP_TYPE,T.F_IPPC,T.F_PAWN_CERT_TYPE,T.F_PAWN_CERT_NUM',
                              'T1.B_CC_CODE=T2.B_CC_CODE AND T1.F_IMP_TYPE = T2.F_IMP_TYPE AND T1.F_IPPC =T2.F_IPPC AND T1.F_PAWN_CERT_TYPE =T2.F_PAWN_CERT_TYPE AND T1.F_PAWN_CERT_NUM = T2.F_PAWN_CERT_NUM',
                              F_ARRAYLIST,
                              6,
                              'MBT_510',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND T3.C_GUAR_TYPE = T4.ACCT_TYPE
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              TABLE_KEY);
      --------------------修改子表[MBT_510_F]结束--------------------
    END;
  ELSE

    BEGIN
      SELECT MAX(NVL(CASE
                       WHEN (A.C_GUAR_TYPE = '1' AND C.DATA_ID IS NOT NULL) OR
                            (A.C_GUAR_TYPE = '2' AND B.DATA_ID IS NOT NULL) THEN
                        1
                     END,
                     0))
        INTO INSPECT_RESULT
        FROM ODS_MBT_510 A
        LEFT JOIN ODS_MBT_510_E B
          ON A.DATA_ID = B.PDATA_ID
        LEFT JOIN ODS_MBT_510_F C
          ON A.DATA_ID = C.PDATA_ID;

      /* IF INSPECT_RESULT = 1 THEN
        DSC := '[ODS_MBT_510]表校验失败[抵押合同,不应该有ODS_MBT_510_F质押表信息或质押合同,不应该有ODS_MBT_510_E抵押表信息]';
        SP_MBT_LOG(1, '', 'ERROR50001', DSC, ERRCODE, ERRMSG);
        DBMS_OUTPUT.PUT_LINE(DSC);
        DSC := '##=======MBT510存储过程==结束' || ENDTIME || '========##';
        DBMS_OUTPUT.PUT_LINE(DSC);
        RETURN;
      END IF;*/
      --------------------备份数据--------------------
      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_510_TODAY_BAK';
      INSERT INTO MBT_510_TODAY_BAK
        SELECT * FROM MBT_510;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_510_D_TODAY_BAK';
      INSERT INTO MBT_510_D_TODAY_BAK
        SELECT * FROM MBT_510_D;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_510_E_TODAY_BAK';
      INSERT INTO MBT_510_E_TODAY_BAK
        SELECT * FROM MBT_510_E;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_510_F_TODAY_BAK';
      INSERT INTO MBT_510_F_TODAY_BAK
        SELECT * FROM MBT_510_F;
      --------------------备份数据--------------------
      --------------------更新数据开始--------------------
      MERGE INTO MBT_510 T1
      USING (SELECT A.*,
                    CASE
                      WHEN INSTR(B.B_INFO_ID_TYPE || B.B_NAME ||
                                 B.B_CERT_TYPE || B.B_CERT_NUM ||
                                 B.B_MNGMT_ORG_CODE || B.C_GUAR_TYPE ||
                                 B.C_CC_AMT || B.C_CY || B.C_CC_VAL_DATE ||
                                 B.C_CC_EXP_DATE || B.C_MAX_GUAR ||
                                 B.C_CC_STATUS || B.CUST_TYPE || '1',
                                 A.B_INFO_ID_TYPE || A.B_NAME || A.B_CERT_TYPE ||
                                 A.B_CERT_NUM || A.B_MNGMT_ORG_CODE ||
                                 A.C_GUAR_TYPE || A.C_CC_AMT || A.C_CY ||
                                 A.C_CC_VAL_DATE || A.C_CC_EXP_DATE ||
                                 A.C_MAX_GUAR || A.C_CC_STATUS || A.CUST_TYPE || '1') > 0 THEN
                       'N'
                      ELSE
                       'Y'
                    END AS UPDATE_FLAG
               FROM ODS_MBT_510 A
              INNER JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_CC_CODE ORDER BY DATA_LOAD_TIME DESC) RN,
                                        T.*
                                   FROM ODS_MBT_510_HIS T
                                  ORDER BY T.DATA_LOAD_TIME DESC)
                          WHERE RN = 1) B
                 ON A.B_CC_CODE = B.B_CC_CODE) T2
      ON (T1.B_CC_CODE = T2.B_CC_CODE AND T2.UPDATE_FLAG = 'Y')
      WHEN MATCHED THEN
        UPDATE
           SET T1.B_INFO_ID_TYPE   = T2.B_INFO_ID_TYPE,
               T1.B_NAME           = T2.B_NAME,
               T1.B_CERT_TYPE      = T2.B_CERT_TYPE,
               T1.B_CERT_NUM       = T2.B_CERT_NUM,
               T1.C_GUAR_TYPE      = T2.C_GUAR_TYPE,
               T1.C_CC_AMT         = T2.C_CC_AMT,
               T1.C_CY             = T2.C_CY,
               T1.C_CC_VAL_DATE    = T2.C_CC_VAL_DATE,
               T1.C_CC_EXP_DATE    = T2.C_CC_EXP_DATE,
               T1.C_MAX_GUAR       = T2.C_MAX_GUAR,
               T1.C_CC_STATUS      = T2.C_CC_STATUS,
               T1.CUST_TYPE        = T2.CUST_TYPE,
               T1.DATA_STATUS      = '00',
               T1.DATA_CHG_USER    = 'SYSTEM',
               T1.DATA_CHG_DATE    = CURRENTDATE,
               T1.DATA_CHG_TIME    = CURRENTTIME,
               T1.B_RPT_DATE       = V_DATE,
               T1.B_MNGMT_ORG_CODE = T2.B_MNGMT_ORG_CODE,
               T1.CHECK_FLAG       = 'N';
      --------------------更新数据结束--------------------
      --------------------新增数据开始--------------------
      MERGE INTO MBT_510 T1
      USING (SELECT A.*, '10' AS B_RPT_DATE_CODE, '11|000' AS IS_RPT
               FROM ODS_MBT_510 A) T2
      ON (T1.B_CC_CODE = T2.B_CC_CODE)
      WHEN NOT MATCHED THEN
        INSERT
          (T1.DATA_ID,
           T1.DATA_DATE,
           T1.CORP_ID,
           T1.ORG_ID,
           T1.GROUP_ID,
           T1.INQ_ORG_ID,
           T1.INQ_GROUP_ID,
           T1.B_INF_REC_TYPE,
           T1.B_CC_CODE,
           T1.B_RPT_DATE,
           T1.B_RPT_DATE_CODE,
           T1.B_INFO_ID_TYPE,
           T1.B_NAME,
           T1.B_CERT_TYPE,
           T1.B_CERT_NUM,
           T1.B_MNGMT_ORG_CODE,
           T1.B_CUST_NO,
           T1.C_GUAR_TYPE,
           T1.C_CC_AMT,
           T1.C_CY,
           T1.C_CC_VAL_DATE,
           T1.C_CC_EXP_DATE,
           T1.C_MAX_GUAR,
           T1.C_CC_STATUS,
           T1.DATA_STATUS,
           T1.DATA_SOURCE,
           T1.DATA_CRT_USER,
           T1.DATA_CRT_DATE,
           T1.DATA_CRT_TIME,
           T1.RSV1,
           T1.RSV2,
           T1.RSV3,
           T1.RSV4,
           T1.RSV5,
           T1.IS_RPT,
           T1.CUST_TYPE)
        VALUES
          (T2.DATA_ID,
           T2.DATA_DATE,
           T2.CORP_ID,
           T2.ORG_ID,
           T2.GROUP_ID,
           T2.ORG_ID,
           T2.ORG_ID,
           '510',
           T2.B_CC_CODE,
           V_DATE,
           T2.B_RPT_DATE_CODE,
           T2.B_INFO_ID_TYPE,
           T2.B_NAME,
           T2.B_CERT_TYPE,
           T2.B_CERT_NUM,
           T2.B_MNGMT_ORG_CODE,
           T2.B_CUST_NO,
           T2.C_GUAR_TYPE,
           T2.C_CC_AMT,
           T2.C_CY,
           T2.C_CC_VAL_DATE,
           T2.C_CC_EXP_DATE,
           T2.C_MAX_GUAR,
           T2.C_CC_STATUS,
           '00',
           '2',
           'SYSTEM',
           CURRENTDATE,
           CURRENTTIME,
           T2.RSV1,
           T2.RSV2,
           T2.RSV3,
           T2.RSV4,
           T2.RSV5,
           T2.IS_RPT,
           T2.CUST_TYPE);
      --------------------新增结束--------------------
      --------------------修改子表[MBT_510_D]数据开始--------------------
      -- 先删除所有相关数据 然后重新插入
      DELETE FROM MBT_510_D
       WHERE B_CC_CODE IN (SELECT DISTINCT B_CC_CODE FROM ODS_MBT_510);
      --------------------新增数据开始--------------------
      MERGE INTO MBT_510_D T1
      USING (SELECT A.DATA_ID,
                    A.DATA_DATE,
                    A.D_INFO_ID_TYPE,
                    A.D_GUAR_NAME,
                    A.D_GUAR_CERT_TYPE,
                    A.D_GUAR_CERT_NUM,
                    A.D_GUAR_NO,
                    A.RSV1,
                    A.RSV2,
                    A.RSV3,
                    A.RSV4,
                    A.RSV5,
                    A.B_CC_CODE,
                    CASE
                      WHEN C.DATA_ID IS NULL THEN
                       A.PDATA_ID
                      ELSE
                       C.DATA_ID
                    END AS PDATA_ID
               FROM ODS_MBT_510_D A
               LEFT JOIN MBT_510 C
                 ON A.B_CC_CODE = C.B_CC_CODE) T2
      ON (T1.B_CC_CODE=T2.B_CC_CODE AND T1.D_INFO_ID_TYPE=T2.D_INFO_ID_TYPE AND T1.D_GUAR_CERT_TYPE=T2.D_GUAR_CERT_TYPE AND T1.D_GUAR_CERT_NUM = T2.D_GUAR_CERT_NUM)
      WHEN NOT MATCHED THEN
        INSERT
          (T1.DATA_ID,
           T1.PDATA_ID,
           T1.DATA_DATE,
           T1.B_CC_CODE,
           T1.D_INFO_ID_TYPE,
           T1.D_GUAR_NAME,
           T1.D_GUAR_CERT_TYPE,
           T1.D_GUAR_CERT_NUM,
           T1.D_GUAR_NO,
           T1.DATA_SOURE,
           T1.DATA_CRT_USER,
           T1.DATA_CRT_DATE,
           T1.DATA_CRT_TIME,
           T1.RSV1,
           T1.RSV2,
           T1.RSV3,
           T1.RSV4,
           T1.RSV5)
        VALUES
          (T2.DATA_ID,
           T2.PDATA_ID,
           T2.DATA_DATE,
           T2.B_CC_CODE,
           T2.D_INFO_ID_TYPE,
           T2.D_GUAR_NAME,
           T2.D_GUAR_CERT_TYPE,
           T2.D_GUAR_CERT_NUM,
           T2.D_GUAR_NO,
           '2',
           'SYSEM',
           CURRENTDATE,
           CURRENTTIME,
           T2.RSV1,
           T2.RSV2,
           T2.RSV3,
           T2.RSV4,
           'FLAG');

      --更改主表数据状态
      MERGE INTO MBT_510 T1
      USING (SELECT DISTINCT B.DATA_ID
               FROM MBT_510_D A
               LEFT JOIN MBT_510 B
                 ON A.PDATA_ID = B.DATA_ID
              WHERE A.RSV5 = 'FLAG') T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.DATA_STATUS = '00';

      UPDATE MBT_510_D SET RSV5 = NULL WHERE RSV5 = 'FLAG';
      --------------------修改子表[MBT_510_D]数据结束--------------------

      --------------------修改子表[MBT_510_E]数据开始--------------------
      -- 先删除所有相关数据 然后重新插入
      DELETE FROM MBT_510_E
       WHERE B_CC_CODE IN (SELECT DISTINCT B_CC_CODE FROM ODS_MBT_510);
      --------------------新增数据开始--------------------
      MERGE INTO MBT_510_E T1
      USING (SELECT A.DATA_ID,
                    A.DATA_DATE,
                    A.E_PLE_TYPE,
                    A.E_MOTGA_PROPT_ID_TYPE,
                    A.E_PLE_CERT_ID,
                    A.E_PLE_DISTR,
                    A.E_PLE_VALUE,
					A.E_PLE_VALUE_ORG,
                    A.E_PLE_CY,
                    A.E_VAL_ORG_TYPE,
                    A.E_VAL_DATE,
                    A.E_PLEDGOR_TYPE,
                    A.E_PLEDGOR_NAME,
                    A.E_PLEOR_CERT_TYPE,
                    A.E_PLEOR_CERT_NUM,
                    A.E_PLE_DESC,
                    A.RSV1,
                    A.RSV2,
                    A.RSV3,
                    A.RSV4,
                    A.RSV5,
                    A.B_CC_CODE,
                    CASE
                      WHEN C.DATA_ID IS NULL THEN
                       A.PDATA_ID
                      ELSE
                       C.DATA_ID
                    END AS PDATA_ID
               FROM ODS_MBT_510_E A
               LEFT JOIN MBT_510 C
                 ON A.B_CC_CODE = C.B_CC_CODE
              WHERE C.C_GUAR_TYPE = '1') T2
      ON (T1.B_CC_CODE=T2.B_CC_CODE
                              AND T1.E_PLE_TYPE = T2.E_PLE_TYPE
                              AND T1.E_PLE_CERT_ID = T2.E_PLE_CERT_ID
                              AND T1.E_PLEDGOR_TYPE =T2.E_PLEDGOR_TYPE
                              AND T1.E_PLEOR_CERT_TYPE =T2.E_PLEOR_CERT_TYPE
                              AND T1.E_PLEOR_CERT_NUM =T2.E_PLEOR_CERT_NUM )
      WHEN NOT MATCHED THEN
        INSERT
          (T1.DATA_ID,
           T1.PDATA_ID,
           T1.DATA_DATE,
           T1.B_CC_CODE,
           T1.E_PLE_TYPE,
           T1.E_MOTGA_PROPT_ID_TYPE,
           T1.E_PLE_CERT_ID,
           T1.E_PLE_DISTR,
           T1.E_PLE_VALUE,
		   T1.E_PLE_VALUE_ORG,
           T1.E_PLE_CY,
           T1.E_VAL_ORG_TYPE,
           T1.E_VAL_DATE,
           T1.E_PLEDGOR_TYPE,
           T1.E_PLEDGOR_NAME,
           T1.E_PLEOR_CERT_TYPE,
           T1.E_PLEOR_CERT_NUM,
           T1.E_PLE_DESC,
           T1.DATA_SOURE,
           T1.DATA_CRT_USER,
           T1.DATA_CRT_DATE,
           T1.DATA_CRT_TIME,
           T1.RSV1,
           T1.RSV2,
           T1.RSV3,
           T1.RSV4,
           T1.RSV5)
        VALUES
          (T2.DATA_ID,
           T2.PDATA_ID,
           T2.DATA_DATE,
           T2.B_CC_CODE,
           T2.E_PLE_TYPE,
           T2.E_MOTGA_PROPT_ID_TYPE,
           T2.E_PLE_CERT_ID,
           T2.E_PLE_DISTR,
           T2.E_PLE_VALUE,
		   T2.E_PLE_VALUE_ORG,
           T2.E_PLE_CY,
           T2.E_VAL_ORG_TYPE,
           T2.E_VAL_DATE,
           T2.E_PLEDGOR_TYPE,
           T2.E_PLEDGOR_NAME,
           T2.E_PLEOR_CERT_TYPE,
           T2.E_PLEOR_CERT_NUM,
           T2.E_PLE_DESC,
           '2',
           'SYSEM',
           CURRENTDATE,
           CURRENTTIME,
           T2.RSV1,
           T2.RSV2,
           T2.RSV3,
           T2.RSV4,
           'FLAG');

      --更改主表数据状态
      MERGE INTO MBT_510 T1
      USING (SELECT DISTINCT B.DATA_ID
               FROM MBT_510_E A
               LEFT JOIN MBT_510 B
                 ON A.PDATA_ID = B.DATA_ID
              WHERE A.RSV5 = 'FLAG') T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.DATA_STATUS = '00';

      UPDATE MBT_510_E SET RSV5 = NULL WHERE RSV5 = 'FLAG';
      --------------------修改子表[MBT_510_E]数据结束--------------------

      --------------------修改子表[MBT_510_F]数据开始--------------------
      -- 先删除所有相关数据 然后重新插入
      DELETE FROM MBT_510_F
       WHERE B_CC_CODE IN (SELECT DISTINCT B_CC_CODE FROM ODS_MBT_510);
      --------------------新增数据开始--------------------
      MERGE INTO MBT_510_F T1
      USING (SELECT A.DATA_ID,
                    A.DATA_DATE,
                    A.F_IMP_TYPE,
                    A.F_IMP_VAL,
					A.F_IMP_VAL_ORG,
                    A.F_IMP_CY,
                    A.F_IPPC,
                    A.F_PAWN_NAME,
                    A.F_PAWN_CERT_TYPE,
                    A.F_PAWN_CERT_NUM,
                    A.RSV1,
                    A.RSV2,
                    A.RSV3,
                    A.RSV4,
                    A.RSV5,
                    A.B_CC_CODE,
                    CASE
                      WHEN C.DATA_ID IS NULL THEN
                       A.PDATA_ID
                      ELSE
                       C.DATA_ID
                    END AS PDATA_ID
               FROM ODS_MBT_510_F A
               LEFT JOIN MBT_510 C
                 ON A.B_CC_CODE = C.B_CC_CODE
              WHERE C.C_GUAR_TYPE = '2') T2
      ON (T1.B_CC_CODE=T2.B_CC_CODE AND T1.F_IMP_TYPE = T2.F_IMP_TYPE AND T1.F_IPPC =T2.F_IPPC AND T1.F_PAWN_CERT_TYPE =T2.F_PAWN_CERT_TYPE AND T1.F_PAWN_CERT_NUM = T2.F_PAWN_CERT_NUM)
      WHEN NOT MATCHED THEN
        INSERT
          (T1.DATA_ID,
           T1.PDATA_ID,
           T1.DATA_DATE,
           T1.B_CC_CODE,
           T1.F_IMP_TYPE,
           T1.F_IMP_VAL,
		   T1.F_IMP_VAL_ORG,
           T1.F_IMP_CY,
           T1.F_IPPC,
           T1.F_PAWN_NAME,
           T1.F_PAWN_CERT_TYPE,
           T1.F_PAWN_CERT_NUM,
           T1.DATA_SOURE,
           T1.DATA_CRT_USER,
           T1.DATA_CRT_DATE,
           T1.DATA_CRT_TIME,
           T1.RSV1,
           T1.RSV2,
           T1.RSV3,
           T1.RSV4,
           T1.RSV5)
        VALUES
          (T2.DATA_ID,
           T2.PDATA_ID,
           T2.DATA_DATE,
           T2.B_CC_CODE,
           T2.F_IMP_TYPE,
           T2.F_IMP_VAL,
		   T2.F_IMP_VAL_ORG,
           T2.F_IMP_CY,
           T2.F_IPPC,
           T2.F_PAWN_NAME,
           T2.F_PAWN_CERT_TYPE,
           T2.F_PAWN_CERT_NUM,
           '2',
           'SYSEM',
           CURRENTDATE,
           CURRENTTIME,
           T2.RSV1,
           T2.RSV2,
           T2.RSV3,
           T2.RSV4,
           'FLAG');

      --更改主表数据状态
      MERGE INTO MBT_510 T1
      USING (SELECT DISTINCT B.DATA_ID
               FROM MBT_510_F A
               LEFT JOIN MBT_510 B
                 ON A.PDATA_ID = B.DATA_ID
              WHERE A.RSV5 = 'FLAG') T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.DATA_STATUS = '00';

      UPDATE MBT_510_F SET RSV5 = NULL WHERE RSV5 = 'FLAG';
      --------------------修改子表[MBT_510_F]数据结束--------------------
      --------------------更新报告时点开始--------------------
      MERGE INTO MBT_510 T1
      USING (SELECT DISTINCT A.*,
                             CASE
                             -- 未上报过且‘抵(质)押合同状态'<> '2-到期/失效’
                               WHEN B.DATA_ID IS NULL AND
                                    a.C_CC_STATUS <> '2' THEN
                                '10'
                             --已上报过且‘抵(质)押合同状态'= '2-到期/失效’ 且未上报过’20-合同到期/失效’时点
                               WHEN B.DATA_ID IS NOT NULL AND
                                    A.C_CC_STATUS = '2' AND nvl(E.CNT, 0) = 0 THEN
                                '20'
                             --                CASE
                             --                  WHEN B.B_RPT_DATE_CODE = '20' THEN
                             --                   '99'
                             --                  ELSE
                             --                   '20'
                             --                END
                             --已报送过且未上报过’20-合同到期/失效’时点且（抵押物信息段和最新一次的抵押物信息段信息不一致或质押物信息段和最新一次的质押物信息段信息不一致）
                               WHEN B.DATA_ID IS NOT NULL AND
                                   ( C.B_CC_CODE IS NOT NULL OR
                                    D.B_CC_CODE IS NOT NULL) AND
                                    nvl(E.CNT, 0) = 0 THEN
                                '30'
                               ELSE
                                '99'
                             END AS NEW_B_RPT_DATE_CODE
               FROM MBT_510 A
               LEFT JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_CC_CODE ORDER BY RPT_TIME DESC) RN,
                                        T.*
                                   FROM MBT_510_RPT T
                                  WHERE DATA_STATUS = '27')
                          WHERE RN = 1) B
                 ON A.B_CC_CODE = B.B_CC_CODE
               LEFT JOIN (SELECT DISTINCT (B_CC_CODE)
                     FROM ((SELECT B_CC_CODE,
                                   E_PLE_TYPE,
                                   E_MOTGA_PROPT_ID_TYPE,
                                   E_PLE_CERT_ID,
                                   E_PLE_DISTR,
                                   E_PLE_VALUE_ORG,
                                   E_PLE_CY,
                                   E_VAL_ORG_TYPE,
                                   E_VAL_DATE,
                                   E_PLEDGOR_TYPE,
                                   E_PLEDGOR_NAME,
                                   E_PLEOR_CERT_TYPE,
                                   E_PLEOR_CERT_NUM,
                                   E_PLE_DESC
                              FROM MBT_510_E
                            MINUS
                            SELECT B_CC_CODE,
                                   E_PLE_TYPE,
                                   E_MOTGA_PROPT_ID_TYPE,
                                   E_PLE_CERT_ID,
                                   E_PLE_DISTR,
                                   E_PLE_VALUE_ORG,
                                   E_PLE_CY,
                                   E_VAL_ORG_TYPE,
                                   E_VAL_DATE,
                                   E_PLEDGOR_TYPE,
                                   E_PLEDGOR_NAME,
                                   E_PLEOR_CERT_TYPE,
                                   E_PLEOR_CERT_NUM,
                                   E_PLE_DESC
                              FROM (SELECT *
                                      FROM MBT_510_E_HIS
                                     WHERE PDATA_ID IN
                                           (SELECT ODS_DATA_ID
                                              FROM (SELECT ROW_NUMBER() OVER(PARTITION BY TMP.B_CC_CODE ORDER BY TMP.RPT_DATE DESC) RN,
                                                           TMP.*
                                                      FROM MBT_510_RPT TMP
                                                     WHERE TMP.DATA_STATUS = '27')
                                             WHERE RN = 1))) UNION ALL
                           (SELECT B_CC_CODE,
                                   E_PLE_TYPE,
                                   E_MOTGA_PROPT_ID_TYPE,
                                   E_PLE_CERT_ID,
                                   E_PLE_DISTR,
                                   E_PLE_VALUE_ORG,
                                   E_PLE_CY,
                                   E_VAL_ORG_TYPE,
                                   E_VAL_DATE,
                                   E_PLEDGOR_TYPE,
                                   E_PLEDGOR_NAME,
                                   E_PLEOR_CERT_TYPE,
                                   E_PLEOR_CERT_NUM,
                                   E_PLE_DESC
                              FROM (SELECT *
                                      FROM MBT_510_E_HIS
                                     WHERE PDATA_ID IN
                                           (SELECT ODS_DATA_ID
                                              FROM (SELECT ROW_NUMBER() OVER(PARTITION BY TMP.B_CC_CODE ORDER BY TMP.RPT_DATE DESC) RN,
                                                           TMP.*
                                                      FROM MBT_510_RPT TMP
                                                     WHERE TMP.DATA_STATUS = '27')
                                             WHERE RN = 1))
                            MINUS
                            SELECT B_CC_CODE,
                                   E_PLE_TYPE,
                                   E_MOTGA_PROPT_ID_TYPE,
                                   E_PLE_CERT_ID,
                                   E_PLE_DISTR,
                                   E_PLE_VALUE_ORG,
                                   E_PLE_CY,
                                   E_VAL_ORG_TYPE,
                                   E_VAL_DATE,
                                   E_PLEDGOR_TYPE,
                                   E_PLEDGOR_NAME,
                                   E_PLEOR_CERT_TYPE,
                                   E_PLEOR_CERT_NUM,
                                   E_PLE_DESC
                              FROM MBT_510_E)) ) C
                 ON A.B_CC_CODE = C.B_CC_CODE
               LEFT JOIN (SELECT DISTINCT (B_CC_CODE)
                     FROM (SELECT B_CC_CODE,
                                  F_IMP_TYPE,
                                  F_IMP_VAL_ORG,
                                  F_IMP_CY,
                                  F_IPPC,
                                  F_PAWN_NAME,
                                  F_PAWN_CERT_TYPE,
                                  F_PAWN_CERT_NUM
                             FROM MBT_510_F
                           MINUS
                           SELECT B_CC_CODE,
                                  F_IMP_TYPE,
                                  F_IMP_VAL_ORG,
                                  F_IMP_CY,
                                  F_IPPC,
                                  F_PAWN_NAME,
                                  F_PAWN_CERT_TYPE,
                                  F_PAWN_CERT_NUM
                             FROM (SELECT *
                                     FROM MBT_510_F_HIS
                                     WHERE PDATA_ID IN
                                  --  WHERE DATA_ID IN
                                          (SELECT ODS_DATA_ID
                                             FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_CC_CODE ORDER BY T.RPT_DATE DESC) RN,
                                                          T.*
                                                     FROM MBT_510_RPT T
                                                    WHERE T.DATA_STATUS = '27')
                                            WHERE RN = 1))
                           UNION ALL
                           SELECT B_CC_CODE,
                                  F_IMP_TYPE,
                                  F_IMP_VAL_ORG,
                                  F_IMP_CY,
                                  F_IPPC,
                                  F_PAWN_NAME,
                                  F_PAWN_CERT_TYPE,
                                  F_PAWN_CERT_NUM
                             FROM (SELECT *
                                     FROM MBT_510_F_HIS
                                    WHERE PDATA_ID IN
                                          (SELECT ODS_DATA_ID
                                             FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_CC_CODE ORDER BY T.RPT_DATE DESC) RN,
                                                          T.*
                                                     FROM MBT_510_RPT T
                                                    WHERE T.DATA_STATUS = '27')
                                            WHERE RN = 1))
                           MINUS
                           SELECT B_CC_CODE,
                                  F_IMP_TYPE,
                                  F_IMP_VAL_ORG,
                                  F_IMP_CY,
                                  F_IPPC,
                                  F_PAWN_NAME,
                                  F_PAWN_CERT_TYPE,
                                  F_PAWN_CERT_NUM
                             FROM MBT_510_F ) ) D
                 ON A.B_CC_CODE = D.B_CC_CODE
               left join (select count(1) cnt, B_CC_CODE
                           from MBT_510_RPT
                          WHERE DATA_STATUS = '27'
                            and B_RPT_DATE_CODE = '20'
                          GROUP BY B_CC_CODE) E
                 ON A.B_CC_CODE = E.B_CC_CODE) T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.B_RPT_DATE_CODE = T2.NEW_B_RPT_DATE_CODE;
      --------------------更新报告时点结束--------------------
      --------------------修改B段数据开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_510',
                              'T.B_CC_CODE',
                              'T1.B_CC_CODE=T2.B_CC_CODE',
                              B_ARRAYLIST,
                              1,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T1.C_GUAR_TYPE = T3.ACCT_TYPE
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      --------------------修改B段数据结束--------------------
      --------------------修改C段数据开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_510',
                              'T.B_CC_CODE',
                              'T1.B_CC_CODE=T2.B_CC_CODE',
                              C_ARRAYLIST,
                              2,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T1.C_GUAR_TYPE = T3.ACCT_TYPE
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      --------------------修改C段数据结束--------------------
      --------------------修改子表[MBT_510_D]数据开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_510_D',
                              'T.B_CC_CODE,T.D_INFO_ID_TYPE,T.D_GUAR_CERT_TYPE,T.D_GUAR_CERT_NUM',
                              'T1.B_CC_CODE=T2.B_CC_CODE AND T1.D_INFO_ID_TYPE=T2.D_INFO_ID_TYPE AND T1.D_GUAR_CERT_TYPE=T2.D_GUAR_CERT_TYPE AND T1.D_GUAR_CERT_NUM = T2.D_GUAR_CERT_NUM',
                              D_ARRAYLIST,
                              4,
                              'MBT_510',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND T3.C_GUAR_TYPE = T4.ACCT_TYPE
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              NULL);
      --------------------修改子表[MBT_510_D]数据结束--------------------

      --------------------修改子表[MBT_510_E]数据开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_510_E',
                              'T.B_CC_CODE,T.E_PLE_TYPE,T.E_PLE_CERT_ID,T.E_PLEDGOR_TYPE,T.E_PLEOR_CERT_TYPE,T.E_PLEOR_CERT_NUM',
                              'T1.B_CC_CODE=T2.B_CC_CODE
                              AND T1.E_PLE_TYPE = T2.E_PLE_TYPE
                              AND T1.E_PLE_CERT_ID = T2.E_PLE_CERT_ID
                              AND T1.E_PLEDGOR_TYPE =T2.E_PLEDGOR_TYPE
                              AND T1.E_PLEOR_CERT_TYPE =T2.E_PLEOR_CERT_TYPE
                              AND T1.E_PLEOR_CERT_NUM =T2.E_PLEOR_CERT_NUM ',
                              E_ARRAYLIST,
                              5,
                              'MBT_510',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND T3.C_GUAR_TYPE = T4.ACCT_TYPE
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              NULL);

      --------------------修改子表[MBT_510_E]数据结束--------------------

      --------------------修改子表[MBT_510_F]数据开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_510_F',
                              'T.B_CC_CODE,T.F_IMP_TYPE,T.F_IPPC,T.F_PAWN_CERT_TYPE,T.F_PAWN_CERT_NUM',
                              'T1.B_CC_CODE=T2.B_CC_CODE AND T1.F_IMP_TYPE = T2.F_IMP_TYPE AND T1.F_IPPC =T2.F_IPPC AND T1.F_PAWN_CERT_TYPE =T2.F_PAWN_CERT_TYPE AND T1.F_PAWN_CERT_NUM = T2.F_PAWN_CERT_NUM',
                              F_ARRAYLIST,
                              6,
                              'MBT_510',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND T3.C_GUAR_TYPE = T4.ACCT_TYPE
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              NULL);
      --------------------修改子表[MBT_510_F]数据结束--------------------

      --数据插入历史表，然后删除ODS表
      INSERT INTO ODS_MBT_510_HIS
        SELECT * FROM ODS_MBT_510;
      DELETE FROM ODS_MBT_510;
      --数据插入历史表，然后删除ODS表
      INSERT INTO ODS_MBT_510_D_HIS
        SELECT * FROM ODS_MBT_510_D;
      DELETE FROM ODS_MBT_510_D;
      --数据插入历史表，然后删除ODS表
      INSERT INTO ODS_MBT_510_E_HIS
        SELECT * FROM ODS_MBT_510_E;
      DELETE FROM ODS_MBT_510_E;
      --数据插入历史表，然后删除ODS表
      INSERT INTO ODS_MBT_510_F_HIS
        SELECT * FROM ODS_MBT_510_F;
      DELETE FROM ODS_MBT_510_F;

      --将报告时点代码是88或99的直接审核通过并将校验修改为校验通过
      UPDATE mbt_510
         SET DATA_STATUS = '21', CHECK_FLAG = 'Y'
       WHERE DATA_DATE <= CURRENTDATE
         AND (B_RPT_DATE_CODE = '88' OR B_RPT_DATE_CODE = '99')
         AND DATA_STATUS = '00';

           --将报告时点代码不是88或99的校验修改为未校验ZHAO
    /*  UPDATE mbt_510
         SET CHECK_FLAG = 'N'
       WHERE DATA_DATE <= CURRENTDATE
         AND (B_RPT_DATE_CODE  NOT IN('88','99'))
         AND DATA_STATUS = '00'
         AND CUST_TYPE='P';--个人*/
    END;
  END IF;

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ERRCODE := SQLCODE;
    ERRMSG  := SUBSTR(SQLERRM, 1, 200);
    SP_MBT_LOG(1,
               'SP_ODS_MBT_510',
               'ERROR51001',
               'SP_ODS_MBT_510失败：' || ERRMSG,
               ERRCODE,
               ERRMSG);
    ROLLBACK;

    ENDTIME := TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS');
    DSC     := '##=======MBT510存储过程==结束' || ENDTIME || '========##';
    DBMS_OUTPUT.PUT_LINE(DSC);
END;

