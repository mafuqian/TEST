CREATE OR REPLACE PROCEDURE "SP_ODS_MBT_410"(ERRCODE           IN OUT VARCHAR,
                                             ERRMSG            IN OUT VARCHAR,
                                             TABLE_KEY         IN VARCHAR2,
                                             RPT_DATE_CODE_OUT OUT VARCHAR2) AS

  DSC         VARCHAR2(1000);
  BEGINTIME   VARCHAR2(20);
  ENDTIME     VARCHAR2(20);
  CURRENTDATE VARCHAR2(8);
  CURRENTTIME VARCHAR2(14);
  B_ARRAYLIST VARCHAR2(400);
  C_ARRAYLIST VARCHAR2(400);
  D_ARRAYLIST VARCHAR2(400);
  E_ARRAYLIST VARCHAR2(400);
  F_ARRAYLIST VARCHAR2(400);
  G_ARRAYLIST VARCHAR2(400);
  H_ARRAYLIST VARCHAR2(400);
  I_ARRAYLIST VARCHAR2(400);
  IS_RPT_OUT  VARCHAR2(64);
    V_DATE  VARCHAR2(8) ;
    V_NUM   NUMBER(8);
BEGIN
  B_ARRAYLIST := 'B_NAME,B_ID_TYPE,B_ID_NUM,B_MNGMT_ORG_CODE';
  C_ARRAYLIST := 'C_BUSI_LINES,C_BUSI_DTL_LINES,C_OPEN_DATE,C_CY,C_ACCT_CRED_LINE_AMT,C_LOAN_AMT,C_FLAG,C_DUE_DATE,C_REPAY_MODE,C_REPAY_FREQCY,C_APPLY_BUSI_DIST,C_GUAR_MODE,C_OTH_REPY_GUAR_WAY,C_LOAN_TIME_LIM_CAT,C_LOA_FRM,C_ACT_INVEST,C_FUND_SOU,C_ASSET_TRAND_FLAG';
  D_ARRAYLIST := 'D_ARLP_NAME,D_ARLP_TYPE,D_ARLP_AMT,D_WARTY_SIGN,D_MAX_GUAR_MCC';
  E_ARRAYLIST := 'E_CCC';
  F_ARRAYLIST := 'F_MCC';
  G_ARRAYLIST := 'G_INIT_CRED_NAME,G_INIT_CED_ORG_CODE, G_INIT_RPY_STS';
  H_ARRAYLIST := 'H_ACCT_STATUS, H_ACCT_BAL,
                 H_BAL_CHG_DATE, H_FIVE_CATE, H_FIVE_CATE_ADJ_DATE,
                 H_PYMT_PRD, H_TOT_OVERD, H_OVERD_PRINC, H_OVERD_DY,
                 H_LAT_RPY_DATE, H_LAT_RPY_AMT, H_LAT_RPY_PRINC_AMT,
                 H_RPMT_TYPE, H_LAT_AGRR_RPY_DATE, H_LAT_AGRR_RPY_AMT,
                 H_NXT_AGRR_RPY_DATE, H_CLOSE_DATE';
  I_ARRAYLIST := 'I_TRAN_AMT,I_DUE_TRAN_MON,I_DET_INFO';

  CURRENTDATE := TO_CHAR(SYSDATE, 'YYYYMMDD');
  CURRENTTIME := TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS');
  BEGINTIME   := TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS');
    V_DATE := GET_NEW_DAY(CURRENTDATE);
  DSC         := '##=======MBT410存储过程==开始' || BEGINTIME || '========##';
  DBMS_OUTPUT.PUT_LINE(DSC);

  IF TABLE_KEY IS NOT NULL THEN
    --处理从页面来的数据
    BEGIN
      SELECT DISTINCT CASE
                        WHEN C.DATA_ID IS NULL and (A.H_ACCT_STATUS <> '21' OR A.H_ACCT_STATUS IS NULL) THEN
                         '10'
                        WHEN A.H_ACCT_STATUS = '21' THEN
                         CASE
                           WHEN F.DATA_ID IS  NULL OR  C.B_RPT_DATE_CODE = '20' THEN
                            '99'
                           ELSE
                            '20'
                         END
                        WHEN A.B_ACCT_TYPE = 'D1' AND A.C_FLAG = '2' AND
                             A.C_LOAN_AMT > C.C_LOAN_AMT THEN
                         '31'
                        WHEN A.B_ACCT_TYPE IN ('D1', 'R4', 'D2') AND
                             NVL(A.H_LAT_RPY_DATE, 'NULL') = NVL(A.H_LAT_AGRR_RPY_DATE, 'NULL') AND
                             A.H_LAT_RPY_AMT <> 0 AND
                             NVL(A.H_LAT_RPY_DATE, 'NULL') <> NVL(C.H_LAT_RPY_DATE, 'NULL') THEN
                         '32'
                        WHEN A.B_ACCT_TYPE IN ('D1', 'R4', 'D2', 'C1') AND
                             NVL(A.H_LAT_RPY_DATE, 'NULL') <> NVL(A.H_LAT_AGRR_RPY_DATE, 'NULL') AND
                             A.H_LAT_RPY_AMT <> 0 AND
                             NVL(A.H_LAT_RPY_DATE, 'NULL') <> NVL(C.H_LAT_RPY_DATE, 'NULL') THEN
                         '33'
                        WHEN A.H_FIVE_CATE <> C.H_FIVE_CATE THEN
                         '41'
                         WHEN  F.DATA_ID IS NOT NULL AND A.B_ACCT_TYPE IN ('D1', 'R4') AND B.B_ACCT_CODE IS NOT NULL AND
                             NVL(B.I_CHAN_TRAN_TYPE, 'NULL') <> NVL(E.I_CHAN_TRAN_TYPE, 'NULL') AND
                             NVL(B.I_TRAN_DATE, 'NULL') <> NVL(E.I_TRAN_DATE, 'NULL') THEN
                         '42'
                        WHEN D.DATA_ID IS NULL AND F.DATA_ID IS NOT NULL  THEN
                         CASE
                           WHEN (A.B_ACCT_TYPE IN ('D1', 'R4') AND A.H_TOT_OVERD > 0) OR
                                (A.B_ACCT_TYPE IN ('D1', 'D2', 'R4') AND
                                A.C_GUAR_MODE <> C.C_GUAR_MODE) OR
                                (A.B_ACCT_TYPE IN ('D1', 'D2', 'R4', 'C1') AND
                                A.H_ACCT_STATUS IN ('31', '32')) OR A.B_ACCT_TYPE ='R1' or
                                (A.B_ACCT_TYPE IN ('D1', 'D2', 'R4', 'R1') AND NVL(A.C_DUE_DATE,NULL) <>NVL(F.C_DUE_DATE,NULL) )
                                 or
                                (A.B_ACCT_TYPE IN ('D1', 'D2', 'R4', 'R1') AND NVL(A.C_OTH_REPY_GUAR_WAY,NULL) <>NVL(F.C_OTH_REPY_GUAR_WAY,NULL) )
                                 or
                                (A.B_ACCT_TYPE IN ('D1',  'R4') AND NVL(A.C_LOAN_TIME_LIM_CAT,NULL) <>NVL(F.C_LOAN_TIME_LIM_CAT,NULL) )
                                 or
                                (A.B_ACCT_TYPE IN ('D1', 'D2', 'R4', 'C1') AND NVL(A.C_LOAN_AMT,NULL) <>NVL(F.C_LOAN_AMT,NULL) )
                                or
                                (A.B_ACCT_TYPE IN ('D1', 'R1', 'R4') AND NVL(A.F_MCC,NULL) <>NVL(F.F_MCC,NULL) )
                                or
                                (  NVL(A.B_NAME,NULL) <>NVL(F.B_NAME,NULL) )
                                 or
                                (NVL(A.B_ID_TYPE,NULL) <>NVL(F.B_ID_TYPE,NULL) )
                                or
                                ( NVL(A.B_ID_NUM,NULL) <>NVL(F.B_ID_NUM,NULL) )
                                or
                                ( NVL(A.B_MNGMT_ORG_CODE,NULL) <>NVL(F.B_MNGMT_ORG_CODE,NULL) )
                                or
                                (A.B_ACCT_TYPE IN ('D1', 'D2', 'R4', 'R1') AND NVL(A.C_APPLY_BUSI_DIST,NULL) <>NVL(F.C_APPLY_BUSI_DIST,NULL) )

                                THEN
                            '49'
                         END
                        ELSE
                         '99'
                      END
        INTO RPT_DATE_CODE_OUT
        FROM MBT_410 A
        LEFT JOIN MBT_410_I B
          ON A.B_ACCT_CODE = B.B_ACCT_CODE
         AND B.I_CHAN_TRAN_TYPE = '11'
        LEFT JOIN (SELECT *
                     FROM MBT_410_HIS
                    WHERE DATA_ID IN (SELECT ODS_DATA_ID
                                        FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_ACCT_CODE ORDER BY RPT_TIME DESC) RN,
                                                     T.ODS_DATA_ID
                                                FROM MBT_410_RPT T
                                               WHERE DATA_STATUS = '27')
                                       WHERE RN = 1)) C
          ON A.B_ACCT_CODE = C.B_ACCT_CODE
        LEFT JOIN MBT_410_RPT D
          ON A.B_ACCT_CODE = D.B_ACCT_CODE
         AND SUBSTR(D.RPT_DATE, 1, 6) = SUBSTR(CURRENTDATE, 1, 6)
         AND D.DATA_STATUS = '27'
        LEFT JOIN (SELECT *
                     FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_ACCT_CODE ORDER BY T.RPT_TIME DESC) RN,
                                  T.*
                             FROM MBT_410_I_RPT T
                            INNER JOIN MBT_410_RPT TMP
                               ON T.PDATA_ID = TMP.DATA_ID
                              AND TMP.DATA_STATUS = '27')
                    WHERE RN = 1) E
          ON B.B_ACCT_CODE = E.B_ACCT_CODE

            LEFT JOIN (SELECT *
                     FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_ACCT_CODE ORDER BY RPT_TIME DESC) RN,
                                  T.*
                             FROM MBT_410_RPT T
                            WHERE DATA_STATUS = '27')
                    WHERE RN = 1) F
          ON A.B_ACCT_CODE = F.B_ACCT_CODE
       WHERE A.DATA_ID = TABLE_KEY;

  begin
   --更新时点（子表有改动）
  SELECT
                             CASE
                               WHEN T4.DATA_ID IS NOT NULL THEN
                                '49'
                               ELSE
                                '99'
                             END AS RPT_DATE_CODE_OUT INTO RPT_DATE_CODE_OUT
               FROM (SELECT DISTINCT D_ARLP_ID_TYPE,D_ARLP_NAME,D_ARLP_CERT_TYPE,D_ARLP_CERT_NUM,B_ACCT_CODE,D_ARLP_TYPE,D_WARTY_SIGN,D_MAX_GUAR_MCC
                       FROM (SELECT D_ARLP_ID_TYPE,D_ARLP_NAME,D_ARLP_CERT_TYPE,D_ARLP_CERT_NUM,B_ACCT_CODE,D_ARLP_TYPE,D_WARTY_SIGN,D_MAX_GUAR_MCC
                               FROM MBT_410_D
                             MINUS
                             SELECT D_ARLP_ID_TYPE,D_ARLP_NAME,D_ARLP_CERT_TYPE,D_ARLP_CERT_NUM,B_ACCT_CODE,D_ARLP_TYPE,D_WARTY_SIGN,D_MAX_GUAR_MCC
                               FROM MBT_410_D_RPT
                              WHERE PDATA_ID IN (SELECT DATA_ID
                                                   FROM (SELECT ROW_NUMBER() OVER(PARTITION BY b_acct_code ORDER BY RPT_TIME DESC) RN,
                                                                T.*
                                                           FROM MBT_410_RPT T
                                                          WHERE DATA_STATUS = '27')
                                                  WHERE RN = 1)
                             UNION ALL
                             SELECT D_ARLP_ID_TYPE,D_ARLP_NAME,D_ARLP_CERT_TYPE,D_ARLP_CERT_NUM,B_ACCT_CODE,D_ARLP_TYPE,D_WARTY_SIGN,D_MAX_GUAR_MCC
                               FROM MBT_410_D_RPT
                              WHERE PDATA_ID IN (SELECT DATA_ID
                                                   FROM (SELECT ROW_NUMBER() OVER(PARTITION BY b_acct_code ORDER BY RPT_TIME DESC) RN,
                                                                T.*
                                                           FROM MBT_410_RPT T
                                                          WHERE DATA_STATUS = '27')
                                                  WHERE RN = 1)
                             MINUS
                             SELECT D_ARLP_ID_TYPE,D_ARLP_NAME,D_ARLP_CERT_TYPE,D_ARLP_CERT_NUM,B_ACCT_CODE,D_ARLP_TYPE,D_WARTY_SIGN,D_MAX_GUAR_MCC
                               FROM MBT_410_D

                             )) T1
               LEFT JOIN MBT_410_D T2
                 ON T1.b_acct_code = T2.b_acct_code
                LEFT JOIN MBT_410 T3
                 ON T2.PDATA_ID = T3.DATA_ID
               LEFT JOIN MBT_410_RPT T4
                 ON T1.b_acct_code = T2.b_acct_code
                AND T4.DATA_STATUS = '27'  where t3.b_rpt_date_code='99' and t3.H_ACCT_STATUS <> '21' and t3.DATA_ID = TABLE_KEY;
                EXCEPTION
  WHEN OTHERS THEN  DBMS_OUTPUT.PUT_LINE(1);
                end;
                begin
                  SELECT
                             CASE
                               WHEN T4.DATA_ID IS NOT NULL THEN
                                '49'
                               ELSE
                                '99'
                             END AS RPT_DATE_CODE_OUT INTO RPT_DATE_CODE_OUT
               FROM (SELECT DISTINCT E_CCC,b_acct_code
                       FROM (SELECT E_CCC,b_acct_code
                               FROM MBT_410_e
                             MINUS
                             SELECT E_CCC,b_acct_code
                               FROM MBT_410_E_RPT
                              WHERE PDATA_ID IN (SELECT DATA_ID
                                                   FROM (SELECT ROW_NUMBER() OVER(PARTITION BY b_acct_code ORDER BY RPT_TIME DESC) RN,
                                                                T.*
                                                           FROM MBT_410_RPT T
                                                          WHERE DATA_STATUS = '27')
                                                  WHERE RN = 1)
                             UNION ALL
                             SELECT E_CCC,b_acct_code
                               FROM MBT_410_E_RPT
                              WHERE PDATA_ID IN (SELECT DATA_ID
                                                   FROM (SELECT ROW_NUMBER() OVER(PARTITION BY  b_acct_code ORDER BY RPT_TIME DESC) RN,
                                                                T.*
                                                           FROM MBT_410_RPT T
                                                          WHERE DATA_STATUS = '27')
                                                  WHERE RN = 1)
                             MINUS
                             SELECT E_CCC,b_acct_code
                               FROM MBT_410_E

                             )) T1
               LEFT JOIN MBT_410_E T2
                 ON T1.b_acct_code = T2.b_acct_code
                LEFT JOIN MBT_410 T3
                 ON T2.PDATA_ID = T3.DATA_ID
               LEFT JOIN MBT_410_RPT T4
                 ON T1.b_acct_code = T2.b_acct_code
                AND T4.DATA_STATUS = '27'  where t3.b_rpt_date_code='99' and t3.H_ACCT_STATUS <> '21' and t3.DATA_ID = TABLE_KEY;
                    EXCEPTION
  WHEN OTHERS THEN  DBMS_OUTPUT.PUT_LINE(2);
end;
      SELECT IS_RPT INTO IS_RPT_OUT FROM MBT_410 WHERE DATA_ID = TABLE_KEY;
      IF IS_RPT_OUT IS NULL THEN
       -- DBMS_OUTPUT.PUT_LINE('进入了判断IS_RPT');
        MERGE INTO MBT_410 T1
        USING (SELECT A.DATA_ID, B.INIT_VALUE AS IS_RPT
                 FROM MBT_410 A
                 LEFT JOIN MBT_RPT_DATE_CODE_CFG B
                   ON A.B_INF_REC_TYPE = B.INF_REC_TYPE
                  AND INSTR(B.ACCT_TYPE, A.B_ACCT_TYPE) > 0
                  AND A.B_RPT_DATE_CODE = B.RPT_DATE_CODE) T2
        ON (T1.DATA_ID = T2.DATA_ID AND T1.DATA_ID = TABLE_KEY)
        WHEN MATCHED THEN
          UPDATE SET T1.IS_RPT = T2.IS_RPT;
      ELSE
       -- DBMS_OUTPUT.PUT_LINE('2222');
        --------------------修改IS_RPT开始--------------------
        SP_ODS_MBT_CAL_RPT_PROC('MBT_410',
                                'T.B_ACCT_CODE',
                                'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                                B_ARRAYLIST,
                                1,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND INSTR(T3.ACCT_TYPE,T1.B_ACCT_TYPE) > 0
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                TABLE_KEY);
        SP_ODS_MBT_CAL_RPT_PROC('MBT_410',
                                'T.B_ACCT_CODE',
                                'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                                C_ARRAYLIST,
                                2,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND INSTR(T3.ACCT_TYPE,T1.B_ACCT_TYPE) > 0
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                TABLE_KEY);
        SP_ODS_MBT_CAL_RPT_PROC('MBT_410',
                                'T.B_ACCT_CODE',
                                'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                                F_ARRAYLIST,
                                3,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND INSTR(T3.ACCT_TYPE,T1.B_ACCT_TYPE) > 0
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                TABLE_KEY);
        SP_ODS_MBT_CAL_RPT_PROC('MBT_410',
                                'T.B_ACCT_CODE',
                                'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                                G_ARRAYLIST,
                                4,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND INSTR(T3.ACCT_TYPE,T1.B_ACCT_TYPE) > 0
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                TABLE_KEY);
        SP_ODS_MBT_CAL_RPT_PROC('MBT_410',
                                'T.B_ACCT_CODE',
                                'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                                H_ARRAYLIST,
                                5,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND INSTR(T3.ACCT_TYPE,T1.B_ACCT_TYPE) > 0
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                TABLE_KEY);
        --------------------修改IS_RPT结束--------------------
        --------------------修改子表IS_RPT开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_410_D',
                             'T.D_ARLP_ID_TYPE,T.D_ARLP_NAME,T.D_ARLP_CERT_TYPE,T.D_ARLP_CERT_NUM,T.B_ACCT_CODE,T.D_ARLP_TYPE,T.D_WARTY_SIGN,T.D_MAX_GUAR_MCC',
                              'T1.D_ARLP_ID_TYPE = T2.D_ARLP_ID_TYPE AND T1.D_ARLP_NAME = T2.D_ARLP_NAME AND T1.D_ARLP_CERT_TYPE = T2.D_ARLP_CERT_TYPE AND T1.D_ARLP_CERT_NUM = T2.D_ARLP_CERT_NUM AND T1.B_ACCT_CODE = T2.B_ACCT_CODE AND T1.D_ARLP_TYPE =  T2.D_ARLP_TYPE AND T1.D_WARTY_SIGN =T2.D_WARTY_SIGN  AND T1.D_MAX_GUAR_MCC = T2.D_MAX_GUAR_MCC',
                              D_ARRAYLIST,
                              7,
                              'MBT_410',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND INSTR(T4.ACCT_TYPE,T3.B_ACCT_TYPE) > 0
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              TABLE_KEY);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_410_E',
                              'T.E_CCC,T.B_ACCT_CODE',
                              'T1.E_CCC = T2.E_CCC AND T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              E_ARRAYLIST,
                              8,
                              'MBT_410',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND INSTR(T4.ACCT_TYPE,T3.B_ACCT_TYPE) > 0
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              TABLE_KEY);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_410_I',
                              'T.I_CHAN_TRAN_TYPE,T.I_TRAN_DATE,T.B_ACCT_CODE',
                              'T1.I_CHAN_TRAN_TYPE=T2.I_CHAN_TRAN_TYPE AND T1.I_TRAN_DATE=T2.I_TRAN_DATE AND T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              I_ARRAYLIST,
                              9,
                              'MBT_410',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND INSTR(T4.ACCT_TYPE,T3.B_ACCT_TYPE) > 0
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              TABLE_KEY);
        --------------------修改子表IS_RPT结束--------------------
      END IF;
    END;
  ELSE
/*   V_NUM := 0;
      BEGIN
        SELECT count(*)
          INTO V_NUM
          FROM ODS_MBT_410_HIS
         WHERE DATA_LOAD_DATE = CURRENTDATE AND RSV5 IN (SELECT DISTINCT RSV5 FROM ODS_MBT_410);
      EXCEPTION
        WHEN OTHERS THEN
          V_NUM := '';
      END;
      if V_NUM > 0 then

        delete from MBT_410_E WHERE PDATA_ID IN (SELECT DATA_ID FROM MBT_410
         WHERE RSV5 IN (SELECT DISTINCT RSV5 FROM ODS_MBT_410));
        INSERT INTO MBT_410_E
          SELECT * FROM MBT_410_E_TODAY_BAK WHERE PDATA_ID IN (SELECT DATA_ID FROM  MBT_410_TODAY_BAK  WHERE RSV5 IN (SELECT DISTINCT RSV5 FROM ODS_MBT_410));

        delete from MBT_410_D WHERE PDATA_ID IN (SELECT DATA_ID FROM MBT_410
         WHERE RSV5 IN (SELECT DISTINCT RSV5 FROM ODS_MBT_410));
        INSERT INTO MBT_410_D
          SELECT * FROM MBT_410_D_TODAY_BAK WHERE PDATA_ID IN (SELECT DATA_ID FROM  MBT_410_TODAY_BAK  WHERE RSV5 IN (SELECT DISTINCT RSV5 FROM ODS_MBT_410));

        delete from MBT_410_I WHERE PDATA_ID IN (SELECT DATA_ID FROM MBT_410
         WHERE RSV5 IN (SELECT DISTINCT RSV5 FROM ODS_MBT_410));
        INSERT INTO MBT_410_I
          SELECT * FROM MBT_410_I_TODAY_BAK WHERE PDATA_ID IN (SELECT DATA_ID FROM  MBT_410_TODAY_BAK  WHERE RSV5 IN (SELECT DISTINCT RSV5 FROM ODS_MBT_410));

            delete from MBT_410 WHERE RSV5 IN (SELECT DISTINCT RSV5 FROM ODS_MBT_410);
        INSERT INTO MBT_410
          SELECT * FROM MBT_410_TODAY_BAK  WHERE RSV5 IN (SELECT DISTINCT RSV5 FROM ODS_MBT_410);

        --20200612 增加删除当天ODS HIS表记录？？？
        DELETE FROM ODS_MBT_410_HIS WHERE DATA_LOAD_DATE = CURRENTDATE   AND RSV5 IN (SELECT DISTINCT RSV5 FROM ODS_MBT_410);
        DELETE FROM ODS_MBT_410_D_HIS WHERE DATA_LOAD_DATE = CURRENTDATE AND PDATA_ID IN (SELECT DATA_ID FROM ODS_MBT_410_HIS WHERE DATA_LOAD_DATE = CURRENTDATE   AND RSV5 IN (SELECT DISTINCT RSV5 FROM ODS_MBT_410 );
        DELETE FROM ODS_MBT_410_E_HIS WHERE DATA_LOAD_DATE = CURRENTDATE AND PDATA_ID IN (SELECT DATA_ID FROM ODS_MBT_410_HIS WHERE DATA_LOAD_DATE = CURRENTDATE   AND RSV5 IN (SELECT DISTINCT RSV5 FROM ODS_MBT_410 );
        DELETE FROM ODS_MBT_410_I_HIS WHERE DATA_LOAD_DATE = CURRENTDATE AND PDATA_ID IN (SELECT DATA_ID FROM ODS_MBT_410_HIS WHERE DATA_LOAD_DATE = CURRENTDATE   AND RSV5 IN (SELECT DISTINCT RSV5 FROM ODS_MBT_410 );

      end if;
*/
    BEGIN
      --------------------备份数据--------------------
      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_410_TODAY_BAK';
      INSERT INTO MBT_410_TODAY_BAK
        SELECT * FROM MBT_410;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_410_D_TODAY_BAK';
      INSERT INTO MBT_410_D_TODAY_BAK
        SELECT * FROM MBT_410_D;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_410_E_TODAY_BAK';
      INSERT INTO MBT_410_E_TODAY_BAK
        SELECT * FROM MBT_410_E;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_410_I_TODAY_BAK';
      INSERT INTO MBT_410_I_TODAY_BAK
        SELECT * FROM MBT_410_I;
      --------------------备份数据--------------------
      --------------------更新数据开始--------------------
      MERGE INTO MBT_410 T1
      USING (SELECT A.*,
                    CASE
                      WHEN INSTR(B.B_NAME || B.B_ID_TYPE || B.B_ID_NUM ||B.B_MNGMT_ORG_CODE||
                                 B.C_BUSI_LINES || B.C_BUSI_DTL_LINES ||
                                 B.C_OPEN_DATE || B.C_CY ||
                                 B.C_ACCT_CRED_LINE_AMT || B.C_LOAN_AMT ||
                                 B.C_FLAG || B.C_DUE_DATE || B.C_REPAY_MODE ||
                                 B.C_REPAY_FREQCY || B.C_APPLY_BUSI_DIST ||
                                 B.C_GUAR_MODE || B.C_OTH_REPY_GUAR_WAY ||
                                 B.C_LOAN_TIME_LIM_CAT || B.C_LOA_FRM ||
                                 B.C_ACT_INVEST || B.C_FUND_SOU ||
                                 B.C_ASSET_TRAND_FLAG || B.F_MCC ||
                                 B.G_INIT_CRED_NAME || B.G_INIT_CED_ORG_CODE ||
                                 B.G_ORIG_DBT_CATE || B.G_INIT_RPY_STS ||
                                 B.H_ACCT_STATUS || B.H_ACCT_BAL ||
                                 B.H_BAL_CHG_DATE || B.H_FIVE_CATE ||
                                 B.H_FIVE_CATE_ADJ_DATE || B.H_PYMT_PRD ||
                                 B.H_TOT_OVERD || B.H_OVERD_PRINC ||
                                 B.H_OVERD_DY || B.H_LAT_RPY_DATE ||
                                 B.H_LAT_RPY_AMT || B.H_LAT_RPY_PRINC_AMT ||
                                 B.H_RPMT_TYPE || B.H_LAT_AGRR_RPY_DATE ||
                                 B.H_LAT_AGRR_RPY_AMT ||
                                 B.H_NXT_AGRR_RPY_DATE || B.H_CLOSE_DATE || '1',
                                 A.B_NAME || A.B_ID_TYPE || A.B_ID_NUM ||A.B_MNGMT_ORG_CODE||
                                 A.C_BUSI_LINES || A.C_BUSI_DTL_LINES ||
                                 A.C_OPEN_DATE || A.C_CY ||
                                 A.C_ACCT_CRED_LINE_AMT || A.C_LOAN_AMT ||
                                 A.C_FLAG || A.C_DUE_DATE || A.C_REPAY_MODE ||
                                 A.C_REPAY_FREQCY || A.C_APPLY_BUSI_DIST ||
                                 A.C_GUAR_MODE || A.C_OTH_REPY_GUAR_WAY ||
                                 A.C_LOAN_TIME_LIM_CAT || A.C_LOA_FRM ||
                                 A.C_ACT_INVEST || A.C_FUND_SOU ||
                                 A.C_ASSET_TRAND_FLAG || A.F_MCC ||
                                 A.G_INIT_CRED_NAME || A.G_INIT_CED_ORG_CODE ||
                                 A.G_ORIG_DBT_CATE || A.G_INIT_RPY_STS ||
                                 A.H_ACCT_STATUS || A.H_ACCT_BAL ||
                                 A.H_BAL_CHG_DATE || A.H_FIVE_CATE ||
                                 A.H_FIVE_CATE_ADJ_DATE || A.H_PYMT_PRD ||
                                 A.H_TOT_OVERD || A.H_OVERD_PRINC ||
                                 A.H_OVERD_DY || A.H_LAT_RPY_DATE ||
                                 A.H_LAT_RPY_AMT || A.H_LAT_RPY_PRINC_AMT ||
                                 A.H_RPMT_TYPE || A.H_LAT_AGRR_RPY_DATE ||
                                 A.H_LAT_AGRR_RPY_AMT || A.H_NXT_AGRR_RPY_DATE ||
                                 A.H_CLOSE_DATE || '1') > 0 THEN
                       'N'
                      ELSE
                       'Y'
                    END AS UPDATE_FLAG
               FROM ODS_MBT_410 A
              INNER JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_ACCT_CODE ORDER BY DATA_LOAD_TIME DESC) RN,
                                        T.*
                                   FROM ODS_MBT_410_HIS T
                                  ORDER BY T.DATA_LOAD_TIME DESC)
                          WHERE RN = 1) B
                 ON A.B_ACCT_CODE = B.B_ACCT_CODE) T2
      ON (T1.B_ACCT_CODE = T2.B_ACCT_CODE AND T2.UPDATE_FLAG = 'Y')
      WHEN MATCHED THEN
        UPDATE
           SET T1.B_NAME               = T2.B_NAME,
               T1.B_ID_TYPE            = T2.B_ID_TYPE,
               T1.B_ID_NUM             = T2.B_ID_NUM,
               T1.C_BUSI_LINES         = T2.C_BUSI_LINES,
               T1.C_BUSI_DTL_LINES     = T2.C_BUSI_DTL_LINES,
               T1.C_OPEN_DATE          = T2.C_OPEN_DATE,
               T1.C_CY                 = T2.C_CY,
               T1.C_ACCT_CRED_LINE_AMT = T2.C_ACCT_CRED_LINE_AMT,
               T1.C_LOAN_AMT           = T2.C_LOAN_AMT,
               T1.C_FLAG               = T2.C_FLAG,
               T1.C_DUE_DATE           = T2.C_DUE_DATE,
               T1.C_REPAY_MODE         = T2.C_REPAY_MODE,
               T1.C_REPAY_FREQCY       = T2.C_REPAY_FREQCY,
               T1.C_APPLY_BUSI_DIST    = T2.C_APPLY_BUSI_DIST,
               T1.C_GUAR_MODE          = T2.C_GUAR_MODE,
               T1.C_OTH_REPY_GUAR_WAY  = T2.C_OTH_REPY_GUAR_WAY,
               T1.C_LOAN_TIME_LIM_CAT  = T2.C_LOAN_TIME_LIM_CAT,
               T1.C_LOA_FRM            = T2.C_LOA_FRM,
               T1.C_ACT_INVEST         = T2.C_ACT_INVEST,
               T1.C_FUND_SOU           = T2.C_FUND_SOU,
               T1.C_ASSET_TRAND_FLAG   = T2.C_ASSET_TRAND_FLAG,
               T1.F_MCC                = T2.F_MCC,
               T1.G_INIT_CRED_NAME     = T2.G_INIT_CRED_NAME,
               T1.G_INIT_CED_ORG_CODE  = T2.G_INIT_CED_ORG_CODE,
               T1.G_ORIG_DBT_CATE      = T2.G_ORIG_DBT_CATE,
               T1.G_INIT_RPY_STS       = T2.G_INIT_RPY_STS,
               T1.H_ACCT_STATUS        = T2.H_ACCT_STATUS,
               T1.H_ACCT_BAL           = T2.H_ACCT_BAL,
               T1.H_BAL_CHG_DATE       = T2.H_BAL_CHG_DATE,
               T1.H_FIVE_CATE          = T2.H_FIVE_CATE,
               T1.H_FIVE_CATE_ADJ_DATE = T2.H_FIVE_CATE_ADJ_DATE,
               T1.H_PYMT_PRD           = T2.H_PYMT_PRD,
               T1.H_TOT_OVERD          = T2.H_TOT_OVERD,
               T1.H_OVERD_PRINC        = T2.H_OVERD_PRINC,
               T1.H_OVERD_DY           = T2.H_OVERD_DY,
               T1.H_LAT_RPY_DATE       = T2.H_LAT_RPY_DATE,
               T1.H_LAT_RPY_AMT        = T2.H_LAT_RPY_AMT,
               T1.H_LAT_RPY_PRINC_AMT  = T2.H_LAT_RPY_PRINC_AMT,
               T1.H_RPMT_TYPE          = T2.H_RPMT_TYPE,
               T1.H_LAT_AGRR_RPY_DATE  = T2.H_LAT_AGRR_RPY_DATE,
               T1.H_LAT_AGRR_RPY_AMT   = T2.H_LAT_AGRR_RPY_AMT,
               T1.H_NXT_AGRR_RPY_DATE  = T2.H_NXT_AGRR_RPY_DATE,
               T1.H_CLOSE_DATE         = T2.H_CLOSE_DATE,
               T1.DATA_STATUS          = '00',
               T1.DATA_CHG_USER        = 'SYSTEM',
               T1.DATA_CHG_DATE        = CURRENTDATE,
               T1.DATA_CHG_TIME        = CURRENTTIME,
               T1.B_RPT_DATE           = V_DATE,
               T1.CHECK_FLAG       = 'N';
      --------------------更新数据结束--------------------
      --------------------新增数据开始--------------------
      MERGE INTO MBT_410 T1
      USING (SELECT A.*,
                    '10' AS B_RPT_DATE_CODE,
                    CASE
                      WHEN A.B_ACCT_TYPE IN ('D1', 'R1', 'R4') THEN
                       '11101|000'
                      WHEN A.B_ACCT_TYPE = 'C1' THEN
                      --20200520 修改
                       --'11011|000'
                       '11001|000'
                      WHEN A.B_ACCT_TYPE = 'D2' THEN
                       '11001|000'
                    END AS IS_RPT
               FROM ODS_MBT_410 A) T2
      ON (T1.B_ACCT_CODE = T2.B_ACCT_CODE)
      WHEN NOT MATCHED THEN
        INSERT
          (T1.DATA_ID,
           T1.DATA_DATE,
           T1.CORP_ID,
           T1.ORG_ID,
           T1.GROUP_ID,
           T1.INQ_ORG_ID,
           T1.INQ_GROUP_ID,
           T1.B_INF_REC_TYPE,
           T1.B_ACCT_TYPE,
           T1.B_ACCT_CODE,
           T1.B_RPT_DATE,
           T1.B_RPT_DATE_CODE,
           T1.B_NAME,
           T1.B_ID_TYPE,
           T1.B_ID_NUM,
           T1.B_MNGMT_ORG_CODE,
           T1.C_BUSI_LINES,
           T1.C_BUSI_DTL_LINES,
           T1.C_OPEN_DATE,
           T1.C_CY,
           T1.C_ACCT_CRED_LINE_AMT,
           T1.C_LOAN_AMT,
           T1.C_FLAG,
           T1.C_DUE_DATE,
           T1.C_REPAY_MODE,
           T1.C_REPAY_FREQCY,
           T1.C_APPLY_BUSI_DIST,
           T1.C_GUAR_MODE,
           T1.C_OTH_REPY_GUAR_WAY,
           T1.C_LOAN_TIME_LIM_CAT,
           T1.C_LOA_FRM,
           T1.C_ACT_INVEST,
           T1.C_FUND_SOU,
           T1.C_ASSET_TRAND_FLAG,
           T1.F_MCC,
           T1.G_INIT_CRED_NAME,
           T1.G_INIT_CED_ORG_CODE,
           T1.G_ORIG_DBT_CATE,
           T1.G_INIT_RPY_STS,
           T1.H_ACCT_STATUS,
           T1.H_ACCT_BAL,
           T1.H_BAL_CHG_DATE,
           T1.H_FIVE_CATE,
           T1.H_FIVE_CATE_ADJ_DATE,
           T1.H_PYMT_PRD,
           T1.H_TOT_OVERD,
           T1.H_OVERD_PRINC,
           T1.H_OVERD_DY,
           T1.H_LAT_RPY_DATE,
           T1.H_LAT_RPY_AMT,
           T1.H_LAT_RPY_PRINC_AMT,
           T1.H_RPMT_TYPE,
           T1.H_LAT_AGRR_RPY_DATE,
           T1.H_LAT_AGRR_RPY_AMT,
           T1.H_NXT_AGRR_RPY_DATE,
           T1.H_CLOSE_DATE,
           T1.DATA_STATUS,
           T1.DATA_SOURCE,
           T1.DATA_CRT_USER,
           T1.DATA_CRT_DATE,
           T1.DATA_CRT_TIME,
           T1.RSV1,
           T1.RSV2,
           T1.RSV3,
           T1.RSV4,
           T1.RSV5,
           T1.IS_RPT,
           T1.B_CUST_NO)
        VALUES
          (T2.DATA_ID,
           T2.DATA_DATE,
           T2.CORP_ID,
           T2.ORG_ID,
           T2.GROUP_ID,
           T2.ORG_ID,
           T2.ORG_ID,
           '410',
           T2.B_ACCT_TYPE,
           T2.B_ACCT_CODE,
           V_DATE,
           T2.B_RPT_DATE_CODE,
           T2.B_NAME,
           T2.B_ID_TYPE,
           T2.B_ID_NUM,
           T2.B_MNGMT_ORG_CODE,
           T2.C_BUSI_LINES,
           T2.C_BUSI_DTL_LINES,
           T2.C_OPEN_DATE,
           T2.C_CY,
           T2.C_ACCT_CRED_LINE_AMT,
           T2.C_LOAN_AMT,
           T2.C_FLAG,
           T2.C_DUE_DATE,
           T2.C_REPAY_MODE,
           T2.C_REPAY_FREQCY,
           T2.C_APPLY_BUSI_DIST,
           T2.C_GUAR_MODE,
           T2.C_OTH_REPY_GUAR_WAY,
           T2.C_LOAN_TIME_LIM_CAT,
           T2.C_LOA_FRM,
           T2.C_ACT_INVEST,
           T2.C_FUND_SOU,
           T2.C_ASSET_TRAND_FLAG,
           T2.F_MCC,
           T2.G_INIT_CRED_NAME,
           T2.G_INIT_CED_ORG_CODE,
           T2.G_ORIG_DBT_CATE,
           T2.G_INIT_RPY_STS,
           T2.H_ACCT_STATUS,
           T2.H_ACCT_BAL,
           T2.H_BAL_CHG_DATE,
           T2.H_FIVE_CATE,
           T2.H_FIVE_CATE_ADJ_DATE,
           T2.H_PYMT_PRD,
           T2.H_TOT_OVERD,
           T2.H_OVERD_PRINC,
           T2.H_OVERD_DY,
           T2.H_LAT_RPY_DATE,
           T2.H_LAT_RPY_AMT,
           T2.H_LAT_RPY_PRINC_AMT,
           T2.H_RPMT_TYPE,
           T2.H_LAT_AGRR_RPY_DATE,
           T2.H_LAT_AGRR_RPY_AMT,
           T2.H_NXT_AGRR_RPY_DATE,
           T2.H_CLOSE_DATE,
           '00',
           '2',
           'SYSTEM',
           CURRENTDATE,
           CURRENTTIME,
           T2.RSV1,
           T2.RSV2,
           T2.RSV3,
           T2.RSV4,
           T2.RSV5,
           T2.IS_RPT,
           T2.CUST_NO);
      --------------------新增结束--------------------
      --------------------修改子表[MBT_410_D]数据开始--------------------
      -- 先删除所有相关数据 然后重新插入
      DELETE FROM MBT_410_D
       WHERE B_ACCT_CODE IN (SELECT DISTINCT B_ACCT_CODE FROM ODS_MBT_410);
      --------------------新增数据开始--------------------
      MERGE INTO MBT_410_D T1
      USING (SELECT A.DATA_ID,
                    A.DATA_DATE,
                    A.D_ARLP_ID_TYPE,
                    A.D_ARLP_NAME,
                    A.D_ARLP_CERT_TYPE,
                    A.D_ARLP_CERT_NUM,
                    A.D_ARLP_TYPE,
                    A.D_ARLP_AMT,
					A.D_ARLP_AMT_ORG,
                    A.D_WARTY_SIGN,
                    A.D_MAX_GUAR_MCC,
                    A.RSV1,
                    A.RSV2,
                    A.RSV3,
                    A.RSV4,
                    A.RSV5,
                    A.B_ACCT_CODE,
                    CASE
                      WHEN C.DATA_ID IS NULL THEN
                       A.PDATA_ID
                      ELSE
                       C.DATA_ID
                    END AS PDATA_ID
               FROM ODS_MBT_410_D A
               LEFT JOIN MBT_410 C
                 ON A.B_ACCT_CODE = C.B_ACCT_CODE) T2
      ON (T1.D_ARLP_ID_TYPE = T2.D_ARLP_ID_TYPE
      AND T1.D_ARLP_NAME = T2.D_ARLP_NAME
       AND T1.D_ARLP_CERT_TYPE = T2.D_ARLP_CERT_TYPE
       AND T1.D_ARLP_CERT_NUM = T2.D_ARLP_CERT_NUM
       AND T1.B_ACCT_CODE = T2.B_ACCT_CODE
       AND T1.D_ARLP_TYPE =  T2.D_ARLP_TYPE
       AND T1.D_WARTY_SIGN =T2.D_WARTY_SIGN
       AND T1.D_MAX_GUAR_MCC = T2.D_MAX_GUAR_MCC)
      WHEN NOT MATCHED THEN
        INSERT
          (T1.DATA_ID,
           T1.DATA_DATE,
           T1.PDATA_ID,
           T1.B_ACCT_CODE,
           T1.D_ARLP_ID_TYPE,
           T1.D_ARLP_NAME,
           T1.D_ARLP_CERT_TYPE,
           T1.D_ARLP_CERT_NUM,
           T1.D_ARLP_TYPE,
           T1.D_ARLP_AMT,
		   T1.D_ARLP_AMT_ORG,
           T1.D_WARTY_SIGN,
           T1.D_MAX_GUAR_MCC,
           T1.DATA_SOURE,
           T1.DATA_CRT_USER,
           T1.DATA_CRT_DATE,
           T1.DATA_CRT_TIME,
           T1.RSV1,
           T1.RSV2,
           T1.RSV3,
           T1.RSV4,
           T1.RSV5)
        VALUES
          (T2.DATA_ID,
           T2.DATA_DATE,
           T2.PDATA_ID,
           T2.B_ACCT_CODE,
           T2.D_ARLP_ID_TYPE,
           T2.D_ARLP_NAME,
           T2.D_ARLP_CERT_TYPE,
           T2.D_ARLP_CERT_NUM,
           T2.D_ARLP_TYPE,
           T2.D_ARLP_AMT,
		   T2.D_ARLP_AMT_ORG,
           T2.D_WARTY_SIGN,
           T2.D_MAX_GUAR_MCC,
           '2',
           'SYSTEM',
           CURRENTDATE,
           CURRENTTIME,
           T2.RSV1,
           T2.RSV2,
           T2.RSV3,
           T2.RSV4,
           'FLAG');

      --更改主表数据状态
      MERGE INTO MBT_410 T1
      USING (SELECT DISTINCT B.DATA_ID
               FROM MBT_410_D A
               LEFT JOIN MBT_410 B
                 ON A.PDATA_ID = B.DATA_ID
              WHERE A.RSV5 = 'FLAG') T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.DATA_STATUS = '00';

      UPDATE MBT_410_D SET RSV5 = NULL WHERE RSV5 = 'FLAG';
      --------------------修改子表[MBT_410_D]数据开始--------------------

      --------------------修改子表[MBT_410_E]数据开始--------------------
      -- 先删除所有相关数据 然后重新插入
      DELETE FROM MBT_410_E
       WHERE B_ACCT_CODE IN (SELECT DISTINCT B_ACCT_CODE FROM ODS_MBT_410);
      --------------------新增数据开始--------------------
      MERGE INTO MBT_410_E T1
      USING (SELECT A.DATA_ID,
                    A.DATA_DATE,
                    A.E_CCC,
                    A.RSV1,
                    A.RSV2,
                    A.RSV3,
                    A.RSV4,
                    A.RSV5,
                    A.B_ACCT_CODE,
                    CASE
                      WHEN B.DATA_ID IS NULL THEN
                       A.PDATA_ID
                      ELSE
                       B.DATA_ID
                    END AS PDATA_ID
               FROM ODS_MBT_410_E A
               LEFT JOIN MBT_410 B
                 ON A.B_ACCT_CODE = B.B_ACCT_CODE) T2
      ON (T1.E_CCC = T2.E_CCC  AND T1.B_ACCT_CODE = T2.B_ACCT_CODE )
      WHEN NOT MATCHED THEN
        INSERT
          (T1.DATA_ID,
           T1.DATA_DATE,
           T1.PDATA_ID,
           T1.E_CCC,
           T1.DATA_SOURE,
           T1.DATA_CRT_USER,
           T1.DATA_CRT_DATE,
           T1.DATA_CRT_TIME,
           T1.RSV1,
           T1.RSV2,
           T1.RSV3,
           T1.RSV4,
           T1.RSV5,
           T1.B_ACCT_CODE)
        VALUES
          (T2.DATA_ID,
           T2.DATA_DATE,
           T2.PDATA_ID,
           T2.E_CCC,
           '2',
           'SYSTEM',
           CURRENTDATE,
           CURRENTTIME,
           T2.RSV1,
           T2.RSV2,
           T2.RSV3,
           T2.RSV4,
           'FLAG',
           T2.B_ACCT_CODE);

      --更改主表数据状态
      MERGE INTO MBT_410 T1
      USING (SELECT DISTINCT B.DATA_ID
               FROM MBT_410_E A
               LEFT JOIN MBT_410 B
                 ON A.PDATA_ID = B.DATA_ID
              WHERE A.RSV5 = 'FLAG') T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.DATA_STATUS = '00';

      UPDATE MBT_410_E SET RSV5 = NULL WHERE RSV5 = 'FLAG';
      --------------------修改子表[MBT_410_E]数据开始--------------------

      --------------------修改子表[MBT_410_I]数据开始--------------------
      -- 先删除所有相关数据 然后重新插入
      DELETE FROM MBT_410_I
       WHERE B_ACCT_CODE IN (SELECT DISTINCT B_ACCT_CODE FROM ODS_MBT_410);
      --------------------新增数据开始--------------------
      MERGE INTO MBT_410_I T1
      USING (SELECT A.DATA_ID,
                    A.DATA_DATE,
                    A.REF_NO,
                    A.I_CHAN_TRAN_TYPE,
                    A.I_TRAN_DATE,
                    A.I_TRAN_AMT,
					A.I_TRAN_AMT_ORG,
                    A.I_DUE_TRAN_MON,
                    A.I_DET_INFO,
                    A.RSV1,
                    A.RSV2,
                    A.RSV3,
                    A.RSV4,
                    A.RSV5,
                    A.B_ACCT_CODE,
                    CASE
                      WHEN C.DATA_ID IS NULL THEN
                       A.PDATA_ID
                      ELSE
                       C.DATA_ID
                    END AS PDATA_ID
               FROM ODS_MBT_410_I A
               LEFT JOIN MBT_410 C
                 ON A.B_ACCT_CODE = C.B_ACCT_CODE) T2
      ON (T1.I_CHAN_TRAN_TYPE = T2.I_CHAN_TRAN_TYPE AND T1.I_TRAN_DATE = T2.I_TRAN_DATE AND T1.B_ACCT_CODE = T2.B_ACCT_CODE)
      WHEN NOT MATCHED THEN
        INSERT	
          (T1.DATA_ID,
           T1.DATA_DATE,
           T1.PDATA_ID,
           T1.B_ACCT_CODE,
           T1.REF_NO,
           T1.I_CHAN_TRAN_TYPE,
           T1.I_TRAN_DATE,
           T1.I_TRAN_AMT,
		   T1.I_TRAN_AMT_ORG,
           T1.I_DUE_TRAN_MON,
           T1.I_DET_INFO,
           T1.DATA_SOURE,
           T1.DATA_CRT_USER,
           T1.DATA_CRT_DATE,
           T1.DATA_CRT_TIME,
           T1.RSV1,
           T1.RSV2,
           T1.RSV3,
           T1.RSV4,
           T1.RSV5)
        VALUES
          (T2.DATA_ID,
           T2.DATA_DATE,
           T2.PDATA_ID,
           T2.B_ACCT_CODE,
           T2.REF_NO,
           T2.I_CHAN_TRAN_TYPE,
           T2.I_TRAN_DATE,
           T2.I_TRAN_AMT,
		   T2.I_TRAN_AMT_ORG,
           T2.I_DUE_TRAN_MON,
           T2.I_DET_INFO,
           '2',
           'SYSTEM',
           CURRENTDATE,
           CURRENTTIME,
           T2.RSV1,
           T2.RSV2,
           T2.RSV3,
           T2.RSV4,
           'FLAG');

      --更改主表数据状态
      MERGE INTO MBT_410 T1
      USING (SELECT DISTINCT B.DATA_ID
               FROM MBT_410_I A
               LEFT JOIN MBT_410 B
                 ON A.PDATA_ID = B.DATA_ID
              WHERE A.RSV5 = 'FLAG') T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.DATA_STATUS = '00';

      UPDATE MBT_410_I SET RSV5 = NULL WHERE RSV5 = 'FLAG';
      --------------------修改子表[MBT_410_I]数据开始--------------------
      --------------------更新报告时点开始--------------------
      MERGE INTO MBT_410 T1
      USING (SELECT DISTINCT A.*,
                             CASE
                               WHEN C.DATA_ID IS NULL  and (A.H_ACCT_STATUS <> '21' OR A.H_ACCT_STATUS IS NULL)   THEN
                                '10'
                               WHEN  A.H_ACCT_STATUS = '21' THEN
                                CASE
                                  WHEN F.DATA_ID IS  NULL OR  C.B_RPT_DATE_CODE = '20' THEN
                                   '99'
                                  ELSE
                                   '20'
                                END
                               WHEN F.DATA_ID IS NOT NULL AND A.B_ACCT_TYPE = 'D1' AND A.C_FLAG = '2' AND
                                    A.C_LOAN_AMT > C.C_LOAN_AMT THEN
                                '31'
                               WHEN F.DATA_ID IS NOT NULL AND A.B_ACCT_TYPE IN ('D1', 'R4', 'D2') AND
                                    NVL(A.H_LAT_RPY_DATE, 'NULL') =
                                    NVL(A.H_LAT_AGRR_RPY_DATE, 'NULL') AND
                                    A.H_LAT_RPY_AMT <> 0 AND
                                    NVL(A.H_LAT_RPY_DATE, 'NULL') <>
                                    NVL(C.H_LAT_RPY_DATE, 'NULL') THEN
                                '32'
                               WHEN F.DATA_ID IS NOT NULL AND A.B_ACCT_TYPE IN ('D1', 'R4', 'D2', 'C1') AND
                                    NVL(A.H_LAT_RPY_DATE, 'NULL') <>
                                    NVL(A.H_LAT_AGRR_RPY_DATE, 'NULL') AND
                                    A.H_LAT_RPY_AMT <> 0 AND
                                    NVL(A.H_LAT_RPY_DATE, 'NULL') <>
                                    NVL(C.H_LAT_RPY_DATE, 'NULL') THEN
                                '33'
                               WHEN F.DATA_ID IS NOT NULL AND A.H_FIVE_CATE <> C.H_FIVE_CATE THEN
                                '41'
                                WHEN F.DATA_ID IS NOT NULL AND A.B_ACCT_TYPE IN ('D1', 'R4') AND
                                  B.B_ACCT_CODE IS NOT NULL AND
                                  NVL(B.I_CHAN_TRAN_TYPE, 'NULL') <> NVL(E.I_CHAN_TRAN_TYPE, 'NULL') AND
                                  NVL(B.I_TRAN_DATE, 'NULL') <> NVL(E.I_TRAN_DATE, 'NULL') THEN
                                '42'
                               WHEN D.DATA_ID IS NULL AND F.DATA_ID IS NOT NULL  THEN
                                CASE
                                  WHEN (A.B_ACCT_TYPE IN ('D1', 'R4') AND
                                       A.H_TOT_OVERD > 0) OR
                                       (A.B_ACCT_TYPE IN ('D1', 'D2', 'R4') AND
                                       A.C_GUAR_MODE <> C.C_GUAR_MODE) OR
                                       (A.B_ACCT_TYPE IN
                                       ('D1', 'D2', 'R4', 'C1') AND
                                       A.H_ACCT_STATUS IN ('31', '32'))
                                       OR A.B_ACCT_TYPE ='R1' or
                                (A.B_ACCT_TYPE IN ('D1', 'D2', 'R4', 'R1') AND NVL(A.C_DUE_DATE,NULL) <>NVL(F.C_DUE_DATE,NULL) )
                                 or
                                (A.B_ACCT_TYPE IN ('D1', 'D2', 'R4', 'R1') AND NVL(A.C_OTH_REPY_GUAR_WAY,NULL) <>NVL(F.C_OTH_REPY_GUAR_WAY,NULL) )
                                 or
                                (A.B_ACCT_TYPE IN ('D1',  'R4') AND NVL(A.C_LOAN_TIME_LIM_CAT,NULL) <>NVL(F.C_LOAN_TIME_LIM_CAT,NULL) )
                                 or
                                (A.B_ACCT_TYPE IN ('D1', 'D2', 'R4', 'C1') AND NVL(A.C_LOAN_AMT,NULL) <>NVL(F.C_LOAN_AMT,NULL) )
                                or
                                (A.B_ACCT_TYPE IN ('D1', 'R1', 'R4') AND NVL(A.F_MCC,NULL) <>NVL(F.F_MCC,NULL) )
                                or
                                (  NVL(A.B_NAME,NULL) <>NVL(F.B_NAME,NULL) )
                                 or
                                (NVL(A.B_ID_TYPE,NULL) <>NVL(F.B_ID_TYPE,NULL) )
                                or
                                ( NVL(A.B_ID_NUM,NULL) <>NVL(F.B_ID_NUM,NULL) )
                                or
                                ( NVL(A.B_MNGMT_ORG_CODE,NULL) <>NVL(F.B_MNGMT_ORG_CODE,NULL) )
                                or
                                (A.B_ACCT_TYPE IN ('D1', 'D2', 'R4', 'R1') AND NVL(A.C_APPLY_BUSI_DIST,NULL) <>NVL(F.C_APPLY_BUSI_DIST,NULL) )

                                THEN
                            '49'

                                END
                               ELSE
                                '99'
                             END AS NEW_B_RPT_DATE_CODE
               FROM MBT_410 A
               LEFT JOIN MBT_410_I B
                 ON A.B_ACCT_CODE = B.B_ACCT_CODE
                AND B.I_CHAN_TRAN_TYPE = '11'
               LEFT JOIN (SELECT *
                           FROM MBT_410_HIS
                          WHERE DATA_ID IN (SELECT ODS_DATA_ID
                                              FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_ACCT_CODE ORDER BY RPT_TIME DESC) RN,
                                                           T.ODS_DATA_ID
                                                      FROM MBT_410_RPT T
                                                     WHERE DATA_STATUS = '27')
                                             WHERE RN = 1)) C
                 ON A.B_ACCT_CODE = C.B_ACCT_CODE
               LEFT JOIN MBT_410_RPT D
                 ON A.B_ACCT_CODE = D.B_ACCT_CODE
                AND SUBSTR(D.RPT_DATE, 1, 6) = SUBSTR(CURRENTDATE, 1, 6)
                AND D.DATA_STATUS = '27'
               LEFT JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_ACCT_CODE ORDER BY T.RPT_TIME DESC) RN,
                                        T.*
                                   FROM MBT_410_I_RPT T
                                  INNER JOIN MBT_410_RPT TMP
                                     ON T.PDATA_ID = TMP.DATA_ID
                                    AND TMP.DATA_STATUS = '27')
                          WHERE RN = 1) E
                 ON B.B_ACCT_CODE = E.B_ACCT_CODE
                  LEFT JOIN (SELECT *
                     FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_ACCT_CODE ORDER BY RPT_TIME DESC) RN,
                                  T.*
                             FROM MBT_410_RPT T
                            WHERE DATA_STATUS = '27')
                    WHERE RN = 1) F
          ON A.B_ACCT_CODE = F.B_ACCT_CODE) T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.B_RPT_DATE_CODE = T2.NEW_B_RPT_DATE_CODE;

         --更新时点（子表有改动）
  MERGE INTO MBT_410 A
      USING (SELECT DISTINCT T3.DATA_ID,
                             CASE
                               WHEN T4.DATA_ID IS NOT NULL THEN
                                '49'
                               ELSE
                                '99'
                             END AS NEW_B_RPT_DATE_CODE
               FROM (SELECT DISTINCT D_ARLP_ID_TYPE,D_ARLP_NAME,D_ARLP_CERT_TYPE,D_ARLP_CERT_NUM,B_ACCT_CODE,D_ARLP_TYPE,D_WARTY_SIGN,D_MAX_GUAR_MCC
                       FROM (SELECT D_ARLP_ID_TYPE,D_ARLP_NAME,D_ARLP_CERT_TYPE,D_ARLP_CERT_NUM,B_ACCT_CODE,D_ARLP_TYPE,D_WARTY_SIGN,D_MAX_GUAR_MCC
                               FROM MBT_410_D
                             MINUS
                             SELECT D_ARLP_ID_TYPE,D_ARLP_NAME,D_ARLP_CERT_TYPE,D_ARLP_CERT_NUM,B_ACCT_CODE,D_ARLP_TYPE,D_WARTY_SIGN,D_MAX_GUAR_MCC
                               FROM MBT_410_D_RPT
                              WHERE PDATA_ID IN (SELECT DATA_ID
                                                   FROM (SELECT ROW_NUMBER() OVER(PARTITION BY b_acct_code ORDER BY RPT_TIME DESC) RN,
                                                                T.*
                                                           FROM MBT_410_RPT T
                                                          WHERE DATA_STATUS = '27')
                                                  WHERE RN = 1)
                             UNION ALL
                             SELECT D_ARLP_ID_TYPE,D_ARLP_NAME,D_ARLP_CERT_TYPE,D_ARLP_CERT_NUM,B_ACCT_CODE,D_ARLP_TYPE,D_WARTY_SIGN,D_MAX_GUAR_MCC
                               FROM MBT_410_D_RPT
                              WHERE PDATA_ID IN (SELECT DATA_ID
                                                   FROM (SELECT ROW_NUMBER() OVER(PARTITION BY b_acct_code ORDER BY RPT_TIME DESC) RN,
                                                                T.*
                                                           FROM MBT_410_RPT T
                                                          WHERE DATA_STATUS = '27')
                                                  WHERE RN = 1)
                             MINUS
                             SELECT D_ARLP_ID_TYPE,D_ARLP_NAME,D_ARLP_CERT_TYPE,D_ARLP_CERT_NUM,B_ACCT_CODE,D_ARLP_TYPE,D_WARTY_SIGN,D_MAX_GUAR_MCC
                               FROM MBT_410_D

                             )) T1
               LEFT JOIN MBT_410_D T2
                 ON T1.b_acct_code = T2.b_acct_code
                LEFT JOIN MBT_410 T3
                 ON T2.PDATA_ID = T3.DATA_ID
               LEFT JOIN MBT_410_RPT T4
                 ON T1.b_acct_code = T2.b_acct_code
                AND T4.DATA_STATUS = '27'  where t3.b_rpt_date_code='99' and t3.H_ACCT_STATUS <> '21' and t3.H_ACCT_STATUS <> '22') B
      ON (A.DATA_ID = B.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET A.B_RPT_DATE_CODE = B.NEW_B_RPT_DATE_CODE;

                MERGE INTO MBT_410 A
      USING (SELECT DISTINCT T3.DATA_ID,
                             CASE
                               WHEN T4.DATA_ID IS NOT NULL THEN
                                '49'
                               ELSE
                                '99'
                             END AS NEW_B_RPT_DATE_CODE
               FROM (SELECT DISTINCT E_CCC,b_acct_code
                       FROM (SELECT E_CCC,b_acct_code
                               FROM MBT_410_e
                             MINUS
                             SELECT E_CCC,b_acct_code
                               FROM MBT_410_E_RPT
                              WHERE PDATA_ID IN (SELECT DATA_ID
                                                   FROM (SELECT ROW_NUMBER() OVER(PARTITION BY b_acct_code ORDER BY RPT_TIME DESC) RN,
                                                                T.*
                                                           FROM MBT_410_RPT T
                                                          WHERE DATA_STATUS = '27')
                                                  WHERE RN = 1)
                             UNION ALL
                             SELECT E_CCC,b_acct_code
                               FROM MBT_410_E_RPT
                              WHERE PDATA_ID IN (SELECT DATA_ID
                                                   FROM (SELECT ROW_NUMBER() OVER(PARTITION BY  b_acct_code ORDER BY RPT_TIME DESC) RN,
                                                                T.*
                                                           FROM MBT_410_RPT T
                                                          WHERE DATA_STATUS = '27')
                                                  WHERE RN = 1)
                             MINUS
                             SELECT E_CCC,b_acct_code
                               FROM MBT_410_E

                             )) T1
               LEFT JOIN MBT_410_E T2
                 ON T1.b_acct_code = T2.b_acct_code
                LEFT JOIN MBT_410 T3
                 ON T2.PDATA_ID = T3.DATA_ID
               LEFT JOIN MBT_410_RPT T4
                 ON T1.b_acct_code = T2.b_acct_code
                AND T4.DATA_STATUS = '27'  where t3.b_rpt_date_code='99' and t3.H_ACCT_STATUS <> '21' and t3.H_ACCT_STATUS <> '22' ) B
      ON (A.DATA_ID = B.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET A.B_RPT_DATE_CODE = B.NEW_B_RPT_DATE_CODE;
      --------------------更新报告时点结束--------------------
      --------------------修改IS_RPT开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_410',
                              'T.B_ACCT_CODE',
                              'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              B_ARRAYLIST,
                              1,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND INSTR(T3.ACCT_TYPE,T1.B_ACCT_TYPE) > 0
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_410',
                              'T.B_ACCT_CODE',
                              'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              C_ARRAYLIST,
                              2,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND INSTR(T3.ACCT_TYPE,T1.B_ACCT_TYPE) > 0
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_410',
                              'T.B_ACCT_CODE',
                              'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              F_ARRAYLIST,
                              3,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND INSTR(T3.ACCT_TYPE,T1.B_ACCT_TYPE) > 0
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_410',
                              'T.B_ACCT_CODE',
                              'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              G_ARRAYLIST,
                              4,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND INSTR(T3.ACCT_TYPE,T1.B_ACCT_TYPE) > 0
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_410',
                              'T.B_ACCT_CODE',
                              'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              H_ARRAYLIST,
                              5,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND INSTR(T3.ACCT_TYPE,T1.B_ACCT_TYPE) > 0
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      --------------------修改IS_RPT结束--------------------
      --------------------修改子表IS_RPT开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_410_D',
                              'T.D_ARLP_ID_TYPE,T.D_ARLP_NAME,T.D_ARLP_CERT_TYPE,T.D_ARLP_CERT_NUM,T.B_ACCT_CODE,T.D_ARLP_TYPE,T.D_WARTY_SIGN,T.D_MAX_GUAR_MCC',
                              'T1.D_ARLP_ID_TYPE = T2.D_ARLP_ID_TYPE AND T1.D_ARLP_NAME = T2.D_ARLP_NAME AND T1.D_ARLP_CERT_TYPE = T2.D_ARLP_CERT_TYPE AND T1.D_ARLP_CERT_NUM = T2.D_ARLP_CERT_NUM AND T1.B_ACCT_CODE = T2.B_ACCT_CODE AND T1.D_ARLP_TYPE =  T2.D_ARLP_TYPE AND T1.D_WARTY_SIGN =T2.D_WARTY_SIGN  AND T1.D_MAX_GUAR_MCC = T2.D_MAX_GUAR_MCC',
                              D_ARRAYLIST,
                              7,
                              'MBT_410',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND INSTR(T4.ACCT_TYPE,T3.B_ACCT_TYPE) > 0
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_410_E',
                              'T.E_CCC,T.B_ACCT_CODE',
                              'T1.E_CCC = T2.E_CCC AND T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              E_ARRAYLIST,
                              8,
                              'MBT_410',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND INSTR(T4.ACCT_TYPE,T3.B_ACCT_TYPE) > 0
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_410_I',
                              'T.I_CHAN_TRAN_TYPE,T.I_TRAN_DATE,T.B_ACCT_CODE',
                              'T1.I_CHAN_TRAN_TYPE=T2.I_CHAN_TRAN_TYPE AND T1.I_TRAN_DATE=T2.I_TRAN_DATE AND T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              I_ARRAYLIST,
                              9,
                              'MBT_410',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND INSTR(T4.ACCT_TYPE,T3.B_ACCT_TYPE) > 0
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              NULL);
      --------------------修改子表IS_RPT结束--------------------
      --数据插入历史表，然后删除ODS表




       begin

        --数据插入历史表，然后删除ODS表
       INSERT INTO ODS_MBT_410_HIS
        SELECT * FROM ODS_MBT_410;
      DELETE FROM ODS_MBT_410;

      INSERT INTO ODS_MBT_410_D_HIS
        SELECT * FROM ODS_MBT_410_D;
      DELETE FROM ODS_MBT_410_D;

      INSERT INTO ODS_MBT_410_E_HIS
        SELECT * FROM ODS_MBT_410_E;
      DELETE FROM ODS_MBT_410_E;

      INSERT INTO ODS_MBT_410_I_HIS
        SELECT * FROM ODS_MBT_410_I;
      DELETE FROM ODS_MBT_410_I;

  --将报告时点代码是88或99的直接审核通过并将校验修改为校验通过
      UPDATE mbt_410
         SET DATA_STATUS = '21', CHECK_FLAG = 'Y'
       WHERE DATA_DATE <= CURRENTDATE
         AND (B_RPT_DATE_CODE = '88' OR B_RPT_DATE_CODE = '99')
         AND DATA_STATUS = '00';

        --20200611如果上报时点不是88 99，那么需要更新主表的信息报告日期
        UPDATE mbt_410
           SET B_RPT_DATE = V_DATE
         WHERE DATA_DATE <= CURRENTDATE
           AND (B_RPT_DATE_CODE != '88' AND B_RPT_DATE_CODE != '99');
        COMMIT;

            END;
      END;
  END IF;
  --------------------处理特殊情况开始--------------------
  --D1账户，时点为账户开立时，基本信息段中分次放款标志值为“1”、“2”，必须上报授信额度信息段；
  --基本信息段中分次放款标志值为“0”，不报送授信额度信息段


  MERGE INTO MBT_410 T1
  USING (SELECT DATA_ID,
                CASE
                  WHEN C_FLAG = '0' OR B_ACCT_TYPE='C1' THEN
                   '0'
                   ELSE '1'
                END AS FLAG
           FROM MBT_410
          WHERE B_RPT_DATE_CODE IN( '10','42') and B_ACCT_TYPE in ('D1','C1')) T2
  ON (T1.DATA_ID = T2.DATA_ID)
  WHEN MATCHED THEN
    UPDATE
       SET T1.IS_RPT = SUBSTR(T1.IS_RPT, 1, 2) || T2.FLAG ||
                       SUBSTR(T1.IS_RPT, 4);

  --D1账户，已报送过账户开立时点的记录，且报送记录中基本信息段中分次放款标志值为“2”的情况，后续的时点必须报送基本信息段
  MERGE INTO MBT_410 T1
  USING (SELECT DISTINCT A.DATA_ID
           FROM MBT_410 A
           LEFT JOIN MBT_410_RPT B
             ON A.B_ACCT_CODE = B.B_ACCT_CODE
          WHERE A.C_FLAG = '2'
            AND B.B_RPT_DATE_CODE = '10'
            AND B.DATA_STATUS = '27'
             and A.B_ACCT_TYPE='D1') T2
  ON (T1.DATA_ID = T2.DATA_ID)
  WHEN MATCHED THEN
    UPDATE
       SET T1.IS_RPT = SUBSTR(T1.IS_RPT, 1, 1) || '1' ||
                       SUBSTR(T1.IS_RPT, 3);
     MERGE INTO MBT_410 T1
  USING (SELECT DATA_ID
           FROM MBT_410
          WHERE B_RPT_DATE_CODE <>'99' AND F_MCC IS NULL AND SUBSTR(IS_RPT,3,1)='1' AND GROUP_ID LIKE'CDT(EL%') T2
  ON (T1.DATA_ID = T2.DATA_ID)
  WHEN MATCHED THEN
    UPDATE
       SET T1.IS_RPT = SUBSTR(T1.IS_RPT, 1, 2) || '0' ||
                       SUBSTR(T1.IS_RPT, 4);


  --月结日获取：当时点为其他报送日，取月底最后一天（若时点不是其他报送日，需要清除月结日的值）
  UPDATE MBT_410 SET MON_SETTLE_DATE = NULL WHERE B_RPT_DATE_CODE <> '49';

  UPDATE MBT_410
     SET MON_SETTLE_DATE = TO_CHAR(LAST_DAY(SYSDATE), 'YYYYMMDD')
   WHERE B_RPT_DATE_CODE = '49';

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
     DBMS_OUTPUT.PUT_LINE(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE());
    ERRCODE := SQLCODE;
    ERRMSG  := SUBSTR(SQLERRM, 1, 200);
    SP_MBT_LOG(1,
               'SP_ODS_MBT_410',
               'ERROR41001',
               '新增失败：' || ERRMSG,
               ERRCODE,
               ERRMSG);
    ROLLBACK;
    --------------------处理特殊情况结束--------------------
    ENDTIME := TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS');
    DSC     := '##=======MBT410存储过程==结束' || ENDTIME || '========##';
    DBMS_OUTPUT.PUT_LINE(DSC);
END;

