CREATE OR REPLACE PROCEDURE "SP_ODS_MBT_110"(ERRCODE           IN OUT VARCHAR,
                                             ERRMSG            IN OUT VARCHAR,
                                             TABLE_KEY         IN VARCHAR2,
                                             RPT_DATE_CODE_OUT IN OUT VARCHAR2) AS
  DSC         VARCHAR2(1000);
  BEGINTIME   VARCHAR2(20);
  ENDTIME     VARCHAR2(20);
  CURRENTDATE VARCHAR2(8);
  CURRENTTIME VARCHAR2(14);
  B_ARRAYLIST VARCHAR2(4000);
  C_ARRAYLIST VARCHAR2(20);
  D_ARRAYLIST VARCHAR2(4000);
  E_ARRAYLIST VARCHAR2(4000);
  F_ARRAYLIST VARCHAR2(4000);
  G_ARRAYLIST VARCHAR2(4000);
  H_ARRAYLIST VARCHAR2(4000);
  I_ARRAYLIST VARCHAR2(4000);
  J_ARRAYLIST VARCHAR2(4000);
  IS_RPT_OUT  VARCHAR2(64);
  --add by wuxy
  V_DATE VARCHAR2(8);
  --add end
BEGIN

  B_ARRAYLIST := 'B_NAME,B_CUSTOMER_TYPE';
  C_ARRAYLIST := 'ALIAS';
  D_ARRAYLIST := 'D_SEX,D_DOB,D_NATION,D_HOUSE_ADD,D_HH_DIST,D_CELL_PHONE,D_EMAIL';
  E_ARRAYLIST := 'E_MARI_STATUS,E_SPO_NAME, E_SPO_ID_TYPE,E_SPO_ID_NUM,E_SPO_TEL,E_SPS_CMPY_NM';
  F_ARRAYLIST := 'F_EDU_LEVEL, F_ACA_DEGREE';
  G_ARRAYLIST := 'G_EMP_STATUS,G_CPN_NAME,G_CPN_TYPE,G_INDUSTRY,G_CPN_ADDR,G_CPN_PC,G_CPN_DIST,G_CPN_TEL,G_OCCUPATION,G_TITLE,G_TECH_TITLE,G_WORK_START_DATE';
  H_ARRAYLIST := 'H_RESI_STATUS,H_RESI_ADDR,H_RESI_PC,H_RESI_DIST,H_HOME_TEL';
  I_ARRAYLIST := 'I_MAIL_ADDR,I_MAIL_DIST';
  J_ARRAYLIST := 'J_ANNL_INC_LCY,J_TAX_INCOME_LCY';
  CURRENTDATE := TO_CHAR(SYSDATE, 'YYYYMMDD');
  CURRENTTIME := TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS');
  BEGINTIME   := TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS');
  --add by wuxy
  V_DATE := GET_NEW_DAY(CURRENTDATE);
  --add end
  DSC := '##=======MBT110存储过程==开始' || BEGINTIME || '========##';
  DBMS_OUTPUT.PUT_LINE(DSC);

  IF TABLE_KEY IS NOT NULL THEN
    --处理从页面来的数据 计算时点
    BEGIN
      --计算报告时点
      --1、查看主表是否更新过
      SELECT CASE
               WHEN T2.DATA_ID IS NULL THEN
                '10'
               WHEN INSTR(T2.B_INF_REC_TYPE || T2.B_NAME || T2.B_ID_TYPE || T2.B_ID_NUM ||
                          T2.B_INF_SURC_CODE || T2.B_RPT_DATE || T2.B_CIMOC ||
                          T2.B_CUSTOMER_TYPE || T2.C_ID_INFO_UP_DATE || T2.D_SEX ||
                          T2.D_DOB || T2.D_NATION || T2.D_HOUSE_ADD || T2.D_HH_DIST ||
                          T2.D_CELL_PHONE || T2.D_EMAIL || T2.D_FCS_INFO_UP_DATE ||
                          T2.E_MARI_STATUS || T2.E_SPO_NAME || T2.E_SPO_ID_TYPE ||
                          T2.E_SPO_ID_NUM || T2.E_SPO_TEL || T2.E_SPS_CMPY_NM ||
                          T2.E_SPS_INFO_UP_DATE || T2.F_EDU_LEVEL || T2.F_ACA_DEGREE ||
                          T2.F_EDU_INFO_UP_DATE || T2.G_EMP_STATUS || T2.G_CPN_NAME ||
                          T2.G_CPN_TYPE || T2.G_INDUSTRY || T2.G_CPN_ADDR || T2.G_CPN_PC ||
                          T2.G_CPN_DIST || T2.G_CPN_TEL || T2.G_OCCUPATION || T2.G_TITLE ||
                          T2.G_TECH_TITLE || T2.G_WORK_START_DATE ||
                          T2.G_OCTPN_INFO_UP_DATE || T2.H_RESI_STATUS || T2.H_RESI_ADDR ||
                          T2.H_RESI_PC || T2.H_RESI_DIST || T2.H_HOME_TEL ||
                          T2.H_RESI_INFO_UP_DATE || T2.I_MAIL_ADDR || T2.I_MAIL_PC ||
                          T2.I_MAIL_DIST || T2.I_MLG_INFO_UP_DATE || T2.J_ANNL_INC ||
                          T2.J_TAX_INCOME || T2.J_INC_INFO_UP_DATE || '1', --避免删除最后一个段的时候  INSTR 还为1
                          T1.B_INF_REC_TYPE || T1.B_NAME || T1.B_ID_TYPE || T1.B_ID_NUM ||
                          T1.B_INF_SURC_CODE || T1.B_RPT_DATE || T1.B_CIMOC ||
                          T1.B_CUSTOMER_TYPE || T1.C_ID_INFO_UP_DATE || T1.D_SEX ||
                          T1.D_DOB || T1.D_NATION || T1.D_HOUSE_ADD || T1.D_HH_DIST ||
                          T1.D_CELL_PHONE || T1.D_EMAIL || T1.D_FCS_INFO_UP_DATE ||
                          T1.E_MARI_STATUS || T1.E_SPO_NAME || T1.E_SPO_ID_TYPE ||
                          T1.E_SPO_ID_NUM || T1.E_SPO_TEL || T1.E_SPS_CMPY_NM ||
                          T1.E_SPS_INFO_UP_DATE || T1.F_EDU_LEVEL || T1.F_ACA_DEGREE ||
                          T1.F_EDU_INFO_UP_DATE || T1.G_EMP_STATUS || T1.G_CPN_NAME ||
                          T1.G_CPN_TYPE || T1.G_INDUSTRY || T1.G_CPN_ADDR || T1.G_CPN_PC ||
                          T1.G_CPN_DIST || T1.G_CPN_TEL || T1.G_OCCUPATION || T1.G_TITLE ||
                          T1.G_TECH_TITLE || T1.G_WORK_START_DATE ||
                          T1.G_OCTPN_INFO_UP_DATE || T1.H_RESI_STATUS || T1.H_RESI_ADDR ||
                          T1.H_RESI_PC || T1.H_RESI_DIST || T1.H_HOME_TEL ||
                          T1.H_RESI_INFO_UP_DATE || T1.I_MAIL_ADDR || T1.I_MAIL_PC ||
                          T1.I_MAIL_DIST || T1.I_MLG_INFO_UP_DATE || T1.J_ANNL_INC ||
                          T1.J_TAX_INCOME || T1.J_INC_INFO_UP_DATE || '1') > 0 THEN --避免删除最后一个段的时候  INSTR 还为1
                '99'
               ELSE
                '20'
             END
        INTO RPT_DATE_CODE_OUT
        FROM MBT_110 T1
        LEFT JOIN (SELECT *
                     FROM MBT_110_HIS
                    WHERE DATA_ID IN (SELECT ODS_DATA_ID
                                        FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_ID_TYPE, B_ID_NUM ORDER BY RPT_TIME DESC) RN,
                                                     T.*
                                                FROM MBT_110_RPT T
                                               WHERE DATA_STATUS = '27')
                                       WHERE RN = 1)) T2
          ON T2.B_ID_TYPE = T1.B_ID_TYPE
         AND T2.B_ID_NUM = T1.B_ID_NUM
       WHERE T1.DATA_ID = TABLE_KEY;

      --1、查看子表是否更新过
      SELECT DISTINCT CASE
                        WHEN T4.DATA_ID IS NOT NULL THEN
                         '20'
                        ELSE
                         '10'
                      END
        INTO RPT_DATE_CODE_OUT
        FROM (SELECT DISTINCT OTH_ID_TYPE, OTH_ID_NUM, ALIAS
                FROM (SELECT OTH_ID_TYPE, OTH_ID_NUM, ALIAS
                        FROM MBT_110_C
                      MINUS
                      SELECT OTH_ID_TYPE, OTH_ID_NUM, ALIAS
                        FROM MBT_110_C_RPT
                       WHERE PDATA_ID IN (SELECT DATA_ID
                                            FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_ID_TYPE, B_ID_NUM ORDER BY RPT_TIME DESC) RN,
                                                         T.*
                                                    FROM MBT_110_RPT T
                                                   WHERE DATA_STATUS = '27')
                                           WHERE RN = 1)
                      UNION ALL
                      SELECT OTH_ID_TYPE, OTH_ID_NUM, ALIAS
                        FROM MBT_110_C_RPT
                       WHERE PDATA_ID IN (SELECT DATA_ID
                                            FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_ID_TYPE, B_ID_NUM ORDER BY RPT_TIME DESC) RN,
                                                         T.*
                                                    FROM MBT_110_RPT T
                                                   WHERE DATA_STATUS = '27')
                                           WHERE RN = 1)
                      MINUS
                      SELECT OTH_ID_TYPE, OTH_ID_NUM, ALIAS FROM MBT_110_C)) T1
        LEFT JOIN MBT_110_C T2
          ON T1.OTH_ID_TYPE = T2.OTH_ID_TYPE
         AND T1.OTH_ID_NUM = T2.OTH_ID_NUM
        LEFT JOIN MBT_110 T3
          ON T2.PDATA_ID = T3.DATA_ID
        LEFT JOIN MBT_110_RPT T4
          ON T3.B_ID_TYPE = T4.B_ID_TYPE
         AND T3.B_ID_NUM = T4.B_ID_NUM
         AND T4.DATA_STATUS = '27'
       WHERE T3.DATA_ID = TABLE_KEY;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('子表没有发生变动');
    END;
    SELECT IS_RPT INTO IS_RPT_OUT FROM MBT_110 WHERE DATA_ID = TABLE_KEY;

    IF IS_RPT_OUT IS NULL THEN
      UPDATE MBT_110 SET IS_RPT = '11111110|0' WHERE DATA_ID = TABLE_KEY;
      --update by wuxy
    END IF;
    --update end
    SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                            'T.B_ID_TYPE,T.B_ID_NUM',
                            'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                            B_ARRAYLIST,
                            1,
                            null,
                            'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                            TABLE_KEY);

    SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                            'T.B_ID_TYPE,T.B_ID_NUM',
                            'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                            D_ARRAYLIST,
                            2,
                            null,
                            'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                            TABLE_KEY);

    SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                            'T.B_ID_TYPE,T.B_ID_NUM',
                            'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                            E_ARRAYLIST,
                            3,
                            null,
                            'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                            TABLE_KEY);

    SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                            'T.B_ID_TYPE,T.B_ID_NUM',
                            'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                            F_ARRAYLIST,
                            4,
                            null,
                            'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                            TABLE_KEY);

    SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                            'T.B_ID_TYPE,T.B_ID_NUM',
                            'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                            G_ARRAYLIST,
                            5,
                            null,
                            'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                            TABLE_KEY);

    SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                            'T.B_ID_TYPE,T.B_ID_NUM',
                            'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                            H_ARRAYLIST,
                            6,
                            null,
                            'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                            TABLE_KEY);

    SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                            'T.B_ID_TYPE,T.B_ID_NUM',
                            'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                            I_ARRAYLIST,
                            7,
                            null,
                            'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                            TABLE_KEY);

    SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                            'T.B_ID_TYPE,T.B_ID_NUM',
                            'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                            J_ARRAYLIST,
                            8,
                            null,
                            'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                            TABLE_KEY);

    SP_ODS_MBT_CAL_RPT_PROC('MBT_110_C',
                            'T.OTH_ID_TYPE,T.OTH_ID_NUM',
                            'T1.OTH_ID_TYPE=T2.OTH_ID_TYPE AND T1.OTH_ID_NUM=T2.OTH_ID_NUM',
                            C_ARRAYLIST,
                            10,
                            'MBT_110',
                            'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND T4.ACCT_TYPE IS NULL
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                            TABLE_KEY);

  ELSE
    --处理从ODS表来的数据
    BEGIN
      --------------------备份数据--------------------
      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_110_TODAY_BAK';
      INSERT INTO MBT_110_TODAY_BAK
        SELECT * FROM MBT_110;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_110_C_TODAY_BAK';
      INSERT INTO MBT_110_C_TODAY_BAK
        SELECT * FROM MBT_110_C;
      --------------------备份数据--------------------
      --------------------更新数据开始--------------------
      --修改B段
      MERGE INTO MBT_110 T1
      USING (SELECT A.*,
                    CASE
                      WHEN INSTR(B.B_NAME || B.B_CUSTOMER_TYPE || '1',
                                 A.B_NAME || A.B_CUSTOMER_TYPE || '1') > 0 THEN
                       'N'
                      ELSE
                       'Y'
                    END AS UPDATE_FLAG
               FROM ODS_MBT_110 A
              INNER JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_ID_TYPE, T.B_ID_NUM ORDER BY DATA_LOAD_TIME DESC) RN,
                                        T.*
                                   FROM ODS_MBT_110_HIS T
                                  ORDER BY T.DATA_LOAD_TIME DESC)
                          WHERE RN = 1) B
                 ON A.B_ID_TYPE = B.B_ID_TYPE
                AND A.B_ID_NUM = B.B_ID_NUM) T2
      ON (T1.B_ID_TYPE = T2.B_ID_TYPE AND T1.B_ID_NUM = T2.B_ID_NUM AND T2.UPDATE_FLAG = 'Y')
      WHEN MATCHED THEN
        UPDATE
           SET T1.B_NAME          = T2.B_NAME,
               T1.B_CUSTOMER_TYPE = T2.B_CUSTOMER_TYPE,
               T1.DATA_STATUS     = '00',
               T1.DATA_CHG_USER   = 'SYSTEM',
               T1.DATA_CHG_DATE   = CURRENTDATE,
               T1.DATA_CHG_TIME   = CURRENTTIME,
               T1.B_RPT_DATE      = V_DATE,
               T1.CHECK_FLAG      = 'N';

      --修改D段
      MERGE INTO MBT_110 T1
      USING (SELECT A.*,
                    CASE
                      WHEN INSTR(B.D_SEX || B.D_DOB || B.D_NATION ||
                                 B.D_HOUSE_ADD || B.D_HH_DIST ||
                                 B.D_CELL_PHONE || B.D_EMAIL || '1',
                                 A.D_SEX || A.D_DOB || A.D_NATION ||
                                 A.D_HOUSE_ADD || A.D_HH_DIST ||
                                 A.D_CELL_PHONE || A.D_EMAIL || '1') > 0 THEN
                       'N'
                      ELSE
                       'Y'
                    END AS UPDATE_FLAG
               FROM ODS_MBT_110 A
              INNER JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_ID_TYPE, T.B_ID_NUM ORDER BY DATA_LOAD_TIME DESC) RN,
                                        T.*
                                   FROM ODS_MBT_110_HIS T
                                  ORDER BY T.DATA_LOAD_TIME DESC)
                          WHERE RN = 1) B
                 ON A.B_ID_TYPE = B.B_ID_TYPE
                AND A.B_ID_NUM = B.B_ID_NUM) T2
      ON (T1.B_ID_TYPE = T2.B_ID_TYPE AND T1.B_ID_NUM = T2.B_ID_NUM AND T2.UPDATE_FLAG = 'Y')
      WHEN MATCHED THEN
        UPDATE
           SET T1.D_SEX         = T2.D_SEX,
               T1.D_DOB         = T2.D_DOB,
               T1.D_NATION      = T2.D_NATION,
               T1.D_HOUSE_ADD   = T2.D_HOUSE_ADD,
               T1.D_HH_DIST     = T2.D_HH_DIST,
               T1.D_CELL_PHONE  = T2.D_CELL_PHONE,
               T1.D_EMAIL       = T2.D_EMAIL,
               T1.DATA_STATUS   = '00',
               T1.DATA_CHG_USER = 'SYSTEM',
               T1.DATA_CHG_DATE = CURRENTDATE,
               T1.DATA_CHG_TIME = CURRENTTIME,
               --update by wuxy
               T1.B_RPT_DATE         = V_DATE,
               T1.D_FCS_INFO_UP_DATE = V_DATE,
               T1.CHECK_FLAG         = 'N';
      --update end
      --修改E段
      MERGE INTO MBT_110 T1
      USING (SELECT A.*,
                    CASE
                      WHEN INSTR(B.E_MARI_STATUS || B.E_SPO_NAME ||
                                 B.E_SPO_ID_TYPE || B.E_SPO_ID_NUM ||
                                 B.E_SPO_TEL || B.E_SPS_CMPY_NM ||
                                 B.F_EDU_LEVEL || '1',
                                 A.E_MARI_STATUS || A.E_SPO_NAME ||
                                 A.E_SPO_ID_TYPE || A.E_SPO_ID_NUM ||
                                 A.E_SPO_TEL || A.E_SPS_CMPY_NM ||
                                 A.F_EDU_LEVEL || '1') > 0 THEN
                       'N'
                      ELSE
                       'Y'
                    END AS UPDATE_FLAG
               FROM ODS_MBT_110 A
              INNER JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_ID_TYPE, T.B_ID_NUM ORDER BY DATA_LOAD_TIME DESC) RN,
                                        T.*
                                   FROM ODS_MBT_110_HIS T
                                  ORDER BY T.DATA_LOAD_TIME DESC)
                          WHERE RN = 1) B
                 ON A.B_ID_TYPE = B.B_ID_TYPE
                AND A.B_ID_NUM = B.B_ID_NUM) T2
      ON (T1.B_ID_TYPE = T2.B_ID_TYPE AND T1.B_ID_NUM = T2.B_ID_NUM AND T2.UPDATE_FLAG = 'Y')
      WHEN MATCHED THEN
        UPDATE
           SET T1.E_MARI_STATUS = T2.E_MARI_STATUS,
               T1.E_SPO_NAME    = T2.E_SPO_NAME,
               T1.E_SPO_ID_TYPE = T2.E_SPO_ID_TYPE,
               T1.E_SPO_ID_NUM  = T2.E_SPO_ID_NUM,
               T1.E_SPO_TEL     = T2.E_SPO_TEL,
               T1.E_SPS_CMPY_NM = T2.E_SPS_CMPY_NM,
               T1.DATA_STATUS   = '00',
               T1.DATA_CHG_USER = 'SYSTEM',
               T1.DATA_CHG_DATE = CURRENTDATE,
               T1.DATA_CHG_TIME = CURRENTTIME,
               --update by wuxy

               T1.B_RPT_DATE         = V_DATE,
               T1.E_SPS_INFO_UP_DATE = V_DATE,
               T1.CHECK_FLAG         = 'N';
      --update end

      --修改F段
      MERGE INTO MBT_110 T1
      USING (SELECT A.*,
                    CASE
                      WHEN INSTR(B.F_EDU_LEVEL || B.F_ACA_DEGREE || '1',
                                 A.F_EDU_LEVEL || A.F_ACA_DEGREE || '1') > 0 THEN
                       'N'
                      ELSE
                       'Y'
                    END AS UPDATE_FLAG
               FROM ODS_MBT_110 A
              INNER JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_ID_TYPE, T.B_ID_NUM ORDER BY DATA_LOAD_TIME DESC) RN,
                                        T.*
                                   FROM ODS_MBT_110_HIS T
                                  ORDER BY T.DATA_LOAD_TIME DESC)
                          WHERE RN = 1) B
                 ON A.B_ID_TYPE = B.B_ID_TYPE
                AND A.B_ID_NUM = B.B_ID_NUM) T2
      ON (T1.B_ID_TYPE = T2.B_ID_TYPE AND T1.B_ID_NUM = T2.B_ID_NUM AND T2.UPDATE_FLAG = 'Y')
      WHEN MATCHED THEN
        UPDATE
           SET T1.F_EDU_LEVEL   = T2.F_EDU_LEVEL,
               T1.F_ACA_DEGREE  = T2.F_ACA_DEGREE,
               T1.DATA_STATUS   = '00',
               T1.DATA_CHG_USER = 'SYSTEM',
               T1.DATA_CHG_DATE = CURRENTDATE,
               T1.DATA_CHG_TIME = CURRENTTIME,
               --update by wuxy
               T1.B_RPT_DATE         = V_DATE,
               T1.F_EDU_INFO_UP_DATE = V_DATE,
               T1.CHECK_FLAG         = 'N';
      --update end

      --修改G段
      MERGE INTO MBT_110 T1
      USING (SELECT A.*,
                    CASE
                      WHEN INSTR(B.G_EMP_STATUS || B.G_CPN_NAME ||
                                 B.G_CPN_TYPE || B.G_INDUSTRY || B.G_CPN_ADDR ||
                                 B.G_CPN_PC || B.G_CPN_DIST || B.G_CPN_TEL ||
                                 B.G_OCCUPATION || B.G_TITLE ||
                                 B.G_TECH_TITLE || B.G_WORK_START_DATE || '1',
                                 A.G_EMP_STATUS || A.G_CPN_NAME ||
                                 A.G_CPN_TYPE || A.G_INDUSTRY || A.G_CPN_ADDR ||
                                 A.G_CPN_PC || A.G_CPN_DIST || A.G_CPN_TEL ||
                                 A.G_OCCUPATION || A.G_TITLE || A.G_TECH_TITLE ||
                                 A.G_WORK_START_DATE || '1') > 0 THEN
                       'N'
                      ELSE
                       'Y'
                    END AS UPDATE_FLAG
               FROM ODS_MBT_110 A
              INNER JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_ID_TYPE, T.B_ID_NUM ORDER BY DATA_LOAD_TIME DESC) RN,
                                        T.*
                                   FROM ODS_MBT_110_HIS T
                                  ORDER BY T.DATA_LOAD_TIME DESC)
                          WHERE RN = 1) B
                 ON A.B_ID_TYPE = B.B_ID_TYPE
                AND A.B_ID_NUM = B.B_ID_NUM) T2
      ON (T1.B_ID_TYPE = T2.B_ID_TYPE AND T1.B_ID_NUM = T2.B_ID_NUM AND T2.UPDATE_FLAG = 'Y')
      WHEN MATCHED THEN
        UPDATE
           SET T1.G_EMP_STATUS      = T2.G_EMP_STATUS,
               T1.G_CPN_NAME        = T2.G_CPN_NAME,
               T1.G_CPN_TYPE        = T2.G_CPN_TYPE,
               T1.G_INDUSTRY        = T2.G_INDUSTRY,
               T1.G_CPN_ADDR        = T2.G_CPN_ADDR,
               T1.G_CPN_PC          = T2.G_CPN_PC,
               T1.G_CPN_DIST        = T2.G_CPN_DIST,
               T1.G_CPN_TEL         = T2.G_CPN_TEL,
               T1.G_OCCUPATION      = T2.G_OCCUPATION,
               T1.G_TITLE           = T2.G_TITLE,
               T1.G_TECH_TITLE      = T2.G_TECH_TITLE,
               T1.G_WORK_START_DATE = T2.G_WORK_START_DATE,
               T1.G_OCTPN_INFO_UP_DATE = V_DATE,
               T1.DATA_STATUS       = '00',
               T1.DATA_CHG_USER     = 'SYSTEM',
               T1.DATA_CHG_DATE     = CURRENTDATE,
               T1.DATA_CHG_TIME     = CURRENTTIME,
               --update by wuxy
               T1.B_RPT_DATE = V_DATE,
               T1.CHECK_FLAG = 'N';
      --update end
      --修改H段
      MERGE INTO MBT_110 T1
      USING (SELECT A.*,
                    CASE
                      WHEN INSTR(B.H_RESI_STATUS || B.H_RESI_ADDR ||
                                 B.H_RESI_PC || B.H_RESI_DIST || B.H_HOME_TEL || '1',
                                 A.H_RESI_STATUS || A.H_RESI_ADDR ||
                                 A.H_RESI_PC || A.H_RESI_DIST || A.H_HOME_TEL || '1') > 0 THEN
                       'N'
                      ELSE
                       'Y'
                    END AS UPDATE_FLAG
               FROM ODS_MBT_110 A
              INNER JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_ID_TYPE, T.B_ID_NUM ORDER BY DATA_LOAD_TIME DESC) RN,
                                        T.*
                                   FROM ODS_MBT_110_HIS T
                                  ORDER BY T.DATA_LOAD_TIME DESC)
                          WHERE RN = 1) B
                 ON A.B_ID_TYPE = B.B_ID_TYPE
                AND A.B_ID_NUM = B.B_ID_NUM) T2
      ON (T1.B_ID_TYPE = T2.B_ID_TYPE AND T1.B_ID_NUM = T2.B_ID_NUM AND T2.UPDATE_FLAG = 'Y')
      WHEN MATCHED THEN
        UPDATE
           SET T1.H_RESI_STATUS = T2.H_RESI_STATUS,
               T1.H_RESI_ADDR   = T2.H_RESI_ADDR,
               T1.H_RESI_PC     = T2.H_RESI_PC,
               T1.H_RESI_DIST   = T2.H_RESI_DIST,
               T1.H_HOME_TEL    = T2.H_HOME_TEL,
               T1.DATA_STATUS   = '00',
               T1.DATA_CHG_USER = 'SYSTEM',
               T1.DATA_CHG_DATE = CURRENTDATE,
               T1.DATA_CHG_TIME = CURRENTTIME,
               --update by wuxy
               T1.B_RPT_DATE          = V_DATE,
               T1.H_RESI_INFO_UP_DATE = V_DATE,
               T1.CHECK_FLAG          = 'N';
      --update end
      --修改I段
      MERGE INTO MBT_110 T1
      USING (SELECT A.*,
                    CASE
                      WHEN INSTR(B.I_MAIL_ADDR || B.I_MAIL_PC ||
                                 B.I_MAIL_DIST || '1',
                                 A.I_MAIL_ADDR || A.I_MAIL_PC || A.I_MAIL_DIST || '1') > 0 THEN
                       'N'
                      ELSE
                       'Y'
                    END AS UPDATE_FLAG
               FROM ODS_MBT_110 A
              left JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_ID_TYPE, T.B_ID_NUM ORDER BY DATA_LOAD_TIME DESC) RN,
                                        T.*
                                   FROM ODS_MBT_110_HIS T
                                  ORDER BY T.DATA_LOAD_TIME DESC)
                          WHERE RN = 1) B
                 ON A.B_ID_TYPE = B.B_ID_TYPE
                AND A.B_ID_NUM = B.B_ID_NUM) T2
      ON (T1.B_ID_TYPE = T2.B_ID_TYPE AND T1.B_ID_NUM = T2.B_ID_NUM AND T2.UPDATE_FLAG = 'Y')
      WHEN MATCHED THEN
        UPDATE
           SET T1.I_MAIL_ADDR   = T2.I_MAIL_ADDR,
               T1.I_MAIL_PC     = T2.I_MAIL_PC,
               T1.I_MAIL_DIST   = T2.I_MAIL_DIST,
               T1.DATA_STATUS   = '00',
               T1.DATA_CHG_USER = 'SYSTEM',
               T1.DATA_CHG_DATE = CURRENTDATE,
               T1.DATA_CHG_TIME = CURRENTTIME,
               --update by wuxy
               T1.B_RPT_DATE         = V_DATE,
               T1.I_MLG_INFO_UP_DATE = V_DATE,
               T1.CHECK_FLAG         = 'N';
      --update end
      --修改J段
      MERGE INTO MBT_110 T1
      USING (SELECT A.*,
                    CASE
                      WHEN INSTR(B.J_ANNL_INC || B.J_ANNL_INC_LCY
						|| B.J_TAX_INCOME || B.J_TAX_INCOME_LCY || '1',
                                 A.J_ANNL_INC || A.J_ANNL_INC_LCY
						|| A.J_TAX_INCOME || A.J_TAX_INCOME_LCY || '1') > 0 THEN
                       'N'
                      ELSE
                       'Y'
                    END AS UPDATE_FLAG
               FROM ODS_MBT_110 A
              INNER JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_ID_TYPE, T.B_ID_NUM ORDER BY DATA_LOAD_TIME DESC) RN,
                                        T.*
                                   FROM ODS_MBT_110_HIS T
                                  ORDER BY T.DATA_LOAD_TIME DESC)
                          WHERE RN = 1) B
                 ON A.B_ID_TYPE = B.B_ID_TYPE
                AND A.B_ID_NUM = B.B_ID_NUM) T2
      ON (T1.B_ID_TYPE = T2.B_ID_TYPE AND T1.B_ID_NUM = T2.B_ID_NUM AND T2.UPDATE_FLAG = 'Y')
      WHEN MATCHED THEN
        UPDATE
           SET T1.J_ANNL_INC    = T2.J_ANNL_INC,
               T1.J_TAX_INCOME  = T2.J_TAX_INCOME,
			   T1.J_ANNL_INC_LCY    = T2.J_ANNL_INC_LCY,
               T1.J_TAX_INCOME_LCY  = T2.J_TAX_INCOME_LCY,
               T1.DATA_STATUS   = '00',
               T1.DATA_CHG_USER = 'SYSTEM',
               T1.DATA_CHG_DATE = CURRENTDATE,
               T1.DATA_CHG_TIME = CURRENTTIME,
               --update by wuxy
               T1.B_RPT_DATE         = V_DATE,
               T1.J_INC_INFO_UP_DATE = V_DATE,
               T1.CHECK_FLAG         = 'N';
      --update end
      --------------------更新数据结束--------------------
      --------------------新增数据开始--------------------
      MERGE INTO MBT_110 T1
      USING (SELECT DISTINCT A.*, '11111110|0' AS IS_RPT, B.SECTION_CODE
               FROM (SELECT *
                       FROM ODS_MBT_110
                      WHERE EXISTS --只查询不存在MBT_110的数据
                      (SELECT B_ID_TYPE, B_ID_NUM
                               FROM ODS_MBT_110
                             MINUS
                             SELECT B_ID_TYPE, B_ID_NUM FROM MBT_110)) A
               LEFT JOIN MBT_SECTION_CODE B
                 ON A.ORG_ID = B.ORG_ID) T2
      ON (T1.B_ID_TYPE = T2.B_ID_TYPE AND T1.B_ID_NUM = T2.B_ID_NUM)
      WHEN NOT MATCHED THEN
        INSERT
          (T1.DATA_ID,
           T1.DATA_DATE,
           T1.CORP_ID,
           T1.ORG_ID,
           T1.CUST_NO,
           T1.GROUP_ID,
           T1.INQ_ORG_ID,
           T1.INQ_GROUP_ID,
           T1.B_INF_REC_TYPE,
           T1.B_NAME,
           T1.B_ID_TYPE,
           T1.B_ID_NUM,
           T1.B_INF_SURC_CODE,
           T1.B_RPT_DATE,
           T1.B_RPT_DATE_CODE,
           T1.B_CIMOC,
           T1.B_CUSTOMER_TYPE,
           T1.C_ID_INFO_UP_DATE,
           T1.D_SEX,
           T1.D_DOB,
           T1.D_NATION,
           T1.D_HOUSE_ADD,
           T1.D_HH_DIST,
           T1.D_CELL_PHONE,
           T1.D_EMAIL,
           T1.D_FCS_INFO_UP_DATE,
           T1.E_MARI_STATUS,
           T1.E_SPO_NAME,
           T1.E_SPO_ID_TYPE,
           T1.E_SPO_ID_NUM,
           T1.E_SPO_TEL,
           T1.E_SPS_CMPY_NM,
           T1.E_SPS_INFO_UP_DATE,
           T1.F_EDU_LEVEL,
           T1.F_ACA_DEGREE,
           T1.F_EDU_INFO_UP_DATE,
           T1.G_EMP_STATUS,
           T1.G_CPN_NAME,
           T1.G_CPN_TYPE,
           T1.G_INDUSTRY,
           T1.G_CPN_ADDR,
           T1.G_CPN_PC,
           T1.G_CPN_DIST,
           T1.G_CPN_TEL,
           T1.G_OCCUPATION,
           T1.G_TITLE,
           T1.G_TECH_TITLE,
           T1.G_WORK_START_DATE,
           T1.G_OCTPN_INFO_UP_DATE,
           T1.H_RESI_STATUS,
           T1.H_RESI_ADDR,
           T1.H_RESI_PC,
           T1.H_RESI_DIST,
           T1.H_HOME_TEL,
           T1.H_RESI_INFO_UP_DATE,
           T1.I_MAIL_ADDR,
           T1.I_MAIL_PC,
           T1.I_MAIL_DIST,
           T1.I_MLG_INFO_UP_DATE,
           T1.J_ANNL_INC,
           T1.J_ANNL_INC_LCY,
           T1.J_TAX_INCOME,
           T1.J_TAX_INCOME_LCY, 
           T1.J_INC_INFO_UP_DATE,
           T1.DATA_STATUS,
           T1.DATA_SOURCE,
           T1.DATA_CRT_USER,
           T1.DATA_CRT_DATE,
           T1.DATA_CRT_TIME,
           T1.RSV1,
           T1.RSV2,
           T1.RSV3,
           T1.RSV4,
           T1.RSV5,
           T1.IS_RPT)
        VALUES
          (T2.DATA_ID,
           T2.DATA_DATE,
           T2.CORP_ID,
           T2.ORG_ID,
           T2.CUST_NO,
           T2.GROUP_ID,
           T2.ORG_ID,
           T2.ORG_ID,
           '110',
           T2.B_NAME,
           T2.B_ID_TYPE,
           T2.B_ID_NUM,
           T2.B_INF_SURC_CODE,
           V_DATE,
           '10',
           T2.B_CIMOC,
           T2.B_CUSTOMER_TYPE,
           V_DATE,
           T2.D_SEX,
           T2.D_DOB,
           T2.D_NATION,
           T2.D_HOUSE_ADD,
           T2.D_HH_DIST,
           T2.D_CELL_PHONE,
           T2.D_EMAIL,
           V_DATE,
           T2.E_MARI_STATUS,
           T2.E_SPO_NAME,
           T2.E_SPO_ID_TYPE,
           T2.E_SPO_ID_NUM,
           T2.E_SPO_TEL,
           T2.E_SPS_CMPY_NM,
           V_DATE,
           T2.F_EDU_LEVEL,
           T2.F_ACA_DEGREE,
           V_DATE,
           T2.G_EMP_STATUS,
           T2.G_CPN_NAME,
           T2.G_CPN_TYPE,
           T2.G_INDUSTRY,
           T2.G_CPN_ADDR,
           T2.G_CPN_PC,
           T2.G_CPN_DIST,
           T2.G_CPN_TEL,
           T2.G_OCCUPATION,
           T2.G_TITLE,
           T2.G_TECH_TITLE,
           T2.G_WORK_START_DATE,
           V_DATE,
           T2.H_RESI_STATUS,
           T2.H_RESI_ADDR,
           T2.H_RESI_PC,
           T2.H_RESI_DIST,
           T2.H_HOME_TEL,
           V_DATE,
           T2.I_MAIL_ADDR,
           T2.I_MAIL_PC,
           T2.I_MAIL_DIST,
           V_DATE,
           T2.J_ANNL_INC,
           T2.J_ANNL_INC_LCY,
           T2.J_TAX_INCOME,
           T2.J_ANNL_INC_LCY,
           V_DATE,
           '00',
           '2',
           'SYSTEM',
           CURRENTDATE,
           CURRENTTIME,
           T2.RSV1,
           T2.RSV2,
           T2.RSV3,
           T2.RSV4,
           T2.RSV5,
           T2.IS_RPT);
      --------------------修改子表[MBT_110_C]数据开始--------------------
      -- 先删除所有相关数据 然后重新插入
      DELETE FROM MBT_110_C
       WHERE PDATA_ID IN (SELECT B.DATA_ID
                            FROM ODS_MBT_110 A
                            LEFT JOIN MBT_110 B
                              ON A.B_ID_TYPE = B.B_ID_TYPE
                             AND A.B_ID_NUM = B.B_ID_NUM);
      --------------------新增数据开始--------------------
      MERGE INTO MBT_110_C T1
      USING (SELECT A.DATA_ID,
                    A.DATA_DATE,
                    A.ALIAS,
                    A.OTH_ID_TYPE,
                    A.OTH_ID_NUM,
                    A.RSV1,
                    A.RSV2,
                    A.RSV3,
                    A.RSV4,
                    A.RSV5,
                    CASE
                      WHEN C.DATA_ID IS NULL THEN
                       A.PDATA_ID
                      ELSE
                       C.DATA_ID
                    END AS PDATA_ID
               FROM ODS_MBT_110_C A
               LEFT JOIN ODS_MBT_110 B
                 ON A.PDATA_ID = B.DATA_ID
               LEFT JOIN MBT_110 C
                 ON B.B_ID_TYPE = C.B_ID_TYPE
                AND B.B_ID_NUM = C.B_ID_NUM) T2
      ON (T1.OTH_ID_TYPE = T2.OTH_ID_TYPE AND T1.OTH_ID_NUM = T2.OTH_ID_NUM)
      WHEN NOT MATCHED THEN
        INSERT
          (T1.DATA_ID,
           T1.PDATA_ID,
           T1.DATA_DATE,
           T1.ALIAS,
           T1.OTH_ID_TYPE,
           T1.OTH_ID_NUM,
           T1.ODS_DATA_ID,
           T1.DATA_SOURE,
           T1.DATA_CRT_USER,
           T1.DATA_CRT_DATE,
           T1.DATA_CRT_TIME,
           T1.RSV1,
           T1.RSV2,
           T1.RSV3,
           T1.RSV4,
           T1.RSV5)
        VALUES
          (T2.DATA_ID,
           T2.PDATA_ID,
           T2.DATA_DATE,
           T2.ALIAS,
           T2.OTH_ID_TYPE,
           T2.OTH_ID_NUM,
           T2.DATA_ID,
           '2',
           'SYSEM',
           CURRENTDATE,
           CURRENTTIME,
           T2.RSV1,
           T2.RSV2,
           T2.RSV3,
           T2.RSV4,
           'FLAG');

      --更改主表数据状态
      MERGE INTO MBT_110 T1
      USING (SELECT DISTINCT B.DATA_ID
               FROM MBT_110_C A
               LEFT JOIN MBT_110 B
                 ON A.PDATA_ID = B.DATA_ID
              WHERE A.RSV5 = 'FLAG') T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.DATA_STATUS = '00';

      UPDATE MBT_110_C SET RSV5 = NULL WHERE RSV5 = 'FLAG';
      --------------------修改子表[MBT_110_C]数据结束--------------------

      --------------------更新报告时点开始--------------------
      MERGE INTO MBT_110 T1
      USING (SELECT A.DATA_ID,
                    CASE
                      WHEN B.DATA_ID IS NULL THEN
                       '10'
                      WHEN INSTR(B.B_NAME || B.B_INF_SURC_CODE ||
                                 B.B_RPT_DATE || B.B_CIMOC ||
                                 B.B_CUSTOMER_TYPE || B.D_SEX || B.D_DOB ||
                                 B.D_NATION || B.D_HOUSE_ADD || B.D_HH_DIST ||
                                 B.D_CELL_PHONE || B.D_EMAIL ||
                                 B.E_MARI_STATUS || B.E_SPO_NAME ||
                                 B.E_SPO_ID_TYPE || B.E_SPO_ID_NUM ||
                                 B.E_SPO_TEL || B.E_SPS_CMPY_NM ||
                                 B.F_EDU_LEVEL || B.F_ACA_DEGREE ||
                                 B.G_EMP_STATUS || B.G_CPN_NAME ||
                                 B.G_CPN_TYPE || B.G_INDUSTRY || B.G_CPN_ADDR ||
                                 B.G_CPN_PC || B.G_CPN_DIST || B.G_CPN_TEL ||
                                 B.G_OCCUPATION || B.G_TITLE ||
                                 B.G_TECH_TITLE || B.G_WORK_START_DATE ||
                                 B.H_RESI_STATUS || B.H_RESI_ADDR ||
                                 B.H_RESI_PC || B.H_RESI_DIST || B.H_HOME_TEL ||
                                 B.I_MAIL_ADDR || B.I_MAIL_PC ||
                                 B.I_MAIL_DIST || B.J_ANNL_INC ||
                                 B.J_TAX_INCOME || '1',
                                 A.B_NAME || A.B_INF_SURC_CODE || A.B_RPT_DATE ||
                                 A.B_CIMOC || A.B_CUSTOMER_TYPE || A.D_SEX ||
                                 A.D_DOB || A.D_NATION || A.D_HOUSE_ADD ||
                                 A.D_HH_DIST || A.D_CELL_PHONE || A.D_EMAIL ||
                                 A.E_MARI_STATUS || A.E_SPO_NAME ||
                                 A.E_SPO_ID_TYPE || A.E_SPO_ID_NUM ||
                                 A.E_SPO_TEL || A.E_SPS_CMPY_NM ||
                                 A.F_EDU_LEVEL || A.F_ACA_DEGREE ||
                                 A.G_EMP_STATUS || A.G_CPN_NAME ||
                                 A.G_CPN_TYPE || A.G_INDUSTRY || A.G_CPN_ADDR ||
                                 A.G_CPN_PC || A.G_CPN_DIST || A.G_CPN_TEL ||
                                 A.G_OCCUPATION || A.G_TITLE || A.G_TECH_TITLE ||
                                 A.G_WORK_START_DATE || A.H_RESI_STATUS ||
                                 A.H_RESI_ADDR || A.H_RESI_PC || A.H_RESI_DIST ||
                                 A.H_HOME_TEL || A.I_MAIL_ADDR || A.I_MAIL_PC ||
                                 A.I_MAIL_DIST || A.J_ANNL_INC ||
                                 A.J_TAX_INCOME || '1') > 0 THEN
                       '99'
                      ELSE
                       '20'
                    END AS B_RPT_DATE_CODE
               FROM MBT_110 A
              INNER JOIN (SELECT *
                           FROM MBT_110_HIS
                          WHERE DATA_ID IN (SELECT ODS_DATA_ID
                                              FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_ID_TYPE, B_ID_NUM ORDER BY RPT_TIME DESC) RN,
                                                           T.*
                                                      FROM MBT_110_RPT T
                                                     WHERE DATA_STATUS = '27')
                                             WHERE RN = 1)) B
                 ON A.B_ID_TYPE = B.B_ID_TYPE
                AND A.B_ID_NUM = B.B_ID_NUM) T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.B_RPT_DATE_CODE = T2.B_RPT_DATE_CODE;

      --更新时点（子表有改动）
      MERGE INTO MBT_110 A
      USING (SELECT DISTINCT T3.DATA_ID,
                             CASE
                               WHEN T4.DATA_ID IS NOT NULL THEN
                                '20'
                               ELSE
                                '10'
                             END AS NEW_B_RPT_DATE_CODE
               FROM (SELECT DISTINCT OTH_ID_TYPE, OTH_ID_NUM, ALIAS
                       FROM (SELECT OTH_ID_TYPE, OTH_ID_NUM, ALIAS
                               FROM MBT_110_C
                             MINUS
                             SELECT OTH_ID_TYPE, OTH_ID_NUM, ALIAS
                               FROM MBT_110_C_RPT
                              WHERE PDATA_ID IN (SELECT DATA_ID
                                                   FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_ID_TYPE, B_ID_NUM ORDER BY RPT_TIME DESC) RN,
                                                                T.*
                                                           FROM MBT_110_RPT T
                                                          WHERE DATA_STATUS = '27')
                                                  WHERE RN = 1)
                             UNION ALL
                             SELECT OTH_ID_TYPE, OTH_ID_NUM, ALIAS
                               FROM MBT_110_C_RPT
                              WHERE PDATA_ID IN (SELECT DATA_ID
                                                   FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_ID_TYPE, B_ID_NUM ORDER BY RPT_TIME DESC) RN,
                                                                T.*
                                                           FROM MBT_110_RPT T
                                                          WHERE DATA_STATUS = '27')
                                                  WHERE RN = 1)
                             MINUS
                             SELECT OTH_ID_TYPE, OTH_ID_NUM, ALIAS
                               FROM MBT_110_C

                             )) T1
               LEFT JOIN MBT_110_C T2
                 ON T1.OTH_ID_TYPE = T2.OTH_ID_TYPE
                AND T1.OTH_ID_NUM = T2.OTH_ID_NUM
               LEFT JOIN MBT_110 T3
                 ON T2.PDATA_ID = T3.DATA_ID
               LEFT JOIN MBT_110_RPT T4
                 ON T3.B_ID_TYPE = T4.B_ID_TYPE
                AND T3.B_ID_NUM = T4.B_ID_NUM
                AND T4.DATA_STATUS = '27') B
      ON (A.DATA_ID = B.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET A.B_RPT_DATE_CODE = B.NEW_B_RPT_DATE_CODE;
      --------------------更新报告时点结束--------------------

      --------------------更新IS_RPT开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                              'T.B_ID_TYPE,T.B_ID_NUM',
                              'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                              B_ARRAYLIST,
                              1,
                              NULL,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                              'T.B_ID_TYPE,T.B_ID_NUM',
                              'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                              D_ARRAYLIST,
                              2,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                              'T.B_ID_TYPE,T.B_ID_NUM',
                              'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                              E_ARRAYLIST,
                              3,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                              'T.B_ID_TYPE,T.B_ID_NUM',
                              'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                              F_ARRAYLIST,
                              4,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                              'T.B_ID_TYPE,T.B_ID_NUM',
                              'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                              G_ARRAYLIST,
                              5,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                              'T.B_ID_TYPE,T.B_ID_NUM',
                              'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                              H_ARRAYLIST,
                              6,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                              'T.B_ID_TYPE,T.B_ID_NUM',
                              'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                              I_ARRAYLIST,
                              7,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_110',
                              'T.B_ID_TYPE,T.B_ID_NUM',
                              'T1.B_ID_TYPE=T2.B_ID_TYPE AND T1.B_ID_NUM=T2.B_ID_NUM',
                              J_ARRAYLIST,
                              8,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_110_C',
                              'T.OTH_ID_TYPE,T.OTH_ID_NUM',
                              'T1.OTH_ID_TYPE=T2.OTH_ID_TYPE AND T1.OTH_ID_NUM=T2.OTH_ID_NUM',
                              C_ARRAYLIST,
                              10,
                              'MBT_110',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND T4.ACCT_TYPE IS NULL
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              NULL);
      --------------------更新IS_RPT结束--------------------
    END;
    --------------------新增结束--------------------
    --数据插入历史表，然后删除ODS表
    INSERT INTO ODS_MBT_110_HIS
      SELECT * FROM ODS_MBT_110;
    DELETE FROM ODS_MBT_110;
    --数据插入历史表，然后删除ODS表
    INSERT INTO ODS_MBT_110_C_HIS
      SELECT * FROM ODS_MBT_110_C;
    DELETE FROM ODS_MBT_110_C;

    --将报告时点代码是88或99的直接审核通过并将校验修改为校验通过
    --update by wuxy
    UPDATE mbt_110
       SET DATA_STATUS = '21', CHECK_FLAG = 'Y'
     WHERE DATA_CRT_DATE <= CURRENTDATE
       AND (B_RPT_DATE_CODE = '88' OR B_RPT_DATE_CODE = '99')
       AND DATA_STATUS = '00';
    --update end
/*   --将报告时点代码非88或99的校验修改为未交验 ZHAO
    UPDATE mbt_110
       SET CHECK_FLAG = 'N'
     WHERE DATA_CRT_DATE <= CURRENTDATE
       AND (B_RPT_DATE_CODE NOT IN('99','88'))
       AND DATA_STATUS = '00';*/
    --update end
  END IF;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ERRCODE := SQLCODE;
    ERRMSG  := SUBSTR(SQLERRM, 1, 200);
    SP_MBT_LOG(1,
               'SP_ODS_MBT_110',
               'ERROR11001',
               'SP_ODS_MBT_110失败：' || ERRMSG,
               ERRCODE,
               ERRMSG);
    ROLLBACK;

    ENDTIME := TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS');
    DSC     := '##=======MBT110存储过程==结束' || ENDTIME || '========##';
    DBMS_OUTPUT.PUT_LINE(DSC);
END;

