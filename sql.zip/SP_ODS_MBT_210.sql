CREATE OR REPLACE PROCEDURE "SP_ODS_MBT_210"(ERRCODE           IN OUT VARCHAR,
                                             ERRMSG            IN OUT VARCHAR,
                                             TABLE_KEY         IN VARCHAR2,
                                             RPT_DATE_CODE_OUT IN OUT VARCHAR2) AS
  DSC         VARCHAR2(1000);
  BEGINTIME   VARCHAR2(20);
  ENDTIME     VARCHAR2(20);
  CURRENTDATE VARCHAR2(8);
  CURRENTTIME VARCHAR2(14);
  B_ARRAYLIST VARCHAR2(4000);
  C_ARRAYLIST VARCHAR2(4000);
  D_ARRAYLIST VARCHAR2(4000);
  E_ARRAYLIST VARCHAR2(40);
  F_ARRAYLIST VARCHAR2(4000);
  G_ARRAYLIST VARCHAR2(4000);
  H_ARRAYLIST VARCHAR2(4000);
  I_ARRAYLIST VARCHAR2(4000);
  J_ARRAYLIST VARCHAR2(4000);
  K_ARRAYLIST VARCHAR2(4000);
  IS_RPT_OUT  VARCHAR2(64);
  V_DATE      VARCHAR2(8);
  V_YE_DATE   VARCHAR2(8);

  V_KX_DATE    VARCHAR2(8);
  V_YEAR_MONTH VARCHAR2(8);
BEGIN
  --yuan
  B_ARRAYLIST := ('B_ACCT_TYPE,B_NAME,B_ID_TYPE,B_ID_NUM,B_MNGMT_ORG_CODE');
  C_ARRAYLIST := ('C_BUSI_LINES,
  C_BUSI_DTL_LINES,
  C_OPEN_DATE,
  C_CY,
  C_ACCT_CRED_LINE_AMT_LCY,
  C_LOAN_AMT_LCY,
  C_FLAG,
  C_DUE_DATE,
  C_REPAY_MODE,
  C_REPAY_FREQCY,
  C_REPAY_PRD,
  C_APPLY_BUSI_DIST,
  C_GUAR_MODE,
  C_OTH_REPY_GUAR_WAY,
  C_ASSET_TRAND_FLAG,
  C_FUND_SOU,
  C_LOAN_FORM,
  C_CREDIT_ID');
  D_ARRAYLIST := ('D_ARLP_ID_TYPE,D_ARLP_NAME,D_ARLP_TYPE,D_ARLP_AMT,D_WARTY_SIGN,D_MAX_GUAR_MCC');
  E_ARRAYLIST := ('E_CCC');
  F_ARRAYLIST := ('F_MCC');
  G_ARRAYLIST := ('G_INIT_CRED_NAME,G_INIT_CRED_ORG_NM,G_ORIG_DBT_CATE,G_INIT_RPY_STS');
  H_ARRAYLIST := ('H_MONTH,H_SETT_DATE,H_ACCT_STATUS,H_ACCT_BAL_LCY,H_PRID_ACCT_BAL_LCY,H_USED_AMT_LCY,H_NOTLSU_BAL_LCY,H_REM_REP_PRD,H_FIVE_CATE,H_FIVE_CATE_ADJ_DATE,H_RPY_STATUS,H_RPY_PRCT,H_OVERD_PRD,H_TOT_OVERD_LCY,H_OVAER_PRINC_LCY,H_OVERD31_60PRINC_LCY,H_OVERD61_90PRINC_LCY,H_OVERD91_180PRINC_LCY,H_OVERD_PRINC180_LCY,H_OVERD_RAW_BA_OVE180_LCY,H_CUR_RPY_AMT_LCY,H_ACT_RPY_AMT_LCY,H_LAT_RPY_DATE,H_CLOSE_DATE');
  I_ARRAYLIST := ('I_SPEC_LINE_LCY ,I_SPEC_EFCT_DATE,I_SPEC_END_DATE,I_USED_INST_AMT_LCY');
  J_ARRAYLIST := ('J_ACCT_STATUS,J_ACCT_BAL_LCY,J_FIVE_CATE,J_FIVE_CATE_ADJ_DATE,J_REM_REP_PRD,J_RPY_STATUS,J_OVERD_PRD,J_TOT_OVERD_LCY,J_LAT_RPY_AMT_LCY,J_LAT_RPY_DATE,J_CLOSE_DATE');
  K_ARRAYLIST := ('K_CHAN_TRAN_TYPE,K_TRAN_DATE,K_TRAN_AMT,K_DUE_TRAN_MON,K_DET_INFO');
  CURRENTDATE := TO_CHAR(SYSDATE, 'YYYYMMDD');
  CURRENTTIME := TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS');
  BEGINTIME   := TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS');
  V_DATE      := GET_NEW_DAY(CURRENTDATE);
  V_YE_DATE   := to_char(to_Date(V_DATE, 'YYYY-MM-DD') - 1, 'YYYYMMDD');

  V_YEAR_MONTH := SUBSTR(V_DATE, 0, 6);

  DSC := '##=======MBT210存储过程==开始' || BEGINTIME || '========##';
  DBMS_OUTPUT.PUT_LINE(DSC);
  IF TABLE_KEY IS NOT NULL THEN
    --处理从页面来的数据 计算时点
    BEGIN
      MERGE INTO mbt_210 T1
      USING (SELECT DISTINCT A.*,
                            CASE
                              /*  WHEN A.H_SETT_DATE IS NOT NULL AND V_DATE <= A.H_SETT_DATE then
                                A.H_SETT_DATE
                               WHEN A.H_SETT_DATE IS NOT NULL AND A.H_ACT_RPY_AMT >= A.H_CUR_RPY_AMT AND
                                    V_DATE > A.H_SETT_DATE AND
                                    V_DATE <= GET_WORKDAY_NEW(A.H_SETT_DATE, 0) THEN
                                V_DATE*/

                               WHEN  A.H_SETT_DATE IS NOT NULL
                                 /*AND A.H_ACT_RPY_AMT < A.H_CUR_RPY_AMT AND
                                    V_DATE > A.H_SETT_DATE AND
                                    V_DATE >= GET_WORKDAY_NEW(A.H_SETT_DATE, 0)*/ THEN
                                GET_WORKDAY_NEW(A.H_SETT_DATE, 0)
                               when A.H_SETT_DATE IS NULL THEN
                                TO_CHAR(LAST_DAY(SYSDATE), 'YYYYMMDD')
                               ELSE
                                null
                             END AS NEW_MON_SETTLE_DATE
               FROM MBT_210 A
               LEFT JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_ACCT_CODE ORDER BY RPT_TIME DESC) RN,
                                        T.*
                                   FROM MBT_210_RPT T
                                  WHERE DATA_STATUS = '27')
                          WHERE RN = 1) E
                 ON A.B_ACCT_CODE = E.B_ACCT_CODE
               LEFT JOIN MBT_210_RPT F
                 ON A.B_ACCT_CODE = F.B_ACCT_CODE
                AND SUBSTR(A.J_LAT_RPY_DATE, 1, 6) =
                    SUBSTR(F.B_RPT_DATE, 1, 6)
                AND F.B_RPT_DATE_CODE = '40'
                AND F.DATA_STATUS = '27'
              WHERE A.DATA_ID = TABLE_KEY) T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.MON_SETTLE_DATE = T2.NEW_MON_SETTLE_DATE;
      --计算报告时点
      SELECT DISTINCT CASE
                      -- 对于R2/R3类账户，在激活之前不需要每月报送
                        WHEN A.B_ACCT_TYPE IN ('R2 ', 'R3') AND
                             A.H_ACCT_STATUS = '6' THEN
                         '99'
                        WHEN A.C_OPEN_DATE = V_DATE AND
                             ((A.B_ACCT_TYPE <> 'C1' AND
                             A.H_ACCT_STATUS NOT IN ('3', '4')) OR
                             ((A.B_ACCT_TYPE = 'C1' AND
                             A.H_ACCT_STATUS <> '2'))) AND E.DATA_ID IS NULL THEN
                         '10'
                        WHEN ((A.B_ACCT_TYPE <> 'C1' AND
                             (A.H_ACCT_STATUS in ('3', '4'))) OR
                             (A.B_ACCT_TYPE = 'C1' AND
                             A.J_ACCT_STATUS = '2')) AND nvl(H.CNT, 0) = 0 AND
                             E.DATA_ID IS NOT NULL AND
                             A.MON_SETTLE_DATE = V_DATE THEN
                         '32'
                        WHEN ((A.B_ACCT_TYPE <> 'C1' AND
                             (A.H_ACCT_STATUS in ('3', '4'))) OR
                             (A.B_ACCT_TYPE = 'C1' AND
                             A.J_ACCT_STATUS = '2')) AND nvl(H.CNT, 0) = 0 AND
                             E.DATA_ID IS NOT NULL THEN
                         '20'
                      --                         CASE
                      --                           WHEN A.B_ACCT_TYPE <> 'C1' AND A.H_CLOSE_DATE = A.MON_SETTLE_DATE AND A.B_ACCT_TYPE <> 'C1' THEN
                      --                            CASE
                      --                              WHEN SUBSTR(E.B_RPT_DATE, 1, 6) = TO_CHAR(SYSDATE, 'YYYYMM') AND
                      --                                   E.B_RPT_DATE_CODE = '32' THEN
                      --                               '99'
                      --                              ELSE
                      --                               '32'
                      --                            END
                      --                           WHEN E.B_RPT_DATE_CODE = '20' THEN
                      --                            '99'
                      --                           ELSE
                      --                            '20'
                      --                         END
                      --允许首次上报有tday关闭的数据
                        WHEN /*((A.B_ACCT_TYPE <> 'C1' AND (A.H_ACCT_STATUS not in ('3', '4'))) OR (A.B_ACCT_TYPE = 'C1' AND A.J_ACCT_STATUS <> '2'))

                                                                                                                                                                             AND*/
                         A.MON_SETTLE_DATE = V_DATE AND nvl(H.CNT, 0) = 0 AND
                         nvl(G.CNT, 0) = 0 THEN
                        -- E.DATA_ID IS NULL
                         '31'
                      --                         CASE
                      --                           WHEN SUBSTR(E.B_RPT_DATE, 1, 6) = TO_CHAR(SYSDATE, 'YYYYMM') AND
                      --                                E.B_RPT_DATE_CODE = '31' THEN
                      --                            '99'
                      --                           ELSE
                      --                            '31'
                      --                         END
                      --                        WHEN A.B_ACCT_TYPE IN ('D1', 'R1',  'R4') AND   A.J_TOT_OVERD  IS NOT NULL AND
                      --                             A.J_LAT_RPY_AMT IS NOT NULL AND A.J_LAT_RPY_DATE IS NOT NULL AND A.J_TOT_OVERD = A.J_LAT_RPY_AMT  AND
                      --                             F.DATA_ID IS NULL THEN
                      --                         '40'
                      --                        WHEN A.B_ACCT_TYPE IN ('R2','C1') AND   A.J_ACCT_BAL IS NOT NULL AND
                      --                             A.J_LAT_RPY_AMT IS NOT NULL  AND A.J_LAT_RPY_DATE IS NOT NULL AND A.J_ACCT_BAL = A.J_LAT_RPY_AMT AND
                      --                             F.DATA_ID IS NULL THEN
                      --                         '40'

                        WHEN A.B_ACCT_TYPE IN ('D1', 'R1', 'R4') AND
                             A.H_TOT_OVERD = 0 AND I.H_TOT_OVERD <> 0 AND
                             A.B_RPT_DATE <> A.MON_SETTLE_DATE AND
                             F.DATA_ID IS NULL THEN
                         '40'
                        WHEN A.B_ACCT_TYPE IN ('R2', 'C1') AND
                             A.B_RPT_DATE <> A.MON_SETTLE_DATE AND
                             F.DATA_ID IS NULL THEN
                         '40'
                        WHEN A.B_ACCT_TYPE = 'C1' THEN
                         '99'
                        ELSE
                         CASE
                         -- WHEN SUBSTR(E.B_RPT_DATE, 1, 6) = TO_CHAR(SYSDATE, 'YYYYMM') AND E.B_RPT_DATE_CODE = '30'  THEN '99'
                         -- WHEN SUBSTR(E.B_RPT_DATE, 1, 6) != TO_CHAR(SYSDATE, 'YYYYMM') AND
                           when E.B_RPT_DATE_CODE != '30' AND
                                A.MON_SETTLE_DATE IS NOT NULL AND
                                V_DATE = A.MON_SETTLE_DATE THEN
                            '30'
                         --  WHEN A.MON_SETTLE_DATE IS NOT NULL AND V_DATE != A.MON_SETTLE_DATE
                         -- THEN '99'
                           ELSE
                            '99'
                         END
                      END
        INTO RPT_DATE_CODE_OUT
        FROM MBT_210 A
        LEFT JOIN (SELECT *
                     FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_ACCT_CODE ORDER BY RPT_TIME DESC) RN,
                                  T.*
                             FROM MBT_210_RPT T
                            WHERE DATA_STATUS = '27')
                    WHERE RN = 1) E
          ON A.B_ACCT_CODE = E.B_ACCT_CODE
        LEFT JOIN MBT_210_RPT F
          ON A.B_ACCT_CODE = F.B_ACCT_CODE
        left join (select count(1) cnt, B_ACCT_CODE
                     from MBT_210_RPT
                    WHERE DATA_STATUS = '27'
                         --首次报送允许报账户关闭数据，要过滤掉
                      and (B_RPT_DATE_CODE IN ('20', '32') or
                          (B_RPT_DATE_CODE = '31' AND
                          ((B_ACCT_TYPE <> 'C1' AND
                          (H_ACCT_STATUS in ('3', '4'))) OR
                          (B_ACCT_TYPE = 'C1' AND J_ACCT_STATUS = '2'))))
                    GROUP BY B_ACCT_CODE) H
          ON A.B_ACCT_CODE = H.B_ACCT_CODE
        left join (select count(1) cnt, B_ACCT_CODE
                     from MBT_210_RPT
                    WHERE DATA_STATUS = '27'
                      and B_RPT_DATE_CODE = '31'
                    GROUP BY B_ACCT_CODE) G
          ON A.B_ACCT_CODE = G.B_ACCT_CODE
        left join MBT_210_RPT I
          ON A.B_ACCT_CODE = I.B_ACCT_CODE
         AND SUBSTR(A.J_LAT_RPY_DATE, 1, 6) = SUBSTR(F.B_RPT_DATE, 1, 6)
         AND F.B_RPT_DATE_CODE = '40'
         AND F.DATA_STATUS = '27'
         AND I.B_RPT_DATE = V_YE_DATE
         AND I.DATA_STATUS = '27'
       WHERE A.DATA_ID = TABLE_KEY;

      SELECT IS_RPT INTO IS_RPT_OUT FROM MBT_210 WHERE DATA_ID = TABLE_KEY;
      IF IS_RPT_OUT IS NULL THEN
        MERGE INTO MBT_210 T1
        USING (SELECT A.DATA_ID, B.INIT_VALUE AS IS_RPT
                 FROM MBT_210 A
                 LEFT JOIN MBT_RPT_DATE_CODE_CFG B
                   ON A.B_INF_REC_TYPE = B.INF_REC_TYPE
                  AND INSTR(B.ACCT_TYPE, A.B_ACCT_TYPE) > 0
                  AND A.B_RPT_DATE_CODE = B.RPT_DATE_CODE) T2
        ON (T1.DATA_ID = T2.DATA_ID)
        WHEN MATCHED THEN
          UPDATE SET T1.IS_RPT = T2.IS_RPT;
      ELSE
        --根据各段判断报送情况
        --------------------修改IS_RPT开始--------------------
        SP_ODS_MBT_CAL_RPT_PROC('MBT_210',
                                'T.B_ACCT_CODE',
                                'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                                B_ARRAYLIST,
                                1,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                 AND INSTR(T3.ACCT_TYPE, T1.B_ACCT_TYPE) > 0
                 AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                TABLE_KEY);
        SP_ODS_MBT_CAL_RPT_PROC('MBT_210',
                                'T.B_ACCT_CODE',
                                'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                                C_ARRAYLIST,
                                2,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                 AND INSTR(T3.ACCT_TYPE, T1.B_ACCT_TYPE) > 0
                 AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                TABLE_KEY);
        SP_ODS_MBT_CAL_RPT_PROC('MBT_210',
                                'T.B_ACCT_CODE',
                                'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                                F_ARRAYLIST,
                                3,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                 AND INSTR(T3.ACCT_TYPE, T1.B_ACCT_TYPE) > 0
                 AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                TABLE_KEY);
        SP_ODS_MBT_CAL_RPT_PROC('MBT_210',
                                'T.B_ACCT_CODE',
                                'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                                G_ARRAYLIST,
                                4,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                 AND INSTR(T3.ACCT_TYPE, T1.B_ACCT_TYPE) > 0
                 AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                TABLE_KEY);
        SP_ODS_MBT_CAL_RPT_PROC('MBT_210',
                                'T.B_ACCT_CODE',
                                'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                                H_ARRAYLIST,
                                5,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                 AND INSTR(T3.ACCT_TYPE, T1.B_ACCT_TYPE) > 0
                 AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                TABLE_KEY);
        SP_ODS_MBT_CAL_RPT_PROC('MBT_210',
                                'T.B_ACCT_CODE',
                                'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                                I_ARRAYLIST,
                                6,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                 AND INSTR(T3.ACCT_TYPE, T1.B_ACCT_TYPE) > 0
                 AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                TABLE_KEY);
        SP_ODS_MBT_CAL_RPT_PROC('MBT_210',
                                'T.B_ACCT_CODE',
                                'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                                J_ARRAYLIST,
                                7,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                 AND INSTR(T3.ACCT_TYPE, T1.B_ACCT_TYPE) > 0
                 AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                TABLE_KEY);
        --------------------修改IS_RPT结束--------------------
        --------------------修改子表IS_RPT开始--------------------
        /*  SP_ODS_MBT_CAL_RPT_PROC('MBT_210_D',
                      'T.D_ARLP_CERT_TYPE,T.D_ARLP_CERT_NUM',
                      'T1.D_ARLP_CERT_TYPE=T2.D_ARLP_CERT_TYPE AND T1.D_ARLP_CERT_NUM=T2.D_ARLP_CERT_NUM',
                      D_ARRAYLIST,
                      9,
                      'MBT_210',
                      'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
        AND INSTR(T4.ACCT_TYPE,T3.B_ACCT_TYPE) > 0
        AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                      TABLE_KEY);*/
        SP_ODS_MBT_CAL_RPT_PROC('MBT_210_D',
                                'T.B_ACCT_CODE,T.D_ARLP_ID_TYPE,T.D_ARLP_NAME,T.D_ARLP_CERT_TYPE,T.D_ARLP_CERT_NUM,T.D_ARLP_TYPE,T.D_WARTY_SIGN,T.D_MAX_GUAR_MCC',
                                'T1.B_ACCT_CODE =T2.B_ACCT_CODE AND T1.D_ARLP_ID_TYPE =T2.D_ARLP_ID_TYPE AND T1.D_ARLP_NAME =T2.D_ARLP_NAME  AND T1.D_ARLP_CERT_TYPE =T2.D_ARLP_CERT_TYPE AND T1.D_ARLP_CERT_NUM =T2.D_ARLP_CERT_NUM AND T1.D_ARLP_TYPE =T2.D_ARLP_TYPE AND T1.D_WARTY_SIGN =T2.D_WARTY_SIGN AND T1.D_MAX_GUAR_MCC =T2.D_MAX_GUAR_MCC',
                                D_ARRAYLIST,
                                9,
                                'MBT_210',
                                'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND INSTR(T4.ACCT_TYPE,T3.B_ACCT_TYPE) > 0
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                                TABLE_KEY);

        SP_ODS_MBT_CAL_RPT_PROC('MBT_210_E',
                                'T.E_CCC',
                                'T1.E_CCC=T2.E_CCC',
                                E_ARRAYLIST,
                                10,
                                'MBT_210',
                                'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND INSTR(T4.ACCT_TYPE,T3.B_ACCT_TYPE) > 0
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                                TABLE_KEY);
        SP_ODS_MBT_CAL_RPT_PROC('MBT_210_K',
                                'T.REF_NO',
                                'T1.REF_NO=T2.REF_NO',
                                K_ARRAYLIST,
                                11,
                                'MBT_210',
                                'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND INSTR(T4.ACCT_TYPE,T3.B_ACCT_TYPE) > 0
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                                TABLE_KEY);
        --------------------修改子表IS_RPT结束--------------------
      END IF;
    END;
  ELSE
    BEGIN
      --------------------备份数据--------------------
      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_210_TODAY_BAK';
      INSERT INTO MBT_210_TODAY_BAK
        SELECT * FROM MBT_210;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_210_D_TODAY_BAK';
      INSERT INTO MBT_210_D_TODAY_BAK
        SELECT * FROM MBT_210_D;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_210_E_TODAY_BAK';
      INSERT INTO MBT_210_E_TODAY_BAK
        SELECT * FROM MBT_210_E;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_210_K_TODAY_BAK';
      INSERT INTO MBT_210_K_TODAY_BAK
        SELECT * FROM MBT_210_K;
      --------------------备份数据--------------------
      --------------------修改数据--------------------

      MERGE INTO MBT_210 T1
      USING (SELECT A.*,
                   CASE
                    /*   WHEN A.H_SETT_DATE IS NOT NULL AND
                           V_DATE <= A.H_SETT_DATE then
                       A.H_SETT_DATE
                      WHEN A.H_SETT_DATE IS NOT NULL AND
                           A.H_ACT_RPY_AMT >= A.H_CUR_RPY_AMT AND
                           V_DATE > A.H_SETT_DATE AND
                           V_DATE <= GET_WORKDAY_NEW(A.H_SETT_DATE, 0)
                       THEN
                       V_DATE*/
                      WHEN A.H_SETT_DATE IS NOT NULL /*AND
                           A.H_ACT_RPY_AMT < A.H_CUR_RPY_AMT AND
                           V_DATE > A.H_SETT_DATE AND
                           V_DATE >= GET_WORKDAY_NEW(A.H_SETT_DATE, 0)*/ THEN
                       GET_WORKDAY_NEW(A.H_SETT_DATE, 0)
                      when A.H_SETT_DATE IS NULL THEN
                       TO_CHAR(LAST_DAY(SYSDATE), 'YYYYMMDD')
                      ELSE
                       null
                    END AS NEW_MON_SETTLE_DATE,
                    CASE ---新增 B_LOAN_CON_CODE||B_FIRST_HOU_LOAN_FLAG
                      WHEN INSTR(B.B_NAME || B.C_LOAN_CON_CODE ||
                                 B.C_FIRST_HOU_LOAN_FLAG || B.C_BUSI_LINES ||
                                 B.C_BUSI_DTL_LINES || B.B_MNGMT_ORG_CODE ||
                                 B.C_OPEN_DATE || B.C_CY ||
                                 B.C_ACCT_CRED_LINE_AMT || B.C_ACCT_CRED_LINE_AMT_LCY || B.C_LOAN_AMT || B.C_LOAN_AMT_LCY ||
                                 B.C_FLAG || B.C_DUE_DATE || B.C_REPAY_MODE ||
                                 B.C_REPAY_FREQCY || B.C_REPAY_PRD ||
                                 B.C_APPLY_BUSI_DIST || B.C_GUAR_MODE ||
                                 B.C_OTH_REPY_GUAR_WAY ||
                                 B.C_ASSET_TRAND_FLAG || B.C_FUND_SOU ||
                                 B.C_LOAN_FORM || B.C_CREDIT_ID || B.F_MCC ||
                                 B.G_INIT_CRED_NAME || B.G_INIT_CRED_ORG_NM ||
                                 B.G_ORIG_DBT_CATE || B.G_INIT_RPY_STS ||
                                 B.H_MONTH || B.H_SETT_DATE ||
                                 B.H_ACCT_STATUS || B.H_ACCT_BAL || B.H_ACCT_BAL_LCY ||
                                 B.H_PRID_ACCT_BAL || B.H_PRID_ACCT_BAL_LCY || B.H_USED_AMT || B.H_USED_AMT_LCY ||
                                 B.H_NOTLSU_BAL || B.H_NOTLSU_BAL_LCY || B.H_REM_REP_PRD ||
                                 B.H_FIVE_CATE || B.H_FIVE_CATE_ADJ_DATE ||
                                 B.H_RPY_STATUS || B.H_RPY_PRCT ||
                                 B.H_OVERD_PRD || B.H_TOT_OVERD || B.H_TOT_OVERD_LCY ||
                                 B.H_OVAER_PRINC || B.H_OVAER_PRINC_LCY || B.H_OVERD31_60PRINC || B.H_OVERD31_60PRINC_LCY ||
                                 B.H_OVERD61_90PRINC || B.H_OVERD61_90PRINC_LCY || B.H_OVERD91_180PRINC || B.H_OVERD91_180PRINC_LCY ||
                                 B.H_OVERD_PRINC180 || B.H_OVERD_PRINC180_LCY ||
                                 B.H_OVERD_RAW_BA_OVE180 || B.H_OVERD_RAW_BA_OVE180_LCY || B.H_CUR_RPY_AMT || B.H_CUR_RPY_AMT_LCY ||
                                 B.H_ACT_RPY_AMT || B.H_ACT_RPY_AMT_LCY || B.H_LAT_RPY_DATE ||
                                 B.H_CLOSE_DATE || B.I_SPEC_LINE || B.I_SPEC_LINE_LCY ||
                                 B.I_SPEC_EFCT_DATE || B.I_SPEC_END_DATE ||
                                 B.I_USED_INST_AMT || B.I_USED_INST_AMT_LCY || B.J_ACCT_STATUS ||
                                 B.J_ACCT_BAL || B.J_ACCT_BAL_LCY || B.J_FIVE_CATE ||
                                 B.J_FIVE_CATE_ADJ_DATE || B.J_REM_REP_PRD ||
                                 B.J_RPY_STATUS || B.J_OVERD_PRD ||
                                 B.J_TOT_OVERD || B.J_TOT_OVERD_LCY || B.J_LAT_RPY_AMT || B.J_LAT_RPY_AMT_LCY ||
                                 B.J_LAT_RPY_DATE || B.J_CLOSE_DATE || '1', --避免删除最后一个段的时候  INSTR 还为1
                                 ---新增 B_LOAN_CON_CODE||B_FIRST_HOU_LOAN_FLAG
                                 A.B_NAME || A.C_LOAN_CON_CODE ||
                                 A.C_FIRST_HOU_LOAN_FLAG || A.C_BUSI_LINES ||
                                 A.C_BUSI_DTL_LINES || A.B_MNGMT_ORG_CODE ||
                                 A.C_OPEN_DATE || A.C_CY ||
                                 A.C_ACCT_CRED_LINE_AMT || A.C_ACCT_CRED_LINE_AMT_LCY || A.C_LOAN_AMT || A.C_LOAN_AMT_LCY ||
                                 A.C_FLAG || A.C_DUE_DATE || A.C_REPAY_MODE ||
                                 A.C_REPAY_FREQCY || A.C_REPAY_PRD ||
                                 A.C_APPLY_BUSI_DIST || A.C_GUAR_MODE ||
                                 A.C_OTH_REPY_GUAR_WAY || A.C_ASSET_TRAND_FLAG ||
                                 A.C_FUND_SOU || A.C_LOAN_FORM ||
                                 A.C_CREDIT_ID || A.F_MCC ||
                                 A.G_INIT_CRED_NAME || A.G_INIT_CRED_ORG_NM ||
                                 A.G_ORIG_DBT_CATE || A.G_INIT_RPY_STS ||
                                 A.H_MONTH || A.H_SETT_DATE || A.H_ACCT_STATUS ||
                                 A.H_ACCT_BAL || A.H_ACCT_BAL_LCY || A.H_PRID_ACCT_BAL || A.H_PRID_ACCT_BAL_LCY ||
                                 A.H_USED_AMT || A.H_USED_AMT_LCY || A.H_NOTLSU_BAL || A.H_NOTLSU_BAL_LCY ||
                                 A.H_REM_REP_PRD || A.H_FIVE_CATE ||
                                 A.H_FIVE_CATE_ADJ_DATE || A.H_RPY_STATUS ||
                                 A.H_RPY_PRCT || A.H_OVERD_PRD ||
                                 A.H_TOT_OVERD || A.H_TOT_OVERD_LCY || A.H_OVAER_PRINC || A.H_OVAER_PRINC_LCY ||
                                 A.H_OVERD31_60PRINC || A.H_OVERD31_60PRINC_LCY || A.H_OVERD61_90PRINC || A.H_OVERD61_90PRINC_LCY ||
                                 A.H_OVERD91_180PRINC || A.H_OVERD91_180PRINC_LCY || A.H_OVERD_PRINC180 || A.H_OVERD_PRINC180_LCY ||
                                 A.H_OVERD_RAW_BA_OVE180 || A.H_OVERD_RAW_BA_OVE180_LCY || A.H_CUR_RPY_AMT || A.H_CUR_RPY_AMT_LCY ||
                                 A.H_ACT_RPY_AMT || A.H_ACT_RPY_AMT_LCY || A.H_LAT_RPY_DATE ||
                                 A.H_CLOSE_DATE || A.I_SPEC_LINE || A.I_SPEC_LINE_LCY ||
                                 A.I_SPEC_EFCT_DATE || A.I_SPEC_END_DATE ||
                                 A.I_USED_INST_AMT || A.I_USED_INST_AMT_LCY || A.J_ACCT_STATUS ||
                                 A.J_ACCT_BAL || A.J_ACCT_BAL_LCY || A.J_FIVE_CATE ||
                                 A.J_FIVE_CATE_ADJ_DATE || A.J_REM_REP_PRD ||
                                 A.J_RPY_STATUS || A.J_OVERD_PRD ||
                                 A.J_TOT_OVERD || A.J_TOT_OVERD_LCY || A.J_LAT_RPY_AMT || A.J_LAT_RPY_AMT_LCY ||
                                 A.J_LAT_RPY_DATE || A.J_CLOSE_DATE || '1') > 0 THEN --避免删除最后一个段的时候  INSTR 还为1
                       'N'
                      ELSE
                       'Y'
                    END AS UPDATE_FLAG

               FROM ODS_MBT_210 A
              INNER JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_ACCT_CODE ORDER BY DATA_LOAD_TIME DESC) RN,
                                        T.*
                                   FROM ODS_MBT_210_HIS T
                                  ORDER BY T.DATA_LOAD_TIME DESC)
                          WHERE RN = 1) B
                 ON A.B_ACCT_CODE = B.B_ACCT_CODE) T2
      ON (T1.B_ACCT_CODE = T2.B_ACCT_CODE AND T2.UPDATE_FLAG = 'Y')
      WHEN MATCHED THEN
        UPDATE
           SET T1.B_NAME    = T2.B_NAME,
               T1.B_ID_TYPE = T2.B_ID_TYPE,
               ---新增B_LOAN_CON_CODE||B_FIRST_HOU_LOAN_FLAG
               T1.C_LOAN_CON_CODE       = T2.C_LOAN_CON_CODE,
               T1.C_FIRST_HOU_LOAN_FLAG = T2.C_FIRST_HOU_LOAN_FLAG,
               T1.C_BUSI_LINES          = T2.C_BUSI_LINES,
               T1.C_BUSI_DTL_LINES      = T2.C_BUSI_DTL_LINES,
               T1.C_OPEN_DATE           = T2.C_OPEN_DATE,
               T1.C_CY                  = T2.C_CY,
T1.C_ACCT_CRED_LINE_AMT_LCY = T2.C_ACCT_CRED_LINE_AMT_LCY,
               T1.C_ACCT_CRED_LINE_AMT  = T2.C_ACCT_CRED_LINE_AMT,
T1.C_LOAN_AMT_LCY = T2.C_LOAN_AMT_LCY,
               T1.C_LOAN_AMT            = T2.C_LOAN_AMT,
               T1.C_FLAG                = T2.C_FLAG,
               T1.C_DUE_DATE            = T2.C_DUE_DATE,
               T1.C_REPAY_MODE          = T2.C_REPAY_MODE,
               T1.C_REPAY_FREQCY        = T2.C_REPAY_FREQCY,
               T1.C_REPAY_PRD           = T2.C_REPAY_PRD,
               T1.C_APPLY_BUSI_DIST     = T2.C_APPLY_BUSI_DIST,
               T1.C_GUAR_MODE           = T2.C_GUAR_MODE,
               T1.C_OTH_REPY_GUAR_WAY   = T2.C_OTH_REPY_GUAR_WAY,
               T1.C_ASSET_TRAND_FLAG    = T2.C_ASSET_TRAND_FLAG,
               T1.C_FUND_SOU            = T2.C_FUND_SOU,
               T1.C_LOAN_FORM           = T2.C_LOAN_FORM,
               T1.C_CREDIT_ID           = T2.C_CREDIT_ID,
               T1.F_MCC                 = T2.F_MCC,
               T1.G_INIT_CRED_NAME      = T2.G_INIT_CRED_NAME,
               T1.G_INIT_CRED_ORG_NM    = T2.G_INIT_CRED_ORG_NM,
               T1.G_ORIG_DBT_CATE       = T2.G_ORIG_DBT_CATE,
               T1.G_INIT_RPY_STS        = T2.G_INIT_RPY_STS,
               T1.H_MONTH               = T2.H_MONTH,
               T1.H_SETT_DATE           = T2.H_SETT_DATE,
               T1.H_ACCT_STATUS         = T2.H_ACCT_STATUS,
T1.H_ACCT_BAL_LCY = T2.H_ACCT_BAL_LCY,
               T1.H_ACCT_BAL            = T2.H_ACCT_BAL,
T1.H_PRID_ACCT_BAL_LCY = T2.H_PRID_ACCT_BAL_LCY,
               T1.H_PRID_ACCT_BAL       = T2.H_PRID_ACCT_BAL,
T1.H_USED_AMT_LCY = T2.H_USED_AMT_LCY,
               T1.H_USED_AMT            = T2.H_USED_AMT,
T1.H_NOTLSU_BAL_LCY = T2.H_NOTLSU_BAL_LCY,
               T1.H_NOTLSU_BAL          = T2.H_NOTLSU_BAL,
               T1.H_REM_REP_PRD         = T2.H_REM_REP_PRD,
               T1.H_FIVE_CATE           = T2.H_FIVE_CATE,
               T1.H_FIVE_CATE_ADJ_DATE  = T2.H_FIVE_CATE_ADJ_DATE,
               T1.H_RPY_STATUS          = T2.H_RPY_STATUS,
               T1.H_RPY_PRCT            = T2.H_RPY_PRCT,
               T1.H_OVERD_PRD           = T2.H_OVERD_PRD,
T1.H_TOT_OVERD_LCY = T2.H_TOT_OVERD_LCY,
               T1.H_TOT_OVERD           = T2.H_TOT_OVERD,
T1.H_OVAER_PRINC_LCY = T2.H_OVAER_PRINC_LCY,
               T1.H_OVAER_PRINC         = T2.H_OVAER_PRINC,
T1.H_OVERD31_60PRINC_LCY = T2.H_OVERD31_60PRINC_LCY,
               T1.H_OVERD31_60PRINC     = T2.H_OVERD31_60PRINC,
T1.H_OVERD61_90PRINC_LCY = T2.H_OVERD61_90PRINC_LCY,
               T1.H_OVERD61_90PRINC     = T2.H_OVERD61_90PRINC,
T1.H_OVERD91_180PRINC_LCY = T2.H_OVERD91_180PRINC_LCY,
               T1.H_OVERD91_180PRINC    = T2.H_OVERD91_180PRINC,
T1.H_OVERD_PRINC180_LCY = T2.H_OVERD_PRINC180_LCY,
               T1.H_OVERD_PRINC180      = T2.H_OVERD_PRINC180,
T1.H_OVERD_RAW_BA_OVE180_LCY = T2.H_OVERD_RAW_BA_OVE180_LCY,
               T1.H_OVERD_RAW_BA_OVE180 = T2.H_OVERD_RAW_BA_OVE180,
T1.H_CUR_RPY_AMT_LCY = T2.H_CUR_RPY_AMT_LCY,
               T1.H_CUR_RPY_AMT         = T2.H_CUR_RPY_AMT,
T1.H_ACT_RPY_AMT_LCY = T2.H_ACT_RPY_AMT_LCY,
               T1.H_ACT_RPY_AMT         = T2.H_ACT_RPY_AMT,
               T1.H_LAT_RPY_DATE        = T2.H_LAT_RPY_DATE,
               T1.H_CLOSE_DATE          = T2.H_CLOSE_DATE,
T1.I_SPEC_LINE_LCY = T2.I_SPEC_LINE_LCY,
               T1.I_SPEC_LINE           = T2.I_SPEC_LINE,
               T1.I_SPEC_EFCT_DATE      = T2.I_SPEC_EFCT_DATE,
               T1.I_SPEC_END_DATE       = T2.I_SPEC_END_DATE,
T1.I_USED_INST_AMT_LCY = T2.I_USED_INST_AMT_LCY,
               T1.I_USED_INST_AMT       = T2.I_USED_INST_AMT,
               T1.J_ACCT_STATUS         = T2.J_ACCT_STATUS,
T1.J_ACCT_BAL_LCY = T2.J_ACCT_BAL_LCY,
               T1.J_ACCT_BAL            = T2.J_ACCT_BAL,
               T1.J_FIVE_CATE           = T2.J_FIVE_CATE,
               T1.J_FIVE_CATE_ADJ_DATE  = T2.J_FIVE_CATE_ADJ_DATE,
               T1.J_REM_REP_PRD         = T2.J_REM_REP_PRD,
               T1.J_RPY_STATUS          = T2.J_RPY_STATUS,
               T1.J_OVERD_PRD           = T2.J_OVERD_PRD,
T1.J_TOT_OVERD_LCY = T2.J_TOT_OVERD_LCY,
               T1.J_TOT_OVERD           = T2.J_TOT_OVERD,
T1.J_LAT_RPY_AMT_LCY = T2.J_LAT_RPY_AMT_LCY,
               T1.J_LAT_RPY_AMT         = T2.J_LAT_RPY_AMT,
               T1.J_LAT_RPY_DATE        = T2.J_LAT_RPY_DATE,
               T1.J_CLOSE_DATE          = T2.J_CLOSE_DATE,
               T1.DATA_STATUS           = '00',
               T1.DATA_CHG_USER         = 'SYSTEM',
               T1.DATA_CHG_DATE         = CURRENTDATE,
               T1.DATA_CHG_TIME         = CURRENTTIME,
               T1.B_RPT_DATE            = V_DATE,
               T1.MON_SETTLE_DATE       = T2.NEW_MON_SETTLE_DATE,
               T1.CUST_NO               = T2.CUST_NO,
               T1.B_MNGMT_ORG_CODE      = T2.B_MNGMT_ORG_CODE,
               T1.GROUP_ID              = T2.GROUP_ID,
               T1.CHECK_FLAG            = 'N',
               T1.B_RPT_DATE_CODE       = RPT_DATE_CODE_OUT;

      --------------------修改数据--------------------
      --------------------新增数据开始--------------------
      MERGE INTO MBT_210 T1
      USING (SELECT DISTINCT A.*,
                             CASE
                             -- 对于R2/R3类账户，在激活之前不需要每月报送
                               WHEN A.B_ACCT_TYPE IN ('R2', 'R3') AND
                                    A.H_ACCT_STATUS = '6' THEN
                                '99'
                               WHEN SUBSTR(A.C_OPEN_DATE, 1, 6) =
                                    TO_CHAR(SYSDATE, 'YYYYMM') THEN
                                '10'
                               WHEN (A.B_ACCT_TYPE <> 'C1' AND
                                    (A.H_ACCT_STATUS in ('3', '4'))) OR
                                    (A.B_ACCT_TYPE = 'C1' AND
                                    A.J_ACCT_STATUS = '2') THEN
                                CASE
                                  WHEN A.H_CLOSE_DATE = A.MON_SETTLE_DATE AND
                                       A.B_ACCT_TYPE <> 'C1' THEN
                                   '32'
                                  ELSE
                                   '20'
                                END
                               WHEN A.B_ACCT_TYPE <> 'C1' AND
                                    SUBSTR(A.C_OPEN_DATE, 1, 6) <>
                                    TO_CHAR(SYSDATE, 'YYYYMM') THEN
                                '31'
                               WHEN A.B_ACCT_TYPE IN ('D1', 'R1', 'R2', 'R4') AND
                                    A.J_LAT_RPY_AMT IS NOT NULL AND
                                    A.J_LAT_RPY_DATE IS NOT NULL THEN
                                '40'
                               WHEN A.B_ACCT_TYPE = 'C1' AND
                                    A.J_ACCT_BAL = A.J_LAT_RPY_AMT THEN
                                '40'
                               WHEN A.B_ACCT_TYPE = 'C1' THEN
                                '99'
                               ELSE
                                '30'
                             END AS B_RPT_DATE_CODE,
                             CASE
                               WHEN A.B_ACCT_TYPE IN
                                    ('D1', 'R1', 'R2', 'R3', 'R4') THEN
                                CASE
                                  WHEN A.B_ACCT_TYPE IN ('R2', 'R3') AND
                                       A.H_ACCT_STATUS = '6' THEN
                                   ''
                                  WHEN SUBSTR(A.C_OPEN_DATE, 1, 6) =
                                       TO_CHAR(SYSDATE, 'YYYYMM') THEN
                                   '1110100|000'
                                  WHEN (A.B_ACCT_TYPE <> 'C1' AND
                                       (A.H_ACCT_STATUS in ('3', '4'))) OR
                                       (A.B_ACCT_TYPE = 'C1' AND
                                       A.J_ACCT_STATUS = '2') THEN
                                   CASE
                                     WHEN A.H_CLOSE_DATE = A.MON_SETTLE_DATE AND
                                          A.B_ACCT_TYPE <> 'C1' THEN
                                      CASE
                                        WHEN A.B_ACCT_TYPE = 'R2' THEN
                                         '1110110|000'
                                        ELSE
                                         '1110100|000'
                                      END
                                     ELSE
                                      CASE
                                        WHEN A.B_ACCT_TYPE = 'R2' THEN
                                         '1110110|000'
                                        ELSE
                                         '1110100|000'
                                      END
                                   END
                                  WHEN A.B_ACCT_TYPE <> 'C1' AND
                                       SUBSTR(A.C_OPEN_DATE, 1, 6) <>
                                       TO_CHAR(SYSDATE, 'YYYYMM') THEN
                                   CASE
                                     WHEN A.B_ACCT_TYPE = 'R2' THEN
                                      '1110110|000'
                                     ELSE
                                      '1110100|000'
                                   END
                                  WHEN A.J_LAT_RPY_AMT IS NOT NULL AND
                                       A.J_LAT_RPY_DATE IS NOT NULL AND
                                       A.B_ACCT_TYPE <> 'R3' THEN
                                   CASE
                                     WHEN A.B_ACCT_TYPE = 'R2' THEN
                                      '1000011|000'
                                     ELSE
                                      '1000001|000'
                                   END
                                  ELSE
                                   CASE
                                     WHEN A.B_ACCT_TYPE = 'R2' THEN
                                      '1110110|000'
                                     ELSE
                                      '1110100|000'
                                   END
                                END
                               WHEN A.B_ACCT_TYPE = 'C1' THEN
                                CASE
                                  WHEN SUBSTR(A.C_OPEN_DATE, 1, 6) =
                                       TO_CHAR(SYSDATE, 'YYYYMM') THEN
                                   '1101001|000'
                                  WHEN A.H_CLOSE_DATE IS NOT NULL THEN
                                   '1000001|000'
                                  WHEN A.J_ACCT_BAL = A.J_LAT_RPY_AMT THEN
                                   '1100001|000'
                                END
                             END AS IS_RPT,
                             CASE
                              /* WHEN A.H_SETT_DATE IS NOT NULL AND
                                    V_DATE <= A.H_SETT_DATE then
                                A.H_SETT_DATE
                               WHEN A.H_SETT_DATE IS NOT NULL AND
                                    A.H_ACT_RPY_AMT = A.H_CUR_RPY_AMT AND
                                    V_DATE > A.H_SETT_DATE AND
                                    V_DATE <
                                    GET_WORKDAY_NEW(A.H_SETT_DATE, 0) AND
                                    V_YEAR_MONTH =
                                    SUBSTR(GET_WORKDAY_NEW(A.H_SETT_DATE, 0),
                                           0,
                                           6) THEN
                                V_DATE
                               WHEN A.H_SETT_DATE IS NOT NULL AND
                                    A.H_ACT_RPY_AMT >= A.H_CUR_RPY_AMT AND
                                    V_DATE > A.H_SETT_DATE AND
                                    V_DATE <
                                    GET_WORKDAY_NEW(A.H_SETT_DATE, 0) AND
                                    V_YEAR_MONTH <>
                                    SUBSTR(GET_WORKDAY_NEW(A.H_SETT_DATE, 0),
                                           0,
                                           6) THEN
                                GET_WORKDAY_NEW(A.H_SETT_DATE, 0)*/
                               WHEN A.H_SETT_DATE IS NOT NULL /*AND
                                    A.H_ACT_RPY_AMT < A.H_CUR_RPY_AMT AND
                                    V_DATE > A.H_SETT_DATE AND
                                    V_DATE >
                                    GET_WORKDAY_NEW(A.H_SETT_DATE, 0)*/ THEN
                                GET_WORKDAY_NEW(A.H_SETT_DATE, 0)
                               ELSE
                                TO_CHAR(LAST_DAY(SYSDATE), 'YYYYMMDD')

                             END AS NEW_MON_SETTLE_DATE
               FROM (SELECT *
                       FROM ODS_MBT_210
                      WHERE B_ACCT_CODE IN
                            (SELECT B_ACCT_CODE
                               FROM ODS_MBT_210
                             MINUS
                             SELECT B_ACCT_CODE FROM MBT_210)) A --拿到业务表中没有的数据
             ) T2
      ON (T1.B_ACCT_CODE = T2.B_ACCT_CODE)
      WHEN NOT MATCHED THEN
        INSERT
          (T1.DATA_ID,
           T1.DATA_DATE,
           T1.CORP_ID,
           T1.ORG_ID,
           T1.GROUP_ID,
           T1.INQ_ORG_ID,
           T1.INQ_GROUP_ID,
           T1.B_INF_REC_TYPE,
           T1.B_ACCT_TYPE,
           T1.B_ACCT_CODE,
           T1.B_RPT_DATE,
           T1.B_RPT_DATE_CODE,
           T1.B_NAME,
           T1.B_ID_TYPE,
           T1.B_ID_NUM,
           T1.B_MNGMT_ORG_CODE,
           T1.C_BUSI_LINES,
           T1.C_BUSI_DTL_LINES,
           T1.C_OPEN_DATE,
           T1.C_CY,
T1.C_ACCT_CRED_LINE_AMT_LCY,
           T1.C_ACCT_CRED_LINE_AMT,
T1.C_LOAN_AMT_LCY,
           T1.C_LOAN_AMT,
           T1.C_FLAG,
           T1.C_DUE_DATE,
           T1.C_REPAY_MODE,
           T1.C_REPAY_FREQCY,
           T1.C_REPAY_PRD,
           T1.C_APPLY_BUSI_DIST,
           T1.C_GUAR_MODE,
           T1.C_OTH_REPY_GUAR_WAY,
           T1.C_ASSET_TRAND_FLAG,
           T1.C_FUND_SOU,
           T1.C_LOAN_FORM,
           T1.C_CREDIT_ID,
           T1.F_MCC,
           T1.G_INIT_CRED_NAME,
           T1.G_INIT_CRED_ORG_NM,
           T1.G_ORIG_DBT_CATE,
           T1.G_INIT_RPY_STS,
           T1.H_MONTH,
           T1.H_SETT_DATE,
           T1.H_ACCT_STATUS,
T1.H_ACCT_BAL_LCY,
           T1.H_ACCT_BAL,
T1.H_PRID_ACCT_BAL_LCY,
           T1.H_PRID_ACCT_BAL,
T1.H_USED_AMT_LCY,
           T1.H_USED_AMT,
T1.H_NOTLSU_BAL_LCY,
           T1.H_NOTLSU_BAL,
           T1.H_REM_REP_PRD,
           T1.H_FIVE_CATE,
           T1.H_FIVE_CATE_ADJ_DATE,
           T1.H_RPY_STATUS,
           T1.H_RPY_PRCT,
           T1.H_OVERD_PRD,
T1.H_TOT_OVERD_LCY,
           T1.H_TOT_OVERD,
T1.H_OVAER_PRINC_LCY,
           T1.H_OVAER_PRINC,
T1.H_OVERD31_60PRINC_LCY,
           T1.H_OVERD31_60PRINC,
T1.H_OVERD61_90PRINC_LCY,
           T1.H_OVERD61_90PRINC,
T1.H_OVERD91_180PRINC_LCY,
           T1.H_OVERD91_180PRINC,
T1.H_OVERD_PRINC180_LCY,
           T1.H_OVERD_PRINC180,
T1.H_OVERD_RAW_BA_OVE180_LCY,
           T1.H_OVERD_RAW_BA_OVE180,
T1.H_CUR_RPY_AMT_LCY,
           T1.H_CUR_RPY_AMT,
T1.H_ACT_RPY_AMT_LCY,
           T1.H_ACT_RPY_AMT,
           T1.H_LAT_RPY_DATE,
           T1.H_CLOSE_DATE,
T1.I_SPEC_LINE_LCY,
           T1.I_SPEC_LINE,
           T1.I_SPEC_EFCT_DATE,
           T1.I_SPEC_END_DATE,
T1.I_USED_INST_AMT_LCY,
           T1.I_USED_INST_AMT,
           T1.J_ACCT_STATUS,
T1.J_ACCT_BAL_LCY,
           T1.J_ACCT_BAL,
           T1.J_FIVE_CATE,
           T1.J_FIVE_CATE_ADJ_DATE,
           T1.J_REM_REP_PRD,
           T1.J_RPY_STATUS,
           T1.J_OVERD_PRD,
T1.J_TOT_OVERD_LCY,
           T1.J_TOT_OVERD,
T1.J_LAT_RPY_AMT_LCY,
           T1.J_LAT_RPY_AMT,
           T1.J_LAT_RPY_DATE,
           T1.J_CLOSE_DATE,
           T1.DATA_STATUS,
           T1.DATA_SOURCE,
           T1.DATA_CRT_USER,
           T1.DATA_CRT_DATE,
           T1.DATA_CRT_TIME,
           T1.RSV1,
           T1.RSV2,
           T1.RSV3,
           T1.RSV4,
           T1.RSV5,
           T1.IS_RPT,
           T1.MON_SETTLE_DATE,
           T1.CUST_NO,
           ---新增B_LOAN_CON_CODE||B_FIRST_HOU_LOAN_FLAG
           T1.C_LOAN_CON_CODE,
           T1.C_FIRST_HOU_LOAN_FLAG)

        VALUES
          (T2.DATA_ID,
           T2.DATA_DATE,
           T2.CORP_ID,
           T2.ORG_ID,
           T2.GROUP_ID,
           T2.ORG_ID,
           T2.ORG_ID,
           '210',
           T2.B_ACCT_TYPE,
           T2.B_ACCT_CODE,
           V_DATE,
           T2.B_RPT_DATE_CODE,
           T2.B_NAME,
           T2.B_ID_TYPE,
           T2.B_ID_NUM,
           T2.B_MNGMT_ORG_CODE,
           T2.C_BUSI_LINES,
           T2.C_BUSI_DTL_LINES,
           T2.C_OPEN_DATE,
           T2.C_CY,
T2.C_ACCT_CRED_LINE_AMT_LCY,
           T2.C_ACCT_CRED_LINE_AMT,
T2.C_LOAN_AMT_LCY,
           T2.C_LOAN_AMT,
           T2.C_FLAG,
           T2.C_DUE_DATE,
           T2.C_REPAY_MODE,
           T2.C_REPAY_FREQCY,
           T2.C_REPAY_PRD,
           T2.C_APPLY_BUSI_DIST,
           T2.C_GUAR_MODE,
           T2.C_OTH_REPY_GUAR_WAY,
           T2.C_ASSET_TRAND_FLAG,
           T2.C_FUND_SOU,
           T2.C_LOAN_FORM,
           T2.C_CREDIT_ID,
           T2.F_MCC,
           T2.G_INIT_CRED_NAME,
           T2.G_INIT_CRED_ORG_NM,
           T2.G_ORIG_DBT_CATE,
           T2.G_INIT_RPY_STS,
           T2.H_MONTH,
           T2.H_SETT_DATE,
           T2.H_ACCT_STATUS,
T2.H_ACCT_BAL_LCY,
           T2.H_ACCT_BAL,
T2.H_PRID_ACCT_BAL_LCY,
           T2.H_PRID_ACCT_BAL,
T2.H_USED_AMT_LCY,
           T2.H_USED_AMT,
T2.H_NOTLSU_BAL_LCY,
           T2.H_NOTLSU_BAL,
           T2.H_REM_REP_PRD,
           T2.H_FIVE_CATE,
           T2.H_FIVE_CATE_ADJ_DATE,
           T2.H_RPY_STATUS,
           T2.H_RPY_PRCT,
           T2.H_OVERD_PRD,
T2.H_TOT_OVERD_LCY,
           T2.H_TOT_OVERD,
T2.H_OVAER_PRINC_LCY,
           T2.H_OVAER_PRINC,
T2.H_OVERD31_60PRINC_LCY,
           T2.H_OVERD31_60PRINC,
T2.H_OVERD61_90PRINC_LCY,
           T2.H_OVERD61_90PRINC,
T2.H_OVERD91_180PRINC_LCY,
           T2.H_OVERD91_180PRINC,
T2.H_OVERD_PRINC180_LCY,
           T2.H_OVERD_PRINC180,
T2.H_OVERD_RAW_BA_OVE180_LCY,
           T2.H_OVERD_RAW_BA_OVE180,
T2.H_CUR_RPY_AMT_LCY,
           T2.H_CUR_RPY_AMT,
T2.H_ACT_RPY_AMT_LCY,
           T2.H_ACT_RPY_AMT,
           T2.H_LAT_RPY_DATE,
           T2.H_CLOSE_DATE,
T2.I_SPEC_LINE_LCY,
           T2.I_SPEC_LINE,
           T2.I_SPEC_EFCT_DATE,
           T2.I_SPEC_END_DATE,
T2.I_USED_INST_AMT_LCY,
           T2.I_USED_INST_AMT,
           T2.J_ACCT_STATUS,
T2.J_ACCT_BAL_LCY,
           T2.J_ACCT_BAL,
           T2.J_FIVE_CATE,
           T2.J_FIVE_CATE_ADJ_DATE,
           T2.J_REM_REP_PRD,
           T2.J_RPY_STATUS,
           T2.J_OVERD_PRD,
T2.J_TOT_OVERD_LCY,
           T2.J_TOT_OVERD,
T2.J_LAT_RPY_AMT_LCY,
           T2.J_LAT_RPY_AMT,
           T2.J_LAT_RPY_DATE,
           T2.J_CLOSE_DATE,
           '00',
           '2',
           'SYSTEM',
           CURRENTDATE,
           CURRENTTIME,
           T2.RSV1,
           T2.RSV2,
           T2.RSV3,
           T2.RSV4,
           T2.RSV5,
           T2.IS_RPT,
           T2.NEW_MON_SETTLE_DATE,
           T2.CUST_NO,
           ---新增B_LOAN_CON_CODE||B_FIRST_HOU_LOAN_FLAG
           T2.C_LOAN_CON_CODE,
           T2.C_FIRST_HOU_LOAN_FLAG);


      --------------------新增结束--------------------
      --------------------修改子表[MBT_210_D]数据开始--------------------
      -- 先删除所有相关数据 然后重新插入
      DELETE FROM MBT_210_D
       WHERE B_ACCT_CODE IN (SELECT DISTINCT B_ACCT_CODE FROM ODS_MBT_210);
      --------------------新增数据开始--------------------
      MERGE INTO MBT_210_D T1
      USING (SELECT A.DATA_ID,
                    A.DATA_DATE,
                    A.D_ARLP_ID_TYPE,
                    A.D_ARLP_NAME,
                    A.D_ARLP_CERT_TYPE,
                    A.D_ARLP_CERT_NUM,
                    A.D_ARLP_TYPE,
                    A.D_ARLP_AMT,
					A.D_ARLP_AMT_ORG,
                    A.D_WARTY_SIGN,
                    A.D_MAX_GUAR_MCC,
                    A.RSV1,
                    A.RSV2,
                    A.RSV3,
                    A.RSV4,
                    A.RSV5,
                    A.B_ACCT_CODE,
                    CASE
                      WHEN C.DATA_ID IS NULL THEN
                       A.PDATA_ID
                      ELSE
                       C.DATA_ID
                    END AS PDATA_ID
               FROM ODS_MBT_210_D A
               LEFT JOIN ODS_MBT_210 B
                 ON A.PDATA_ID = B.DATA_ID
               LEFT JOIN MBT_210 C
                 ON B.B_ACCT_CODE = C.B_ACCT_CODE) T2
      ON (T1.D_ARLP_ID_TYPE = T2.D_ARLP_ID_TYPE AND T1.D_ARLP_NAME = T2.D_ARLP_NAME AND T1.D_ARLP_CERT_TYPE = T2.D_ARLP_CERT_TYPE AND T1.D_ARLP_CERT_NUM = T2.D_ARLP_CERT_NUM AND T1.D_ARLP_TYPE = T2.D_ARLP_TYPE AND T1.D_WARTY_SIGN = T2.D_WARTY_SIGN AND T1.D_MAX_GUAR_MCC = T2.D_MAX_GUAR_MCC AND T1.B_ACCT_CODE = T2.B_ACCT_CODE)
      WHEN NOT MATCHED THEN
        INSERT
          (T1.DATA_ID,
           T1.DATA_DATE,
           T1.PDATA_ID,
           T1.D_ARLP_ID_TYPE,
           T1.D_ARLP_NAME,
           T1.D_ARLP_CERT_TYPE,
           T1.D_ARLP_CERT_NUM,
           T1.D_ARLP_TYPE,
           T1.D_ARLP_AMT,
		   T1.D_ARLP_AMT_ORG,
           T1.D_WARTY_SIGN,
           T1.D_MAX_GUAR_MCC,
           T1.DATA_SOURE,
           T1.DATA_CRT_USER,
           T1.DATA_CRT_DATE,
           T1.DATA_CRT_TIME,
           T1.RSV1,
           T1.RSV2,
           T1.RSV3,
           T1.RSV4,
           T1.RSV5,
           T1.B_ACCT_CODE)
        VALUES
          (T2.DATA_ID,
           T2.DATA_DATE,
           T2.PDATA_ID,
           T2.D_ARLP_ID_TYPE,
           T2.D_ARLP_NAME,
           T2.D_ARLP_CERT_TYPE,
           T2.D_ARLP_CERT_NUM,
           T2.D_ARLP_TYPE,
           T2.D_ARLP_AMT,
		   T2.D_ARLP_AMT_ORG,
           T2.D_WARTY_SIGN,
           T2.D_MAX_GUAR_MCC,
           '2',
           'SYSTEM',
           CURRENTDATE,
           CURRENTTIME,
           T2.RSV1,
           T2.RSV2,
           T2.RSV3,
           T2.RSV4,
           'FLAG',
           T2.B_ACCT_CODE);

      --更改主表数据状态
      MERGE INTO MBT_210 T1
      USING (SELECT DISTINCT B.DATA_ID
               FROM MBT_210_D A
               LEFT JOIN MBT_210 B
                 ON A.PDATA_ID = B.DATA_ID
              WHERE A.RSV5 = 'FLAG') T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.DATA_STATUS = '00';

      UPDATE MBT_210_D SET RSV5 = NULL WHERE RSV5 = 'FLAG';
      --------------------修改子表[MBT_210_D]数据结束--------------------

      --------------------修改子表[MBT_210_E]数据开始--------------------
      -- 先删除所有相关数据 然后重新插入
      DELETE FROM MBT_210_E
       WHERE B_ACCT_CODE IN (SELECT DISTINCT B_ACCT_CODE FROM ODS_MBT_210);
      --------------------新增数据开始--------------------
      MERGE INTO MBT_210_E T1
      USING (SELECT A.DATA_ID,
                    A.DATA_DATE,
                    A.E_CCC,
                    A.RSV1,
                    A.RSV2,
                    A.RSV3,
                    A.RSV4,
                    A.RSV5,
                    A.B_ACCT_CODE,
                    CASE
                      WHEN C.DATA_ID IS NULL THEN
                       A.PDATA_ID
                      ELSE
                       C.DATA_ID
                    END AS PDATA_ID
               FROM ODS_MBT_210_E A
               LEFT JOIN ODS_MBT_210 B
                 ON A.PDATA_ID = B.DATA_ID
               LEFT JOIN MBT_210 C
                 ON B.B_ACCT_CODE = C.B_ACCT_CODE) T2
      ON (T1.E_CCC = T2.E_CCC)
      WHEN NOT MATCHED THEN
        INSERT
          (T1.DATA_ID,
           T1.PDATA_ID,
           T1.DATA_DATE,
           T1.E_CCC,
           T1.DATA_SOURE,
           T1.DATA_CRT_USER,
           T1.DATA_CRT_DATE,
           T1.DATA_CRT_TIME,
           T1.RSV1,
           T1.RSV2,
           T1.RSV3,
           T1.RSV4,
           T1.RSV5,
           T1.B_ACCT_CODE)
        VALUES
          (T2.DATA_ID,
           T2.PDATA_ID,
           T2.DATA_DATE,
           T2.E_CCC,
           '2',
           'SYSTEM',
           CURRENTDATE,
           CURRENTTIME,
           T2.RSV1,
           T2.RSV2,
           T2.RSV3,
           T2.RSV4,
           'FLAG',
           T2.B_ACCT_CODE);

      --更改主表数据状态
      MERGE INTO MBT_210 T1
      USING (SELECT DISTINCT B.DATA_ID
               FROM MBT_210_E A
               LEFT JOIN MBT_210 B
                 ON A.PDATA_ID = B.DATA_ID
              WHERE A.RSV5 = 'FLAG') T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.DATA_STATUS = '00';

      UPDATE MBT_210_E SET RSV5 = NULL WHERE RSV5 = 'FLAG';
      --------------------修改子表[MBT_210_E]数据结束--------------------

      --------------------修改子表[MBT_210_K]数据开始--------------------
      -- 先删除所有相关数据 然后重新插入
      DELETE FROM MBT_210_K
       WHERE B_ACCT_CODE IN (SELECT DISTINCT B_ACCT_CODE FROM ODS_MBT_210);
      --------------------新增数据开始--------------------
      MERGE INTO MBT_210_K T1
      USING (SELECT A.DATA_ID,
                    A.DATA_DATE,
                    A.REF_NO,
                    A.K_CHAN_TRAN_TYPE,
                    A.K_TRAN_DATE,
                    A.K_TRAN_AMT,
					A.K_TRAN_AMT_ORG,
                    A.K_DUE_TRAN_MON,
                    A.K_DET_INFO,
                    A.RSV1,
                    A.RSV2,
                    A.RSV3,
                    A.RSV4,
                    A.RSV5,
                    A.B_ACCT_CODE,
                    CASE
                      WHEN C.DATA_ID IS NULL THEN
                       A.PDATA_ID
                      ELSE
                       C.DATA_ID
                    END AS PDATA_ID
               FROM ODS_MBT_210_K A
               LEFT JOIN ODS_MBT_210 B
                 ON A.PDATA_ID = B.DATA_ID
               LEFT JOIN MBT_210 C
                 ON B.B_ACCT_CODE = C.B_ACCT_CODE) T2
      ON (T1.REF_NO = T2.REF_NO)
      WHEN NOT MATCHED THEN
        INSERT
          (T1.DATA_ID,
           T1.DATA_DATE,
           T1.PDATA_ID,
           T1.REF_NO,
           T1.K_CHAN_TRAN_TYPE,
           T1.K_TRAN_DATE,
           T1.K_TRAN_AMT,
		   T1.K_TRAN_AMT_ORG,
           T1.K_DUE_TRAN_MON,
           T1.K_DET_INFO,
           T1.DATA_SOURE,
           T1.DATA_CRT_USER,
           T1.DATA_CRT_DATE,
           T1.DATA_CRT_TIME,
           T1.RSV1,
           T1.RSV2,
           T1.RSV3,
           T1.RSV4,
           T1.RSV5,
           T1.B_ACCT_CODE)
        VALUES
          (T2.DATA_ID,
           T2.DATA_DATE,
           T2.PDATA_ID,
           T2.REF_NO,
           T2.K_CHAN_TRAN_TYPE,
           T2.K_TRAN_DATE,
           T2.K_TRAN_AMT,
		   T2.K_TRAN_AMT_ORG,
           T2.K_DUE_TRAN_MON,
           T2.K_DET_INFO,
           '2',
           'SYSTEM',
           CURRENTDATE,
           CURRENTTIME,
           T2.RSV1,
           T2.RSV2,
           T2.RSV3,
           T2.RSV4,
           'FLAG',
           T2.B_ACCT_CODE);

      --更改主表数据状态
      MERGE INTO MBT_210 T1
      USING (SELECT DISTINCT B.DATA_ID
               FROM MBT_210_K A
               LEFT JOIN MBT_210 B
                 ON A.PDATA_ID = B.DATA_ID
              WHERE A.RSV5 = 'FLAG') T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.DATA_STATUS = '00';

      UPDATE MBT_210_K SET RSV5 = NULL WHERE RSV5 = 'FLAG';
      --------------------修改子表[MBT_210_K]数据结束--------------------
      --------------------修改报告时点--------------------
      MERGE INTO MBT_210 T1
      USING (SELECT DISTINCT A.DATA_ID,
                             CASE
                             -- 对于R2/R3类账户，在激活之前不需要每月报送
                               WHEN A.B_ACCT_TYPE IN ('R2 ', 'R3') AND
                                    A.H_ACCT_STATUS = '6' THEN
                                '99'
                               WHEN A.C_OPEN_DATE = V_DATE AND
                                    ((A.B_ACCT_TYPE <> 'C1' AND
                                    A.H_ACCT_STATUS NOT IN ('3', '4')) OR
                                    ((A.B_ACCT_TYPE = 'C1' AND
                                    A.H_ACCT_STATUS <> '2'))) AND
                                    E.DATA_ID IS NULL THEN
                                '10'
                               WHEN ((A.B_ACCT_TYPE <> 'C1' AND
                                    (A.H_ACCT_STATUS in ('3', '4'))) OR
                                    (A.B_ACCT_TYPE = 'C1' AND
                                    A.J_ACCT_STATUS = '2')) AND
                                    nvl(H.CNT, 0) = 0 AND
                                    E.DATA_ID IS NOT NULL AND
                                    A.MON_SETTLE_DATE = V_DATE THEN
                                '32'
                               WHEN ((A.B_ACCT_TYPE <> 'C1' AND
                                    (A.H_ACCT_STATUS in ('3', '4'))) OR
                                    (A.B_ACCT_TYPE = 'C1' AND
                                    A.J_ACCT_STATUS = '2')) AND
                                    nvl(H.CNT, 0) = 0 AND
                                    E.DATA_ID IS NOT NULL THEN
                                '20'
                             --允许首次上报有tday关闭的数据
                               WHEN /*((A.B_ACCT_TYPE <> 'C1' AND (A.H_ACCT_STATUS NOT in ('3', '4'))) OR (A.B_ACCT_TYPE = 'C1' AND A.J_ACCT_STATUS <> '2'))
                                                                                                                                                                                                                       AND*/
                                A.MON_SETTLE_DATE = V_DATE AND
                                nvl(H.CNT, 0) = 0 AND nvl(G.CNT, 0) = 0 THEN
                                '31'
                             --                        WHEN A.B_ACCT_TYPE IN ('D1', 'R1',  'R4') AND   A.J_TOT_OVERD  IS NOT NULL AND
                             --                             A.J_LAT_RPY_AMT IS NOT NULL AND A.J_LAT_RPY_DATE IS NOT NULL AND A.J_TOT_OVERD = A.J_LAT_RPY_AMT  AND
                             --                             F.DATA_ID IS NULL THEN
                             --                         '40'
                             --                        WHEN A.B_ACCT_TYPE IN ('R2','C1') AND   A.J_ACCT_BAL IS NOT NULL AND
                             --                             A.J_LAT_RPY_AMT IS NOT NULL  AND A.J_LAT_RPY_DATE IS NOT NULL AND A.J_ACCT_BAL = A.J_LAT_RPY_AMT AND
                             --                             F.DATA_ID IS NULL THEN
                             --                         '40'
                               WHEN A.B_ACCT_TYPE IN ('D1', 'R1', 'R4') AND
                                    A.H_TOT_OVERD = 0 AND I.H_TOT_OVERD <> 0 AND
                                    A.B_RPT_DATE <> A.MON_SETTLE_DATE AND
                                    F.DATA_ID IS NULL THEN
                                '40'
                               WHEN A.B_ACCT_TYPE IN ('R2', 'C1') AND
                                    A.B_RPT_DATE <> A.MON_SETTLE_DATE AND
                                    F.DATA_ID IS NULL THEN
                                '40'
                               WHEN A.B_ACCT_TYPE = 'C1' THEN
                                '99'
                               ELSE
                               ---ZHAO
                                CASE
                                  WHEN (SUBSTR(E.B_RPT_DATE, 1, 6) !=
                                       V_YEAR_MONTH
                                       /* TO_CHAR(SYSDATE, 'YYYYMM')*/ /* AND
                                                                                                                                                                                                                                 E.B_RPT_DATE_CODE != '30'*/
                                       OR (SUBSTR(E.B_RPT_DATE, 1, 6) =
                                       V_YEAR_MONTH AND
                                       E.B_RPT_DATE_CODE != '30')) AND
                                       A.MON_SETTLE_DATE IS NOT NULL AND
                                       V_DATE = A.MON_SETTLE_DATE THEN
                                   '30'
                                  ELSE
                                   '99'
                                END
                             END AS NEW_B_RPT_DATE_CODE
               FROM MBT_210 A
               LEFT JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_ACCT_CODE ORDER BY RPT_TIME DESC) RN,
                                        T.*
                                   FROM MBT_210_RPT T
                                  WHERE DATA_STATUS = '27')
                          WHERE RN = 1) E
                 ON A.B_ACCT_CODE = E.B_ACCT_CODE
               LEFT JOIN MBT_210_RPT F
                 ON A.B_ACCT_CODE = F.B_ACCT_CODE
                AND SUBSTR(A.J_LAT_RPY_DATE, 1, 6) =
                    SUBSTR(F.B_RPT_DATE, 1, 6)
                AND F.B_RPT_DATE_CODE = '40'
                AND F.DATA_STATUS = '27'
               left join (select count(1) cnt, B_ACCT_CODE
                           from MBT_210_RPT
                          WHERE DATA_STATUS = '27'
                            and (B_RPT_DATE_CODE IN ('20', '32') OR
                                (B_RPT_DATE_CODE = '31' AND
                                ((B_ACCT_TYPE <> 'C1' AND
                                (H_ACCT_STATUS in ('3', '4'))) OR
                                (B_ACCT_TYPE = 'C1' AND
                                J_ACCT_STATUS = '2'))))
                          GROUP BY B_ACCT_CODE) H
                 ON A.B_ACCT_CODE = H.B_ACCT_CODE
               left join (select count(1) cnt, B_ACCT_CODE
                           from MBT_210_RPT
                          WHERE DATA_STATUS = '27'
                            and B_RPT_DATE_CODE = '31'
                          GROUP BY B_ACCT_CODE) G
                 ON A.B_ACCT_CODE = G.B_ACCT_CODE
               left join MBT_210_RPT I
                 ON A.B_ACCT_CODE = I.B_ACCT_CODE
                AND I.B_RPT_DATE = V_YE_DATE
                AND I.DATA_STATUS = '27') T2
      ON (T1.DATA_ID = T2.DATA_ID)
      WHEN MATCHED THEN
        UPDATE SET T1.B_RPT_DATE_CODE = T2.NEW_B_RPT_DATE_CODE;
      --------------------修改报告时点--------------------

      --------------------更新IS_RPT开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_210',
                              'T.B_ACCT_CODE',
                              'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              B_ARRAYLIST,
                              1,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                 AND INSTR(T3.ACCT_TYPE, T1.B_ACCT_TYPE) > 0
                 AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_210',
                              'T.B_ACCT_CODE',
                              'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              C_ARRAYLIST,
                              2,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                 AND INSTR(T3.ACCT_TYPE, T1.B_ACCT_TYPE) > 0
                 AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_210',
                              'T.B_ACCT_CODE',
                              'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              F_ARRAYLIST,
                              3,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                 AND INSTR(T3.ACCT_TYPE, T1.B_ACCT_TYPE) > 0
                 AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_210',
                              'T.B_ACCT_CODE',
                              'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              G_ARRAYLIST,
                              4,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                 AND INSTR(T3.ACCT_TYPE, T1.B_ACCT_TYPE) > 0
                 AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_210',
                              'T.B_ACCT_CODE',
                              'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              H_ARRAYLIST,
                              5,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                 AND INSTR(T3.ACCT_TYPE, T1.B_ACCT_TYPE) > 0
                 AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_210',
                              'T.B_ACCT_CODE',
                              'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              I_ARRAYLIST,
                              6,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                 AND INSTR(T3.ACCT_TYPE, T1.B_ACCT_TYPE) > 0
                 AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      SP_ODS_MBT_CAL_RPT_PROC('MBT_210',
                              'T.B_ACCT_CODE',
                              'T1.B_ACCT_CODE = T2.B_ACCT_CODE',
                              J_ARRAYLIST,
                              7,
                              null,
                              'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                 AND INSTR(T3.ACCT_TYPE, T1.B_ACCT_TYPE) > 0
                 AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                              NULL);
      --------------------修改子表[MBT_220_D] IS_RPT开始--------------------
      /* SP_ODS_MBT_CAL_RPT_PROC('MBT_210_D',
                  'T.D_ARLP_CERT_TYPE,T.D_ARLP_CERT_NUM',
                  'T1.D_ARLP_CERT_TYPE=T2.D_ARLP_CERT_TYPE AND T1.D_ARLP_CERT_NUM=T2.D_ARLP_CERT_NUM',
                  D_ARRAYLIST,
                  9,
                  'MBT_210',
                  'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
      AND INSTR(T4.ACCT_TYPE,T3.B_ACCT_TYPE) > 0
      AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                  NULL);*/

      SP_ODS_MBT_CAL_RPT_PROC('MBT_210_D',
                              'T.B_ACCT_CODE,T.D_ARLP_ID_TYPE,T.D_ARLP_NAME,T.D_ARLP_CERT_TYPE,T.D_ARLP_CERT_NUM,T.D_ARLP_TYPE,T.D_WARTY_SIGN,T.D_MAX_GUAR_MCC',
                              'T1.B_ACCT_CODE =T2.B_ACCT_CODE AND T1.D_ARLP_ID_TYPE =T2.D_ARLP_ID_TYPE AND T1.D_ARLP_NAME =T2.D_ARLP_NAME  AND T1.D_ARLP_CERT_TYPE =T2.D_ARLP_CERT_TYPE AND T1.D_ARLP_CERT_NUM =T2.D_ARLP_CERT_NUM AND T1.D_ARLP_TYPE =T2.D_ARLP_TYPE AND T1.D_WARTY_SIGN =T2.D_WARTY_SIGN AND T1.D_MAX_GUAR_MCC =T2.D_MAX_GUAR_MCC',
                              D_ARRAYLIST,
                              9,
                              'MBT_210',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND INSTR(T4.ACCT_TYPE,T3.B_ACCT_TYPE) > 0
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              NULL);
      --------------------修改子表[MBT_220_D] IS_RPT结束--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_210_E',
                              'T.E_CCC',
                              'T1.E_CCC=T2.E_CCC',
                              E_ARRAYLIST,
                              10,
                              'MBT_210',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND INSTR(T4.ACCT_TYPE,T3.B_ACCT_TYPE) > 0
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              NULL);
      --------------------修改子表[MBT_220_E] IS_RPT结束--------------------
      --------------------修改子表[MBT_220_K] IS_RPT开始--------------------
      SP_ODS_MBT_CAL_RPT_PROC('MBT_210_K',
                              'T.REF_NO',
                              'T1.REF_NO=T2.REF_NO',
                              K_ARRAYLIST,
                              11,
                              'MBT_210',
                              'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                  AND INSTR(T4.ACCT_TYPE,T3.B_ACCT_TYPE) > 0
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                              NULL);
      --------------------修改子表[MBT_220_K] IS_RPT结束--------------------
      --------------------更新IS_RPT结束--------------------

      --------------------处理RPT_DATE开始--------------------
      --只处理从ods来的数据并且今天插入或者今天修改的数据
      --采集时点为账户关闭时，若已经报送过账户关闭日期所在月的月度表现信息段，
      --则本次报送该段落中“月份”数据项填写账户关闭日期所在月次月,同时'结算/应还款日'填空
      MERGE INTO MBT_210 T1
      USING (SELECT A.DATA_ID,
                    CASE
                      WHEN A.B_RPT_DATE_CODE = '20' THEN
                       CASE
                         WHEN C.DATA_ID IS NOT NULL THEN
                          TO_CHAR(ADD_MONTHS(TO_DATE(A.H_CLOSE_DATE, 'YYYYMMDD'),
                                             1),
                                  'YYYYMMDD')
                         ELSE
                          A.H_CLOSE_DATE
                       END
                      ELSE
                       A.H_CLOSE_DATE
                    END AS H_CLOSE_DATE
               FROM MBT_210 A
               JOIN MBT_210_RPT C
                 ON A.B_ACCT_CODE = C.B_ACCT_CODE
                AND SUBSTR(C.B_RPT_DATE, 1, 6) =
                    SUBSTR(A.H_CLOSE_DATE, 1, 6)
                AND C.DATA_STATUS = '27') T2
      ON (T1.DATA_ID = T2.DATA_ID AND T1.DATA_SOURCE = '2' AND (T1.DATA_CRT_DATE = CURRENTDATE OR T1.DATA_CHG_DATE = CURRENTDATE))
      WHEN MATCHED THEN
        UPDATE
           SET T1.H_MONTH     = SUBSTR(T2.H_CLOSE_DATE, 1, 6),
               T1.H_SETT_DATE = null;
      --------------------处理RPT_DATE结束--------------------
    --不能清空
   /*   --若时点不是月结日，需要清除月结日的值
      UPDATE MBT_210
         SET MON_SETTLE_DATE = NULL
       WHERE B_RPT_DATE_CODE NOT IN ('30', '31', '32');*/

      --数据插入历史表，然后删除ODS表
      INSERT INTO ODS_MBT_210_HIS
        SELECT * FROM ODS_MBT_210;
      DELETE FROM ODS_MBT_210;

      INSERT INTO ODS_MBT_210_D_HIS
        SELECT * FROM ODS_MBT_210_D;
      DELETE FROM ODS_MBT_210_D;

      INSERT INTO ODS_MBT_210_E_HIS
        SELECT * FROM ODS_MBT_210_E;
      DELETE FROM ODS_MBT_210_E;

      INSERT INTO ODS_MBT_210_K_HIS
        SELECT * FROM ODS_MBT_210_K;
      DELETE FROM ODS_MBT_210_K;

      --将报告时点代码是88或99的直接审核通过并将校验修改为校验通过
      UPDATE mbt_210
         SET DATA_STATUS = '21', CHECK_FLAG = 'Y'
       WHERE DATA_DATE <= CURRENTDATE
         AND (B_RPT_DATE_CODE = '88' OR B_RPT_DATE_CODE = '99')
         AND DATA_STATUS = '00';
      --RBWM 需求月结日默认取宽限期最后一天，信息报告日期也要更新成月结日
        UPDATE mbt_210
         SET B_RPT_DATE=V_DATE
       WHERE  B_RPT_DATE_CODE = '30';
      --将报告时点代码不是88或99的校验修改为未校验ZHAO
      /*  UPDATE mbt_210
        SET CHECK_FLAG = 'N'
      WHERE DATA_DATE <= CURRENTDATE
        AND (B_RPT_DATE_CODE NOT IN('88', '99'))
        AND DATA_STATUS = '00';*/
    END;
  END IF;
  UPDATE mbt_210
     SET is_rpt = SUBSTR(IS_RPT, 0, 2) || 0 || SUBSTR(IS_RPT, 4, 8)
   WHERE B_RPT_DATE_CODE <> '40'
     AND B_RPT_DATE_CODE <> '88'
     AND B_RPT_DATE_CODE <> '99'
     AND B_ACCT_TYPE = 'D1'
     AND C_FLAG = '0';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ERRCODE := SQLCODE;
    ERRMSG  := SUBSTR(SQLERRM, 1, 200);
    SP_MBT_LOG(1,
               'SP_ODS_MBT_210',
               'ERROR21001',
               '新增失败：' || ERRMSG,
               ERRCODE,
               ERRMSG);
    ROLLBACK;

    ENDTIME := TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS');
    DSC     := '##=======MBT210存储过程==结束' || ENDTIME || '========##';
    DBMS_OUTPUT.PUT_LINE(DSC);
    DBMS_OUTPUT.PUT_LINE(dbms_utility.format_error_backtrace());
END;

