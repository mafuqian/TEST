CREATE OR REPLACE PROCEDURE "SP_ODS_MBT_220"(ERRCODE           IN OUT VARCHAR,
                                             ERRMSG            IN OUT VARCHAR,
                                             TABLE_KEY         IN VARCHAR2,
                                             RPT_DATE_CODE_OUT IN OUT VARCHAR2) AS
  DSC         VARCHAR2(1000);
  BEGINTIME   VARCHAR2(20);
  ENDTIME     VARCHAR2(20);
  CURRENTDATE VARCHAR2(8);
  CURRENTTIME VARCHAR2(14);
  B_ARRAYLIST VARCHAR2(4000);
  C_ARRAYLIST VARCHAR2(4000);
  D_ARRAYLIST VARCHAR2(4000);
  IS_RPT_OUT  VARCHAR2(64);
  V_DATE  VARCHAR2(8) ;
BEGIN
  B_ARRAYLIST := 'B_NAME,B_ID_TYPE,B_ID_NUM,B_CONTRACT_NO,B_MNGMT_ORG_CODE';
  C_ARRAYLIST := 'C_BRER_TYPE, C_CERT_REL_NAME';
  D_ARRAYLIST := 'D_CREDIT_LIM_TYPE,D_LIM_LOOP_FLG,D_CREDIT_LIM_LCY,D_CY,
                                     D_CON_EFF_DATE,D_CON_EXP_DATE,D_CON_STATUS,D_CREDIT_REST_LCY,D_CREDIT_REST_CODE';
  CURRENTDATE := TO_CHAR(SYSDATE, 'YYYYMMDD');
  CURRENTTIME := TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS');
  BEGINTIME   := TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS');
  V_DATE := GET_NEW_DAY(CURRENTDATE);
  DSC         := '##=======MBT220存储过程==开始' || BEGINTIME || '========##';
  DBMS_OUTPUT.PUT_LINE(DSC);

  IF TABLE_KEY IS NOT NULL THEN
    --处理从页面来的数据 计算时点
    BEGIN
      --计算报告时点
      SELECT CASE
              --没有上报过且额度状态不为2-到期/失效  --- 10
               WHEN B.DATA_ID IS NULL and A.D_CON_STATUS <> '2' THEN
                '10'
        --已经上报过记录且没上报过20-授信到期/失效且额度状态为2-到期/失效
               WHEN B.DATA_ID IS NOT NULL and A.D_CON_STATUS = '2' AND nvl(C.CNT,0)=0 THEN
                '20'
         --已经上报过记录且没上报过20-授信到期/失效且当前的授信额度与上次上报成功的授信额度相比有调整
               WHEN B.DATA_ID IS NOT NULL and A.D_CREDIT_LIM <> B.D_CREDIT_LIM AND nvl(C.CNT,0)=0 THEN
                '30'
         --其他情况均为99
               ELSE
                '99'
             END
        INTO RPT_DATE_CODE_OUT
        FROM MBT_220 A
        LEFT JOIN (SELECT *
                     FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_CONTRACT_CODE ORDER BY RPT_TIME DESC) RN,
                                  T.*
                             FROM MBT_220_RPT T
                            WHERE DATA_STATUS = '27')
                    WHERE RN = 1) B
          ON A.B_CONTRACT_CODE = B.B_CONTRACT_CODE
    left join (select count(1) cnt,B_CONTRACT_CODE from MBT_220_RPT  WHERE DATA_STATUS = '27' and B_RPT_DATE_CODE='20' GROUP BY B_CONTRACT_CODE) C
    ON A.B_CONTRACT_CODE = C.B_CONTRACT_CODE
       WHERE A.DATA_ID = TABLE_KEY;

      SELECT IS_RPT INTO IS_RPT_OUT FROM MBT_220 WHERE DATA_ID = TABLE_KEY;
      IF IS_RPT_OUT IS NULL THEN
        UPDATE MBT_220 SET IS_RPT = '11|0' WHERE DATA_ID = TABLE_KEY;
      END IF;

        --------------------修改B段IS_RPT开始--------------------
        SP_ODS_MBT_CAL_RPT_PROC('MBT_220',
                                'T.B_CONTRACT_CODE',
                                'T1.B_CONTRACT_CODE=T2.B_CONTRACT_CODE',
                                B_ARRAYLIST,
                                1,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                TABLE_KEY);
        --------------------修改B段IS_RPT结束--------------------
        --------------------修改D段IS_RPT开始--------------------
        SP_ODS_MBT_CAL_RPT_PROC('MBT_220',
                                'T.B_CONTRACT_CODE',
                                'T1.B_CONTRACT_CODE=T2.B_CONTRACT_CODE',
                                D_ARRAYLIST,
                                2,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                    AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                TABLE_KEY);
        --------------------修改D段IS_RPT结束--------------------
        --------------------修改子表[MBT_220_C]数据开始--------------------
        SP_ODS_MBT_CAL_RPT_PROC('MBT_220_C',
                                'T.C_CERT_REL_ID_TYPE,T.C_CERT_REL_ID_NUM,T.B_CONTRACT_CODE',
                                'T1.B_CONTRACT_CODE = T2.B_CONTRACT_CODE AND T1.C_CERT_REL_ID_TYPE=T2.C_CERT_REL_ID_TYPE AND T1.C_CERT_REL_ID_NUM=T2.C_CERT_REL_ID_NUM',
                                C_ARRAYLIST,
                                4,
                                'MBT_220',
                                'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                    AND T4.ACCT_TYPE IS NULL
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                                TABLE_KEY);
        --------------------修改子表[MBT_220_C]数据开始--------------------
    END;
  ELSE
    BEGIN
      --------------------备份数据--------------------
      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_220_TODAY_BAK';
      INSERT INTO MBT_220_TODAY_BAK
        SELECT * FROM MBT_220;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE MBT_220_C_TODAY_BAK';
      INSERT INTO MBT_220_C_TODAY_BAK
        SELECT * FROM MBT_220_C;
      --------------------备份数据--------------------
      --------------------修改数据--------------------
      MERGE INTO MBT_220 T1
      USING (SELECT A.*,
                    CASE
                      WHEN INSTR(B.B_NAME || B.B_ID_TYPE || B.B_ID_NUM ||
                                 B.B_CONTRACT_NO ||B.B_MNGMT_ORG_CODE|| B.D_CREDIT_LIM_TYPE ||
                                 B.D_LIM_LOOP_FLG || B.D_CREDIT_LIM || B.D_CREDIT_LIM_LCY || B.D_CY ||
                                 B.D_CON_EFF_DATE || B.D_CON_EXP_DATE ||
                                 B.D_CON_STATUS || B.D_CREDIT_REST ||B.D_CREDIT_REST_LCY ||
                                 B.D_CREDIT_REST_CODE || '1', --避免删除最后一个段的时候  INSTR 还为1
                                 A.B_NAME || A.B_ID_TYPE || A.B_ID_NUM ||
                                 A.B_CONTRACT_NO ||A.B_MNGMT_ORG_CODE|| A.D_CREDIT_LIM_TYPE ||
                                 A.D_LIM_LOOP_FLG || A.D_CREDIT_LIM || A.D_CREDIT_LIM_LCY || A.D_CY ||
                                 A.D_CON_EFF_DATE || A.D_CON_EXP_DATE ||
                                 A.D_CON_STATUS || A.D_CREDIT_REST || A.D_CREDIT_REST_LCY ||
                                 A.D_CREDIT_REST_CODE || '1') > 0 THEN --避免删除最后一个段的时候  INSTR 还为1
                       'N'
                      ELSE
                       'Y'
                    END AS UPDATE_FLAG
               FROM ODS_MBT_220 A
              INNER JOIN (SELECT *
                           FROM (SELECT ROW_NUMBER() OVER(PARTITION BY T.B_CONTRACT_CODE ORDER BY DATA_LOAD_TIME DESC) RN,
                                        T.*
                                   FROM ODS_MBT_220_HIS T
                                  ORDER BY T.DATA_LOAD_TIME DESC)
                          WHERE RN = 1) B
                 ON A.B_CONTRACT_CODE = B.B_CONTRACT_CODE) T2
      ON (T1.B_CONTRACT_CODE = T2.B_CONTRACT_CODE AND T2.UPDATE_FLAG = 'Y')
      WHEN MATCHED THEN
        UPDATE
           SET T1.B_NAME             = T2.B_NAME,
               T1.B_ID_TYPE          = T2.B_ID_TYPE,
               T1.B_ID_NUM           = T2.B_ID_NUM,
               T1.B_CONTRACT_NO      = T2.B_CONTRACT_NO,
               T1.D_CREDIT_LIM_TYPE  = T2.D_CREDIT_LIM_TYPE,
               T1.D_LIM_LOOP_FLG     = T2.D_LIM_LOOP_FLG,
               T1.D_CREDIT_LIM       = T2.D_CREDIT_LIM,
               T1.D_CREDIT_LIM_LCY   = T2.D_CREDIT_LIM_LCY,
               T1.D_CY               = T2.D_CY,
               T1.D_CON_EFF_DATE     = T2.D_CON_EFF_DATE,
               T1.D_CON_EXP_DATE     = T2.D_CON_EXP_DATE,
               T1.D_CON_STATUS       = T2.D_CON_STATUS,
               T1.D_CREDIT_REST      = T2.D_CREDIT_REST,
               T1.D_CREDIT_REST_LCY  = T2.D_CREDIT_REST_LCY,
               T1.D_CREDIT_REST_CODE = T2.D_CREDIT_REST_CODE,
               T1.DATA_STATUS        = '00',
               T1.DATA_CHG_USER      = 'SYSTEM',
               T1.DATA_CHG_DATE      = CURRENTDATE,
               T1.DATA_CHG_TIME      = CURRENTTIME,
               T1.B_RPT_DATE         = V_DATE,
               T1.B_MNGMT_ORG_CODE   = T2.B_MNGMT_ORG_CODE,
               T1.CHECK_FLAG       = 'N';
      --------------------修改数据--------------------
      --------------------新增数据开始--------------------
      BEGIN
        MERGE INTO MBT_220 T1
        USING (SELECT A.*, '10' AS B_RPT_DATE_CODE, '11|0' AS IS_RPT
                 FROM ODS_MBT_220 A) T2
        ON (T1.B_CONTRACT_CODE = T2.B_CONTRACT_CODE)
        WHEN NOT MATCHED THEN
          INSERT
            (T1.DATA_ID,
             T1.DATA_DATE,
             T1.CORP_ID,
             T1.ORG_ID,
             T1.GROUP_ID,
             T1.INQ_ORG_ID,
             T1.INQ_GROUP_ID,
             T1.B_INF_REC_TYPE,
             T1.B_CONTRACT_CODE,
             T1.B_RPT_DATE,
             T1.B_RPT_DATE_CODE,
             T1.B_NAME,
             T1.B_ID_TYPE,
             T1.B_ID_NUM,
             T1.B_MNGMT_ORG_CODE,
             T1.B_CONTRACT_NO,
             T1.D_CREDIT_LIM_TYPE,
             T1.D_LIM_LOOP_FLG,
             T1.D_CREDIT_LIM,
             T1.D_CREDIT_LIM_LCY,
             T1.D_CY,
             T1.D_CON_EFF_DATE,
             T1.D_CON_EXP_DATE,
             T1.D_CON_STATUS,
             T1.D_CREDIT_REST,
             T1.D_CREDIT_REST_LCY,
             T1.D_CREDIT_REST_CODE,
             T1.DATA_STATUS,
             T1.DATA_SOURCE,
             T1.DATA_CRT_USER,
             T1.DATA_CRT_DATE,
             T1.DATA_CRT_TIME,
             T1.RSV1,
             T1.RSV2,
             T1.RSV3,
             T1.RSV4,
             T1.RSV5,
             T1.CUST_NO,
             T1.IS_RPT)
          VALUES
            (T2.DATA_ID,
             T2.DATA_DATE,
             T2.CORP_ID,
             T2.ORG_ID,
             T2.GROUP_ID,
             T2.ORG_ID,
             T2.ORG_ID,
             '220',
             T2.B_CONTRACT_CODE,
             V_DATE,
             T2.B_RPT_DATE_CODE,
             T2.B_NAME,
             T2.B_ID_TYPE,
             T2.B_ID_NUM,
             T2.B_MNGMT_ORG_CODE,
             T2.B_CONTRACT_NO,
             T2.D_CREDIT_LIM_TYPE,
             T2.D_LIM_LOOP_FLG,
             T2.D_CREDIT_LIM,
             T2.D_CREDIT_LIM_LCY,
             T2.D_CY,
             T2.D_CON_EFF_DATE,
             T2.D_CON_EXP_DATE,
             T2.D_CON_STATUS,
             T2.D_CREDIT_REST,
             T2.D_CREDIT_REST_LCY,
             T2.D_CREDIT_REST_CODE,
             '00',
             '2',
             'SYSTEM',
             CURRENTDATE,
             CURRENTTIME,
             T2.RSV1,
             T2.RSV2,
             T2.RSV3,
             T2.RSV4,
             T2.RSV5,
             T2.CUST_NO,
             T2.IS_RPT);
        --------------------新增结束--------------------
        --------------------修改子表[MBT_220_C]数据开始--------------------
        -- 先删除所有相关数据 然后重新插入
        DELETE FROM MBT_220_C
         WHERE B_CONTRACT_CODE IN
               (SELECT DISTINCT B_CONTRACT_CODE FROM ODS_MBT_220);
        --------------------新增数据开始--------------------
        MERGE INTO MBT_220_C T1
        USING (SELECT A.DATA_ID,
                      A.DATA_DATE,
                      A.C_BRER_TYPE,
                      A.C_CERT_REL_NAME,
                      A.C_CERT_REL_ID_TYPE,
                      A.C_CERT_REL_ID_NUM,
                      A.RSV1,
                      A.RSV2,
                      A.RSV3,
                      A.RSV4,
                      A.RSV5,
                      A.B_CONTRACT_CODE,
                      CASE
                        WHEN B.DATA_ID IS NULL THEN
                         A.PDATA_ID
                        ELSE
                         B.DATA_ID
                      END AS PDATA_ID
                 FROM ODS_MBT_220_C A
                 LEFT JOIN MBT_220 B
                   ON A.B_CONTRACT_CODE = B.B_CONTRACT_CODE) T2
        ON (T1.C_CERT_REL_ID_TYPE = T2.C_CERT_REL_ID_TYPE
        AND T1.C_CERT_REL_ID_NUM = T2.C_CERT_REL_ID_NUM
        AND T1.B_CONTRACT_CODE = T2.B_CONTRACT_CODE)
        WHEN NOT MATCHED THEN
          INSERT
            (T1.DATA_ID,
             T1.PDATA_ID,
             T1.DATA_DATE,
             T1.C_BRER_TYPE,
             T1.C_CERT_REL_NAME,
             T1.C_CERT_REL_ID_TYPE,
             T1.C_CERT_REL_ID_NUM,
             T1.DATA_SOURE,
             T1.DATA_CRT_USER,
             T1.DATA_CRT_DATE,
             T1.DATA_CRT_TIME,
             T1.RSV1,
             T1.RSV2,
             T1.RSV3,
             T1.RSV4,
             T1.RSV5,
             T1.B_CONTRACT_CODE)
          VALUES
            (T2.DATA_ID,
             T2.PDATA_ID,
             T2.DATA_DATE,
             T2.C_BRER_TYPE,
             T2.C_CERT_REL_NAME,
             T2.C_CERT_REL_ID_TYPE,
             T2.C_CERT_REL_ID_NUM,
             '2',
             'SYSEM',
             CURRENTDATE,
             CURRENTTIME,
             T2.RSV1,
             T2.RSV2,
             T2.RSV3,
             T2.RSV4,
             'FLAG',
             T2.B_CONTRACT_CODE);

        --更改主表数据状态
        MERGE INTO MBT_220 T1
        USING (SELECT DISTINCT B.DATA_ID
                 FROM MBT_220_C A
                 LEFT JOIN MBT_220 B
                   ON A.PDATA_ID = B.DATA_ID
                WHERE A.RSV5 = 'FLAG') T2
        ON (T1.DATA_ID = T2.DATA_ID)
        WHEN MATCHED THEN
          UPDATE SET T1.DATA_STATUS = '00';

        UPDATE MBT_220_C SET RSV5 = NULL WHERE RSV5 = 'FLAG';
        --------------------修改子表[MBT_220_C]数据结束--------------------

        --------------------修改报告时点--------------------
        MERGE INTO MBT_220 T1
        USING (SELECT DISTINCT A.DATA_ID,
                               CASE
              --没有上报过且额度状态不为2-到期/失效  --- 10
               WHEN B.DATA_ID IS NULL and A.D_CON_STATUS <> '2' THEN
                '10'
        --已经上报过记录且没上报过20-授信到期/失效且额度状态为2-到期/失效
               WHEN B.DATA_ID IS NOT NULL and A.D_CON_STATUS = '2' AND nvl(C.CNT,0)=0 THEN
                '20'
         --已经上报过记录且没上报过20-授信到期/失效且当前的授信额度与上次上报成功的授信额度相比有调整
               WHEN B.DATA_ID IS NOT NULL and A.D_CREDIT_LIM <> B.D_CREDIT_LIM AND nvl(C.CNT,0)=0 THEN
                '30'
         --其他情况均为99
               ELSE
                '99'
             END AS NEW_B_RPT_DATE_CODE
                 FROM MBT_220 A
                 LEFT JOIN (SELECT *
                             FROM (SELECT ROW_NUMBER() OVER(PARTITION BY B_CONTRACT_CODE ORDER BY RPT_TIME DESC) RN,
                                          T.*
                                     FROM MBT_220_RPT T
                                    WHERE DATA_STATUS = '27')
                            WHERE RN = 1) B
                   ON A.B_CONTRACT_CODE = B.B_CONTRACT_CODE
                   left join (select count(1) cnt,B_CONTRACT_CODE from MBT_220_RPT  WHERE DATA_STATUS = '27' and B_RPT_DATE_CODE='20' GROUP BY B_CONTRACT_CODE) C
    ON A.B_CONTRACT_CODE = C.B_CONTRACT_CODE ) T2
        ON (T1.DATA_ID = T2.DATA_ID)
        WHEN MATCHED THEN
          UPDATE SET T1.B_RPT_DATE_CODE = T2.NEW_B_RPT_DATE_CODE;
        --------------------修改报告时点--------------------
        --------------------分段更新IS_RPT开始--------------------
        SP_ODS_MBT_CAL_RPT_PROC('MBT_220',
                                'T.B_CONTRACT_CODE',
                                'T1.B_CONTRACT_CODE=T2.B_CONTRACT_CODE',
                                B_ARRAYLIST,
                                1,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                  AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                NULL);
        SP_ODS_MBT_CAL_RPT_PROC('MBT_220',
                                'T.B_CONTRACT_CODE',
                                'T1.B_CONTRACT_CODE=T2.B_CONTRACT_CODE',
                                D_ARRAYLIST,
                                2,
                                null,
                                'T1.B_INF_REC_TYPE = T3.INF_REC_TYPE
                    AND T3.ACCT_TYPE IS NULL
                  AND T1.B_RPT_DATE_CODE = T3.RPT_DATE_CODE',
                                NULL);
        --子表
        SP_ODS_MBT_CAL_RPT_PROC('MBT_220_C',
                                'T.C_CERT_REL_ID_TYPE,T.C_CERT_REL_ID_NUM,T.B_CONTRACT_CODE',
                                'T1.B_CONTRACT_CODE = T2.B_CONTRACT_CODE AND T1.C_CERT_REL_ID_TYPE=T2.C_CERT_REL_ID_TYPE AND T1.C_CERT_REL_ID_NUM=T2.C_CERT_REL_ID_NUM',
                                C_ARRAYLIST,
                                4,
                                'MBT_220',
                                'T3.B_INF_REC_TYPE = T4.INF_REC_TYPE
                    AND T4.ACCT_TYPE IS NULL
                  AND T3.B_RPT_DATE_CODE = T4.RPT_DATE_CODE',
                                NULL);
        --------------------分段更新IS_RPT结束--------------------
        --数据插入历史表，然后删除ODS表
        INSERT INTO ODS_MBT_220_HIS
          SELECT * FROM ODS_MBT_220;
        DELETE FROM ODS_MBT_220;
        INSERT INTO ODS_MBT_220_C_HIS
          SELECT * FROM ODS_MBT_220_C;
        DELETE FROM ODS_MBT_220_C;
        --数据插入历史表，然后删除ODS表

        --将报告时点代码是88或99的直接审核通过并将校验修改为校验通过
        UPDATE mbt_220
           SET DATA_STATUS = '21', CHECK_FLAG = 'Y'
         WHERE DATA_DATE <= CURRENTDATE
           AND (B_RPT_DATE_CODE = '88' OR B_RPT_DATE_CODE = '99')
           AND DATA_STATUS = '00';

             --将报告时点代码不是88或99的将校验修改为未校验ZHAO
      /*  UPDATE mbt_220
           SET CHECK_FLAG = 'N'
         WHERE DATA_DATE <= CURRENTDATE
           AND (B_RPT_DATE_CODE  NOT IN('88' ,'99'))
           AND DATA_STATUS = '00';*/
      EXCEPTION
        WHEN OTHERS THEN
          ERRCODE := SQLCODE;
          ERRMSG  := SUBSTR(SQLERRM, 1, 200);
          SP_MBT_LOG(1,
                     'SP_ODS_MBT_220',
                     'ERROR22001',
                     'SP_ODS_MBT_220失败：' || ERRMSG,
                     ERRCODE,
                     ERRMSG);
          ROLLBACK;
          RETURN;
      END;
      COMMIT;
    END;
  END IF;
  ENDTIME := TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS');
  DSC     := '##=======MBT220存储过程==结束' || ENDTIME || '========##';
  DBMS_OUTPUT.PUT_LINE(DSC);
END;

