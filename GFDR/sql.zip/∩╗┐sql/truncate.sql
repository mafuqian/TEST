truncate table PM_RMS_TASK;
truncate table PM_RMS_SUB_TASK;
truncate table PM_RMS_GROUP;
truncate table PM_RMS_GROUP_USER;
truncate table PM_RMS_TASK_FILE;
truncate table PM_RMS_TASK_LOG;

truncate table RTMS_PUBLISH_FEEDBACK;
truncate table TM_RTMS_OP;
truncate table TM_RTMS_OPG;
truncate table TM_RTMS_OPG_BIND;
truncate table TM_RTMS_OP_DEP;
truncate table PM_RTMS_ALERT_RULE;
truncate table PM_RTMS_OP;
truncate table PM_RTMS_OP_DEP;
truncate table PM_RTMS_OPG;
truncate table PM_RTMS_OPG_BIND;
truncate table PM_RTMS_RPT;
truncate table RTMS_PUBLISH;
truncate table TM_RTMS_RPT;
truncate table TM_RTMS_RPT_BIND;
truncate table PM_RTMS_RPT_BIND;
truncate table PM_RTMS_TASK;
truncate table PM_RTMS_ALERT_MSG;
truncate table RTMS_PUBLISH_TOPIC_POST;
truncate table RTMS_PUBLISH_TOPIC;
truncate table TM_RTMS_TASK;
truncate table TM_RTMS_ALERT;
truncate table TM_RTMS_ALERT_RULE;
truncate table PM_RTMS_ALERT;
truncate table RTMS_ALERT_RULE;
truncate table RTMS_OP;
truncate table RTMS_ALERT_MSG_USER_REL;
truncate table RTMS_TASK_LOG;
truncate table RTMS_TASK;
truncate table RTMS_RPT_USER_REL;
truncate table RTMS_RPT_ORG_REL;
truncate table RTMS_RPT_OP_GROUP_REL;
truncate table RTMS_OP_GROUP_REL;
truncate table RTMS_OP_GROUP;
truncate table RTMS_ALERT_LOG;
truncate table RTMS_RPT;
truncate table RTMS_OP_ALERT_RULE_REL;


truncate table GP_BM_BIZ_LOG;
truncate table GP_BM_AUDIT_LOG;
truncate table GP_BM_BMS_CTL_LOG;
truncate table GP_BM_TEMPLATE_EXPORT;
truncate table GP_BM_USER_TAB_COLS;
truncate table GP_BM_TLR_INFO;



INSERT INTO `GP_BM_TLR_INFO` VALUES ('0b641c95cc854a18ad9c08c73f5de37c', '20161102', 'GINGKOO', '9999', 'XD', 'admin', '系统管理员', NULL, NULL, '$2a$10$LndR3LxyfLrCUKZjlgfM7ut25L2neQqoNwYo/FxRgIWuboawkgk9e', 'bcrypt', NULL, '9999', '9999', NULL, '0:0:0:0:0:0:0:1', '0', '4', '0', NULL, '20210218172236', '20210218105115', '20210122141256', 0.000000000000000000000000000000, 0.000000000000000000000000000000, NULL, NULL, NULL, NULL, '20200610181538', 'C4F9A603B42FEE45C79CFD99B78E2FF2', NULL, '1', '20160906', 'admin1', '20210218172237', NULL, NULL, 'my_lishuo@163.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '99', '04', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, 'admin1', '20191128', '20191128104234', 'admin', '20191128', '20191128104304', '20191216114615', '0', NULL, NULL, 'lpsCkj5VgWkM0iJwNweANA', NULL, '21');


