

#export JAVA_OPTS="$JAVA_OPTS -Dspring.profiles.active=customized -Dnucc.env=xuh"
#export JAVA_OPTS="$JAVA_OPTS -Dspring.profiles.active=product -Dnucc.env=xuh"
#export CATALINA_OPTS="$CATALINA_OPTS -Dorg.apache.catalina.STRICT_SERVLET_COMPLIANCE=true"
#export CLASSPATH=$CLASSPATH:/Users/freedomsky/Documents/epcc_var

export JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk1.8.0_261.jdk/Contents/Home

export JRE_HOME=/Library/Java/JavaVirtualMachines/jdk1.8.0_261.jdk/Contents/Home/jre
#export JAVA_OPTS="$JAVA_OPTS -Denv=dev"
#export JAVA_OPTS="$JAVA_OPTS -Dspring.profiles.active=customized -Dnucc.env=dev"
export JAVA_OPTS="$JAVA_OPTS -Denv=dev"
#CLASSPATH=$CLASSPATH:/gnucc/epcc_var/epcc

