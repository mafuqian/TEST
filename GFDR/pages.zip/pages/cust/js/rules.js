var isDigit = "\d+";
var isletterAndNumber = "^[A-Za-z0-9]+$";//字母数字。
var isNotSpecial="^[^%\"\'\\\\/\?]+$";//非特殊字符。
