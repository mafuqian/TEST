truncate table gp_bm_jm;
truncate table gp_bm_jm_batch;
truncate table gp_bm_jm_batch_dtl;
truncate table gp_bm_jm_etl;
truncate table gp_bm_jm_etl_dtl;
truncate table gp_bm_jm_log;
truncate table gp_bm_jm_log_dtl;
truncate table gp_bm_jm_rpt_task;

truncate table pm_rms_task;
truncate table pm_rms_sub_task;
truncate table pm_rms_task_file;
truncate table pm_rms_task_log;

truncate table PM_RTMS_ALERT_MSG;
truncate table PM_RTMS_ALERT_RULE;
truncate table pm_rtms_rpt;
truncate table pm_rtms_rpt_bind;
truncate table PM_RTMS_TASK;
truncate table rtms_publish;
truncate table rtms_publish_feedback;

truncate table tm_rtms_alert;
truncate table tm_rtms_task;
truncate table tm_rtms_rpt_bind;
truncate table tm_rtms_rpt;
truncate table tm_rtms_opg_bind;
truncate table tm_rtms_opg;
truncate table tm_rtms_op_dep;
truncate table tm_rtms_op;
truncate table tm_rtms_alert_rule;



truncate table GP_BM_FILE_EXPORT_TSK_INF;
truncate table gp_bm_gno_q;
truncate table gp_bm_login_log;
truncate table GP_BM_BIZ_LOG;